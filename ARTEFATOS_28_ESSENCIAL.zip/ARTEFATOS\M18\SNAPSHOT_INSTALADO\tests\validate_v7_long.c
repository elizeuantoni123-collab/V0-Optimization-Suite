#include <stdint.h>
#include <stdio.h>
typedef struct { uint32_t id,score,key,valid; } rec;
extern uint32_t v0_semantic_id_safe(const rec*);
extern uint32_t v0_semantic_key_safe(const rec*);
extern uint64_t v0_semantic_id_key64_safe(const rec*);
static uint64_t s=0xd1b54a32d192ed03ULL;
static uint64_t rnd(void){s^=s>>12;s^=s<<25;s^=s>>27;return s*2685821657736338717ULL;}
static uint64_t ref(const rec*p){return (uint64_t)v0_semantic_id_safe(p)|((uint64_t)v0_semantic_key_safe(p)<<32);}
int main(void){
 uint64_t bad=0,checks=0;
 const uint32_t E[]={0,1,0xffffffffu,0x80000000u,0x7fffffffu,0x12345678u};
 for(unsigned a=0;a<6;a++)for(unsigned k=0;k<6;k++)for(unsigned v=0;v<2;v++){rec r={E[a],0xa5a5a5a5u,E[k],v};uint64_t x=ref(&r),y=v0_semantic_id_key64_safe(&r);checks++;bad+=(x!=y);}
 for(uint64_t i=0;i<20000000ULL;i++){rec r={(uint32_t)rnd(),(uint32_t)rnd(),(uint32_t)rnd(),(uint32_t)(rnd()&1u)};uint64_t x=ref(&r),y=v0_semantic_id_key64_safe(&r);checks++;bad+=(x!=y);}
 printf("checks=%llu bad=%llu\n",(unsigned long long)checks,(unsigned long long)bad);return bad?2:0;
}

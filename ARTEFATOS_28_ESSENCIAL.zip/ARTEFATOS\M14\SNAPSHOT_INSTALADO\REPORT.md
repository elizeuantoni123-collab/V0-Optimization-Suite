# Artefato 14 — Compression V10 SAFE — relatório de squeeze

## Baseline
`V0_COMPRESSION_V0L_V10_SAFE_PROMOTED` permanece promovida e intacta.

## Tentativa 1 — emissão RLE V12 4x unrolled
A validação AVX2 V10 foi preservada e a emissão de pares foi desenrolada em grupos maiores.

Correção: 500.896 casos / 4.007.168 checks, 0 divergências.

Desempenho: não robusto. Em 40 cenários (zero/uniforme, 4–64 KiB, múltiplos alinhamentos), a mediana geral ficou praticamente empatada (~1.007x), com várias regressões. **REJEITADO**.

## Tentativa 2 — decoder canônico V12
Criado fast path aditivo para streams RLE que foram produzidos pelos próprios compressores V0: todos os pares completos são `{255,value}` e existe no máximo um par final parcial.

O decoder universal V2/V3 não foi removido.

### Correção
- 500.024 casos gerados pelos compressores V10;
- 4.500.216 checks;
- expected_len, corrupção de pares e conteúdo final verificados;
- 0 divergências no domínio canônico.

### Screening V0L SSE2
Em blocos grandes, a mediana ficou geralmente em ~1.24x–1.30x contra V2/V3. Porém o gate longo ainda encontrou regressões isoladas por alinhamento/rodada.

Exemplos do gate longo (15 processos por alinhamento):
- uniforme 16 KiB: mediana agregada ~1.276x, 58/60 vitórias, mínimo 0.899x;
- uniforme 32 KiB: ~1.268x, 57/60, mínimo 0.536x;
- uniforme 64 KiB: ~1.298x, 59/60, mínimo 0.904x;
- zero 16 KiB: ~1.260x, 57/60, mínimo 0.369x;
- zero 32 KiB: ~1.263x, 56/60, mínimo 0.849x;
- zero 64 KiB: ~1.296x, 59/60, mínimo 0.894x.

## Decisão
**KEEP_BASELINE — V10 SAFE**.

O candidato V12 é preservado apenas como experimento/referência. Não deve entrar no dispatcher nem ser promovido.

Motivo: pela regra permanente do projeto, mediana positiva não compensa regressão em um domínio declarado. A V10 já possui dispatch muito maduro e continua sendo a opção correta.

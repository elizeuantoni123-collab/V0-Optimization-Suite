#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
./TEST_ACCEL_LINUX.sh
./BUILD_V19_LINUX.sh
gcc -O3 -march=native -Iinclude tests/test_v19.c \
  build/linux/v0_batch_plan64_avx2_v14.o \
  build/linux/v0_batch_plan64_avx2_dual_v19.o \
  -o tests/test_v19
./tests/test_v19

Artefato 23: baseline M03 preserved; V7 is an additive exact-256B AVX2 candidate. See REPORT.md.

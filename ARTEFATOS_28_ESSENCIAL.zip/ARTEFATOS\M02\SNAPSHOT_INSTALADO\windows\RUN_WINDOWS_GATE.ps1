$ErrorActionPreference='Stop'
$root = Split-Path -Parent $PSScriptRoot
$zip = Get-ChildItem "$root\baseline\*.zip" | Select-Object -First 1
$ext = "$root\baseline_extracted"
if(Test-Path $ext){Remove-Item $ext -Recurse -Force}
Expand-Archive $zip.FullName $ext -Force
$sub = Get-ChildItem $ext -Directory | Select-Object -First 1
if($sub){ Get-ChildItem $sub.FullName -Force | Move-Item -Destination $ext -Force; Remove-Item $sub.FullName -Recurse -Force }
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$cl = $null
if(Test-Path 'C:\BuildTools\VC\Auxiliary\Build\vcvars64.bat'){ $vcvars='C:\BuildTools\VC\Auxiliary\Build\vcvars64.bat' }
elseif(Test-Path $vswhere){$inst=& $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath; $vcvars=Join-Path $inst 'VC\Auxiliary\Build\vcvars64.bat'}
else{throw 'MSVC Build Tools not found'}
$src=Join-Path $PSScriptRoot 'benchmark_v13_windows.c'
cmd /c "`"$vcvars`" && cl /nologo /O2 /arch:AVX2 /DVARIANT=0 /Fe:`"$PSScriptRoot\base.exe`" `"$src`"" | Out-Host
cmd /c "`"$vcvars`" && cl /nologo /O2 /arch:AVX2 /DVARIANT=1 /Fe:`"$PSScriptRoot\cand.exe`" `"$src`"" | Out-Host
$scenarios=@(@('pin0_rand',0,-1),@('pin1_rand',1,-1),@('pin10_rand',10,-1),@('pin50_rand',50,-1),@('pin100_rand',100,-1),@('pin0_t0',0,0),@('pin0_t1',0,1),@('pin0_t2',0,2),@('pin10_t2',10,2))
$res=@()
foreach($s in $scenarios){$b=@();$c=@();1..11|%{$b += [double](& "$PSScriptRoot\base.exe" $s[1] $s[2])};1..11|%{$c += [double](& "$PSScriptRoot\cand.exe" $s[1] $s[2])};$bs=($b|Sort-Object)[5];$cs=($c|Sort-Object)[5];$res += [pscustomobject]@{Scenario=$s[0];Baseline_ns=$bs;Candidate_ns=$cs;Speedup=$bs/$cs;CandidateWins=(($c|?{$_ -lt $bs}).Count)}}
$res | Format-Table -AutoSize
$res | ConvertTo-Json -Depth 4 | Set-Content "$PSScriptRoot\V13_WINDOWS_RESULT.json" -Encoding UTF8
Write-Host 'No installation/promotion was performed.'

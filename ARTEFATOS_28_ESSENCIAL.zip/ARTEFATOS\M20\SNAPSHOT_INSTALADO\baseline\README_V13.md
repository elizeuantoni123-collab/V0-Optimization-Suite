# V0 Module Manager V13 SAFE

Baseline promovida do M19 em V0L. V13 é um **superset aditivo e não regressivo da V8 SAFE**.

## Regra permanente

Uma versão posterior só pode ser promovida se simultaneamente:

- não quebrar compatibilidade/funcionamento;
- preservar correção/qualidade exata;
- não perder velocidade/desempenho no domínio declarado.

Qualquer candidato regressivo é descartado.

## Estado

```c
uint32_t enabled_mask;
```

4 bytes para M01..M18 + M20. M19 é o próprio Module Manager e não recebe bit.

## ABI promovida

Herdada e byte-preservada da V8:

```c
v0_mm_get
v0_mm_enabled       // ANY bit
v0_mm_enable
v0_mm_disable
v0_mm_set
v0_mm_apply
```

Novas consultas V13:

```c
v0_mm_all_enabled   // TODOS os bits pedidos estão ON
v0_mm_none_enabled  // NENHUM bit pedido está ON
v0_mm_exact         // estado == máscara esperada
v0_mm_matches       // required_on ON e required_off OFF
```

`v0_mm_matches` permite testar uma configuração A+B+C em uma única chamada, incluindo requisitos ON/OFF.

## Correção

- regressão herdada: 13.461.408 checks, 0 erros;
- apply: 20.000.024 checks, 0 erros;
- novas consultas: 59.845.988 checks, 0 erros;
- total funcional: **93.307.420 checks, 0 erros**;
- concorrência, 5 execuções: **8.310.090 leituras, 0 estados intermediários inválidos**.

## Performance V13

Objeto V0L final, 5 processos independentes, 80 comparações:

- **80/80 vitórias**;
- ganho mínimo: **1,447991x**;
- mediana global: **1,839303x**;
- máximo: **2,477167x**.

Por operação:

- `all_enabled`: mínimo 1,495692x; mediana 1,813628x;
- `none_enabled`: mínimo 1,659131x; mediana 1,830802x;
- `exact`: mínimo 1,447991x; mediana 1,663751x;
- `matches`: mínimo 2,224731x; mediana 2,352368x.

## Tamanho

- Linux: **163 B `.text`**, 10 funções, 0 `.rodata`, 0 relocations;
- Windows: **180 B `.text`**, 10 funções, 0 `.rodata`, 0 relocations.

Os primeiros 94 B Linux e 97 B Windows são o prefixo V8 byte-idêntico.

## Escopo

O V0 Global permanece separado e intocado. Este pacote não altera driver, EPT, hypervisor, serviço ou autostart.

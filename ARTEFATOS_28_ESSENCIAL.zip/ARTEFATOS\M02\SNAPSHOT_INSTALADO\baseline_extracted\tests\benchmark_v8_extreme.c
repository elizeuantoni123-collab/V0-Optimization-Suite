#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_fast.h"
#include "../include/v0_decision_v8_extreme.h"

#define N (1u<<20)
#define REPS 11
static int32_t *score32;
static int16_t *q16;
static uint8_t *out8;
static volatile uint64_t sink;
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+(uint64_t)x.tv_nsec;}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static void pin0(void){cpu_set_t c;CPU_ZERO(&c);CPU_SET(0,&c);(void)sched_setaffinity(0,sizeof(c),&c);}

static double native_score_dec(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_decide_v0l_v8_fast((uint32_t)score32[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double native_q6_dec(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_decide_v0l_v8_q6((uint32_t)(int32_t)q16[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double native_score_eval(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v0l_v8_fast((uint32_t)score32[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double native_q6_eval(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v0l_v8_q6((uint32_t)(int32_t)q16[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double inline_q6_eval_scalar(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_q6_extreme_inline(q16[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double inline_score_eval_scalar(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_inline(score32[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double batch_scalar_q6(void){uint64_t t=now_ns();v0_eval_v8_q6_batch_scalar_u8(q16,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double batch_sse2_q6(void){uint64_t t=now_ns();v0_eval_v8_q6_batch_sse2_u8(q16,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
static double batch_avx2_q6(void){uint64_t t=now_ns();v0_eval_v8_q6_batch_avx2_u8(q16,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double batch_avx2_score(void){uint64_t t=now_ns();v0_eval_v8_score_batch_avx2_u8(score32,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double preflight_count_avx2(void){uint64_t t=now_ns();uint64_t c=v0_preflight_v8_q6_count_avx2(q16,N);uint64_t e=now_ns();sink+=c;return(double)(e-t)/N;}
#endif
static void bench(const char*n,double(*fn)(void)){double v[REPS];for(int i=0;i<3;i++)(void)fn();for(int i=0;i<REPS;i++)v[i]=fn();qsort(v,REPS,sizeof(double),cmpd);printf("%-25s p50=%8.4f ns/decision best=%8.4f\n",n,v[REPS/2],v[0]);}
int main(void){pin0();score32=aligned_alloc(64,N*4);q16=aligned_alloc(64,N*2);out8=aligned_alloc(64,N);if(!score32||!q16||!out8)return 2;uint64_t st=0x9e3779b97f4a7c15ULL;static const int32_t bias[6]={0,64,192,33151,33215,33343};for(uint32_t i=0;i<N;i++){uint16_t v=(uint16_t)rng64(&st),c=(uint16_t)rng64(&st);uint8_t te=(uint8_t)(rng64(&st)%3u),p=(uint8_t)(rng64(&st)&1u);score32[i]=(int32_t)v-(int32_t)(c>>1)+bias[te+3u*p];q16[i]=(int16_t)(score32[i]>>6);}bench("native score decision",native_score_dec);bench("native Q6 decision",native_q6_dec);bench("native score fused",native_score_eval);bench("native Q6 fused",native_q6_eval);bench("inline score fused scalar",inline_score_eval_scalar);bench("inline Q6 fused scalar",inline_q6_eval_scalar);bench("batch Q6 scalar u8",batch_scalar_q6);bench("batch Q6 SSE2 u8",batch_sse2_q6);
#if defined(__AVX2__) || defined(_M_AVX2)
bench("batch score AVX2 u8",batch_avx2_score);bench("batch Q6 AVX2 u8",batch_avx2_q6);bench("preflight Q6 AVX2 mask",preflight_count_avx2);
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

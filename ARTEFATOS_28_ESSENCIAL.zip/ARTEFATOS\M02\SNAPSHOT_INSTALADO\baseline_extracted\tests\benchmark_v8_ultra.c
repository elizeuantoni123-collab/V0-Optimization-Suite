#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_fast.h"
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<20)
#define REPS 15
static int16_t *q16; static uint8_t *out8,*e3; static volatile uint64_t sink;
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+(uint64_t)x.tv_nsec;}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static void pin0(void){cpu_set_t c;CPU_ZERO(&c);CPU_SET(0,&c);(void)sched_setaffinity(0,sizeof(c),&c);}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double scalar_v5(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_q6_extreme_inline(q16[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double scalar_v6(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_q6_hot_lut_inline(q16[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double cached_e3_read(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=e3[i];uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
static double batch_v5(void){uint64_t t=now_ns();v0_eval_v8_q6_batch_avx2_u8(q16,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double batch_v6(void){uint64_t t=now_ns();v0_eval_v8_q6_batch_ultra_avx2_u8(q16,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double pre_v5(void){uint64_t t=now_ns();uint64_t c=v0_preflight_v8_q6_count_avx2(q16,N);uint64_t e=now_ns();sink+=c;return(double)(e-t)/N;}
static double pre_v6(void){uint64_t t=now_ns();uint64_t c=v0_preflight_v8_q6_count_ultra_avx2(q16,N);uint64_t e=now_ns();sink+=c;return(double)(e-t)/N;}
#endif
static void bench(const char*n,double(*fn)(void)){double v[REPS];for(int i=0;i<5;i++)(void)fn();for(int i=0;i<REPS;i++)v[i]=fn();qsort(v,REPS,sizeof(double),cmpd);printf("%-26s p50=%8.4f best=%8.4f\n",n,v[REPS/2],v[0]);}
int main(void){pin0();q16=aligned_alloc(64,N*2);out8=aligned_alloc(64,N);e3=aligned_alloc(64,N);if(!q16||!out8||!e3)return 2;uint64_t st=0x9e3779b97f4a7c15ULL;for(uint32_t i=0;i<N;i++){int32_t sc=(int32_t)(rng64(&st)%131646u)-32767;q16[i]=(int16_t)(sc>>6);e3[i]=(uint8_t)v0_eval_v8_q6_hot_lut_inline(q16[i]);}
bench("V5 scalar Q6 fused",scalar_v5);bench("V6 scalar Q6 hot LUT",scalar_v6);bench("V6 cached E3 read",cached_e3_read);
#if defined(__AVX2__) || defined(_M_AVX2)
bench("V5 batch Q6 AVX2",batch_v5);bench("V6 batch Q6 LUT AVX2",batch_v6);bench("V5 preflight count AVX2",pre_v5);bench("V6 preflight count AVX2",pre_v6);
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

# V0 Decision V8 ULTRA V8 — Integration

V8 is additive. Include `include/v0_decision_v8_ultra_v8.h` for the normal V8 paths. Include `include/v0_decision_v8_bandwidth_v8.h` only when the optional `meta8` bandwidth representation is desired.

Recommended routing:

1. If raw `value/cost/temperature/pinned` is the only available representation, use the V8 raw AVX2/AVX-512 path.
2. If legal V7 `bias16` is already available, use the V8 bias-fused path; this is the fastest normal hot-cache route measured.
3. If data already exists as `v0_decision_signal_v7_t[]`, use the direct V8 AoS path; do not transpose solely to reach SoA unless profiling proves it wins end-to-end.
4. For execute/drop only, use the specialized V8 preflight path.
5. For large write-only outputs, nibble streaming can reduce store traffic. The representation is exactly reversible.
6. `meta8` is optional and must not replace bias16 automatically. It reduced bandwidth on the measured large AVX-512 workload but can be slower in hot-cache/AVX2 cases.

All V7/V6 APIs remain available. No controller thresholds or policy were changed.

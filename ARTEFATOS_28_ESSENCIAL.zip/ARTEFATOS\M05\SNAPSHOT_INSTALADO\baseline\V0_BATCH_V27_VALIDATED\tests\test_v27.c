#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct{uint32_t start,count;} span;
extern uint32_t v0_batch_plan64_avx2_dual_v19(span*,uint32_t);
extern uint32_t v0_batch_plan64_avx2_quadload_v27(span*,uint32_t);
static uint32_t st=0x91a7c53du; static uint32_t xr(){st^=st<<13;st^=st>>17;st^=st<<5;return st;}
int main(){__builtin_cpu_init();if(!__builtin_cpu_supports("avx2")){puts("SKIP no avx2");return 0;} const uint32_t ns[4]={1024,2048,3072,4096}; uint64_t checks=0;
size_t cap=4096/64*8+256; unsigned char*ra=aligned_alloc(64,cap+64),*rb=aligned_alloc(64,cap+64); if(!ra||!rb)return 2;
for(int ni=0;ni<4;ni++){uint32_t n=ns[ni],k=n/64;for(int off=0;off<64;off++){span*a=(span*)(ra+off),*b=(span*)(rb+off);memset(ra,0xA5,cap+64);memset(rb,0x5A,cap+64);uint32_t x=v0_batch_plan64_avx2_dual_v19(a,n),y=v0_batch_plan64_avx2_quadload_v27(b,n);if(x!=k||y!=k||x!=y){fprintf(stderr,"count n=%u off=%d x=%u y=%u\n",n,off,x,y);return 3;}for(uint32_t i=0;i<k;i++){if(a[i].start!=i*64u||a[i].count!=64u||memcmp(&a[i],&b[i],8)){fprintf(stderr,"span n=%u off=%d i=%u\n",n,off,i);return 4;}checks++;}if(rb[off+k*8]!=0x5A){fprintf(stderr,"overwrite n=%u off=%d\n",n,off);return 5;}checks++;}}
for(uint32_t t=0;t<5000000u;t++){uint32_t n=ns[xr()&3u],k=n/64;int off=(int)(xr()&63u);span*a=(span*)(ra+off),*b=(span*)(rb+off);memset(ra+off,0x11,k*8+1);memset(rb+off,0x22,k*8+1);uint32_t x=v0_batch_plan64_avx2_dual_v19(a,n),y=v0_batch_plan64_avx2_quadload_v27(b,n);if(x!=y||y!=k){fprintf(stderr,"rnd count n=%u off=%d\n",n,off);return 6;}if(memcmp(a,b,k*8)){fprintf(stderr,"rnd data n=%u off=%d\n",n,off);return 7;}if(rb[off+k*8]!=0x22){fprintf(stderr,"rnd overwrite n=%u off=%d\n",n,off);return 8;}checks+=(uint64_t)k+1;}
free(ra);free(rb);printf("PASS V27 checks=%llu\n",(unsigned long long)checks);return 0;}

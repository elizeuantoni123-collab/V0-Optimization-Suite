# Dispatch guide

A regra mais conservadora validada neste host é:

```text
if items < 64:
    V6
elif items <= 256:
    V13 small4
elif items < 4096:
    V11
elif cpu_has_avx2_and_os_ymm:
    V14 AVX2
else:
    V11
```

Se o consumidor não precisa de um array físico de spans, testar IMPLICIT64 em paralelo. Com V14 ativo, medir novamente o break-even no workload real; nesta validação 8192+ foi um cutoff conservador para o consumidor sintético usado.

Não executar V14 em CPU sem AVX2: isso pode gerar `#UD`/illegal instruction. O feature gate pertence ao host/integrador.

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/build/linux"
python "$ROOT/compiler/v0lc_batch_avx2_dual_v19.py" \
  "$ROOT/src/v0_batch_plan64_avx2_dual_v19.v0l" \
  "$ROOT/build/linux/v0_batch_plan64_avx2_dual_v19.o"
echo "V19 Linux object rebuilt."

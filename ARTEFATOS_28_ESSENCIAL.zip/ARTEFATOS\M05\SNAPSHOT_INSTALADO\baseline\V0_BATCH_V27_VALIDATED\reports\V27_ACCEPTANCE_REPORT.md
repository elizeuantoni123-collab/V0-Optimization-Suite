# V0 Batch V27 Acceptance Report

Status: **PROMOTED AS OPTIONAL NARROW-DOMAIN AVX2 ACCELERATOR**.

V19 remains the general promoted baseline. V27 does not replace V19 outside its explicitly validated domain.

## Domain

Call `v0_batch_plan64_avx2_quadload_v27` only when all are true:

- AVX2 is available and enabled by the OS;
- `items` is exactly one of: **1024, 2048, 3072, 4096**;
- the caller wants the same materialized `{u32 start, u32 count}` span ABI.

All other inputs continue through the previously promoted V19 / V14 / V11 / IMPLICIT64 policy.

## Implementation

V27 uses four YMM data vectors and emits **16 descriptors per loop iteration**. Initial vectors are loaded directly from V0D data to avoid the dependent vector-derivation chain tested in V25. Production kernel remains V0L compiled directly to x86-64.

Linux object:
- `.text`: 103 bytes
- `.rodata`: 160 bytes
- exported function: `v0_batch_plan64_avx2_quadload_v27`
- undefined external symbols: 0

Windows COFF object is generated from the same V0L source/backend.

## Correctness gate

V27 vs V19:
- exact descriptor sequence compared;
- all 64 byte-offset alignments for all four promoted sizes;
- 5,000,000 randomized selections from the promoted size set;
- count equality;
- sentinel check after the final descriptor.

Result: **205,017,440 checks, 0 divergences**.

Inherited V19 release hashes were rechecked and inherited test suites were rerun without modification.

## Performance gate

Seven independent benchmark processes were run on the validation host (AMD EPYC 9V74 virtualized host, single pinned benchmark CPU). Every promoted size won in every process.

Observed speedup ranges over V19:
- 1024: **1.129x .. 1.206x**
- 2048: **1.236x .. 1.422x**
- 3072: **1.155x .. 1.387x**
- 4096: **1.143x .. 1.241x**

These are microbenchmark results for span materialization on this host, not universal hardware guarantees.

## Rejected candidates in this round

Not promoted because of measured regressions or instability:
- V21 return-path micro-optimization as a continuous domain;
- V22 exact-512 specialization after dense sweep;
- V23 DEC+JNZ exact-512;
- V24 reduced-constant derivation;
- V26 DEC+JNZ quad loop;
- V28 terminal-work elimination.

V25/V27 exploration showed the useful quad-YMM direction; only V27's narrow validated domain is promoted.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <intrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct { uint32_t enabled_mask; } mm_state;
uint32_t v0_mm_matches(mm_state*,uint32_t,uint32_t);
uint32_t v0_mm_matches8_snapshot_v14(mm_state*,const uint32_t*);
static volatile uint64_t sinkv;
static uint64_t rngs=0x123456789abcdef0ull;
static uint64_t rng64(void){uint64_t z=(rngs+=0x9e3779b97f4a7c15ull);z=(z^(z>>30))*0xbf58476d1ce4e5b9ull;z=(z^(z>>27))*0x94d049bb133111ebull;return z^(z>>31);}
static int avx2_ok(void){int r[4];__cpuid(r,1);if(!(r[2]&(1<<27))||!(r[2]&(1<<28)))return 0;if((_xgetbv(0)&6)!=6)return 0;__cpuidex(r,7,0);return !!(r[1]&(1<<5));}
static uint32_t base8(mm_state*s,const uint32_t*q){uint32_t m=0;int i;for(i=0;i<8;i++)m|=v0_mm_matches(s,q[i],q[8+i])<<i;return m;}
static double qpc(void){LARGE_INTEGER x,f;QueryPerformanceCounter(&x);QueryPerformanceFrequency(&f);return (double)x.QuadPart*1e9/(double)f.QuadPart;}
static double bb(mm_state*s,uint32_t*q,int n){double a=qpc();uint64_t x=0;int i;for(i=0;i<n;i++)x+=base8(s,q);a=qpc()-a;sinkv+=x;return a/n;}
static double bc(mm_state*s,uint32_t*q,int n){double a=qpc();uint64_t x=0;int i;for(i=0;i<n;i++)x+=v0_mm_matches8_snapshot_v14(s,q);a=qpc()-a;sinkv+=x;return a/n;}
int main(int argc,char**argv){
 static const int aligns[4]={0,4,16,28}; int p,ai,i,r,w; uint64_t k;
 if(!avx2_ok()){puts("FAIL: AVX2/OS YMM unavailable");return 2;}
 {int cpu=argc>1?atoi(argv[1]):0;DWORD_PTR mask=((DWORD_PTR)1)<<cpu;if(!SetThreadAffinityMask(GetCurrentThread(),mask))printf("WARN affinity cpu=%d failed err=%lu\n",cpu,GetLastError());}
 {uint8_t *mem=(uint8_t*)_aligned_malloc(256,64);uint64_t div=0;if(!mem)return 3;
  for(k=0;k<1000000ull;k++){int off=(int)((rng64()&7)*4);uint32_t*q=(uint32_t*)(mem+off);mm_state s={(uint32_t)rng64()};for(i=0;i<16;i++)q[i]=(uint32_t)rng64();if(base8(&s,q)!=v0_mm_matches8_snapshot_v14(&s,q))div++;}
  printf("parity_batches=1000000 predicates=8000000 divergences=%llu\n",(unsigned long long)div);if(div){_aligned_free(mem);return 4;}
  puts("profile,align,round,base_ns,cand_ns,speedup");{int wins=0,total=0;double worst=1e9;
   for(p=0;p<5;p++)for(ai=0;ai<4;ai++){int off=aligns[ai];uint32_t*q=(uint32_t*)(mem+off);mm_state s={(uint32_t)rng64()};for(i=0;i<8;i++){if(p==0){q[i]=1u<<(i%19);q[8+i]=0;}else if(p==1){q[i]=s.enabled_mask&(uint32_t)rng64();q[8+i]=~s.enabled_mask&(uint32_t)rng64();}else{q[i]=(uint32_t)rng64();q[8+i]=(uint32_t)rng64();}}
    for(w=0;w<3;w++){bb(&s,q,10000);bc(&s,q,10000);}for(r=0;r<15;r++){double b,c,x;if(r&1){c=bc(&s,q,800000);b=bb(&s,q,800000);}else{b=bb(&s,q,800000);c=bc(&s,q,800000);}x=b/c;if(x>=1.0)wins++;if(x<worst)worst=x;total++;printf("%d,%d,%d,%.6f,%.6f,%.6f\n",p,off,r,b,c,x);}}
   printf("SUMMARY wins=%d/%d worst=%.6fx sink=%llu\n",wins,total,worst,(unsigned long long)sinkv);_aligned_free(mem);return (wins==total&&worst>=1.0)?0:5;}}
}

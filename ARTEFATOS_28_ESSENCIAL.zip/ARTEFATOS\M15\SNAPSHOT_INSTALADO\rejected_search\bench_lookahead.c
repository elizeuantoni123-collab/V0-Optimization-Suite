#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include <x86intrin.h>
extern uint32_t v0_prefetch_t0_adj2(void*);
static volatile uint64_t sinkv;
static inline uint64_t now_ns(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static uint64_t sm(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ull);z=(z^(z>>30))*0xbf58476d1ce4e5b9ull;z=(z^(z>>27))*0x94d049bb133111ebull;return z^(z>>31);}
static void shuf(uint32_t*a,size_t n,uint64_t s){for(size_t i=n-1;i;i--){size_t j=sm(&s)%(i+1);uint32_t t=a[i];a[i]=a[j];a[j]=t;}}
static inline uint64_t useN(uint8_t*p,int lines){uint64_t s=0;for(int k=0;k<lines;k++)s+=*(uint64_t*)(p+k*64);return s;}
static void flushN(uint8_t*m,uint32_t*o,size_t n,int lines){for(size_t i=0;i<n;i++){uint8_t*p=m+(size_t)o[i]*4096u;for(int k=0;k<lines;k++)_mm_clflush(p+k*64);}_mm_mfence();}
static double run(uint8_t*m,uint32_t*o,size_t n,int lines,int look,uint64_t*sum){uint64_t s=0,t=now_ns();for(size_t i=0;i<n;i++){if(i+(size_t)look<n)v0_prefetch_t0_adj2(m+(size_t)o[i+look]*4096u);s+=useN(m+(size_t)o[i]*4096u,lines);}uint64_t e=now_ns();*sum=s;sinkv+=s;return(double)(e-t)/n;}
static int cmpd(const void*a,const void*b){double x=*(double*)a,y=*(double*)b;return x<y?-1:x>y;}
int main(){const int R=7;size_t bytes=64ull<<20,n=bytes/4096;cpu_set_t set;CPU_ZERO(&set);CPU_SET(0,&set);sched_setaffinity(0,sizeof(set),&set);uint8_t*m;posix_memalign((void**)&m,4096,bytes);uint32_t*o=malloc(n*4);uint64_t sd=1;for(size_t i=0;i<bytes;i+=8)*(uint64_t*)(m+i)=sm(&sd);for(size_t i=0;i<n;i++)o[i]=i;int Ls[]={2,4};printf("lines,look,base8_ns,cand_ns,speedup,correct\n");for(int li=0;li<2;li++){int lines=Ls[li];for(int look=4;look<=12;look++){if(look==8)continue;double b[R],c[R];uint64_t ref=0,x;int ok=1;for(int r=0;r<R;r++){shuf(o,n,0x778800+li*10000+look*313+r*97);int cf=r&1;for(int z=0;z<2;z++){int cand=(z==0)?cf:!cf;flushN(m,o,n,lines);double t=run(m,o,n,lines,cand?look:8,&x);if(!ref)ref=x;else if(x!=ref)ok=0;if(cand)c[r]=t;else b[r]=t;}}qsort(b,R,sizeof(double),cmpd);qsort(c,R,sizeof(double),cmpd);printf("%d,%d,%.6f,%.6f,%.9f,%d\n",lines,look,b[R/2],c[R/2],b[R/2]/c[R/2],ok);}}free(o);free(m);return sinkv==0;}

#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<20)
#define R 11
static v0_decision_signal_v7_t *sigs; static uint8_t *out; static volatile uint64_t sink;
static uint64_t rr(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static double now(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return t.tv_sec*1e9+t.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}

static inline __m512i aos_q16_512(const v0_decision_signal_v7_t *s){
  __m512i a=_mm512_loadu_si512((const void*)s);
  __m512i b=_mm512_loadu_si512((const void*)(s+8));
  const __m512i ie=_mm512_setr_epi32(0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30);
  const __m512i io=_mm512_setr_epi32(1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31);
  __m512i vc=_mm512_permutex2var_epi32(a,ie,b);
  __m512i bi=_mm512_permutex2var_epi32(a,io,b);
  __m512i value=_mm512_and_si512(vc,_mm512_set1_epi32(65535));
  __m512i hc=_mm512_srli_epi32(vc,17);
  bi=_mm512_and_si512(bi,_mm512_set1_epi32(65535));
  return _mm512_srai_epi32(_mm512_add_epi32(_mm512_sub_epi32(value,hc),bi),6);
}
static inline __m128i aos_eval16_512(const v0_decision_signal_v7_t*s){
  __m512i q=aos_q16_512(s);
  __mmask16 k0=_mm512_cmpge_epi32_mask(q,_mm512_setzero_si512());
  __mmask16 k1=_mm512_cmpge_epi32_mask(q,_mm512_set1_epi32(1));
  __mmask16 k3=_mm512_cmpge_epi32_mask(q,_mm512_set1_epi32(3));
  __mmask16 k6=_mm512_cmpge_epi32_mask(q,_mm512_set1_epi32(6));
  __m128i e=_mm_maskz_set1_epi8(k0,4);
  const __m128i one=_mm_set1_epi8(1);
  e=_mm_mask_add_epi8(e,k1,e,one);
  e=_mm_mask_add_epi8(e,k3,e,one);
  e=_mm_mask_add_epi8(e,k6,e,one);
  return e;
}
static void aos_batch512(const v0_decision_signal_v7_t*s,uint8_t*o,size_t n){size_t i=0;for(;i+64<=n;i+=64){_mm_storeu_si128((__m128i*)(o+i),aos_eval16_512(s+i));_mm_storeu_si128((__m128i*)(o+i+16),aos_eval16_512(s+i+16));_mm_storeu_si128((__m128i*)(o+i+32),aos_eval16_512(s+i+32));_mm_storeu_si128((__m128i*)(o+i+48),aos_eval16_512(s+i+48));}for(;i+16<=n;i+=16)_mm_storeu_si128((__m128i*)(o+i),aos_eval16_512(s+i));for(;i<n;i++)o[i]=(uint8_t)v0_eval_v8_signal_ultra_inline(s+i);}
static double scalar(){uint64_t z=0;double a=now();for(size_t i=0;i<N;i++)z+=v0_eval_v8_signal_ultra_inline(sigs+i);double b=now();sink=z;return(b-a)/N;}
static double batch(){double a=now();aos_batch512(sigs,out,N);double b=now();sink+=out[777];return(b-a)/N;}
static void bench(const char*n,double(*f)()){double x[R];for(int i=0;i<3;i++)f();for(int i=0;i<R;i++)x[i]=f();qsort(x,R,sizeof(double),cmpd);printf("%-22s p50 %.5f best %.5f\n",n,x[R/2],x[0]);}
int main(){posix_memalign((void**)&sigs,64,N*sizeof(*sigs));posix_memalign((void**)&out,64,N);uint64_t z=123;for(size_t i=0;i<N;i++){uint16_t v=rr(&z),c=rr(&z);uint8_t t=rr(&z)%3,p=rr(&z)&1;sigs[i]=v0_decision_v7_pack(v,c,t,p);}aos_batch512(sigs,out,N);for(size_t i=0;i<N;i++)if(out[i]!=(uint8_t)v0_eval_v8_signal_ultra_inline(sigs+i)){printf("bad %zu\n",i);return 2;}bench("packed scalar",scalar);bench("packed AoS AVX512",batch);printf("sink %llu\n",(unsigned long long)sink);}

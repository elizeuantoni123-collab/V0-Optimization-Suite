#ifndef V0_MODULE_MANAGER_V14_H
#define V0_MODULE_MANAGER_V14_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct v0_module_manager_state { uint32_t enabled_mask; } v0_module_manager_state;
typedef struct v0_mm_matches8_queries {
    uint32_t required_on[8];
    uint32_t required_off[8];
} v0_mm_matches8_queries;
uint32_t v0_mm_matches8_snapshot_v14(v0_module_manager_state *state, const v0_mm_matches8_queries *queries);
#ifdef __cplusplus
}
#endif
#endif

# V0 Batch V27

V27 adds the optional AVX2 accelerator `v0_batch_plan64_avx2_quadload_v27` for exactly **1024 / 2048 / 3072 / 4096 items**.

It preserves the existing materialized descriptor ABI `{u32 start, u32 count}`. V19 remains the general baseline and all inherited V11/V14/IMPLICIT64/V19 artifacts remain unchanged.

Use V27 only when AVX2 is available and `items` is one of the four validated values. Otherwise use the previously promoted dispatch.

See `reports/V27_ACCEPTANCE_REPORT.md` and `reports/V27_BENCH_7_RUNS.txt`.

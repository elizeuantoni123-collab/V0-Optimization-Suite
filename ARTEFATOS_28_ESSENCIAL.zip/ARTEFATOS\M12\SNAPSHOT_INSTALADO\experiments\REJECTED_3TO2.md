# V7 3→2 experimental path — not selected

A specialized SSE2 `3→2` implementation was correct and had strong positive medians, but expanded multi-process gates produced isolated paired rounds below 1.0x. Under the permanent no-regression rule it is not part of the final V7 candidate dispatch. V6 `v0_kv_window3_v6` remains authoritative for `3→2`.

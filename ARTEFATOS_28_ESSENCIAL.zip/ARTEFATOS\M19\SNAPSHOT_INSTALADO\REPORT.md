# Relatório — V0 Policy Router V10 Squeeze

## Veredito

**KEEP_BASELINE — V10 SAFE permanece promovida.**

## Baseline

A V10 preserva a ordem exata:

`Pin -> Temperature -> Decision -> Tier -> Materializer`

e usa V1 scalar como fallback fora do domínio batch promovido.

## Metodologia adicional desta rodada

Além dos benchmarks linkados, foi criado um gate de `.text` raw em páginas executáveis separadas. Baseline e candidato foram carregados no **mesmo offset de página** (0, 16, 32 e 48 bytes), removendo diferença de alinhamento/layout introduzida pelo linker.

Esse gate foi decisivo porque alguns candidatos pareciam vencedores quando linkados em uma ordem e perdiam quando o layout mudava.

## V13 — branch flags reuse

Mudança:
- baseline: `SUB count,1; TEST count,count; JNE loop`
- candidato: `SUB count,1; JNE loop`, reutilizando ZF do SUB.

Código Linux: 162 B -> 155 B.

No primeiro benchmark linkado apareceu ganho de ~2–7%, porém o gate raw/alinhado mostrou sensibilidade:
- 36 combinações de count/alinhamento;
- vitórias: 20/36;
- pior razão V10/V13: **0.975440x**;
- mediana geral: ~**1.002x**.

**REJEITADO.**

## V14 — cache adicional de stage_ctx

Usou R15 para manter o contexto do primeiro stage, além dos dois callback pointers já cacheados pela V10.

Aumentou prólogo/epílogo e exigiu alinhamento adicional de stack.
Nos gates houve regressões, incluindo razão V10/V14 abaixo de 1.

**REJEITADO.**

## V15 — nonzero + branch otimizado

Remove a guarda `count==0` para o domínio já prevalidado >=16 e aplica o branch otimizado.

Código Linux: **120 B**.

Gate raw/alinhado:
- 36 combinações;
- vitórias: 25/36;
- pior razão V10/V15: **0.960492x**;
- mediana: ~**1.020x**.

A mediana é positiva, mas a regressão por alinhamento viola a regra permanente.

**REJEITADO.**

## V16 — unroll x2

Processa dois registros completos por iteração, preservando exatamente a ordem de todos os callbacks.

Gate raw em quatro alinhamentos:
- 72 combinações;
- vitórias: 52/72;
- mediana geral: **~1.019x**;
- pior razão: **0.978458x**.

**REJEITADO.**

## V17 — unroll x4

Processa quatro registros completos por iteração.

Gate raw em quatro alinhamentos:
- 76 combinações;
- vitórias: 11/76;
- mediana geral: **~0.965x**;
- pior razão: **0.928043x**.

O aumento do corpo prejudicou o front-end/I-cache.

**REJEITADO.**

## Correção

Todos os candidatos testados mantiveram paridade funcional nos gates executados. Exemplos:
- V10/V13/V14: 9.586.000 registros por processo, 0 divergências;
- raw V10/V13/V15: paridade em múltiplos counts/alinhamentos, 0 divergências;
- V16/V17: paridade contra a V10 antes de cada benchmark, 0 divergências.

A rejeição foi exclusivamente por **desempenho não robusto**, não por diferença funcional.

## Decisão final

Não há V11+ desta rodada que possa substituir ou complementar a V10 sem regressão demonstrada.

Continuar com:

```text
count 0..15    -> V1 scalar
count 16..4096 -> V10 batch
count >4096    -> V1 scalar
```

Nenhuma promoção nova.

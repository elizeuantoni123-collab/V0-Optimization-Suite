# V0 Decision V8 Permanent Host protocol — V4

Transport: Windows named pipe `\\.\pipe\V0DecisionV8`, ASCII message mode.

V4 accepts **multiple commands on one connection**. V3-style clients remain compatible: they may connect, send one command, read one reply, and disconnect.

Commands:

- `PING`
- `STATUS`
- `RESET`
- `DECIDE <value> <cost> <temperature> <pinned>`
- `PLAN`
- `COMPLETE <mode> <elapsed_ticks> <count>`

`DECIDE` uses the exact V8 scalar score and one fused V0L evaluation internally.

`PLAN` returns the next V8 block (`BYPASS` or `FILTER`), its count, and whether the block must be measured. The caller executes the downstream work. If `measure=1`, measure the whole block with one monotonic clock and return the result with `COMPLETE`. For an ACTIVE block, `COMPLETE` may use zero ticks because no A/B comparison is made.

The controller remains outside the per-operation/Global/EPT hot path.

#!/usr/bin/env python3
"""V0L -> x86-64 direct backend.

Emits ELF64 relocatable objects itself. No C backend and no assembler are used.
Target ABI: System V AMD64, little-endian x86-64.
"""
from __future__ import annotations
import argparse, json, pathlib, re, struct, sys
from dataclasses import dataclass, field

# ----------------------------- parsing -----------------------------
TYPE_BITS={'u8':8,'u16':16,'u32':32,'u64':64,'i32':32,'ptr':64}
IMM_RE=re.compile(r'-?0x[0-9a-fA-F]+|-?\d+$')
NAME_RE=re.compile(r'[A-Za-z_]\w*$')

@dataclass
class Ins:
    op:str; args:list[str]; line:int
@dataclass
class Fn:
    name:str; params:list[tuple[str,str]]; ret:str; body:list[Ins]=field(default_factory=list); vars:dict[str,str]=field(default_factory=dict)
@dataclass
class Module:
    data_files:list[str]; fns:list[Fn]

def die(msg,line=None):
    p=f'line {line}: ' if line else ''
    raise SystemExit(p+msg)

def parse_source(txt:str)->Module:
    data_files=[]; fns=[]; cur=None
    for ln,raw in enumerate(txt.splitlines(),1):
        s=raw.split('#',1)[0].strip()
        if not s: continue
        t=s.split(); op=t[0]
        if op=='data':
            if cur: die('data directive inside function',ln)
            if len(t)!=2: die('data expects one path',ln)
            data_files.append(t[1]); continue
        if op=='fn':
            if cur: die('nested fn',ln)
            if '->' not in t: die('fn requires -> return-type',ln)
            k=t.index('->'); name=t[1]; ret=t[k+1]
            if not NAME_RE.fullmatch(name) or ret not in TYPE_BITS: die('bad function signature',ln)
            params=[]; vars={}
            for a in t[2:k]:
                if ':' not in a: die('parameter must be name:type',ln)
                n,ty=a.split(':',1)
                if not NAME_RE.fullmatch(n) or ty not in TYPE_BITS: die('bad parameter',ln)
                params.append((n,ty)); vars[n]=ty
            cur=Fn(name,params,ret,vars=vars); fns.append(cur); continue
        if op=='end':
            if not cur: die('end outside fn',ln)
            cur=None; continue
        if not cur: die('instruction outside function',ln)
        if op=='let':
            if len(t)!=3 or t[2] not in TYPE_BITS: die('bad let',ln)
            cur.vars[t[1]]=t[2]
        cur.body.append(Ins(op,t[1:],ln))
    if cur: die('unterminated function')
    return Module(data_files,fns)

# ----------------------------- V0D data -----------------------------
def load_v0d(src_path:pathlib.Path, names:list[str]):
    constants={}; arrays=[]
    for n in names:
        p=(src_path.parent.parent/'generated'/n) if not (src_path.parent/n).exists() else (src_path.parent/n)
        if not p.exists():
            p=src_path.parent/n
        if not p.exists(): die(f'data file not found: {n}')
        d=json.loads(p.read_text())
        if d.get('format')!='V0D1': die(f'unsupported data format in {p}')
        constants.update({k:int(v) for k,v in d.get('constants',{}).items()})
        arrays.extend(d.get('arrays',[]))
    return constants,arrays

# ----------------------------- x86 encoder -----------------------------
REG={
 'rax':0,'rcx':1,'rdx':2,'rbx':3,'rsp':4,'rbp':5,'rsi':6,'rdi':7,
 'r8':8,'r9':9,'r10':10,'r11':11,'r12':12,'r13':13,'r14':14,'r15':15,
}
# allocator pool; rsi/r10/r11 are backend scratch, rdi is first pointer arg.
ALLOC=['rax','rcx','rdx','r8','r9']

class Code:
    def __init__(self): self.b=bytearray(); self.reloc=[]; self.labels={}; self.fix=[]; self.fix8=[]
    def tell(self): return len(self.b)
    def emit(self,*xs): self.b.extend(xs)
    def u32(self,x): self.b.extend(struct.pack('<I',x & 0xffffffff))
    def i32(self,x): self.b.extend(struct.pack('<i',x))
    def rex(self,w=0,r=0,x=0,b=0,force=False):
        v=0x40|(w<<3)|((r>>3)&1)<<2|((x>>3)&1)<<1|((b>>3)&1)
        if v!=0x40 or force: self.emit(v)
    def modrm(self,mod,reg,rm): self.emit(((mod&3)<<6)|((reg&7)<<3)|(rm&7))
    def sib(self,scale,index,base): self.emit(((scale&3)<<6)|((index&7)<<3)|(base&7))
    def mov_rr(self,dst,src,bits=32):
        d=REG[dst]; s=REG[src]; self.rex(bits==64,s,0,d); self.emit(0x89); self.modrm(3,s,d)
    def mov_imm(self,dst,val,bits=32):
        d=REG[dst]
        if bits==64:
            # Prefer shorter encodings when the value fits.  A 32-bit register
            # write zero-extends to 64 bits; C7 /0 sign-extends imm32.
            if 0 <= val <= 0xffffffff:
                self.rex(0,0,0,d); self.emit(0xB8+(d&7)); self.u32(val)
            elif -0x80000000 <= val <= 0x7fffffff:
                self.rex(1,0,0,d); self.emit(0xC7); self.modrm(3,0,d); self.u32(val)
            else:
                self.rex(1,0,0,d); self.emit(0xB8+(d&7)); self.b.extend(struct.pack('<Q',val & 0xffffffffffffffff))
        else:
            self.rex(0,0,0,d); self.emit(0xB8+(d&7)); self.u32(val)
    def mov_mem(self,dst,base,disp=0,bits=32):
        d=REG[dst]; ba=REG[base]; self.rex(bits==64,d,0,ba); self.emit(0x8B)
        self._mem_modrm(d,ba,disp)
    def store_mem(self,base,src,disp=0,bits=32):
        s=REG[src]; ba=REG[base]; self.rex(bits==64,s,0,ba); self.emit(0x89)
        self._mem_modrm(s,ba,disp)
    def movzx8_mem(self,dst,base,disp=0):
        d=REG[dst]; ba=REG[base]
        self.rex(0,d,0,ba); self.emit(0x0F,0xB6); self._mem_modrm(d,ba,disp)
    def movzx8_mem_index(self,dst,base,index,scale=0,disp=0):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(0,d,ix,ba); self.emit(0x0F,0xB6)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def mov_mem_index(self,dst,base,index,scale=0,disp=0,bits=64):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(bits==64,d,ix,ba); self.emit(0x8B)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def store_mem_index(self,base,index,src,scale=0,disp=0,bits=64):
        s=REG[src]; ba=REG[base]; ix=REG[index]
        self.rex(bits==64,s,ix,ba); self.emit(0x89)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,s,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def store8_mem_index(self,base,index,src,scale=0,disp=0):
        s=REG[src]; ba=REG[base]; ix=REG[index]
        # MOV r/m8, r8. Force REX for r8-r15 and for SPL/BPL/SIL/DIL encodings.
        self.rex(0,s,ix,ba,force=(s>=4 or ix>=8 or ba>=8)); self.emit(0x88)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,s,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)

    def cmp_rr(self,a,b,bits=32):
        # flags from a-b
        ra=REG[a]; rb=REG[b]; self.rex(bits==64,rb,0,ra); self.emit(0x39); self.modrm(3,rb,ra)
    def cmp_mem(self,reg,base,disp=0,bits=32):
        r=REG[reg]; ba=REG[base]
        if bits==16: self.emit(0x66)
        self.rex(bits==64,r,0,ba); self.emit(0x3B); self._mem_modrm(r,ba,disp)
    def cmp_mem_index(self,reg,base,index,scale=0,disp=0,bits=32):
        r=REG[reg]; ba=REG[base]; ix=REG[index]
        if bits==16: self.emit(0x66)
        self.rex(bits==64,r,ix,ba); self.emit(0x3B)
        low=ba&7
        mod=0 if disp==0 and low!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,r,4); self.sib(scale,ix,low)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and low==5): self.i32(disp)
    def setcc(self,cc,dst):
        d=REG[dst]; op={'e':0x94,'ne':0x95,'b':0x92,'be':0x96,'a':0x97,'ae':0x93,'l':0x9C,'ge_s':0x9D,'le_s':0x9E,'g':0x9F}[cc]
        self.rex(0,0,0,d,force=(d>=8)); self.emit(0x0F,op); self.modrm(3,0,d)

    def movzx16_mem_index(self,dst,base,index,scale=1,disp=0):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(0,d,ix,ba); self.emit(0x0F,0xB7)
        # indexed address always SIB
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def movzx16_mem(self,dst,base,disp=0):
        d=REG[dst]; ba=REG[base]; self.rex(0,d,0,ba); self.emit(0x0F,0xB7); self._mem_modrm(d,ba,disp)
    def _mem_modrm(self,reg,base,disp):
        low=base&7
        mod=0 if disp==0 and low!=5 else (1 if -128<=disp<=127 else 2)
        if low==4:
            self.modrm(mod,reg,4); self.sib(0,4,low)
        else: self.modrm(mod,reg,low)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and low==5): self.i32(disp)
    def imul_imm(self,dst,src,imm,bits=32,imm8=False):
        d=REG[dst]; s=REG[src]; self.rex(bits==64,d,0,s)
        if imm8 and -128<=imm<=127:
            self.emit(0x6B); self.modrm(3,d,s); self.emit(imm&255)
        else:
            self.emit(0x69); self.modrm(3,d,s); self.u32(imm)
    def shift_imm(self,kind,dst,imm,bits=32):
        d=REG[dst]; ext={'shl':4,'shr':5}[kind]; self.rex(bits==64,0,0,d)
        mask=63 if bits==64 else 31
        if (imm & mask)==1:
            self.emit(0xD1); self.modrm(3,ext,d)
        else:
            self.emit(0xC1); self.modrm(3,ext,d); self.emit(imm&255)
    def bin_rr(self,op,dst,src,bits=32):
        # rm(dst) op reg(src)
        opc={'add':0x01,'sub':0x29,'xor':0x31,'or':0x09,'and':0x21}[op]
        d=REG[dst]; s=REG[src]; self.rex(bits==64,s,0,d); self.emit(opc); self.modrm(3,s,d)
    def bin_imm(self,op,dst,imm,bits=32):
        ext={'add':0,'or':1,'and':4,'sub':5,'xor':6}[op]; d=REG[dst]
        self.rex(bits==64,0,0,d)
        if -128<=imm<=127:
            self.emit(0x83); self.modrm(3,ext,d); self.emit(imm&255)
        else:
            self.emit(0x81); self.modrm(3,ext,d); self.u32(imm)
    def lea_rip(self,dst,sym):
        d=REG[dst]; self.rex(1,d,0,0); self.emit(0x8D); self.modrm(0,d,5)
        off=self.tell(); self.u32(0); self.reloc.append((off,sym,-4))
    def xor_mem(self,dst,base,disp=0,bits=64):
        d=REG[dst]; ba=REG[base]; self.rex(bits==64,d,0,ba); self.emit(0x33); self._mem_modrm(d,ba,disp)
    def test_rr(self,a,b,bits=32):
        ra=REG[a]; rb=REG[b]; self.rex(bits==64,rb,0,ra); self.emit(0x85); self.modrm(3,rb,ra)
    def test_imm8(self,reg,imm):
        # Testing a mask confined to the low byte is equivalent for any u32 value.
        r=REG[reg]
        if r==0:
            self.emit(0xA8,imm&0xff)  # test al, imm8
        else:
            self.rex(0,0,0,r,force=(r>=8)); self.emit(0xF6); self.modrm(3,0,r); self.emit(imm&0xff)
    def movzx16_rr(self,dst,src):
        d=REG[dst]; s=REG[src]; self.rex(0,d,0,s); self.emit(0x0F,0xB7); self.modrm(3,d,s)
    def cmp_imm(self,reg,val,bits=32):
        r=REG[reg]; self.rex(bits==64,0,0,r)
        if -128 <= val <= 127:
            self.emit(0x83); self.modrm(3,7,r); self.emit(val&0xff)
        else:
            self.emit(0x81); self.modrm(3,7,r); self.u32(val)
    def not_reg(self,reg,bits=32):
        r=REG[reg]; self.rex(bits==64,0,0,r); self.emit(0xF7); self.modrm(3,2,r)
    def ret(self): self.emit(0xC3)
    def label(self,name):
        if name in self.labels: raise ValueError(f'duplicate label {name}')
        self.labels[name]=self.tell()
    def jcc(self,cc,label):
        opc={'z':0x84,'e':0x84,'nz':0x85,'ne':0x85,'b':0x82,'ae':0x83,'be':0x86,'a':0x87}[cc]
        self.emit(0x0F,opc); off=self.tell(); self.u32(0); self.fix.append((off,label))
    def jcc8(self,cc,label):
        opc={'z':0x74,'e':0x74,'nz':0x75,'ne':0x75,'b':0x72,'ae':0x73,'be':0x76,'a':0x77,'s':0x78,'ns':0x79,'l':0x7C,'ge_s':0x7D,'le_s':0x7E,'g':0x7F}[cc]
        self.emit(opc); off=self.tell(); self.emit(0); self.fix8.append((off,label))
    def jmp(self,label): self.emit(0xE9); off=self.tell(); self.u32(0); self.fix.append((off,label))
    def patch(self):
        for off,label in self.fix:
            if label not in self.labels: raise ValueError(f'unknown label {label}')
            rel=self.labels[label]-(off+4); self.b[off:off+4]=struct.pack('<i',rel)
        for off,label in self.fix8:
            if label not in self.labels: raise ValueError(f'unknown label {label}')
            rel=self.labels[label]-(off+1)
            if not -128<=rel<=127: raise ValueError(f'short branch to {label} is out of range')
            self.b[off]=rel&255

# ----------------------------- register allocation -----------------------------
def is_value(tok,fn,constants): return tok in fn.vars or tok in constants or IMM_RE.fullmatch(tok)

def uses_defs(ins:Ins):
    op=ins.op; a=ins.args; use=[]; define=[]
    if op=='let': pass
    elif op=='mov': define.append(a[0]); use.append(a[1])
    elif op in ('add32','sub32','mul32','xor32','or32','and32','shl32','shr32','add64','mul64','xor64','or64','and64','shl64','shr64','eq32','ne32','lt32','le32','gt32','ge32'):
        define.append(a[0]); use+=a[1:3]
    elif op.startswith('ld'): define.append(a[0]); use+=[a[1],a[2]]
    elif op.startswith('st'): use+=a[:3]
    elif op in ('aget16','aget32','aget64'): define.append(a[0]); use.append(a[2])
    elif op=='tier4s32': define.append(a[0]); use.append(a[1])
    elif op in ('matcopyrep','matcopy128sse2','matcopy16sse2','matcopy32sse2','matcopy64sse2','matcopy8scalar','matcopy24mixed','matcopy48sse2','matcopy80sse2','matcopy96sse2','matcopy40mixed','matcopy56mixed','matcopy72mixed','matcopy88seq','matcopy104seq','matcopy136seq','matcopy144seq','matcopy152seq','matcopy160seq','matcopy168b6','extput_v1','extget_v1','extexists_v1','extremove_v1','extget_valid_v7','extexists_valid_v7','rle_compress_v1','rle_decompress_v1','rle_zero_compress_v2','rle_zero_decompress_v2','rle_uniform_compress_v3','rle_uniform_decompress_v3','rle_zero_compress_sse2_v4','rle_uniform_compress_sse2_v4','rle_zero_compress_reduce_v5','rle_uniform_compress_reduce_v5','rle_zero_decompress_light_v6','rle_uniform_decompress_light_v6','rle_zero_compress_u4bulk_v7','rle_uniform_compress_u4bulk_v7','rle_zero_compress_avx2_v10','rle_uniform_compress_avx2_v10','rle_zero_decompress_canonical_sse2_v12','rle_uniform_decompress_canonical_sse2_v12'): use.append(a[0])
    elif op=='eq22': define.append(a[0]); use += [a[1],a[3]]
    elif op in ('jz','jnz'): use.append(a[0])
    elif op=='ret': use.append(a[0])
    elif op=='retif': use += [a[0],a[1]]
    return use,define

def destructive_reuse_sources(ins:Ins):
    """Sources whose register may also hold this instruction's destination.

    x86 reads all address/source operands before committing the destination.
    Two-address arithmetic naturally overwrites its left input; commutative
    operations may also reverse their inputs.  Keeping this distinction here
    lets the linear scan end a source lifetime at the defining instruction
    without making unsafe choices for subtraction or eq22.
    """
    op=ins.op; a=ins.args
    if op=='mov': return a[1:2]
    if op in ('mul32','shl32','shr32','add64','mul64','xor64','or64','and64','shl64','shr64'):
        return a[1:2]
    if op in ('add32','xor32','or32','and32'):
        return a[1:2]
    if op=='sub32': return a[1:2]
    if op.startswith('ld'): return a[1:3]
    if op in ('aget16','aget32','aget64'): return a[2:3]
    if op in ('eq32','ne32','lt32','le32','gt32','ge32'): return a[1:3]
    return []

def alloc_regs(fn:Fn,target="linux"):
    # Params: current direct backend supports first pointer parameter in RDI.
    regs={}
    if len(fn.params)>2: die(f'{fn.name}: direct backend currently supports up to two parameters')
    abi=['rdi','rsi'] if target=='linux' else ['rcx','rdx']
    for (n,ty),r in zip(fn.params,abi): regs[n]=r
    first={}; last={}
    for i,ins in enumerate(fn.body):
        u,d=uses_defs(ins)
        for x in d:
            if x in fn.vars and x not in first: first[x]=i
            if x in fn.vars: last[x]=max(last.get(x,i),i)
        for x in u:
            if x in fn.vars:
                first.setdefault(x,0); last[x]=i
    intervals=sorted([(first[v],last.get(v,first[v]),v) for v in first if v not in regs])
    active=[]; free=[r for r in ALLOC if r not in regs.values()]
    for st,en,v in intervals:
        still=[]
        for aen,av,ar in active:
            if aen < st: free.append(ar)
            else: still.append((aen,av,ar))
        active=still
        reusable=set(destructive_reuse_sources(fn.body[st]))
        reuse=next(((aen,av,ar) for aen,av,ar in active
                    if aen==st and av in reusable),None)
        if reuse is not None:
            active.remove(reuse); r=reuse[2]
            regs[v]=r; active.append((en,v,r)); active.sort()
            continue
        if not free: die(f'{fn.name}: register pressure exceeds direct backend pool near {v}')
        # stable preference to low regs for shorter encodings
        free.sort(key=lambda r:ALLOC.index(r)); r=free.pop(0); regs[v]=r
        active.append((en,v,r)); active.sort()
    return regs

# ----------------------------- compile operations -----------------------------
def imm(tok,constants):
    if tok in constants: return int(constants[tok])
    if IMM_RE.fullmatch(tok): return int(tok,0)
    return None

def ensure_reg(c:Code,tok,fn,regs,constants,scratch='r11',bits=32):
    if tok in regs: return regs[tok]
    v=imm(tok,constants)
    if v is None: die(f'unknown value {tok}')
    c.mov_imm(scratch,v,bits); return scratch

def move_value(c:Code,dst,tok,fn,regs,constants,bits=32):
    if tok in regs:
        if regs[tok]!=dst: c.mov_rr(dst,regs[tok],bits)
    else:
        v=imm(tok,constants)
        if v is None: die(f'unknown value {tok}')
        c.mov_imm(dst,v,bits)

def compile_fn(fn:Fn,constants,data_offsets=None,target='linux')->tuple[bytes,list[tuple[int,str,int]]]:
    regs=alloc_regs(fn,target); c=Code(); internal=0; sticky_data=None; data_offsets=data_offsets or {}
    data_scratch='rsi' if target=='linux' else 'r10'
    skip_ins=0
    # skip let: allocation is static and x86 locals need no initialization unless used before def.
    for pos,ins in enumerate(fn.body):
        if skip_ins:
            skip_ins-=1; continue
        op=ins.op; a=ins.args
        if op=='let': continue

        # V0L peephole: masked bit-test feeding retif. Avoid materializing a boolean.
        if op=='and32' and pos+1<len(fn.body):
            nxt=fn.body[pos+1]
            if nxt.op=='retif' and nxt.args[0]==a[0]:
                dst,x,y=a; mask=imm(y,constants)
                if mask is not None and 0 <= mask <= 0xff:
                    xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
                    skip=f'__maskret_skip_{internal}'; internal+=1
                    c.test_imm8(xr,mask); c.jcc8('z',skip)
                    move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret(); c.label(skip)
                    skip_ins=1; continue

        # V0L peephole: sign-bit extraction feeding retif. Test the signed source directly.
        if op=='shr32' and pos+1<len(fn.body):
            nxt=fn.body[pos+1]
            if nxt.op=='retif' and nxt.args[0]==a[0] and imm(a[2],constants)==31:
                _,x,_=a; xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
                skip=f'__signret_skip_{internal}'; internal+=1
                c.test_rr(xr,xr,32); c.jcc8('ns',skip)
                move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret(); c.label(skip)
                skip_ins=1; continue

        # V0L peephole: signbit inversion returned immediately: !(x<0).
        if op=='shr32' and pos+2<len(fn.body):
            nxt=fn.body[pos+1]; last=fn.body[pos+2]
            if (imm(a[2],constants)==31 and nxt.op=='xor32' and last.op=='ret' and
                nxt.args[0]==a[0] and nxt.args[1]==a[0] and imm(nxt.args[2],constants)==1 and
                last.args[0]==a[0]):
                dst,x,_=a; dr=regs[dst]; xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
                if dr!=xr: c.mov_rr(dr,xr,32)
                c.not_reg(dr,32); c.shift_imm('shr',dr,31,32); move_value(c,'rax',dst,fn,regs,constants,32); c.ret()
                skip_ins=2; continue

        # Comparison feeding retif: branch directly on FLAGS, even when more code follows.
        cmp_ops=('eq32','ne32','lt32','le32','gt32','ge32')
        if op in cmp_ops and pos+1<len(fn.body):
            nxt=fn.body[pos+1]
            if nxt.op=='retif' and nxt.args[0]==a[0]:
                _,x,y=a; xi=imm(x,constants); yi=imm(y,constants)
                if x in regs:
                    xr=regs[x]
                    if yi is not None: c.cmp_imm(xr,yi,32)
                    else: c.cmp_rr(xr,ensure_reg(c,y,fn,regs,constants,'r11',32),32)
                    true_cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]
                else:
                    xr=ensure_reg(c,x,fn,regs,constants,'r10',32); yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
                    c.cmp_rr(xr,yr,32)
                    true_cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]
                false_cc={'e':'ne','ne':'e','b':'ae','be':'a','a':'be','ae':'b'}[true_cc]
                skip=f'__cmpret_skip_{internal}'; internal+=1
                c.jcc8(false_cc,skip); move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret(); c.label(skip)
                skip_ins=1; continue

        # eq22 commonly feeds an immediate retif followed by the miss return.
        # Fuse the three V0L operations so no boolean is materialized and each
        # comparison branches directly to the miss epilogue.
        if op=='eq22' and pos+2<len(fn.body):
            nxt=fn.body[pos+1]; last=fn.body[pos+2]
            if nxt.op=='retif' and last.op=='ret' and nxt.args[0]==a[0]:
                _,p,sym,idx=a; fail=f'__eqretfail_{internal}'; internal+=1
                c.lea_rip('r10',sym)
                # The index may itself be the value returned by retif (as in the
                # full V0 lookup).  Only clobber/reuse its register when it is
                # provably dead on both terminal paths.  Otherwise preserve it and
                # use the OPT2 address sequence.
                idx_is_live = (nxt.args[1] == idx or last.args[0] == idx)
                if idx_is_live:
                    c.imul_imm('r11',regs[idx],22,64,imm8=True)
                    c.bin_rr('add','r10','r11',64)
                    c.mov_mem('r11',regs[p],0,64); c.cmp_mem('r11','r10',0,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],8,64); c.cmp_mem('r11','r10',8,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],14,64); c.cmp_mem('r11','r10',14,64); c.jcc8('nz',fail)
                else:
                    idxr=regs[idx]
                    c.imul_imm(idxr,idxr,22,64,imm8=True)
                    c.mov_mem('r11',regs[p],0,64); c.cmp_mem_index('r11','r10',idxr,0,0,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],8,64); c.cmp_mem_index('r11','r10',idxr,0,8,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],14,64); c.cmp_mem_index('r11','r10',idxr,0,14,64); c.jcc8('nz',fail)
                move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret()
                c.label(fail)
                z=imm(last.args[0],constants)
                if z==0: c.bin_rr('xor','rax','rax',32)
                else: move_value(c,'rax',last.args[0],fn,regs,constants,32)
                c.ret()
                skip_ins=2; continue
        # eq22 followed directly by `ret result` is also terminal.  The index
        # is dead on both outcomes, so use the same folded-address exact check
        # and return the boolean directly without materializing it first.
        if op=='eq22' and pos+1<len(fn.body):
            nxt=fn.body[pos+1]
            if nxt.op=='ret' and nxt.args[0]==a[0]:
                _,p,sym,idx=a; fail=f'__eqretboolfail_{internal}'; internal+=1
                c.lea_rip('r10',sym)
                idxr=regs[idx]
                c.imul_imm(idxr,idxr,22,64,imm8=True)
                c.mov_mem('r11',regs[p],0,64); c.cmp_mem_index('r11','r10',idxr,0,0,64); c.jcc8('nz',fail)
                c.mov_mem('r11',regs[p],8,64); c.cmp_mem_index('r11','r10',idxr,0,8,64); c.jcc8('nz',fail)
                c.mov_mem('r11',regs[p],14,64); c.cmp_mem_index('r11','r10',idxr,0,14,64); c.jcc8('nz',fail)
                c.mov_imm('rax',1,32); c.ret()
                c.label(fail); c.bin_rr('xor','rax','rax',32); c.ret()
                skip_ins=1; continue
        # Comparison -> retif -> ret is another common hot-path shape.  Keep
        # flags live and branch directly instead of materializing a 0/1 value
        # only to test it again in retif.
        cmp_ops=('eq32','ne32','lt32','le32','gt32','ge32')
        if op in cmp_ops and pos+2<len(fn.body):
            nxt=fn.body[pos+1]; last=fn.body[pos+2]
            if nxt.op=='retif' and last.op=='ret' and nxt.args[0]==a[0]:
                _,x,y=a
                xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
                yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
                c.cmp_rr(xr,yr,32)
                true_cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]
                false_cc={'e':'ne','ne':'e','b':'ae','be':'a','a':'be','ae':'b'}[true_cc]
                fail=f'__cmpretfail_{internal}'; internal+=1
                c.jcc8(false_cc,fail)
                move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret()
                c.label(fail); move_value(c,'rax',last.args[0],fn,regs,constants,32); c.ret()
                skip_ins=2; continue
        # V6 exact decoders using caller-saved registers. Existing V1-V5 bytes are
        # untouched; Windows saves only the ABI-nonvolatile registers it modifies.
        if op in ('rle_zero_decompress_light_v6','rle_uniform_decompress_light_v6'):
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)
            bad=f'__rled6_bad_{internal}'; internal+=1
            loop=f'__rled6_loop_{internal}'; internal+=1
            parsed=f'__rled6_parsed_{internal}'; internal+=1
            expok=f'__rled6_expok_{internal}'; internal+=1
            done=f'__rled6_done_{internal}'; internal+=1
            # Preserve rdi on Windows because REP STOSB advances it. Uniform V6
            # additionally uses rsi for the reference byte.
            if target=='windows':
                c.emit(0x57)                          # push rdi
                if op=='rle_uniform_decompress_light_v6': c.emit(0x56) # push rsi
            c.mov_rr('r11',req,64)                   # req
            c.bin_rr('xor','rax','rax',32); c.store_mem('r11','rax',24,32)
            c.mov_mem('r10','r11',0,64)              # src
            c.mov_mem('rdi','r11',8,64)              # dst
            c.mov_mem('r8','r11',16,32)              # compressed len
            c.mov_mem('r9','r11',20,32)              # dst cap
            c.bin_rr('xor','rdx','rdx',32)            # total=0, also for empty stream
            if op=='rle_uniform_decompress_light_v6': c.bin_rr('xor','rsi','rsi',32)
            c.test_rr('r8','r8',32); c.jcc('z',parsed)
            c.test_rr('r10','r10',64); c.jcc('z',bad)
            c.test_rr('rdi','rdi',64); c.jcc('z',bad)
            c.mov_rr('rax','r8',32); c.bin_imm('and','rax',1,32); c.jcc('nz',bad)
            if op=='rle_uniform_decompress_light_v6': c.movzx8_mem('rsi','r10',1)
            c.bin_rr('xor','rcx','rcx',32)            # i=0
            c.label(loop)
            c.cmp_rr('rcx','r8',32); c.jcc('ae',parsed)
            c.movzx8_mem_index('rax','r10','rcx',0,0) # count
            c.test_rr('rax','rax',32); c.jcc('z',bad)
            c.bin_rr('add','rax','rdx',32)            # new total
            c.cmp_rr('rax','rdx',32); c.jcc('b',bad)
            c.cmp_rr('rax','r9',32); c.jcc('a',bad)
            c.mov_rr('rdx','rax',32)
            c.movzx8_mem_index('rax','r10','rcx',0,1) # value
            if op=='rle_zero_decompress_light_v6':
                c.test_rr('rax','rax',32); c.jcc('nz',bad)
            else:
                c.cmp_rr('rax','rsi',32); c.jcc('ne',bad)
            c.bin_imm('add','rcx',2,32); c.jmp(loop)
            c.label(parsed)
            c.mov_mem('rax','r11',28,32)
            c.test_rr('rax','rax',32); c.jcc('z',expok)
            c.cmp_rr('rdx','rax',32); c.jcc('ne',bad)
            c.label(expok)
            c.mov_rr('rcx','rdx',32)
            if op=='rle_zero_decompress_light_v6': c.bin_rr('xor','rax','rax',32)
            else: c.mov_rr('rax','rsi',32)
            c.emit(0xF3,0xAA)                        # rep stosb
            c.store_mem('r11','rdx',24,32)
            c.mov_imm('rax',1,32)
            if target=='windows':
                if op=='rle_uniform_decompress_light_v6': c.emit(0x5E)
                c.emit(0x5F)
            c.ret()
            c.label(bad)
            c.bin_rr('xor','rax','rax',32); c.store_mem('r11','rax',24,32)
            if target=='windows':
                if op=='rle_uniform_decompress_light_v6': c.emit(0x5E)
                c.emit(0x5F)
            c.ret()
            continue

        # V0 Compression lossless RLE intrinsics.
        # Request ABI (32 B): src:u64, dst:u64, src_len:u32, dst_cap:u32,
        # out_len:u32, expected_len:u32. Compression requires dst_cap>=src_len;
        # it returns 1 only when the encoded output is strictly smaller.
        if op in ('rle_compress_v1','rle_decompress_v1','rle_zero_compress_v2','rle_zero_decompress_v2','rle_uniform_compress_v3','rle_uniform_decompress_v3','rle_zero_compress_sse2_v4','rle_uniform_compress_sse2_v4','rle_zero_compress_reduce_v5','rle_uniform_compress_reduce_v5','rle_zero_decompress_light_v6','rle_uniform_decompress_light_v6','rle_zero_compress_u4bulk_v7','rle_uniform_compress_u4bulk_v7','rle_zero_compress_avx2_v10','rle_uniform_compress_avx2_v10','rle_zero_decompress_canonical_sse2_v12','rle_uniform_decompress_canonical_sse2_v12'):
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)

            # Preserve every nonvolatile register touched by these terminal intrinsics.
            c.emit(0x53,0x56,0x57)                    # push rbx,rsi,rdi
            c.mov_rr('rbx',req,64)

            def comp_done(v, outreg=None):
                if outreg is None:
                    c.bin_rr('xor','rax','rax',32)
                    c.store_mem('rbx','rax',24,32)
                else:
                    c.store_mem('rbx',outreg,24,32)
                c.mov_imm('rax',v,32)
                c.emit(0x5F,0x5E,0x5B)              # pop rdi,rsi,rbx
                c.ret()

            # ---------------- universal compressor V1 ----------------
            if op=='rle_compress_v1':
                bad=f'__rlec_bad_{internal}'; internal+=1
                loop=f'__rlec_loop_{internal}'; internal+=1
                run=f'__rlec_run_{internal}'; internal+=1
                emit=f'__rlec_emit_{internal}'; internal+=1
                done=f'__rlec_done_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64)          # src
                c.mov_mem('rdi','rbx',8,64)          # dst
                c.mov_mem('r10','rbx',16,32)         # n
                c.mov_mem('r11','rbx',20,32)         # cap
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                c.bin_rr('xor','rax','rax',32)        # i=0
                c.bin_rr('xor','rdx','rdx',32)        # o=0
                c.label(loop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',done)
                c.movzx8_mem_index('r8','rsi','rax',0,0)  # byte
                c.mov_imm('rcx',1,32)                 # run=1
                c.label(run)
                c.cmp_imm('rcx',255,32); c.jcc('ae',emit)
                c.mov_rr('r9','rax',32); c.bin_rr('add','r9','rcx',32)
                c.cmp_rr('r9','r10',32); c.jcc('ae',emit)
                c.movzx8_mem_index('r9','rsi','r9',0,0)
                c.cmp_rr('r9','r8',32); c.jcc('ne',emit)
                c.bin_imm('add','rcx',1,32); c.jmp(run)
                c.label(emit)
                c.mov_rr('r9','rdx',32); c.bin_imm('add','r9',2,32)
                # Strictly smaller only. Once output would reach input length,
                # later output can never recover because encoded size is monotonic.
                c.cmp_rr('r9','r10',32); c.jcc('ae',bad)
                c.store8_mem_index('rdi','rdx','rcx',0,0)
                c.store8_mem_index('rdi','rdx','r8',0,1)
                c.mov_rr('rdx','r9',32)
                c.bin_rr('add','rax','rcx',32)
                c.jmp(loop)
                c.label(done); comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- universal decoder V1 ----------------
            if op=='rle_decompress_v1':
                bad=f'__rled_bad_{internal}'; internal+=1
                loop=f'__rled_loop_{internal}'; internal+=1
                done=f'__rled_done_{internal}'; internal+=1
                expok=f'__rled_expok_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64)           # compressed src
                c.mov_mem('rdi','rbx',8,64)           # output dst (advanced by stosb)
                c.mov_mem('r10','rbx',16,32)          # compressed len
                c.mov_mem('r11','rbx',20,32)          # dst cap
                c.test_rr('r10','r10',32); c.jcc('z',done)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.mov_rr('rax','r10',32); c.bin_imm('and','rax',1,32); c.jcc('nz',bad)
                c.bin_rr('xor','r8','r8',32)          # i=0
                c.bin_rr('xor','r9','r9',32)          # out=0
                c.label(loop)
                c.cmp_rr('r8','r10',32); c.jcc('ae',done)
                c.movzx8_mem_index('rcx','rsi','r8',0,0) # count
                c.test_rr('rcx','rcx',32); c.jcc('z',bad)
                c.mov_rr('rdx','r9',32); c.bin_rr('add','rdx','rcx',32)
                c.cmp_rr('rdx','r9',32); c.jcc('b',bad)  # overflow
                c.cmp_rr('rdx','r11',32); c.jcc('a',bad)
                c.movzx8_mem_index('rax','rsi','r8',0,1) # value -> AL
                c.mov_rr('r9','rdx',32)
                c.emit(0xF3,0xAA)                    # rep stosb
                c.bin_imm('add','r8',2,32)
                c.jmp(loop)
                c.label(done)
                c.mov_mem('r8','rbx',28,32)          # expected_len (0 = unchecked)
                c.test_rr('r8','r8',32); c.jcc('z',expok)
                c.cmp_rr('r9','r8',32); c.jcc('ne',bad)
                c.label(expok); comp_done(1,'r9')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive zero-block compressor V2 ----------------
            if op=='rle_zero_compress_v2':
                bad=f'__rlezc_bad_{internal}'; internal+=1
                qloop=f'__rlezc_qloop_{internal}'; internal+=1
                tail=f'__rlezc_tail_{internal}'; internal+=1
                tloop=f'__rlezc_tloop_{internal}'; internal+=1
                encode=f'__rlezc_encode_{internal}'; internal+=1
                eloop=f'__rlezc_eloop_{internal}'; internal+=1
                elast=f'__rlezc_elast_{internal}'; internal+=1
                edone=f'__rlezc_edone_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                c.bin_rr('xor','rax','rax',32)        # i=0
                c.label(qloop)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',8,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                c.mov_mem_index('r9','rsi','rax',0,0,64)
                c.test_rr('r9','r9',64); c.jcc('nz',bad)
                c.mov_rr('rax','r8',32); c.jmp(qloop)
                c.label(tail)
                c.label(tloop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r9','rsi','rax',0,0)
                c.test_rr('r9','r9',32); c.jcc('nz',bad)
                c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode)
                c.mov_rr('rcx','r10',32)              # remaining
                c.bin_rr('xor','rdx','rdx',32)        # o=0
                c.bin_rr('xor','r8','r8',32)          # zero byte source
                c.label(eloop)
                c.cmp_imm('rcx',255,32); c.jcc('be',elast)
                c.mov_imm('r9',255,32)
                c.store8_mem_index('rdi','rdx','r9',0,0)
                c.store8_mem_index('rdi','rdx','r8',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','rcx',255,32)
                c.jmp(eloop)
                c.label(elast)
                c.test_rr('rcx','rcx',32); c.jcc('z',edone)
                c.store8_mem_index('rdi','rdx','rcx',0,0)
                c.store8_mem_index('rdi','rdx','r8',0,1)
                c.bin_imm('add','rdx',2,32)
                c.label(edone)
                c.cmp_rr('rdx','r10',32); c.jcc('ae',bad)
                comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive zero-stream decoder V2 ----------------
            if op=='rle_zero_decompress_v2':
                bad=f'__rlezd_bad_{internal}'; internal+=1
                loop=f'__rlezd_loop_{internal}'; internal+=1
                parsed=f'__rlezd_parsed_{internal}'; internal+=1
                expok=f'__rlezd_expok_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.test_rr('r10','r10',32); c.jcc('z',parsed)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.mov_rr('rax','r10',32); c.bin_imm('and','rax',1,32); c.jcc('nz',bad)
                c.bin_rr('xor','r8','r8',32)          # i=0
                c.bin_rr('xor','r9','r9',32)          # total=0
                c.label(loop)
                c.cmp_rr('r8','r10',32); c.jcc('ae',parsed)
                c.movzx8_mem_index('rcx','rsi','r8',0,0)
                c.test_rr('rcx','rcx',32); c.jcc('z',bad)
                c.movzx8_mem_index('rax','rsi','r8',0,1)
                c.test_rr('rax','rax',32); c.jcc('nz',bad)
                c.mov_rr('rdx','r9',32); c.bin_rr('add','rdx','rcx',32)
                c.cmp_rr('rdx','r9',32); c.jcc('b',bad)
                c.cmp_rr('rdx','r11',32); c.jcc('a',bad)
                c.mov_rr('r9','rdx',32); c.bin_imm('add','r8',2,32); c.jmp(loop)
                c.label(parsed)
                c.mov_mem('r8','rbx',28,32)
                c.test_rr('r8','r8',32); c.jcc('z',expok)
                c.cmp_rr('r9','r8',32); c.jcc('ne',bad)
                c.label(expok)
                # One bulk zero-fill after validating the whole stream.
                c.mov_rr('rcx','r9',32); c.bin_rr('xor','rax','rax',32); c.emit(0xF3,0xAA)
                comp_done(1,'r9')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive uniform-block compressor V3 ----------------
            if op=='rle_uniform_compress_v3':
                bad=f'__rleuc_bad_{internal}'; internal+=1
                qloop=f'__rleuc_qloop_{internal}'; internal+=1
                tail=f'__rleuc_tail_{internal}'; internal+=1
                tloop=f'__rleuc_tloop_{internal}'; internal+=1
                encode=f'__rleuc_encode_{internal}'; internal+=1
                eloop=f'__rleuc_eloop_{internal}'; internal+=1
                elast=f'__rleuc_elast_{internal}'; internal+=1
                edone=f'__rleuc_edone_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                # r9 = repeated-byte 64-bit pattern from src[0].
                c.movzx8_mem('r9','rsi',0)
                c.mov_rr('rax','r9',64); c.shift_imm('shl','rax',8,64); c.bin_rr('or','r9','rax',64)
                c.mov_rr('rax','r9',64); c.shift_imm('shl','rax',16,64); c.bin_rr('or','r9','rax',64)
                c.mov_rr('rax','r9',64); c.shift_imm('shl','rax',32,64); c.bin_rr('or','r9','rax',64)
                c.bin_rr('xor','rcx','rcx',32)        # i=0
                c.label(qloop)
                c.mov_rr('r8','rcx',32); c.bin_imm('add','r8',8,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                c.mov_mem_index('rax','rsi','rcx',0,0,64)
                c.cmp_rr('rax','r9',64); c.jcc('ne',bad)
                c.mov_rr('rcx','r8',32); c.jmp(qloop)
                c.label(tail)
                # Qword scan is finished; retain only the original byte in r9d.
                c.bin_imm('and','r9',255,32)
                c.label(tloop)
                c.cmp_rr('rcx','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r8','rsi','rcx',0,0)
                c.cmp_rr('r8','r9',32); c.jcc('ne',bad)
                c.bin_imm('add','rcx',1,32); c.jmp(tloop)
                c.label(encode)
                c.mov_rr('rcx','r10',32)              # remaining
                c.bin_rr('xor','rdx','rdx',32)        # o=0
                c.label(eloop)
                c.cmp_imm('rcx',255,32); c.jcc('be',elast)
                c.mov_imm('r8',255,32)
                c.store8_mem_index('rdi','rdx','r8',0,0)
                c.store8_mem_index('rdi','rdx','r9',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','rcx',255,32)
                c.jmp(eloop)
                c.label(elast)
                c.test_rr('rcx','rcx',32); c.jcc('z',edone)
                c.store8_mem_index('rdi','rdx','rcx',0,0)
                c.store8_mem_index('rdi','rdx','r9',0,1)
                c.bin_imm('add','rdx',2,32)
                c.label(edone)
                c.cmp_rr('rdx','r10',32); c.jcc('ae',bad)
                comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive SSE2 OR-reduction zero compressor V5 ----------------
            if op=='rle_zero_compress_reduce_v5':
                bad=f'__rlez5_bad_{internal}'; internal+=1
                vloop=f'__rlez5_vloop_{internal}'; internal+=1
                vdone=f'__rlez5_vdone_{internal}'; internal+=1
                tloop=f'__rlez5_tloop_{internal}'; internal+=1
                encode=f'__rlez5_encode_{internal}'; internal+=1
                eloop=f'__rlez5_eloop_{internal}'; internal+=1
                elast=f'__rlez5_elast_{internal}'; internal+=1
                edone=f'__rlez5_edone_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                c.emit(0x66,0x0F,0xEF,0xC0)          # pxor xmm0,xmm0 accumulator
                c.bin_rr('xor','rax','rax',32)
                c.label(vloop)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',16,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',vdone)
                # Use MOVDQU before POR so arbitrary source alignment is valid.
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi'])
                c.emit(0x66,0x0F,0xEB,0xC1)          # por xmm0,xmm1
                c.mov_rr('rax','r8',32); c.jmp(vloop)
                c.label(vdone)
                # Validate OR accumulator == 0 exactly once.
                c.emit(0x66,0x0F,0xEF,0xC9)          # pxor xmm1,xmm1
                c.emit(0x66,0x0F,0x74,0xC1)          # pcmpeqb xmm0,xmm1
                c.emit(0x66,0x0F,0xD7,0xC8)          # pmovmskb ecx,xmm0
                c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.label(tloop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r9','rsi','rax',0,0)
                c.test_rr('r9','r9',32); c.jcc('nz',bad)
                c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode)
                c.mov_rr('rcx','r10',32); c.bin_rr('xor','rdx','rdx',32); c.bin_rr('xor','r8','r8',32)
                c.label(eloop)
                c.cmp_imm('rcx',255,32); c.jcc('be',elast)
                c.mov_imm('r9',255,32); c.store8_mem_index('rdi','rdx','r9',0,0); c.store8_mem_index('rdi','rdx','r8',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','rcx',255,32); c.jmp(eloop)
                c.label(elast)
                c.test_rr('rcx','rcx',32); c.jcc('z',edone)
                c.store8_mem_index('rdi','rdx','rcx',0,0); c.store8_mem_index('rdi','rdx','r8',0,1); c.bin_imm('add','rdx',2,32)
                c.label(edone); c.cmp_rr('rdx','r10',32); c.jcc('ae',bad); comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive SSE2 XOR/OR-reduction uniform compressor V5 ----------------
            if op=='rle_uniform_compress_reduce_v5':
                bad=f'__rleu5_bad_{internal}'; internal+=1
                vloop=f'__rleu5_vloop_{internal}'; internal+=1
                vdone=f'__rleu5_vdone_{internal}'; internal+=1
                tloop=f'__rleu5_tloop_{internal}'; internal+=1
                encode=f'__rleu5_encode_{internal}'; internal+=1
                eloop=f'__rleu5_eloop_{internal}'; internal+=1
                elast=f'__rleu5_elast_{internal}'; internal+=1
                edone=f'__rleu5_edone_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                c.movzx8_mem('r9','rsi',0)
                c.emit(0x66); c.rex(0,0,0,REG['r9']); c.emit(0x0F,0x6E); c.modrm(3,0,REG['r9'])
                c.emit(0x66,0x0F,0x60,0xC0); c.emit(0x66,0x0F,0x61,0xC0); c.emit(0x66,0x0F,0x70,0xC0,0x00)
                c.emit(0x66,0x0F,0xEF,0xD2)          # pxor xmm2,xmm2 accumulator
                c.bin_rr('xor','rax','rax',32)
                c.label(vloop)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',16,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',vdone)
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi']) # movdqu xmm1,[...]
                c.emit(0x66,0x0F,0xEF,0xC8)          # pxor xmm1,xmm0
                c.emit(0x66,0x0F,0xEB,0xD1)          # por xmm2,xmm1
                c.mov_rr('rax','r8',32); c.jmp(vloop)
                c.label(vdone)
                c.emit(0x66,0x0F,0xEF,0xC9)          # pxor xmm1,xmm1
                c.emit(0x66,0x0F,0x74,0xD1)          # pcmpeqb xmm2,xmm1
                c.emit(0x66,0x0F,0xD7,0xCA)          # pmovmskb ecx,xmm2
                c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.label(tloop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r8','rsi','rax',0,0); c.cmp_rr('r8','r9',32); c.jcc('ne',bad)
                c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode)
                c.mov_rr('rcx','r10',32); c.bin_rr('xor','rdx','rdx',32)
                c.label(eloop)
                c.cmp_imm('rcx',255,32); c.jcc('be',elast)
                c.mov_imm('r8',255,32); c.store8_mem_index('rdi','rdx','r8',0,0); c.store8_mem_index('rdi','rdx','r9',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','rcx',255,32); c.jmp(eloop)
                c.label(elast)
                c.test_rr('rcx','rcx',32); c.jcc('z',edone)
                c.store8_mem_index('rdi','rdx','rcx',0,0); c.store8_mem_index('rdi','rdx','r9',0,1); c.bin_imm('add','rdx',2,32)
                c.label(edone); c.cmp_rr('rdx','r10',32); c.jcc('ae',bad); comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive 4-lane SSE2 + bulk encode zero compressor V7 ----------------
            if op=='rle_zero_compress_u4bulk_v7':
                bad=f'__rlez7_bad_{internal}'; internal+=1
                l64=f'__rlez7_l64_{internal}'; internal+=1
                l16=f'__rlez7_l16_{internal}'; internal+=1
                tail=f'__rlez7_tail_{internal}'; internal+=1
                tloop=f'__rlez7_tloop_{internal}'; internal+=1
                encode=f'__rlez7_encode_{internal}'; internal+=1
                qemit=f'__rlez7_qemit_{internal}'; internal+=1
                qdone=f'__rlez7_qdone_{internal}'; internal+=1
                remloop=f'__rlez7_remloop_{internal}'; internal+=1
                remlast=f'__rlez7_remlast_{internal}'; internal+=1
                done=f'__rlez7_done_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                # Four independent OR accumulators break the long POR dependency chain.
                c.emit(0x66,0x0F,0xEF,0xC0)          # pxor xmm0,xmm0
                c.emit(0x66,0x0F,0xEF,0xC9)          # pxor xmm1,xmm1
                c.emit(0x66,0x0F,0xEF,0xD2)          # pxor xmm2,xmm2
                c.emit(0x66,0x0F,0xEF,0xDB)          # pxor xmm3,xmm3
                c.bin_rr('xor','rax','rax',32)
                c.label(l64)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',64,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',l16)
                # movdqu xmm4,[rsi+rax + {0,16,32,48}]
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,4,4); c.sib(0,REG['rax'],REG['rsi'])
                c.emit(0x66,0x0F,0xEB,0xC4)          # por xmm0,xmm4
                for disp,modrm in ((16,0xCC),(32,0xD4),(48,0xDC)):
                    c.emit(0xF3,0x0F,0x6F); c.modrm(1,4,4); c.sib(0,REG['rax'],REG['rsi']); c.emit(disp)
                    c.emit(0x66,0x0F,0xEB,modrm)      # por xmm{1,2,3},xmm4
                c.mov_rr('rax','r8',32); c.jmp(l64)
                c.label(l16)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',16,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,4,4); c.sib(0,REG['rax'],REG['rsi'])
                c.emit(0x66,0x0F,0xEB,0xC4)          # por xmm0,xmm4
                c.mov_rr('rax','r8',32); c.jmp(l16)
                c.label(tail)
                # Collapse accumulators and reject non-zero input once.
                c.emit(0x66,0x0F,0xEB,0xC1)          # por xmm0,xmm1
                c.emit(0x66,0x0F,0xEB,0xC2)          # por xmm0,xmm2
                c.emit(0x66,0x0F,0xEB,0xC3)          # por xmm0,xmm3
                c.emit(0x66,0x0F,0xEF,0xC9)          # pxor xmm1,xmm1
                c.emit(0x66,0x0F,0x74,0xC1)          # pcmpeqb xmm0,xmm1
                c.emit(0x66,0x0F,0xD7,0xC8)          # pmovmskb ecx,xmm0
                c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.label(tloop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r9','rsi','rax',0,0); c.test_rr('r9','r9',32); c.jcc('nz',bad)
                c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode)
                # full_runs=floor(n/255), rem=n%255, output offset in rdx.
                # DIV is off hot critical validation and removes hundreds of loop branches for large blocks.
                c.mov_rr('rax','r10',32); c.bin_rr('xor','rdx','rdx',32); c.mov_imm('rcx',255,32)
                c.emit(0xF7); c.modrm(3,6,REG['rcx']) # div ecx => eax quotient, edx remainder
                c.mov_rr('r8','rax',32)               # full_runs
                c.mov_rr('r10','rdx',32)              # remainder
                c.bin_rr('xor','rdx','rdx',32)        # out offset
                # qword = four exact {255,0} pairs.
                c.mov_imm('r9',0x00ff00ff00ff00ff,64)
                c.label(qemit)
                c.cmp_imm('r8',4,32); c.jcc('b',qdone)
                c.store_mem_index('rdi','rdx','r9',0,0,64)
                c.bin_imm('add','rdx',8,32); c.bin_imm('sub','r8',4,32); c.jmp(qemit)
                c.label(qdone)
                c.label(remloop)
                c.test_rr('r8','r8',32); c.jcc('z',remlast)
                c.mov_imm('rax',255,32); c.store8_mem_index('rdi','rdx','rax',0,0)
                c.bin_rr('xor','rax','rax',32); c.store8_mem_index('rdi','rdx','rax',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','r8',1,32); c.jmp(remloop)
                c.label(remlast)
                c.test_rr('r10','r10',32); c.jcc('z',done)
                c.store8_mem_index('rdi','rdx','r10',0,0); c.bin_rr('xor','rax','rax',32); c.store8_mem_index('rdi','rdx','rax',0,1); c.bin_imm('add','rdx',2,32)
                c.label(done)
                # encoded size must still be strictly smaller than source length.
                c.mov_mem('r10','rbx',16,32); c.cmp_rr('rdx','r10',32); c.jcc('ae',bad); comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive 4-lane SSE2 + bulk encode uniform compressor V7 ----------------
            if op=='rle_uniform_compress_u4bulk_v7':
                bad=f'__rleu7_bad_{internal}'; internal+=1
                l64=f'__rleu7_l64_{internal}'; internal+=1
                l16=f'__rleu7_l16_{internal}'; internal+=1
                tail=f'__rleu7_tail_{internal}'; internal+=1
                tloop=f'__rleu7_tloop_{internal}'; internal+=1
                encode=f'__rleu7_encode_{internal}'; internal+=1
                qemit=f'__rleu7_qemit_{internal}'; internal+=1
                qdone=f'__rleu7_qdone_{internal}'; internal+=1
                remloop=f'__rleu7_remloop_{internal}'; internal+=1
                remlast=f'__rleu7_remlast_{internal}'; internal+=1
                done=f'__rleu7_done_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                c.movzx8_mem('r9','rsi',0)
                # xmm0 = repeated reference byte.
                c.emit(0x66); c.rex(0,0,0,REG['r9']); c.emit(0x0F,0x6E); c.modrm(3,0,REG['r9'])
                c.emit(0x66,0x0F,0x60,0xC0); c.emit(0x66,0x0F,0x61,0xC0); c.emit(0x66,0x0F,0x70,0xC0,0x00)
                # Four mismatch accumulators xmm2..xmm5.
                c.emit(0x66,0x0F,0xEF,0xD2); c.emit(0x66,0x0F,0xEF,0xDB); c.emit(0x66,0x0F,0xEF,0xE4); c.emit(0x66,0x0F,0xEF,0xED)
                c.bin_rr('xor','rax','rax',32)
                c.label(l64)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',64,32); c.cmp_rr('r8','r10',32); c.jcc('a',l16)
                # lane 0
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi']); c.emit(0x66,0x0F,0xEF,0xC8); c.emit(0x66,0x0F,0xEB,0xD1)
                # lanes 1..3
                for disp,por_modrm in ((16,0xD9),(32,0xE1),(48,0xE9)):
                    c.emit(0xF3,0x0F,0x6F); c.modrm(1,1,4); c.sib(0,REG['rax'],REG['rsi']); c.emit(disp)
                    c.emit(0x66,0x0F,0xEF,0xC8); c.emit(0x66,0x0F,0xEB,por_modrm)
                c.mov_rr('rax','r8',32); c.jmp(l64)
                c.label(l16)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',16,32); c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi']); c.emit(0x66,0x0F,0xEF,0xC8); c.emit(0x66,0x0F,0xEB,0xD1)
                c.mov_rr('rax','r8',32); c.jmp(l16)
                c.label(tail)
                c.emit(0x66,0x0F,0xEB,0xD3); c.emit(0x66,0x0F,0xEB,0xD4); c.emit(0x66,0x0F,0xEB,0xD5) # por xmm2,xmm3/4/5
                c.emit(0x66,0x0F,0xEF,0xC9); c.emit(0x66,0x0F,0x74,0xD1); c.emit(0x66,0x0F,0xD7,0xCA)
                c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.bin_imm('and','r9',255,32)
                c.label(tloop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r8','rsi','rax',0,0); c.cmp_rr('r8','r9',32); c.jcc('ne',bad); c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode)
                # Preserve value in r11d while DIV uses eax/edx/ecx.
                c.mov_rr('r11','r9',32)
                c.mov_rr('rax','r10',32); c.bin_rr('xor','rdx','rdx',32); c.mov_imm('rcx',255,32)
                c.emit(0xF7); c.modrm(3,6,REG['rcx'])
                c.mov_rr('r8','rax',32); c.mov_rr('r10','rdx',32); c.bin_rr('xor','rdx','rdx',32)
                # r9 = repeated little-endian pair {255,value} four times.
                c.mov_rr('r9','r11',64); c.shift_imm('shl','r9',8,64); c.bin_imm('or','r9',255,64)
                c.mov_rr('rax','r9',64); c.shift_imm('shl','rax',16,64); c.bin_rr('or','r9','rax',64)
                c.mov_rr('rax','r9',64); c.shift_imm('shl','rax',32,64); c.bin_rr('or','r9','rax',64)
                c.label(qemit)
                c.cmp_imm('r8',4,32); c.jcc('b',qdone)
                c.store_mem_index('rdi','rdx','r9',0,0,64); c.bin_imm('add','rdx',8,32); c.bin_imm('sub','r8',4,32); c.jmp(qemit)
                c.label(qdone)
                c.label(remloop)
                c.test_rr('r8','r8',32); c.jcc('z',remlast)
                c.mov_imm('rax',255,32); c.store8_mem_index('rdi','rdx','rax',0,0); c.store8_mem_index('rdi','rdx','r11',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','r8',1,32); c.jmp(remloop)
                c.label(remlast)
                c.test_rr('r10','r10',32); c.jcc('z',done)
                c.store8_mem_index('rdi','rdx','r10',0,0); c.store8_mem_index('rdi','rdx','r11',0,1); c.bin_imm('add','rdx',2,32)
                c.label(done)
                c.mov_mem('r10','rbx',16,32); c.cmp_rr('rdx','r10',32); c.jcc('ae',bad); comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive AVX2 zero compressor V10 ----------------
            if op=='rle_zero_compress_avx2_v10':
                bad=f'__rlez10_bad_{internal}'; internal+=1
                l128=f'__rlez10_l128_{internal}'; internal+=1
                l32=f'__rlez10_l32_{internal}'; internal+=1
                tail=f'__rlez10_tail_{internal}'; internal+=1
                tloop=f'__rlez10_tloop_{internal}'; internal+=1
                encode=f'__rlez10_encode_{internal}'; internal+=1
                qemit=f'__rlez10_qemit_{internal}'; internal+=1
                qdone=f'__rlez10_qdone_{internal}'; internal+=1
                remloop=f'__rlez10_remloop_{internal}'; internal+=1
                remlast=f'__rlez10_remlast_{internal}'; internal+=1
                edone=f'__rlez10_edone_{internal}'; internal+=1
                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64); c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad); c.test_rr('rsi','rsi',64); c.jcc('z',bad); c.test_rr('rdi','rdi',64); c.jcc('z',bad); c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                c.emit(0xC5,0xFD,0xEF,0xC0); c.emit(0xC5,0xF5,0xEF,0xC9); c.emit(0xC5,0xED,0xEF,0xD2); c.emit(0xC5,0xE5,0xEF,0xDB)
                c.bin_rr('xor','rax','rax',32)
                c.label(l128); c.mov_rr('r8','rax',32); c.bin_imm('add','r8',128,32); c.cmp_rr('r8','r10',32); c.jcc('a',l32)
                c.emit(0xC5,0xFE,0x6F,0x24,0x06); c.emit(0xC5,0xFD,0xEB,0xC4)
                for disp,por in ((32,0xCC),(64,0xD4),(96,0xDC)):
                    c.emit(0xC5,0xFE,0x6F,0x64,0x06,disp); c.emit(0xC5,[0xF5,0xED,0xE5][(disp//32)-1],0xEB,por)
                c.mov_rr('rax','r8',32); c.jmp(l128)
                c.label(l32); c.mov_rr('r8','rax',32); c.bin_imm('add','r8',32,32); c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                c.emit(0xC5,0xFE,0x6F,0x24,0x06); c.emit(0xC5,0xFD,0xEB,0xC4); c.mov_rr('rax','r8',32); c.jmp(l32)
                c.label(tail); c.emit(0xC5,0xFD,0xEB,0xC1); c.emit(0xC5,0xFD,0xEB,0xC2); c.emit(0xC5,0xFD,0xEB,0xC3); c.emit(0xC4,0xE2,0x7D,0x17,0xC0); c.jcc('nz',bad)
                c.label(tloop); c.cmp_rr('rax','r10',32); c.jcc('ae',encode); c.movzx8_mem_index('r9','rsi','rax',0,0); c.test_rr('r9','r9',32); c.jcc('nz',bad); c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode); c.mov_rr('rax','r10',32); c.bin_rr('xor','rdx','rdx',32); c.mov_imm('rcx',255,32); c.emit(0xF7); c.modrm(3,6,REG['rcx']); c.mov_rr('r8','rax',32); c.mov_rr('r10','rdx',32); c.bin_rr('xor','rdx','rdx',32); c.mov_imm('r9',0x00ff00ff00ff00ff,64)
                c.label(qemit); c.cmp_imm('r8',4,32); c.jcc('b',qdone); c.store_mem_index('rdi','rdx','r9',0,0,64); c.bin_imm('add','rdx',8,32); c.bin_imm('sub','r8',4,32); c.jmp(qemit)
                c.label(qdone); c.label(remloop); c.test_rr('r8','r8',32); c.jcc('z',remlast); c.mov_imm('rax',255,32); c.store8_mem_index('rdi','rdx','rax',0,0); c.bin_rr('xor','rax','rax',32); c.store8_mem_index('rdi','rdx','rax',0,1); c.bin_imm('add','rdx',2,32); c.bin_imm('sub','r8',1,32); c.jmp(remloop)
                c.label(remlast); c.test_rr('r10','r10',32); c.jcc('z',edone); c.store8_mem_index('rdi','rdx','r10',0,0); c.bin_rr('xor','rax','rax',32); c.store8_mem_index('rdi','rdx','rax',0,1); c.bin_imm('add','rdx',2,32)
                c.label(edone); c.emit(0xC5,0xF8,0x77); comp_done(1,'rdx')
                c.label(bad); c.emit(0xC5,0xF8,0x77); comp_done(0,None); continue

            # ---------------- additive AVX2 uniform compressor V10 ----------------
            if op=='rle_uniform_compress_avx2_v10':
                bad=f'__rleu10_bad_{internal}'; internal+=1
                l128=f'__rleu10_l128_{internal}'; internal+=1
                l32=f'__rleu10_l32_{internal}'; internal+=1
                tail=f'__rleu10_tail_{internal}'; internal+=1
                tloop=f'__rleu10_tloop_{internal}'; internal+=1
                encode=f'__rleu10_encode_{internal}'; internal+=1
                qemit=f'__rleu10_qemit_{internal}'; internal+=1
                qdone=f'__rleu10_qdone_{internal}'; internal+=1
                remloop=f'__rleu10_remloop_{internal}'; internal+=1
                remlast=f'__rleu10_remlast_{internal}'; internal+=1
                edone=f'__rleu10_edone_{internal}'; internal+=1
                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64); c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad); c.test_rr('rsi','rsi',64); c.jcc('z',bad); c.test_rr('rdi','rdi',64); c.jcc('z',bad); c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                c.movzx8_mem('r9','rsi',0); c.emit(0xC4,0xE2,0x7D,0x78,0x06)
                c.emit(0xC5,0xED,0xEF,0xD2); c.emit(0xC5,0xE5,0xEF,0xDB); c.emit(0xC5,0xDD,0xEF,0xE4); c.emit(0xC5,0xD5,0xEF,0xED)
                c.bin_rr('xor','rax','rax',32)
                c.label(l128); c.mov_rr('r8','rax',32); c.bin_imm('add','r8',128,32); c.cmp_rr('r8','r10',32); c.jcc('a',l32)
                # lane0
                c.emit(0xC5,0xFE,0x6F,0x0C,0x06); c.emit(0xC5,0xF5,0xEF,0xC8); c.emit(0xC5,0xED,0xEB,0xD1)
                for disp,porpref,por in ((32,0xE5,0xD9),(64,0xDD,0xE1),(96,0xD5,0xE9)):
                    c.emit(0xC5,0xFE,0x6F,0x4C,0x06,disp); c.emit(0xC5,0xF5,0xEF,0xC8); c.emit(0xC5,porpref,0xEB,por)
                c.mov_rr('rax','r8',32); c.jmp(l128)
                c.label(l32); c.mov_rr('r8','rax',32); c.bin_imm('add','r8',32,32); c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                c.emit(0xC5,0xFE,0x6F,0x0C,0x06); c.emit(0xC5,0xF5,0xEF,0xC8); c.emit(0xC5,0xED,0xEB,0xD1); c.mov_rr('rax','r8',32); c.jmp(l32)
                c.label(tail); c.emit(0xC5,0xED,0xEB,0xD3); c.emit(0xC5,0xED,0xEB,0xD4); c.emit(0xC5,0xED,0xEB,0xD5); c.emit(0xC4,0xE2,0x7D,0x17,0xD2); c.jcc('nz',bad); c.bin_imm('and','r9',255,32)
                c.label(tloop); c.cmp_rr('rax','r10',32); c.jcc('ae',encode); c.movzx8_mem_index('r8','rsi','rax',0,0); c.cmp_rr('r8','r9',32); c.jcc('ne',bad); c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode); c.mov_rr('r11','r9',32); c.mov_rr('rax','r10',32); c.bin_rr('xor','rdx','rdx',32); c.mov_imm('rcx',255,32); c.emit(0xF7); c.modrm(3,6,REG['rcx']); c.mov_rr('r8','rax',32); c.mov_rr('r10','rdx',32); c.bin_rr('xor','rdx','rdx',32)
                c.mov_rr('r9','r11',64); c.shift_imm('shl','r9',8,64); c.bin_imm('or','r9',255,64); c.mov_rr('rax','r9',64); c.shift_imm('shl','rax',16,64); c.bin_rr('or','r9','rax',64); c.mov_rr('rax','r9',64); c.shift_imm('shl','rax',32,64); c.bin_rr('or','r9','rax',64)
                c.label(qemit); c.cmp_imm('r8',4,32); c.jcc('b',qdone); c.store_mem_index('rdi','rdx','r9',0,0,64); c.bin_imm('add','rdx',8,32); c.bin_imm('sub','r8',4,32); c.jmp(qemit)
                c.label(qdone); c.label(remloop); c.test_rr('r8','r8',32); c.jcc('z',remlast); c.mov_imm('rax',255,32); c.store8_mem_index('rdi','rdx','rax',0,0); c.store8_mem_index('rdi','rdx','r11',0,1); c.bin_imm('add','rdx',2,32); c.bin_imm('sub','r8',1,32); c.jmp(remloop)
                c.label(remlast); c.test_rr('r10','r10',32); c.jcc('z',edone); c.store8_mem_index('rdi','rdx','r10',0,0); c.store8_mem_index('rdi','rdx','r11',0,1); c.bin_imm('add','rdx',2,32)
                c.label(edone); c.emit(0xC5,0xF8,0x77); comp_done(1,'rdx')
                c.label(bad); c.emit(0xC5,0xF8,0x77); comp_done(0,None); continue

            # ---------------- additive SSE2 zero-block compressor V4 ----------------
            if op=='rle_zero_compress_sse2_v4':
                bad=f'__rlez4_bad_{internal}'; internal+=1
                vloop=f'__rlez4_vloop_{internal}'; internal+=1
                tail=f'__rlez4_tail_{internal}'; internal+=1
                tloop=f'__rlez4_tloop_{internal}'; internal+=1
                encode=f'__rlez4_encode_{internal}'; internal+=1
                eloop=f'__rlez4_eloop_{internal}'; internal+=1
                elast=f'__rlez4_elast_{internal}'; internal+=1
                edone=f'__rlez4_edone_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                # xmm0 = 0. rax = byte index. Test 16 bytes at a time using
                # PCMPEQB + PMOVMSKB; 0xffff means all bytes were zero.
                c.emit(0x66,0x0F,0xEF,0xC0)          # pxor xmm0,xmm0
                c.bin_rr('xor','rax','rax',32)
                c.label(vloop)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',16,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                # movdqu xmm1,[rsi+rax]
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi'])
                c.emit(0x66,0x0F,0x74,0xC8)          # pcmpeqb xmm1,xmm0
                c.emit(0x66,0x0F,0xD7,0xC9)          # pmovmskb ecx,xmm1
                c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.mov_rr('rax','r8',32); c.jmp(vloop)
                c.label(tail)
                c.label(tloop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r9','rsi','rax',0,0)
                c.test_rr('r9','r9',32); c.jcc('nz',bad)
                c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode)
                c.mov_rr('rcx','r10',32)
                c.bin_rr('xor','rdx','rdx',32)
                c.bin_rr('xor','r8','r8',32)
                c.label(eloop)
                c.cmp_imm('rcx',255,32); c.jcc('be',elast)
                c.mov_imm('r9',255,32)
                c.store8_mem_index('rdi','rdx','r9',0,0)
                c.store8_mem_index('rdi','rdx','r8',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','rcx',255,32)
                c.jmp(eloop)
                c.label(elast)
                c.test_rr('rcx','rcx',32); c.jcc('z',edone)
                c.store8_mem_index('rdi','rdx','rcx',0,0)
                c.store8_mem_index('rdi','rdx','r8',0,1)
                c.bin_imm('add','rdx',2,32)
                c.label(edone)
                c.cmp_rr('rdx','r10',32); c.jcc('ae',bad)
                comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive SSE2 uniform-block compressor V4 ----------------
            if op=='rle_uniform_compress_sse2_v4':
                bad=f'__rleu4_bad_{internal}'; internal+=1
                vloop=f'__rleu4_vloop_{internal}'; internal+=1
                tail=f'__rleu4_tail_{internal}'; internal+=1
                tloop=f'__rleu4_tloop_{internal}'; internal+=1
                encode=f'__rleu4_encode_{internal}'; internal+=1
                eloop=f'__rleu4_eloop_{internal}'; internal+=1
                elast=f'__rleu4_elast_{internal}'; internal+=1
                edone=f'__rleu4_edone_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.cmp_imm('r10',3,32); c.jcc('b',bad)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.cmp_rr('r11','r10',32); c.jcc('b',bad)
                # r9d = reference byte. Build 16 repeated bytes directly in XMM0
                # without first synthesizing a 64-bit scalar pattern.
                c.movzx8_mem('r9','rsi',0)
                c.emit(0x66); c.rex(0,0,0,REG['r9']); c.emit(0x0F,0x6E); c.modrm(3,0,REG['r9'])  # movd xmm0,r9d
                c.emit(0x66,0x0F,0x60,0xC0)          # punpcklbw xmm0,xmm0
                c.emit(0x66,0x0F,0x61,0xC0)          # punpcklwd xmm0,xmm0
                c.emit(0x66,0x0F,0x70,0xC0,0x00)     # pshufd xmm0,xmm0,0
                c.bin_rr('xor','rax','rax',32)
                c.label(vloop)
                c.mov_rr('r8','rax',32); c.bin_imm('add','r8',16,32)
                c.cmp_rr('r8','r10',32); c.jcc('a',tail)
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi'])
                c.emit(0x66,0x0F,0x74,0xC8)          # pcmpeqb xmm1,xmm0
                c.emit(0x66,0x0F,0xD7,0xC9)          # pmovmskb ecx,xmm1
                c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.mov_rr('rax','r8',32); c.jmp(vloop)
                c.label(tail)
                c.bin_imm('and','r9',255,32)
                c.label(tloop)
                c.cmp_rr('rax','r10',32); c.jcc('ae',encode)
                c.movzx8_mem_index('r8','rsi','rax',0,0)
                c.cmp_rr('r8','r9',32); c.jcc('ne',bad)
                c.bin_imm('add','rax',1,32); c.jmp(tloop)
                c.label(encode)
                c.mov_rr('rcx','r10',32)
                c.bin_rr('xor','rdx','rdx',32)
                c.label(eloop)
                c.cmp_imm('rcx',255,32); c.jcc('be',elast)
                c.mov_imm('r8',255,32)
                c.store8_mem_index('rdi','rdx','r8',0,0)
                c.store8_mem_index('rdi','rdx','r9',0,1)
                c.bin_imm('add','rdx',2,32); c.bin_imm('sub','rcx',255,32)
                c.jmp(eloop)
                c.label(elast)
                c.test_rr('rcx','rcx',32); c.jcc('z',edone)
                c.store8_mem_index('rdi','rdx','rcx',0,0)
                c.store8_mem_index('rdi','rdx','r9',0,1)
                c.bin_imm('add','rdx',2,32)
                c.label(edone)
                c.cmp_rr('rdx','r10',32); c.jcc('ae',bad)
                comp_done(1,'rdx')
                c.label(bad); comp_done(0,None)
                continue

            # ---------------- additive uniform-stream decoder V3 ----------------
            if op=='rle_uniform_decompress_v3':
                bad=f'__rleud_bad_{internal}'; internal+=1
                loop=f'__rleud_loop_{internal}'; internal+=1
                parsed=f'__rleud_parsed_{internal}'; internal+=1
                expok=f'__rleud_expok_{internal}'; internal+=1

                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64)
                c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.test_rr('r10','r10',32); c.jcc('z',parsed)
                c.test_rr('rsi','rsi',64); c.jcc('z',bad)
                c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.mov_rr('rax','r10',32); c.bin_imm('and','rax',1,32); c.jcc('nz',bad)
                # Reference value comes from first pair; even length ensures byte 1 exists.
                c.movzx8_mem('rdx','rsi',1)
                c.bin_rr('xor','r8','r8',32)          # i=0
                c.bin_rr('xor','r9','r9',32)          # total=0
                c.label(loop)
                c.cmp_rr('r8','r10',32); c.jcc('ae',parsed)
                c.movzx8_mem_index('rcx','rsi','r8',0,0)
                c.test_rr('rcx','rcx',32); c.jcc('z',bad)
                c.movzx8_mem_index('rax','rsi','r8',0,1)
                c.cmp_rr('rax','rdx',32); c.jcc('ne',bad)
                c.mov_rr('rax','r9',32); c.bin_rr('add','rax','rcx',32)
                c.cmp_rr('rax','r9',32); c.jcc('b',bad)
                c.cmp_rr('rax','r11',32); c.jcc('a',bad)
                c.mov_rr('r9','rax',32); c.bin_imm('add','r8',2,32); c.jmp(loop)
                c.label(parsed)
                c.mov_mem('r8','rbx',28,32)
                c.test_rr('r8','r8',32); c.jcc('z',expok)
                c.cmp_rr('r9','r8',32); c.jcc('ne',bad)
                c.label(expok)
                # One bulk fill with the uniform value held in DL.
                c.mov_rr('rcx','r9',32); c.mov_rr('rax','rdx',32); c.emit(0xF3,0xAA)
                comp_done(1,'r9')
                c.label(bad); comp_done(0,None)
                continue


            # ---------------- additive canonical zero decoder V12 SSE2 ----------------
            if op=='rle_zero_decompress_canonical_sse2_v12':
                bad=f'__rlezdc12_bad_{internal}'; internal+=1
                empty=f'__rlezdc12_empty_{internal}'; internal+=1
                vloop=f'__rlezdc12_vloop_{internal}'; internal+=1
                tail=f'__rlezdc12_tail_{internal}'; internal+=1
                tloop=f'__rlezdc12_tloop_{internal}'; internal+=1
                calc=f'__rlezdc12_calc_{internal}'; internal+=1
                expok=f'__rlezdc12_expok_{internal}'; internal+=1
                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64); c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.test_rr('r10','r10',32); c.jcc('z',empty); c.test_rr('rsi','rsi',64); c.jcc('z',bad); c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.mov_rr('rax','r10',32); c.bin_imm('and','rax',1,32); c.jcc('nz',bad)
                c.mov_rr('r8','r10',32); c.bin_imm('sub','r8',2,32)
                c.movzx8_mem_index('rdx','rsi','r8',0,0); c.test_rr('rdx','rdx',32); c.jcc('z',bad)
                c.movzx8_mem_index('rax','rsi','r8',0,1); c.test_rr('rax','rax',32); c.jcc('nz',bad)
                # xmm0 = 8 canonical zero pairs {255,0}
                c.mov_imm('rcx',0x00ff00ff00ff00ff,64)
                c.emit(0x66); c.rex(1,0,0,REG['rcx']); c.emit(0x0F,0x6E); c.modrm(3,0,REG['rcx'])
                c.emit(0x66,0x0F,0x6C,0xC0)
                c.bin_rr('xor','rax','rax',32)
                c.label(vloop); c.mov_rr('r9','rax',32); c.bin_imm('add','r9',16,32); c.cmp_rr('r9','r8',32); c.jcc('a',tail)
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi'])
                c.emit(0x66,0x0F,0x74,0xC8); c.emit(0x66,0x0F,0xD7,0xC9); c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.bin_imm('add','rax',16,32); c.jmp(vloop)
                c.label(tail); c.label(tloop); c.cmp_rr('rax','r8',32); c.jcc('ae',calc)
                c.movzx8_mem_index('r9','rsi','rax',0,0); c.cmp_imm('r9',255,32); c.jcc('ne',bad); c.movzx8_mem_index('r9','rsi','rax',0,1); c.test_rr('r9','r9',32); c.jcc('nz',bad); c.bin_imm('add','rax',2,32); c.jmp(tloop)
                c.label(calc); c.mov_rr('r9','r10',32); c.shift_imm('shr','r9',1,32); c.bin_imm('sub','r9',1,32); c.imul_imm('r9','r9',255,bits=64); c.bin_rr('add','r9','rdx',64)
                c.mov_rr('rax','r9',64); c.shift_imm('shr','rax',32,64); c.test_rr('rax','rax',64); c.jcc('nz',bad); c.mov_mem('r11','rbx',20,32); c.cmp_rr('r9','r11',32); c.jcc('a',bad)
                c.mov_mem('r8','rbx',28,32); c.test_rr('r8','r8',32); c.jcc('z',expok); c.cmp_rr('r9','r8',32); c.jcc('ne',bad)
                c.label(expok); c.mov_rr('rcx','r9',32); c.bin_rr('xor','rax','rax',32); c.emit(0xF3,0xAA); comp_done(1,'r9')
                c.label(empty); c.mov_mem('r8','rbx',28,32); c.test_rr('r8','r8',32); c.jcc('nz',bad); comp_done(1,None)
                c.label(bad); comp_done(0,None); continue

            # ---------------- additive canonical uniform decoder V12 SSE2 ----------------
            if op=='rle_uniform_decompress_canonical_sse2_v12':
                bad=f'__rleudc12_bad_{internal}'; internal+=1
                empty=f'__rleudc12_empty_{internal}'; internal+=1
                vloop=f'__rleudc12_vloop_{internal}'; internal+=1
                tail=f'__rleudc12_tail_{internal}'; internal+=1
                tloop=f'__rleudc12_tloop_{internal}'; internal+=1
                calc=f'__rleudc12_calc_{internal}'; internal+=1
                expok=f'__rleudc12_expok_{internal}'; internal+=1
                c.bin_rr('xor','rax','rax',32); c.store_mem('rbx','rax',24,32)
                c.mov_mem('rsi','rbx',0,64); c.mov_mem('rdi','rbx',8,64); c.mov_mem('r10','rbx',16,32); c.mov_mem('r11','rbx',20,32)
                c.test_rr('r10','r10',32); c.jcc('z',empty); c.test_rr('rsi','rsi',64); c.jcc('z',bad); c.test_rr('rdi','rdi',64); c.jcc('z',bad)
                c.mov_rr('rax','r10',32); c.bin_imm('and','rax',1,32); c.jcc('nz',bad)
                c.movzx8_mem('rdx','rsi',1); c.mov_rr('r8','r10',32); c.bin_imm('sub','r8',2,32)
                c.movzx8_mem_index('r11','rsi','r8',0,0); c.test_rr('r11','r11',32); c.jcc('z',bad); c.movzx8_mem_index('rax','rsi','r8',0,1); c.cmp_rr('rax','rdx',32); c.jcc('ne',bad)
                c.mov_rr('rcx','rdx',64); c.shift_imm('shl','rcx',8,64); c.bin_imm('or','rcx',255,64); c.mov_rr('rax','rcx',64); c.shift_imm('shl','rax',16,64); c.bin_rr('or','rcx','rax',64); c.mov_rr('rax','rcx',64); c.shift_imm('shl','rax',32,64); c.bin_rr('or','rcx','rax',64)
                c.emit(0x66); c.rex(1,0,0,REG['rcx']); c.emit(0x0F,0x6E); c.modrm(3,0,REG['rcx']); c.emit(0x66,0x0F,0x6C,0xC0)
                c.bin_rr('xor','rax','rax',32)
                c.label(vloop); c.mov_rr('r9','rax',32); c.bin_imm('add','r9',16,32); c.cmp_rr('r9','r8',32); c.jcc('a',tail)
                c.emit(0xF3,0x0F,0x6F); c.modrm(0,1,4); c.sib(0,REG['rax'],REG['rsi']); c.emit(0x66,0x0F,0x74,0xC8); c.emit(0x66,0x0F,0xD7,0xC9); c.cmp_imm('rcx',0xffff,32); c.jcc('ne',bad)
                c.bin_imm('add','rax',16,32); c.jmp(vloop)
                c.label(tail); c.label(tloop); c.cmp_rr('rax','r8',32); c.jcc('ae',calc)
                c.movzx8_mem_index('r9','rsi','rax',0,0); c.cmp_imm('r9',255,32); c.jcc('ne',bad); c.movzx8_mem_index('r9','rsi','rax',0,1); c.cmp_rr('r9','rdx',32); c.jcc('ne',bad); c.bin_imm('add','rax',2,32); c.jmp(tloop)
                c.label(calc); c.mov_rr('r9','r10',32); c.shift_imm('shr','r9',1,32); c.bin_imm('sub','r9',1,32); c.imul_imm('r9','r9',255,bits=64); c.bin_rr('add','r9','r11',64)
                c.mov_rr('rax','r9',64); c.shift_imm('shr','rax',32,64); c.test_rr('rax','rax',64); c.jcc('nz',bad); c.mov_mem('r11','rbx',20,32); c.cmp_rr('r9','r11',32); c.jcc('a',bad)
                c.mov_mem('r8','rbx',28,32); c.test_rr('r8','r8',32); c.jcc('z',expok); c.cmp_rr('r9','r8',32); c.jcc('ne',bad)
                c.label(expok); c.mov_rr('rcx','r9',32); c.mov_rr('rax','rdx',32); c.emit(0xF3,0xAA); comp_done(1,'r9')
                c.label(empty); c.mov_mem('r8','rbx',28,32); c.test_rr('r8','r8',32); c.jcc('nz',bad); comp_done(1,None)
                c.label(bad); comp_done(0,None); continue

        # V7 additive fast paths for an already validated/initialized store.
        # Contract: req!=NULL, req->store!=NULL, capacity>0, slots!=NULL.
        # Missing IDs are still handled exactly; only repeated header validation
        # is omitted. SysV implementation uses caller-saved registers only.
        if op in ('extget_valid_v7','extexists_valid_v7'):
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)
            if target=='windows':
                # Keep Windows conservative for now: map additive exports to V1 body.
                op={'extget_valid_v7':'extget_v1','extexists_valid_v7':'extexists_v1'}[op]
            else:
                if op=='extget_valid_v7':
                    c.mov_rr('rsi',req,64)             # req
                    c.mov_mem('r9','rsi',0,64)         # store (validated)
                    c.mov_mem('rdx','r9',16,32)        # capacity
                    c.mov_mem('r11','r9',20,32)        # mask
                    c.mov_mem('rdi','r9',0,64)         # slots
                    c.mov_mem('r10','rsi',24,32)       # id
                else:
                    c.mov_mem('rsi',req,0,64)          # store (validated)
                    c.mov_mem('rdx','rsi',16,32)
                    c.mov_mem('r11','rsi',20,32)
                    c.mov_mem('r10',req,24,32)
                    c.mov_mem('rdi','rsi',0,64)

                c.imul_imm('rax','r10',0x9e3779b1,32)
                c.bin_rr('and','rax','r11',32)
                c.bin_rr('xor','rcx','rcx',32)
                loop=f'__extv7_loop_{internal}'; internal+=1
                nextp=f'__extv7_next_{internal}'; internal+=1
                notfound=f'__extv7_notfound_{internal}'; internal+=1
                found=f'__extv7_found_{internal}'; internal+=1
                c.label(loop)
                c.mov_rr('r8','rax',32)
                c.shift_imm('shl','r8',4,64)
                c.bin_rr('add','r8','rdi',64)
                c.mov_mem('r9','r8',12,32)
                c.cmp_imm('r9',0,32); c.jcc('e',notfound)
                c.cmp_imm('r9',1,32); c.jcc('ne',nextp)
                c.mov_mem('r9','r8',0,32)
                c.cmp_rr('r9','r10',32); c.jcc('e',found)
                c.label(nextp)
                c.bin_imm('add','rax',1,32)
                c.bin_rr('and','rax','r11',32)
                c.bin_imm('add','rcx',1,32)
                c.cmp_rr('rcx','rdx',32); c.jcc('b',loop)
                c.jmp(notfound)

                if op=='extexists_valid_v7':
                    c.label(found); c.mov_imm('rax',1,32); c.ret()
                    c.label(notfound); c.mov_imm('rax',0,32); c.ret()
                    continue

                c.label(found)
                c.mov_mem('rax','rsi',0,64)
                c.mov_mem('rax','rax',8,64)
                c.mov_mem('rdx','r8',4,32)
                c.bin_rr('add','rax','rdx',64)
                c.store_mem('rsi','rax',16,64)
                c.mov_mem('rdx','r8',8,32)
                c.store_mem('rsi','rdx',28,32)
                c.mov_imm('rax',1,32); c.ret()
                c.label(notfound)
                c.bin_rr('xor','rax','rax',64)
                c.store_mem('rsi','rax',16,64)
                c.store_mem('rsi','rax',28,32)
                c.mov_imm('rax',0,32); c.ret()
                continue

        if op in ('extput_v1','extget_v1','extexists_v1','extremove_v1'):
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)

            # Intrinsics are terminal V0L primitives.  They preserve all x64
            # nonvolatile GPRs they use and emit no calls/relocations.
            # rbx=req; rsi/rdi are scratch but saved for Windows/Linux ABI safety.
            c.emit(0x53,0x56,0x57)                    # push rbx,rsi,rdi
            c.mov_rr('rbx',req,64)

            def done_imm(v):
                c.mov_imm('rax',v,32)
                c.emit(0x5F,0x5E,0x5B)              # pop rdi,rsi,rbx
                c.ret()

            # Common store/header validation.
            bad=f'__ext_bad_{internal}'; internal+=1
            c.mov_mem('rsi','rbx',0,64)              # store
            c.test_rr('rsi','rsi',64); c.jcc('z',bad)
            c.mov_mem('rdx','rsi',16,32)             # capacity
            c.test_rr('rdx','rdx',32); c.jcc('z',bad)
            c.mov_mem('r11','rsi',20,32)             # mask
            c.mov_mem('rdi','rsi',0,64)              # slots
            c.test_rr('rdi','rdi',64); c.jcc('z',bad)
            c.mov_mem('r10','rbx',24,32)             # id

            # hash = id * 0x9e3779b1, idx = hash & mask
            c.imul_imm('rax','r10',0x9e3779b1,32)
            c.bin_rr('and','rax','r11',32)
            c.bin_rr('xor','rcx','rcx',32)           # probes=0

            loop=f'__ext_loop_{internal}'; internal+=1
            nextp=f'__ext_next_{internal}'; internal+=1
            notfound=f'__ext_notfound_{internal}'; internal+=1
            found=f'__ext_found_{internal}'; internal+=1
            c.label(loop)
            c.mov_rr('r8','rax',32)
            c.shift_imm('shl','r8',4,64)             # slot size 16
            c.bin_rr('add','r8','rdi',64)
            c.mov_mem('r9','r8',12,32)               # state
            c.cmp_imm('r9',0,32); c.jcc('e',notfound)
            c.cmp_imm('r9',1,32); c.jcc('ne',nextp)
            c.mov_mem('r9','r8',0,32)
            c.cmp_rr('r9','r10',32); c.jcc('e',found)
            c.label(nextp)
            c.bin_imm('add','rax',1,32)
            c.bin_rr('and','rax','r11',32)
            c.bin_imm('add','rcx',1,32)
            c.cmp_rr('rcx','rdx',32); c.jcc('b',loop)
            c.jmp(notfound)

            if op=='extexists_v1':
                c.label(found); done_imm(1)
                c.label(notfound); done_imm(0)
                c.label(bad); done_imm(0)
                continue

            if op=='extget_v1':
                c.label(found)
                c.mov_mem('rax','rsi',8,64)           # arena
                c.mov_mem('rdx','r8',4,32)            # offset
                c.bin_rr('add','rax','rdx',64)
                c.store_mem('rbx','rax',16,64)        # out_data
                c.mov_mem('rdx','r8',8,32)
                c.store_mem('rbx','rdx',28,32)        # out len
                done_imm(1)
                c.label(notfound)
                c.bin_rr('xor','rax','rax',64); c.store_mem('rbx','rax',16,64)
                c.store_mem('rbx','rax',28,32)
                done_imm(0)
                c.label(bad); done_imm(0)
                continue

            if op=='extremove_v1':
                c.label(found)
                c.mov_imm('rax',2,32); c.store_mem('r8','rax',12,32)
                c.mov_mem('rax','rsi',32,32)
                c.bin_imm('sub','rax',1,32)
                c.store_mem('rsi','rax',32,32)
                done_imm(1)
                c.label(notfound); done_imm(0)
                c.label(bad); done_imm(0)
                continue

            # PUT: pass 1 looked for an existing ID.  On miss, pass 2 finds
            # the first non-live slot (empty/tombstone). Two-pass insertion
            # keeps replacement semantics exact without needing another live
            # register in the hot lookup loop.
            put_new=f'__ext_put_new_{internal}'; internal+=1
            put_slot=f'__ext_put_slot_{internal}'; internal+=1
            put_scan=f'__ext_put_scan_{internal}'; internal+=1
            put_scan_next=f'__ext_put_scan_next_{internal}'; internal+=1
            put_noslot=f'__ext_put_noslot_{internal}'; internal+=1
            put_capacity_fail=f'__ext_put_capfail_{internal}'; internal+=1
            put_copy=f'__ext_put_copy_{internal}'; internal+=1

            c.label(found)
            c.bin_rr('xor','r9','r9',32)             # newflag=0
            c.jmp(put_slot)

            c.label(notfound)
            # Restart at hashed index; find first state != LIVE.
            c.imul_imm('rax','r10',0x9e3779b1,32)
            c.bin_rr('and','rax','r11',32)
            c.bin_rr('xor','rcx','rcx',32)
            c.label(put_scan)
            c.mov_rr('r8','rax',32); c.shift_imm('shl','r8',4,64); c.bin_rr('add','r8','rdi',64)
            c.mov_mem('r9','r8',12,32)
            c.cmp_imm('r9',1,32); c.jcc('ne',put_new)
            c.bin_imm('add','rax',1,32); c.bin_rr('and','rax','r11',32)
            c.bin_imm('add','rcx',1,32); c.cmp_rr('rcx','rdx',32); c.jcc('b',put_scan)
            c.jmp(put_noslot)

            c.label(put_new)
            c.mov_imm('r9',1,32)                     # newflag=1
            c.label(put_slot)
            # r8=slot, r9d=newflag. Validate append-only arena capacity.
            c.mov_rr('r10','rsi',64)                 # keep store across REP
            c.mov_mem('rax','r10',28,32)             # old_used
            c.mov_mem('rcx','rbx',28,32)             # len
            c.mov_rr('r11','rax',32); c.bin_rr('add','r11','rcx',32)
            c.jcc('b',put_capacity_fail)              # u32 overflow from ADD
            c.mov_mem('rdx','r10',24,32)
            c.cmp_rr('r11','rdx',32); c.jcc('a',put_capacity_fail)
            c.mov_mem('rdi','r10',8,64)              # arena
            c.test_rr('rdi','rdi',64); c.jcc('z',put_capacity_fail)
            c.bin_rr('add','rdi','rax',64)            # dst=arena+old_used
            c.mov_mem('rsi','rbx',8,64)               # src
            # len==0 is legal; REP MOVSB performs no memory access.
            c.emit(0xF3,0xA4)
            # Commit only after capacity check/copy.
            c.store_mem('r10','r11',28,32)
            c.mov_mem('rdx','rbx',24,32); c.store_mem('r8','rdx',0,32)
            c.store_mem('r8','rax',4,32)
            c.mov_mem('rdx','rbx',28,32); c.store_mem('r8','rdx',8,32)
            c.mov_imm('rdx',1,32); c.store_mem('r8','rdx',12,32)
            c.test_rr('r9','r9',32); c.jcc('z',put_copy)
            c.mov_mem('rdx','r10',32,32); c.bin_imm('add','rdx',1,32); c.store_mem('r10','rdx',32,32)
            c.label(put_copy); done_imm(1)
            c.label(put_capacity_fail); done_imm(0)
            c.label(put_noslot); done_imm(0)
            c.label(bad); done_imm(0)
            continue

        if op=='matcopyrep':
            # V0 Materializer generic primitive. Request: {dst:u64, src:u64, len:u32, flags:u32}.
            # Non-overlapping copy semantics. REP MOVSB keeps the generic path tiny.
            req=regs.get(a[0])
            if req is None: die('matcopyrep request must be in register',ins.line)
            if target=='linux':
                c.mov_mem('r10',req,0,64)
                c.mov_mem('rsi',req,8,64)
                c.mov_mem('rcx',req,16,32)
                c.mov_rr('rdi','r10',64)
                c.emit(0xF3,0xA4)
            else:
                c.emit(0x57,0x56)
                c.mov_mem('rdi',req,0,64)
                c.mov_mem('rsi',req,8,64)
                c.mov_mem('rcx',req,16,32)
                c.emit(0xF3,0xA4)
                c.emit(0x5E,0x5F)
        elif op=='matcopy128sse2':
            # Optional fixed-size 128-byte accelerator. SSE2 is baseline on x86-64; MOVDQU accepts unaligned buffers.
            req=regs.get(a[0])
            if req is None: die('matcopy128sse2 request must be in register',ins.line)
            if target=='windows': c.emit(0x57,0x56)
            c.mov_mem('rsi',req,8,64)
            c.mov_mem('rdi',req,0,64)
            for disp in range(0,128,16):
                c.emit(0xF3,0x0F,0x6F); c._mem_modrm(0,REG['rsi'],disp)
                c.emit(0xF3,0x0F,0x7F); c._mem_modrm(0,REG['rdi'],disp)
            if target=='windows': c.emit(0x5E,0x5F)
        elif op in ('matcopy16sse2','matcopy32sse2','matcopy64sse2'):
            # V3 fixed-size accelerators. MOVUPS is safe for arbitrary alignment.
            # Linux uses rsi/rdi; Windows uses volatile rdx/rax so no save/restore is needed.
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)
            n={'matcopy16sse2':16,'matcopy32sse2':32,'matcopy64sse2':64}[op]
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            cnt=n//16
            for j in range(cnt):
                c.emit(0x0F,0x10); c._mem_modrm(j,REG[srcbase],j*16)
            for j in range(cnt):
                c.emit(0x0F,0x11); c._mem_modrm(j,REG[dstbase],j*16)
        elif op=='matcopy8scalar':
            # V4 promoted: exact 8-byte copy, arbitrary alignment on x86-64.
            req=regs.get(a[0])
            if req is None: die('matcopy8scalar request must be in register',ins.line)
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            c.mov_mem('r10',srcbase,0,64)
            c.store_mem(dstbase,'r10',0,64)
        elif op=='matcopy24mixed':
            # V4 promoted: 16-byte MOVUPS + exact 8-byte tail. No over-copy.
            req=regs.get(a[0])
            if req is None: die('matcopy24mixed request must be in register',ins.line)
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            c.emit(0x0F,0x10); c._mem_modrm(0,REG[srcbase],0)
            c.mov_mem('r10',srcbase,16,64)
            c.emit(0x0F,0x11); c._mem_modrm(0,REG[dstbase],0)
            c.store_mem(dstbase,'r10',16,64)
        elif op in ('matcopy48sse2','matcopy80sse2','matcopy96sse2'):
            # V4 promoted paths: load all chunks before stores. XMM0..5 only, so
            # they remain ABI-safe on both SysV and Windows x64.
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)
            n={'matcopy48sse2':48,'matcopy80sse2':80,'matcopy96sse2':96}[op]
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            cnt=n//16
            for j in range(cnt):
                c.emit(0x0F,0x10); c._mem_modrm(j,REG[srcbase],j*16)
            for j in range(cnt):
                c.emit(0x0F,0x11); c._mem_modrm(j,REG[dstbase],j*16)
        elif op in ('matcopy40mixed','matcopy56mixed','matcopy72mixed'):
            # V5 promoted small mixed paths: k*16 + 8 bytes. Load all vector
            # chunks plus exact qword tail before stores. XMM0..3 only.
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)
            n={'matcopy40mixed':40,'matcopy56mixed':56,'matcopy72mixed':72}[op]
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            cnt=(n-8)//16
            for j in range(cnt):
                c.emit(0x0F,0x10); c._mem_modrm(j,REG[srcbase],j*16)
            c.mov_mem('r10',srcbase,cnt*16,64)
            for j in range(cnt):
                c.emit(0x0F,0x11); c._mem_modrm(j,REG[dstbase],j*16)
            c.store_mem(dstbase,'r10',cnt*16,64)
        elif op in ('matcopy88seq','matcopy104seq'):
            # V5 promoted larger mixed paths: sequential MOVUPS pairs use only
            # volatile XMM0, then copy the exact 8-byte tail. ABI-safe on both.
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)
            n={'matcopy88seq':88,'matcopy104seq':104}[op]
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            cnt=(n-8)//16
            for j in range(cnt):
                c.emit(0x0F,0x10); c._mem_modrm(0,REG[srcbase],j*16)
                c.emit(0x0F,0x11); c._mem_modrm(0,REG[dstbase],j*16)
            c.mov_mem('r10',srcbase,cnt*16,64)
            c.store_mem(dstbase,'r10',cnt*16,64)
        elif op in ('matcopy136seq','matcopy144seq','matcopy152seq','matcopy160seq'):
            # V6 promoted exact-size paths. Sequential MOVUPS pairs use only
            # volatile XMM0; optional qword tail is exact. No over-copy.
            req=regs.get(a[0])
            if req is None: die(f'{op} request must be in register',ins.line)
            n={'matcopy136seq':136,'matcopy144seq':144,'matcopy152seq':152,'matcopy160seq':160}[op]
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            cnt=n//16
            for j in range(cnt):
                c.emit(0x0F,0x10); c._mem_modrm(0,REG[srcbase],j*16)
                c.emit(0x0F,0x11); c._mem_modrm(0,REG[dstbase],j*16)
            if n-cnt*16 == 8:
                c.mov_mem('r10',srcbase,cnt*16,64)
                c.store_mem(dstbase,'r10',cnt*16,64)
        elif op=='matcopy168b6':
            # V6 promoted 168-byte path. Process vectors in batches of at most
            # six XMM registers, using only volatile XMM0..5 on Windows x64.
            # Exact final 8-byte tail; no over-copy.
            req=regs.get(a[0])
            if req is None: die('matcopy168b6 request must be in register',ins.line)
            srcbase,dstbase=('rsi','rdi') if target=='linux' else ('rdx','rax')
            c.mov_mem(srcbase,req,8,64)
            c.mov_mem(dstbase,req,0,64)
            vec=10
            basej=0
            while basej < vec:
                batch=min(6,vec-basej)
                for k in range(batch):
                    j=basej+k
                    c.emit(0x0F,0x10); c._mem_modrm(k,REG[srcbase],j*16)
                for k in range(batch):
                    j=basej+k
                    c.emit(0x0F,0x11); c._mem_modrm(k,REG[dstbase],j*16)
                basej += batch
            c.mov_mem('r10',srcbase,160,64)
            c.store_mem(dstbase,'r10',160,64)
        elif op=='ld8':
            dst,ptr,off=a; base=regs.get(ptr)
            if base is None: die('ld8 pointer must be register',ins.line)
            ov=imm(off,constants)
            if ov is not None:
                # Constant offsets belong in ModRM/SIB displacement directly;
                # do not burn a scratch register + extra instruction.
                c.movzx8_mem(regs[dst],base,ov)
            else:
                if off not in regs: die('ld8 offset must be immediate or register',ins.line)
                c.movzx8_mem_index(regs[dst],base,regs[off],0,0)
        elif op=='ld32':
            dst,ptr,off=a; base=regs.get(ptr)
            if base is None: die('ld32 pointer must be register',ins.line)
            ov=imm(off,constants)
            if ov is None: die('ld32 offset must be immediate',ins.line)
            c.mov_mem(regs[dst],base,ov,32)
        elif op=='ld64':
            dst,ptr,off=a; ov=imm(off,constants); c.mov_mem(regs[dst],regs[ptr],ov or 0,64)
        elif op=='mov': move_value(c,regs[a[0]],a[1],fn,regs,constants,TYPE_BITS[fn.vars[a[0]]])
        elif op in ('mul32','add32','sub32','xor32','or32','and32','shl32','shr32'):
            dst,x,y=a; dr=regs[dst]; xr=regs.get(x); yi=imm(y,constants); xi=imm(x,constants)
            if op=='mul32' and yi is not None and xr is not None:
                c.imul_imm(dr,xr,yi,32)
            elif op in ('shl32','shr32') and yi is not None:
                if xr is None:
                    move_value(c,dr,x,fn,regs,constants,32)
                elif dr!=xr: c.mov_rr(dr,xr,32)
                c.shift_imm('shl' if op=='shl32' else 'shr',dr,yi,32)
            else:
                if op=='and32' and yi==0xffff and xr is not None:
                    c.movzx16_rr(dr,xr)
                    continue
                if xr is None: move_value(c,dr,x,fn,regs,constants,32)
                elif dr!=xr: c.mov_rr(dr,xr,32)
                bop=op[:-2]
                if yi is not None: c.bin_imm(bop,dr,yi,32)
                else: c.bin_rr(bop,dr,regs[y],32)
        elif op=='tier4s32':
            dst,x,t1,t2,t3=a
            dr=regs[dst]; xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
            v1=imm(t1,constants); v2=imm(t2,constants); v3=imm(t3,constants)
            if None in (v1,v2,v3): die('tier4s32 thresholds must be immediate/constants',ins.line)
            done=f'__tier4_done_{internal}'; internal+=1
            # Signed 4-tier classification with one shared epilogue.
            c.mov_imm(dr,3,32); c.cmp_imm(xr,v3-1,32); c.jcc8('g',done)
            c.mov_imm(dr,2,32); c.cmp_imm(xr,v2-1,32); c.jcc8('g',done)
            c.bin_rr('xor',dr,dr,32); c.cmp_imm(xr,v1-1,32); c.setcc('g',dr)
            c.label(done)
        elif op in ('eq32','ne32','lt32','le32','gt32','ge32'):
            dst,x,y=a; xr=ensure_reg(c,x,fn,regs,constants,'r10',32); yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
            dr=regs[dst]
            # xor-zero is shorter than mov imm32, but it clobbers flags and may
            # destroy a source if linear-scan reused its register.  Use it only
            # when the destination is independent, before the compare.
            if dr!=xr and dr!=yr:
                c.bin_rr('xor',dr,dr,32); c.cmp_rr(xr,yr,32)
            else:
                c.cmp_rr(xr,yr,32); c.mov_imm(dr,0,32)
            cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]; c.setcc(cc,dr)
        elif op=='aget16':
            dst,sym,index=a
            if sticky_data is None or sticky_data not in data_offsets or sym not in data_offsets:
                c.lea_rip(data_scratch,sym); sticky_data=sym; delta=0
            else:
                delta=data_offsets[sym]-data_offsets[sticky_data]
            c.movzx16_mem_index(regs[dst],data_scratch,regs[index],1,delta)
        elif op=='eq22':
            dst,p,sym,idx=a; fail=f'__eqfail_{internal}'; done=f'__eqdone_{internal}'; internal+=1
            # r10 = &keys[id*22]
            c.lea_rip('r10',sym)
            c.imul_imm('r11',regs[idx],22,64,imm8=True)
            c.bin_rr('add','r10','r11',64)
            c.mov_imm(regs[dst],0,32)
            # Three qwords cover 0..21 exactly, with a 2-byte overlap in the tail.
            c.mov_mem('r11',regs[p],0,64); c.cmp_mem('r11','r10',0,64); c.jcc8('nz',fail)
            c.mov_mem('r11',regs[p],8,64); c.cmp_mem('r11','r10',8,64); c.jcc8('nz',fail)
            c.mov_mem('r11',regs[p],14,64); c.cmp_mem('r11','r10',14,64); c.jcc8('nz',fail)
            c.mov_imm(regs[dst],1,32); c.label(fail)
        elif op=='retif':
            cond,val=a; skip=f'__retskip_{internal}'; internal+=1
            cr=regs[cond]; c.test_rr(cr,cr,32); c.jcc8('z',skip)
            move_value(c,'rax',val,fn,regs,constants,32); c.ret(); c.label(skip)
        elif op=='ret':
            move_value(c,'rax',a[0],fn,regs,constants,32); c.ret()
        elif op=='label': c.label(a[0])
        elif op=='jmp': c.jmp(a[0])
        elif op in ('jz','jnz'):
            cr=regs[a[0]]; c.test_rr(cr,cr,32); c.jcc('z' if op=='jz' else 'nz',a[1])
        else:
            die(f'direct x64 backend does not yet implement {op}',ins.line)
    c.patch(); return bytes(c.b),c.reloc

# ----------------------------- minimal ELF64 object writer -----------------------------
def align_up(x,a): return (x+a-1)&~(a-1)

def make_strtab(names):
    b=bytearray(b'\0'); off={}
    for n in names:
        if n in off: continue
        off[n]=len(b); b.extend(n.encode()+b'\0')
    return bytes(b),off

def emit_elf(text:bytes, rodata:bytes, funcs, objects, relocs, out:pathlib.Path):
    # section indexes
    TEXT,RODATA,RELA,SYMTAB,STRTAB,SHSTRTAB=1,2,3,4,5,6
    global_names=[f['name'] for f in funcs]+[o['name'] for o in objects]
    strtab,stroff=make_strtab(global_names)
    shnames=['','.text','.rodata','.rela.text','.symtab','.strtab','.shstrtab']
    shstr,shoffname=make_strtab(shnames[1:])
    # symbols: null, local section symbols, then globals
    syms=[(0,0,0,0,0,0),(0,0x03,0,TEXT,0,0),(0,0x03,0,RODATA,0,0)]
    symidx={}
    for f in funcs:
        symidx[f['name']]=len(syms); syms.append((stroff[f['name']],0x12,0,TEXT,f['off'],f['size']))
    for o in objects:
        symidx[o['name']]=len(syms); syms.append((stroff[o['name']],0x11,0,RODATA,o['off'],o['size']))
    symtab=bytearray()
    for s in syms: symtab.extend(struct.pack('<IBBHQQ',*s))
    rela=bytearray()
    for off,sym,add in relocs:
        if sym not in symidx: raise SystemExit(f'relocation references unknown symbol {sym}')
        info=(symidx[sym]<<32)|2 # R_X86_64_PC32
        rela.extend(struct.pack('<QQq',off,info,add))
    # lay out sections after ELF header
    cur=64; sec={}
    for idx,data,al in [(TEXT,text,16),(RODATA,rodata,64),(RELA,bytes(rela),8),(SYMTAB,bytes(symtab),8),(STRTAB,strtab,1),(SHSTRTAB,shstr,1)]:
        cur=align_up(cur,al); sec[idx]=(cur,data,al); cur+=len(data)
    shoff=align_up(cur,8); shnum=7
    outb=bytearray(shoff+64*shnum)
    ident=bytearray(16); ident[:4]=b'\x7fELF'; ident[4]=2; ident[5]=1; ident[6]=1
    outb[:64]=struct.pack('<16sHHIQQQIHHHHHH',bytes(ident),1,62,1,0,0,shoff,0,64,0,0,64,shnum,SHSTRTAB)
    for idx,(off,data,al) in sec.items(): outb[off:off+len(data)]=data
    # section headers
    def sh(idx,name,typ,flags,off,size,link=0,info=0,align=1,entsz=0):
        base=shoff+idx*64; outb[base:base+64]=struct.pack('<IIQQQQIIQQ',shoffname.get(name,0),typ,flags,0,off,size,link,info,align,entsz)
    sh(TEXT,'.text',1,0x6,*sec[TEXT][:1],len(text),align=16)
    sh(RODATA,'.rodata',1,0x2,*sec[RODATA][:1],len(rodata),align=64)
    sh(RELA,'.rela.text',4,0,*sec[RELA][:1],len(rela),link=SYMTAB,info=TEXT,align=8,entsz=24)
    sh(SYMTAB,'.symtab',2,0,*sec[SYMTAB][:1],len(symtab),link=STRTAB,info=3,align=8,entsz=24)
    sh(STRTAB,'.strtab',3,0,*sec[STRTAB][:1],len(strtab),align=1)
    sh(SHSTRTAB,'.shstrtab',3,0,*sec[SHSTRTAB][:1],len(shstr),align=1)
    out.write_bytes(outb)


# ----------------------------- minimal COFF x86-64 object writer -----------------------------
def emit_coff(text:bytes, rodata:bytes, funcs, objects, relocs, out:pathlib.Path):
    # IMAGE_FILE_MACHINE_AMD64, two sections (.text/.rdata), no optional header.
    names=[f['name'] for f in funcs]+[o['name'] for o in objects]
    strdata=bytearray(); stroff={}
    for n in names:
        if len(n.encode())>8:
            stroff[n]=4+len(strdata); strdata.extend(n.encode()+b'\0')
    def nfield(n):
        b=n.encode()
        if len(b)<=8: return b.ljust(8,b'\0')
        return struct.pack('<II',0,stroff[n])
    symidx={}; symtab=bytearray(); idx=0
    for f in funcs:
        symidx[f['name']]=idx; idx+=1
        symtab.extend(struct.pack('<8sIhHBB',nfield(f['name']),f['off'],1,0x20,2,0))
    for o in objects:
        symidx[o['name']]=idx; idx+=1
        symtab.extend(struct.pack('<8sIhHBB',nfield(o['name']),o['off'],2,0,2,0))
    reloc=bytearray()
    for off,sym,add in relocs:
        if sym not in symidx: raise SystemExit(f'COFF relocation references unknown symbol {sym}')
        # IMAGE_REL_AMD64_REL32 is relative to the byte following the 32-bit field; no ELF -4 addend.
        reloc.extend(struct.pack('<IIH',off,symidx[sym],0x0004))
    header_sz=20+2*40
    text_off=align_up(header_sz,16)
    rdata_off=align_up(text_off+len(text),64)
    reloc_off=align_up(rdata_off+len(rodata),4)
    sym_off=reloc_off+len(reloc)
    strings=struct.pack('<I',4+len(strdata))+bytes(strdata)
    total=sym_off+len(symtab)+len(strings)
    b=bytearray(total)
    # COFF file header
    b[:20]=struct.pack('<HHIIIHH',0x8664,2,0,sym_off,len(symtab)//18,0,0)
    # section headers
    text_chars=0x60000020|0x00500000 # code/read/execute + align16
    data_chars=0x40000040|0x00700000 # initialized/read + align64
    b[20:60]=struct.pack('<8sIIIIIIHHI',b'.text\0\0\0',0,0,len(text),text_off,reloc_off,0,len(reloc)//10,0,text_chars)
    b[60:100]=struct.pack('<8sIIIIIIHHI',b'.rdata\0\0',0,0,len(rodata),rdata_off,0,0,0,0,data_chars)
    b[text_off:text_off+len(text)]=text
    b[rdata_off:rdata_off+len(rodata)]=rodata
    b[reloc_off:reloc_off+len(reloc)]=reloc
    b[sym_off:sym_off+len(symtab)]=symtab
    b[sym_off+len(symtab):]=strings
    out.write_bytes(b)

# ----------------------------- driver -----------------------------
def main():
    ap=argparse.ArgumentParser(description='V0L compression direct x86-64 backend (no C, no assembler)')
    ap.add_argument('input',type=pathlib.Path); ap.add_argument('output',type=pathlib.Path)
    ap.add_argument('--map',dest='mapfile',type=pathlib.Path)
    ap.add_argument('--raw-dir',type=pathlib.Path,help='also dump each function as raw machine-code bytes')
    ap.add_argument('--function',action='append',help='emit only selected function(s); may be repeated')
    ap.add_argument('--target',choices=['linux','windows'],default='linux',help='x86-64 object ABI/container')
    ns=ap.parse_args()
    txt=ns.input.read_text(); mod=parse_source(txt); constants,arrays=load_v0d(ns.input,mod.data_files)
    if ns.function:
        wanted=set(ns.function); mod.fns=[f for f in mod.fns if f.name in wanted]
        missing=wanted-{f.name for f in mod.fns}
        if missing: die('unknown function(s): '+', '.join(sorted(missing)))
    used_arrays=set()
    for fn in mod.fns:
        for ins in fn.body:
            if ins.op.startswith('aget') and len(ins.args)>=2: used_arrays.add(ins.args[1])
            elif ins.op=='eq22' and len(ins.args)>=3: used_arrays.add(ins.args[2])
    arrays=[ar for ar in arrays if ar['name'] in used_arrays]
    ro=bytearray(); objects=[]; data_offsets={}
    for ar in arrays:
        al=int(ar.get('align',1))
        while len(ro)%al: ro.append(0)
        off=len(ro); dat=bytes.fromhex(ar['data_hex']); ro.extend(dat)
        objects.append({'name':ar['name'],'off':off,'size':len(dat)}); data_offsets[ar['name']]=off
    text=bytearray(); funcs=[]; allrel=[]
    for fn in mod.fns:
        while len(text)%16:text.append(0x90)
        start=len(text); code,rels=compile_fn(fn,constants,data_offsets,ns.target); text.extend(code)
        funcs.append({'name':fn.name,'off':start,'size':len(code)})
        allrel += [(start+o,s,a) for o,s,a in rels]
    if ns.target=='linux': emit_elf(bytes(text),bytes(ro),funcs,objects,allrel,ns.output)
    else: emit_coff(bytes(text),bytes(ro),funcs,objects,allrel,ns.output)
    if ns.raw_dir:
        ns.raw_dir.mkdir(parents=True,exist_ok=True)
        for f in funcs:
            (ns.raw_dir/(f['name']+'.bin')).write_bytes(bytes(text[f['off']:f['off']+f['size']]))
    if ns.mapfile:
        ns.mapfile.write_text(json.dumps({'target':('x86_64-sysv' if ns.target=='linux' else 'x86_64-windows'),'text_bytes':len(text),'rodata_bytes':len(ro),'functions':funcs,'objects':objects,'relocations':len(allrel)},indent=2))
    print(f'{ns.output}: text={len(text)} B rodata={len(ro)} B funcs={len(funcs)} relocs={len(allrel)}')
    return 0
if __name__=='__main__': raise SystemExit(main())

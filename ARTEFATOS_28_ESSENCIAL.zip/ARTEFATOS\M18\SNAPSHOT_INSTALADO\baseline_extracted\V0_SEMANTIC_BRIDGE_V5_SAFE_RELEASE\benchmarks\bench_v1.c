#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "../include/v0_semantic_bridge.h"
typedef uint32_t(*fn_t)(const v0_semantic_record*);
uint32_t ref_semantic_id_trusted(const v0_semantic_record*);
uint32_t ref_semantic_id_safe(const v0_semantic_record*);
static volatile uint32_t sink;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static double run(fn_t f,const v0_semantic_record* a,uint32_t n){uint32_t x=0;uint64_t s=ns();for(uint32_t i=0;i<n;i++)x^=f(&a[i&4095u])+i;uint64_t e=ns();sink=x;return(double)(e-s)/n;}
static void pair(const char*name,fn_t ref,fn_t v0,const v0_semantic_record*a,uint32_t n,int flip,int round){double x,y;if(!flip){x=run(ref,a,n);y=run(v0,a,n);}else{y=run(v0,a,n);x=run(ref,a,n);}printf("%s %d %.9f %.9f %.6f\n",name,round,x,y,x/y);}
int main(void){
 const uint32_t N=30000000u; static v0_semantic_record trusted[4096],valid[4096],mixed[4096];
 for(uint32_t i=0;i<4096;i++){
   trusted[i]=(v0_semantic_record){0x12345678u+i,0x98765432u-i,0xabcdef01u^(i*2654435761u),1u};
   valid[i]=trusted[i]; mixed[i]=trusted[i]; mixed[i].valid=(i&1u);
 }
 for(int r=0;r<11;r++){
   pair("trusted",ref_semantic_id_trusted,v0_semantic_id_trusted,trusted,N,r&1,r);
   pair("safe_valid",ref_semantic_id_safe,v0_semantic_id_safe,valid,N,r&1,r);
   pair("safe_mixed50",ref_semantic_id_safe,v0_semantic_id_safe,mixed,N,r&1,r);
 }
 return sink==0xdeadbeefu;
}

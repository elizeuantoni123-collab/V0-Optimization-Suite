# Artefato 17 — Remap V22 SIMD APPLY4 candidate

This package preserves the promoted V19 baseline and adds a single specialized candidate for complete groups of four PRECHECKED APPLY operations.

Local result: 420M differential checks / 0 divergences; final performance gate 126/126 wins vs V19, median 1.149642x, minimum 1.051308x.

V22 is not a universal replacement. Keep V1/V11/V19 fallbacks. Run `windows_gate/RUN_WINDOWS_GATE.ps1` on the target Windows/Intel machine before promotion.

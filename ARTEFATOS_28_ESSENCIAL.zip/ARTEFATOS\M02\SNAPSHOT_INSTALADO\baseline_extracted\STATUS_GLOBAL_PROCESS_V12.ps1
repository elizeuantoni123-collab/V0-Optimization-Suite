$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$svc = Get-CimInstance Win32_Service -Filter "Name='V0DecisionV8'"
if (-not $svc) {
    Write-Host "V0DecisionV8 nao esta registrado." -ForegroundColor Red
    exit 2
}

Write-Host "=== V0 DECISION V12 GLOBAL PROCESS ===" -ForegroundColor Cyan
$svc | Select-Object Name, DisplayName, State, StartMode, ProcessId, PathName | Format-List

$client = Join-Path $Root "CLIENTE_DECISION_V8.ps1"
Write-Host "VERSION     : $(& $client -Command 'VERSION')"
Write-Host "STATUS      : $(& $client -Command 'STATUS')"
Write-Host "GLOBALSTATUS: $(& $client -Command 'GLOBALSTATUS')"

if ($svc.ProcessId -gt 0) {
    Get-Process -Id $svc.ProcessId -ErrorAction SilentlyContinue |
        Select-Object Id, ProcessName, CPU, WorkingSet64, Path |
        Format-List
}

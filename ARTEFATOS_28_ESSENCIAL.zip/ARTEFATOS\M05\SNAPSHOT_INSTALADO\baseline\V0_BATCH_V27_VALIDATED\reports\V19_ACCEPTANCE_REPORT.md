# V19 Acceptance Report

Status: **PROMOTED AS OPTIONAL AVX2 ACCELERATOR**.

Promotion rule: no functional/quality regression and no measured speed regression inside the promoted domain.

## Functional gate

- Exact span ABI preserved.
- 3,958,793,361 V19 checks: 0 divergences.
- Inherited suites re-run: PASS.
- Combined executed validation: 7,388,626,190 checks.
- No overwrite beyond the expected span array.
- No dependency on V0 Global.

## Performance gate

The prior real dispatch uses V11 below 4096 and V14 from 4096 upward when AVX2 is selected.

V19 was compared against that real baseline, not only against one function.

Promoted reference-host domain: **385..262144 items**.

Evidence:
- low sweep 257..511 established 385 as the first no-regression suffix in that run;
- dense 512+ sweep: 5,235 measured points, 0 regressions;
- worst 512+ dense speedup: ~1.09976x;
- representative paired speedups: 512 ~1.59x, 1024 ~2.12x, 2048 ~2.54x, 3584 ~3.07x, 4096 ~1.60x, 65536 ~1.03x, 262144 ~1.02x.

Outside this domain, the previous validated path remains the fallback.

# V0 Batch V14 ACCEL — VALIDATED

Esta release **não substitui nem altera** o V11 + IMPLICIT64 validado. Todos os arquivos herdados continuam hash-idênticos. V13/V14 entram como aceleradores opcionais em V0L.

## Estado promovido

### Baseline preservado
- `v0_batch_plan64` (V6): fallback pequeno e universal.
- `v0_batch_plan64x4` (V11): fallback materializado grande e universal.
- IMPLICIT64: caminho sem vetor temporário, somente quando o consumidor aceita spans implícitos.

### V13 `small4`
- símbolo: `v0_batch_plan64_small4`
- produção: V0L -> x86-64 direto;
- precondição lógica: `items <= 256`;
- saída: exatamente a mesma sequência `{u32 start,u32 count}` do V6;
- faixa promovida no host de validação: **64..256 itens**;
- de 0..63 o V6 permanece, porque a varredura mostrou micro-regressões em alguns valores.

### V14 AVX2
- símbolo: `v0_batch_plan64_avx2_v14`
- produção: V0L -> x86-64 direto;
- usa 4 descriptors packed por store de 256 bits;
- mantém incremento vetorial em `YMM1` para não recarregar a cada iteração;
- `vzeroupper` antes do retorno;
- mesma ABI e mesmos bytes de spans do V11;
- requer AVX2 + estado YMM habilitado pelo SO;
- V11 continua fallback obrigatório.

## Dispatch conservador validado neste host

```text
items < 64
    -> V6 v0_batch_plan64

64 <= items <= 256
    -> V13 v0_batch_plan64_small4

257 <= items < 4096
    -> V11 v0_batch_plan64x4

items >= 4096 e AVX2 disponível
    -> V14 v0_batch_plan64_avx2_v14

items >= 4096 sem AVX2
    -> V11 v0_batch_plan64x4
```

Os cutoffs de desempenho são microarquitetura-dependentes. O comportamento/correção não depende deles; somente a escolha do caminho mais rápido.

## IMPLICIT64 após V14

O cutoff antigo de 4096 **não deve mais ser tratado como universal**. V14 reduziu bastante o custo de materialização.

No workload de consumo usado nesta validação:
- 4096: implicit ~0,993x vs AVX2 materializado (ligeira perda);
- 5120: ~empate;
- 6144: ~1,008x;
- 8192: ~1,027x;
- 65536: ~1,028x;
- 262144: ~1,044x;
- 1048576: ~1,040x.

Portanto o IMPLICIT64 continua sendo a melhor arquitetura quando evita um vetor desnecessário, mas seu break-even deve ser medido no consumidor real. Neste host/workload, **8192+** é um cutoff conservador.

## Validação final

Executado no host Linux x86-64 AMD EPYC 9V74:
- testes herdados V11: **148.146.658 checks — PASS**;
- IMPLICIT64: **6.084.121 checks — PASS**;
- V13/V14 accelerator suite: **3.275.602.050 checks — PASS**;
- total da execução final: **3.429.832.829 verificações — 0 divergências**.

Além disso:
- sweep V13 `small4` em todos os valores 64..256: nenhum ponto promovido com mediana abaixo do V6;
- V14: todos os 256 restos em torno de 4096 itens ganharam do V11; pior speedup ~1,322x;
- V14: todos os 256 restos em torno de 65536 itens ganharam; pior speedup ~2,880x;
- Linux ELF64: build + execução PASS;
- Windows COFF x86-64: geração/relocations/estrutura PASS.

## Benchmark final representativo

```text
small4 64:       ~1,67x vs V6
small4 128:      ~1,43x
small4 192:      ~1,11x
small4 256:      ~1,82x

AVX2 4096:       ~1,48x vs V11
AVX2 65536:      ~1,96x
AVX2 1048576:    ~2,00x
```

Outras execuções longas chegaram perto de ~3,9x em grandes planos; os números acima são os da validação final do pacote e são os mais conservadores para referência.

## Tentativas rejeitadas nesta rodada

Não foram promovidas:
- guards novos de `count`/`count64`: ganhos mistos entre distribuições;
- `count64` branchless: não venceu uniformemente;
- V13 universal com cauda unrolled: regressões/ruído em algumas faixas, então não substitui V11;
- AVX2 unroll 2x: ganhou em grandes partes, mas perdeu em 768/1024/1536/2048 e no maior teste;
- cutoff fixo IMPLICIT64=4096: aposentado quando AVX2 está ativo.

## Integridade

`HASHES.sha256` e `HASHES_IMPLICIT64.sha256` continuam válidos para todos os arquivos herdados. Veja `reports/v14/BASELINE_*_HASH_RECHECK_FINAL.txt`.

## Build

Baseline:
```bash
./BUILD_LINUX.sh
```

Aceleradores:
```bash
./BUILD_ACCEL_LINUX.sh
```

Teste completo:
```bash
./TEST_ACCEL_LINUX.sh
```

Windows: `BUILD_WINDOWS.ps1` + `BUILD_ACCEL_WINDOWS.ps1`.

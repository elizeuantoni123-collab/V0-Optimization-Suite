#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_batch_accel.h"
extern uint32_t v0_batch_plan64_avx2_dual_v19(v0_batch_span*,uint32_t);typedef uint32_t(*F)(v0_batch_span*,uint32_t);static volatile uint64_t sink;static uint32_t rs=0xc4a71539u;static uint32_t xr(void){rs^=rs<<13;rs^=rs>>17;rs^=rs<<5;return rs;}static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}static uint64_t run(F f,v0_batch_span*b,uint32_t n,uint32_t reps){uint64_t z=0,t=ns();for(uint32_t r=0;r<reps;r++){uint32_t k=f(b,n);z+=k;if(k)z+=b[k-1].start+b[k-1].count;}uint64_t e=ns();sink+=z;return e-t;}static double one(uint32_t n,v0_batch_span*a,v0_batch_span*b){double A[11],B[11];for(int r=0;r<11;r++){uint64_t p,q;if(xr()&1){q=run(v0_batch_plan64_avx2_dual_v19,b,n,120000);p=run(v0_batch_plan64x4,a,n,120000);}else{p=run(v0_batch_plan64x4,a,n,120000);q=run(v0_batch_plan64_avx2_dual_v19,b,n,120000);}A[r]=(double)p/120000;B[r]=(double)q/120000;}qsort(A,11,sizeof(double),cmpd);qsort(B,11,sizeof(double),cmpd);return A[5]/B[5];}
int main(void){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);v0_batch_span a[16],b[16];FILE*f=fopen("reports/V19_LOW_SWEEP.csv","w");fprintf(f,"n,speedup\n");double worst=99;uint32_t wn=0,reg=0,total=0;for(uint32_t n=257;n<=511;n++){double sp=one(n,a,b);fprintf(f,"%u,%.9f\n",n,sp);total++;if(sp<worst){worst=sp;wn=n;}if(sp<1)reg++;}fclose(f);printf("low total=%u regressions=%u worst=%.6fx n=%u sink=%llu\n",total,reg,worst,wn,(unsigned long long)sink);return 0;}

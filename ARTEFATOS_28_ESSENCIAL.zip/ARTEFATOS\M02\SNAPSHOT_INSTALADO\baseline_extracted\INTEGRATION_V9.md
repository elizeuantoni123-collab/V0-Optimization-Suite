# ULTRA V9 integration

Include:

```c
#include "v0_decision_v8_ultra_v9.h"
```

For AVX2 raw batches:

```c
v0_eval_v8_raw_batch_ultra_v9_avx2_u8(
    value, cost, temperature, pinned, out, n);
```

For preflight-only scans:

```c
uint64_t execute_count = v0_preflight_v8_raw_count_ultra_v9_avx2(
    value, cost, temperature, pinned, n);
```

For a 16-item scheduler/filter block that can consume a bitmap directly:

```c
uint16_t execute_mask = v0_preflight_v8_raw_mask16_ultra_v9_avx2(
    value, cost, temperature, pinned);
```

The bitmap path avoids materializing one preflight byte per item.

Do **not** replace the V8 AVX-512 raw path with this AVX2 function on CPUs where the V8 AVX-512 path is faster. V9 is additive and ISA-specific.

#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "v0_decision_v7.h"
#include "v0_decision_v8_adaptive.h"
#include "v0_decision_v8_fast.h"
#include "v0_decision_v8_extreme.h"

#define SERVICE_NAME_A "V0DecisionV8"
#define PIPE_NAME_A "\\\\.\\pipe\\V0DecisionV8"

static SERVICE_STATUS_HANDLE g_status_handle = NULL;
static SERVICE_STATUS g_status;
static HANDLE g_stop_event = NULL;
static HANDLE g_worker = NULL;
static CRITICAL_SECTION g_lock;
static v0_v8_state_t g_v8;

static const char *mode_name(uint32_t mode) {
    return mode == V0_V8_FILTER ? "FILTER" : "BYPASS";
}

static const char *phase_name(uint32_t phase) {
    switch (phase) {
        case V0_V8_PROBE_A: return "PROBE_A";
        case V0_V8_PROBE_B: return "PROBE_B";
        case V0_V8_ACTIVE:  return "ACTIVE";
        default: return "UNKNOWN";
    }
}

static void set_service_status(DWORD state, DWORD win32_exit, DWORD wait_hint) {
    static DWORD checkpoint = 1;
    ZeroMemory(&g_status, sizeof(g_status));
    g_status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    g_status.dwCurrentState = state;
    g_status.dwWin32ExitCode = win32_exit;
    g_status.dwWaitHint = wait_hint;
    if (state == SERVICE_START_PENDING || state == SERVICE_STOP_PENDING) {
        g_status.dwControlsAccepted = 0;
        g_status.dwCheckPoint = checkpoint++;
    } else {
        g_status.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
        g_status.dwCheckPoint = 0;
    }
    if (state == SERVICE_STOPPED) g_status.dwControlsAccepted = 0;
    if (g_status_handle) SetServiceStatus(g_status_handle, &g_status);
}

static void write_response(HANDLE pipe, const char *text) {
    char out[1024];
    DWORD written = 0;
    _snprintf(out, sizeof(out) - 1, "%s\r\n", text ? text : "");
    out[sizeof(out) - 1] = '\0';
    WriteFile(pipe, out, (DWORD)strlen(out), &written, NULL);
}

static void handle_command(HANDLE pipe, char *cmd) {
    char response[1024];
    unsigned value, cost, temp, pinned;
    unsigned mode, count;
    unsigned long long ticks;

    while (*cmd == ' ' || *cmd == '\t') ++cmd;
    for (char *p = cmd; *p; ++p) {
        if (*p == '\r' || *p == '\n') { *p = '\0'; break; }
    }

    if (_stricmp(cmd, "PING") == 0) {
        write_response(pipe, "PONG V0DecisionV8");
        return;
    }

    if (_stricmp(cmd, "RESET") == 0) {
        EnterCriticalSection(&g_lock);
        v0_v8_init(&g_v8, v0_v8_default_config());
        LeaveCriticalSection(&g_lock);
        write_response(pipe, "OK RESET mode=BYPASS phase=PROBE_A");
        return;
    }

    if (_stricmp(cmd, "STATUS") == 0) {
        EnterCriticalSection(&g_lock);
        _snprintf(response, sizeof(response) - 1,
                  "OK mode=%s phase=%s epoch=%u probes=%u switches_filter=%u switches_bypass=%u probe_count=%u active_count=%u margin_permille=%u",
                  mode_name(g_v8.selected_mode), phase_name(g_v8.phase),
                  g_v8.epoch, g_v8.probes_completed,
                  g_v8.switches_to_filter, g_v8.switches_to_bypass,
                  g_v8.cfg.probe_count, g_v8.cfg.active_count,
                  (unsigned)g_v8.cfg.switch_margin_permille);
        LeaveCriticalSection(&g_lock);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (_stricmp(cmd, "PLAN") == 0) {
        v0_v8_plan_t p;
        EnterCriticalSection(&g_lock);
        p = v0_v8_plan(&g_v8);
        LeaveCriticalSection(&g_lock);
        _snprintf(response, sizeof(response) - 1,
                  "OK mode=%s mode_id=%u count=%u measure=%u authoritative=%u",
                  mode_name(p.mode), p.mode, p.count, p.measure, p.authoritative);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (sscanf(cmd, "COMPLETE %u %llu %u", &mode, &ticks, &count) == 3) {
        if (mode > 1u || count == 0u) {
            write_response(pipe, "ERR COMPLETE expects: mode(0|1) ticks count>0");
            return;
        }
        EnterCriticalSection(&g_lock);
        v0_v8_complete(&g_v8, mode, (uint64_t)ticks, count);
        _snprintf(response, sizeof(response) - 1,
                  "OK mode=%s phase=%s epoch=%u probes=%u switches_filter=%u switches_bypass=%u",
                  mode_name(g_v8.selected_mode), phase_name(g_v8.phase),
                  g_v8.epoch, g_v8.probes_completed,
                  g_v8.switches_to_filter, g_v8.switches_to_bypass);
        LeaveCriticalSection(&g_lock);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (sscanf(cmd, "DECIDE %u %u %u %u", &value, &cost, &temp, &pinned) == 4) {
        if (value > 65535u || cost > 65535u || temp > 2u || pinned > 1u) {
            write_response(pipe, "ERR DECIDE ranges: value/cost 0..65535 temp 0..2 pinned 0..1");
            return;
        }
        {
            const uint32_t packed = v0_eval_v8_raw_ultra_inline(
                (uint16_t)value, (uint16_t)cost, (uint8_t)temp, (uint8_t)pinned);
            const uint32_t pre = v0_eval_v8_preflight(packed);
            const uint32_t dec = v0_eval_v8_decision(packed);
            EnterCriticalSection(&g_lock);
            _snprintf(response, sizeof(response) - 1,
                      "OK preflight=%u decision=%u controller_mode=%s",
                      pre, dec, mode_name(g_v8.selected_mode));
            LeaveCriticalSection(&g_lock);
            response[sizeof(response) - 1] = '\0';
            write_response(pipe, response);
            return;
        }
    }

    write_response(pipe,
        "ERR commands: PING | STATUS | RESET | DECIDE value cost temp pinned | PLAN | COMPLETE mode ticks count");
}

static DWORD WINAPI pipe_worker(LPVOID unused) {
    (void)unused;
    while (WaitForSingleObject(g_stop_event, 0) != WAIT_OBJECT_0) {
        HANDLE pipe = CreateNamedPipeA(
            PIPE_NAME_A,
            PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
            PIPE_UNLIMITED_INSTANCES,
            4096, 4096, 0, NULL);

        if (pipe == INVALID_HANDLE_VALUE) {
            Sleep(1000);
            continue;
        }

        BOOL connected = ConnectNamedPipe(pipe, NULL)
            ? TRUE
            : (GetLastError() == ERROR_PIPE_CONNECTED);

        if (connected && WaitForSingleObject(g_stop_event, 0) != WAIT_OBJECT_0) {
            /*
             * V4 keeps the connection alive for multiple commands. Old V3 clients
             * still work because they simply disconnect after the first reply.
             * This removes ConnectNamedPipe/DisconnectNamedPipe from repeated calls.
             */
            for (;;) {
                char input[1024];
                DWORD got = 0;
                BOOL ok;
                if (WaitForSingleObject(g_stop_event, 0) == WAIT_OBJECT_0) break;
                ZeroMemory(input, sizeof(input));
                ok = ReadFile(pipe, input, sizeof(input) - 1, &got, NULL);
                if (!ok || got == 0) break;
                input[got] = '\0';
                handle_command(pipe, input);
            }
        }

        DisconnectNamedPipe(pipe);
        CloseHandle(pipe);
    }
    return 0;
}

static DWORD WINAPI service_ctrl(DWORD control, DWORD event_type, LPVOID event_data, LPVOID context) {
    (void)event_type; (void)event_data; (void)context;
    if (control == SERVICE_CONTROL_STOP || control == SERVICE_CONTROL_SHUTDOWN) {
        set_service_status(SERVICE_STOP_PENDING, NO_ERROR, 3000);
        if (g_stop_event) SetEvent(g_stop_event);

        /* Wake a blocking ConnectNamedPipe so the worker can observe stop. */
        {
            HANDLE h = CreateFileA(PIPE_NAME_A, GENERIC_READ | GENERIC_WRITE,
                                   0, NULL, OPEN_EXISTING, 0, NULL);
            if (h != INVALID_HANDLE_VALUE) CloseHandle(h);
        }
        return NO_ERROR;
    }
    return NO_ERROR;
}

static VOID WINAPI service_main(DWORD argc, LPSTR *argv) {
    (void)argc; (void)argv;
    g_status_handle = RegisterServiceCtrlHandlerExA(SERVICE_NAME_A, service_ctrl, NULL);
    if (!g_status_handle) return;

    set_service_status(SERVICE_START_PENDING, NO_ERROR, 3000);

    InitializeCriticalSection(&g_lock);
    v0_v8_init(&g_v8, v0_v8_default_config());

    g_stop_event = CreateEventA(NULL, TRUE, FALSE, NULL);
    if (!g_stop_event) {
        DeleteCriticalSection(&g_lock);
        set_service_status(SERVICE_STOPPED, GetLastError(), 0);
        return;
    }

    g_worker = CreateThread(NULL, 0, pipe_worker, NULL, 0, NULL);
    if (!g_worker) {
        DWORD e = GetLastError();
        CloseHandle(g_stop_event); g_stop_event = NULL;
        DeleteCriticalSection(&g_lock);
        set_service_status(SERVICE_STOPPED, e, 0);
        return;
    }

    set_service_status(SERVICE_RUNNING, NO_ERROR, 0);
    WaitForSingleObject(g_stop_event, INFINITE);
    WaitForSingleObject(g_worker, 5000);

    CloseHandle(g_worker); g_worker = NULL;
    CloseHandle(g_stop_event); g_stop_event = NULL;
    DeleteCriticalSection(&g_lock);
    set_service_status(SERVICE_STOPPED, NO_ERROR, 0);
}

int main(void) {
    SERVICE_TABLE_ENTRYA table[] = {
        { SERVICE_NAME_A, service_main },
        { NULL, NULL }
    };

    if (!StartServiceCtrlDispatcherA(table)) {
        DWORD e = GetLastError();
        if (e == ERROR_FAILED_SERVICE_CONTROLLER_CONNECT) {
            fprintf(stderr, "V0DecisionV8Service deve ser iniciado pelo Windows Service Control Manager.\n");
            fprintf(stderr, "Use INSTALAR_E_ATIVAR_PERMANENTE.ps1.\n");
        }
        return (int)e;
    }
    return 0;
}

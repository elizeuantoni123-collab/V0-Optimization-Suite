# Artefato 20 — V0 Module Manager V13 -> V14 MATCHES8 SNAPSHOT SQUEEZE

Estado: **LOCAL_PASS / WINDOWS_GATE_REQUIRED**.

A baseline V13 SAFE está preservada integralmente em `baseline/`.

O candidato V14 adiciona somente `v0_mm_matches8_snapshot_v14(state, queries)`. Ele lê `enabled_mask` uma vez e avalia oito pares `{required_on, required_off}` em paralelo com AVX2, retornando os oito resultados em um bitmask.

O fast path só é válido quando as oito consultas devem observar o **mesmo snapshot**. As APIs V13 existentes continuam sendo o caminho universal.

Consulte `REPORT.md` e `DISPATCH_CANDIDATE.md`.

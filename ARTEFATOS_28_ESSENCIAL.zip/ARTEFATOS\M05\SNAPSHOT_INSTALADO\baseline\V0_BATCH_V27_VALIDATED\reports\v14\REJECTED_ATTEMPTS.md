# Tentativas rejeitadas

- direct-zero guards em count: melhoraram vários cenários, mas perderam em outros -> não promovidos.
- count64 branchless: resultados mistos por distribuição -> não promovido.
- V13 universal tail-unrolled: bom em muitos pontos, porém não uniforme -> não substitui V11.
- AVX2 com incremento lido da memória: correto e rápido, mas V14 com incremento em YMM1 foi superior em grandes lotes.
- AVX2 unroll 2x: regressões em múltiplos tamanhos e no maior teste -> rejeitado.
- IMPLICIT64 cutoff fixo 4096 com V14: não preserva velocidade -> regra aposentada.

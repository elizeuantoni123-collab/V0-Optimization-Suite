$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$Src = Join-Path $Root "tests\benchmark_v8_ultra_v8_windows.c"
$Include = Join-Path $Root "include"
$OutDir = Join-Path $Root "windows_permanent\build"
$Exe = Join-Path $OutDir "BenchmarkV8UltraV8.exe"
$vcvarsCandidates = @(
 "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
 "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat",
 "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat",
 "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat")
$VcVars = $vcvarsCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $VcVars) { throw "Visual Studio 2022 C++ Build Tools x64 nao encontrado." }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
Write-Host "V0 Decision V8 ULTRA V8 - benchmark Windows AVX2" -ForegroundColor Cyan
Write-Host "Comparacao pareada V7 x V8 no mesmo executavel." -ForegroundColor Yellow
$cmd = "`"$VcVars`" && cl /nologo /O2 /Ot /Oi /Ob3 /Qvec- /arch:AVX2 /D__AVX2__=1 /I`"$Include`" `"$Src`" /Fe:`"$Exe`""
cmd /c $cmd
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $Exe)) { throw "Falha ao compilar benchmark V8." }
& $Exe
if ($LASTEXITCODE -ne 0) { throw "Benchmark V8 falhou (exit $LASTEXITCODE)." }

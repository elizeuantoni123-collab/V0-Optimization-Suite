#ifndef V0_REMAP_ABI_H
#define V0_REMAP_ABI_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint32_t source_id;
    uint32_t target_id;
    uint32_t version;
    uint32_t checksum_tag;
    uint32_t rollback_target;
    uint32_t rollback_version;
    uint32_t rollback_checksum;
    uint32_t guard;
    uint32_t rollback_valid;
} v0_remap_desc; /* 36 bytes */

typedef struct {
    uint32_t expected_target;
    uint32_t expected_version;
    uint32_t expected_checksum;
    uint32_t new_target;
    uint32_t new_checksum;
} v0_remap_req; /* 20 bytes */

/* V1 SAFE — universal */
uint32_t v0_remap_seal_v1(void *desc);
uint32_t v0_remap_validate_v1(void *desc);
uint32_t v0_remap_resolve_v1(void *desc);
uint32_t v0_remap_apply_v1(void *desc, void *req);
uint32_t v0_remap_rollback_v1(void *desc, void *req);

/* V11 SAFE PRECHECKED — scalar fast path; caller must prove V11 preconditions. */
uint32_t v0_remap_apply_prechecked_v11(void *desc, void *req);
uint32_t v0_remap_rollback_prechecked_v11(void *desc, void *req);

/* V19 SAFE PRECHECKED BATCH4 — exactly four contiguous descriptors + requests.
   Every lane independently satisfies the V11 PRECHECKED contract.
   Equivalent to four scalar V11 calls. */
uint32_t v0_remap_apply4_prechecked_v19(void *desc4, void *req4);
uint32_t v0_remap_rollback4_prechecked_v19(void *desc4, void *req4);

#ifdef __cplusplus
}
#endif
#endif

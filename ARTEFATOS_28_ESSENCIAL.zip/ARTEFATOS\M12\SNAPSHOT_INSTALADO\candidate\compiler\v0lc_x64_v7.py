#!/usr/bin/env python3
"""V0L -> x86-64 direct backend.

Emits ELF64 relocatable objects itself. No C backend and no assembler are used.
Target ABI: System V AMD64, little-endian x86-64.
"""
from __future__ import annotations
import argparse, json, pathlib, re, struct, sys
from dataclasses import dataclass, field

# ----------------------------- parsing -----------------------------
TYPE_BITS={'u8':8,'u16':16,'u32':32,'u64':64,'i32':32,'ptr':64}
IMM_RE=re.compile(r'-?0x[0-9a-fA-F]+|-?\d+$')
NAME_RE=re.compile(r'[A-Za-z_]\w*$')

@dataclass
class Ins:
    op:str; args:list[str]; line:int
@dataclass
class Fn:
    name:str; params:list[tuple[str,str]]; ret:str; body:list[Ins]=field(default_factory=list); vars:dict[str,str]=field(default_factory=dict)
@dataclass
class Module:
    data_files:list[str]; fns:list[Fn]

def die(msg,line=None):
    p=f'line {line}: ' if line else ''
    raise SystemExit(p+msg)

def parse_source(txt:str)->Module:
    data_files=[]; fns=[]; cur=None
    for ln,raw in enumerate(txt.splitlines(),1):
        s=raw.split('#',1)[0].strip()
        if not s: continue
        t=s.split(); op=t[0]
        if op=='data':
            if cur: die('data directive inside function',ln)
            if len(t)!=2: die('data expects one path',ln)
            data_files.append(t[1]); continue
        if op=='fn':
            if cur: die('nested fn',ln)
            if '->' not in t: die('fn requires -> return-type',ln)
            k=t.index('->'); name=t[1]; ret=t[k+1]
            if not NAME_RE.fullmatch(name) or ret not in TYPE_BITS: die('bad function signature',ln)
            params=[]; vars={}
            for a in t[2:k]:
                if ':' not in a: die('parameter must be name:type',ln)
                n,ty=a.split(':',1)
                if not NAME_RE.fullmatch(n) or ty not in TYPE_BITS: die('bad parameter',ln)
                params.append((n,ty)); vars[n]=ty
            cur=Fn(name,params,ret,vars=vars); fns.append(cur); continue
        if op=='end':
            if not cur: die('end outside fn',ln)
            cur=None; continue
        if not cur: die('instruction outside function',ln)
        if op=='let':
            if len(t)!=3 or t[2] not in TYPE_BITS: die('bad let',ln)
            cur.vars[t[1]]=t[2]
        cur.body.append(Ins(op,t[1:],ln))
    if cur: die('unterminated function')
    return Module(data_files,fns)

# ----------------------------- V0D data -----------------------------
def load_v0d(src_path:pathlib.Path, names:list[str]):
    constants={}; arrays=[]
    for n in names:
        p=(src_path.parent.parent/'generated'/n) if not (src_path.parent/n).exists() else (src_path.parent/n)
        if not p.exists():
            p=src_path.parent/n
        if not p.exists(): die(f'data file not found: {n}')
        d=json.loads(p.read_text())
        if d.get('format')!='V0D1': die(f'unsupported data format in {p}')
        constants.update({k:int(v) for k,v in d.get('constants',{}).items()})
        arrays.extend(d.get('arrays',[]))
    return constants,arrays

# ----------------------------- x86 encoder -----------------------------
REG={
 'rax':0,'rcx':1,'rdx':2,'rbx':3,'rsp':4,'rbp':5,'rsi':6,'rdi':7,
 'r8':8,'r9':9,'r10':10,'r11':11,'r12':12,'r13':13,'r14':14,'r15':15,
}
# allocator pool; rsi/r10/r11 are backend scratch, rdi is first pointer arg.
ALLOC=['rax','rcx','rdx','r8','r9']

class Code:
    def __init__(self): self.b=bytearray(); self.reloc=[]; self.labels={}; self.fix=[]; self.fix8=[]
    def tell(self): return len(self.b)
    def emit(self,*xs): self.b.extend(xs)
    def u32(self,x): self.b.extend(struct.pack('<I',x & 0xffffffff))
    def i32(self,x): self.b.extend(struct.pack('<i',x))
    def rex(self,w=0,r=0,x=0,b=0,force=False):
        v=0x40|(w<<3)|((r>>3)&1)<<2|((x>>3)&1)<<1|((b>>3)&1)
        if v!=0x40 or force: self.emit(v)
    def modrm(self,mod,reg,rm): self.emit(((mod&3)<<6)|((reg&7)<<3)|(rm&7))
    def sib(self,scale,index,base): self.emit(((scale&3)<<6)|((index&7)<<3)|(base&7))
    def mov_rr(self,dst,src,bits=32):
        d=REG[dst]; s=REG[src]; self.rex(bits==64,s,0,d); self.emit(0x89); self.modrm(3,s,d)
    def mov_imm(self,dst,val,bits=32):
        d=REG[dst]
        if bits==64:
            self.rex(1,0,0,d); self.emit(0xB8+(d&7)); self.b.extend(struct.pack('<Q',val & 0xffffffffffffffff))
        else:
            self.rex(0,0,0,d); self.emit(0xB8+(d&7)); self.u32(val)
    def mov_mem(self,dst,base,disp=0,bits=32):
        d=REG[dst]; ba=REG[base]; self.rex(bits==64,d,0,ba); self.emit(0x8B)
        self._mem_modrm(d,ba,disp)
    def mov_mem_index(self,dst,base,index,scale=2,disp=0,bits=32):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(bits==64,d,ix,ba); self.emit(0x8B)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def mov_store(self,base,disp,src,bits=32):
        sr=REG[src]; ba=REG[base]; self.rex(bits==64,sr,0,ba); self.emit(0x89); self._mem_modrm(sr,ba,disp)
    def lea_disp(self,dst,base,disp=0,bits=32):
        d=REG[dst]; ba=REG[base]; self.rex(bits==64,d,0,ba); self.emit(0x8D); self._mem_modrm(d,ba,disp)
    def mov_imm_mem(self,base,disp,val,bits=32):
        ba=REG[base]; self.rex(bits==64,0,0,ba); self.emit(0xC7); self._mem_modrm(0,ba,disp); self.u32(val)
    def movzx8_mem_index(self,dst,base,index,scale=0,disp=0):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(0,d,ix,ba); self.emit(0x0F,0xB6)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def movdqu_load(self,xmm,base,disp=0):
        ba=REG[base]; self.emit(0xF3); self.rex(0,xmm,0,ba); self.emit(0x0F,0x6F); self._mem_modrm(xmm,ba,disp)
    def movq_xmm_mem(self,xmm,base,disp=0):
        ba=REG[base]; self.emit(0xF3); self.rex(0,xmm,0,ba); self.emit(0x0F,0x7E); self._mem_modrm(xmm,ba,disp)
    def punpcklqdq(self,dst_xmm,src_xmm):
        self.emit(0x66); self.rex(0,dst_xmm,0,src_xmm); self.emit(0x0F,0x6C); self.modrm(3,dst_xmm,src_xmm)
    def movdqu_store(self,base,disp,xmm):
        ba=REG[base]; self.emit(0xF3); self.rex(0,xmm,0,ba); self.emit(0x0F,0x7F); self._mem_modrm(xmm,ba,disp)
    def movdqu_load_index(self,xmm,base,index,scale=2,disp=0):
        ba=REG[base]; ix=REG[index]; self.emit(0xF3); self.rex(0,xmm,ix,ba); self.emit(0x0F,0x6F)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,xmm,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def pshufd(self,dst_xmm,src_xmm,imm8):
        self.emit(0x66); self.rex(0,dst_xmm,0,src_xmm); self.emit(0x0F,0x70); self.modrm(3,dst_xmm,src_xmm); self.emit(imm8&255)
    def movd_xmm_reg32(self,xmm,reg):
        r=REG[reg]; self.emit(0x66); self.rex(0,xmm,0,r); self.emit(0x0F,0x6E); self.modrm(3,xmm,r)
    def movdqa_rr(self,dst_xmm,src_xmm):
        self.emit(0x66); self.rex(0,dst_xmm,0,src_xmm); self.emit(0x0F,0x6F); self.modrm(3,dst_xmm,src_xmm)
    def psubd(self,dst_xmm,src_xmm):
        self.emit(0x66); self.rex(0,dst_xmm,0,src_xmm); self.emit(0x0F,0xFA); self.modrm(3,dst_xmm,src_xmm)
    def pcmpeqd(self,dst_xmm,src_xmm):
        self.emit(0x66); self.rex(0,dst_xmm,0,src_xmm); self.emit(0x0F,0x76); self.modrm(3,dst_xmm,src_xmm)
    def por_xmm(self,dst_xmm,src_xmm):
        self.emit(0x66); self.rex(0,dst_xmm,0,src_xmm); self.emit(0x0F,0xEB); self.modrm(3,dst_xmm,src_xmm)
    def movmskps(self,dst,src_xmm):
        d=REG[dst]; self.rex(0,d,0,src_xmm); self.emit(0x0F,0x50); self.modrm(3,d,src_xmm)
    def movdqu_load_rip(self,xmm,sym):
        self.emit(0xF3); self.rex(0,xmm,0,0); self.emit(0x0F,0x6F); self.modrm(0,xmm,5); off=self.tell(); self.u32(0); self.reloc.append((off,sym,-4))
    def cmp_rr(self,a,b,bits=32):
        # flags from a-b
        ra=REG[a]; rb=REG[b]; self.rex(bits==64,rb,0,ra); self.emit(0x39); self.modrm(3,rb,ra)
    def cmp_mem(self,reg,base,disp=0,bits=32):
        r=REG[reg]; ba=REG[base]
        if bits==16: self.emit(0x66)
        self.rex(bits==64,r,0,ba); self.emit(0x3B); self._mem_modrm(r,ba,disp)
    def setcc(self,cc,dst):
        d=REG[dst]; op={'e':0x94,'ne':0x95,'b':0x92,'be':0x96,'a':0x97,'ae':0x93}[cc]
        self.rex(0,0,0,d,force=(d>=8)); self.emit(0x0F,op); self.modrm(3,0,d)

    def movzx16_mem_index(self,dst,base,index,scale=1,disp=0):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(0,d,ix,ba); self.emit(0x0F,0xB7)
        # indexed address always SIB
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def movzx16_mem(self,dst,base,disp=0):
        d=REG[dst]; ba=REG[base]; self.rex(0,d,0,ba); self.emit(0x0F,0xB7); self._mem_modrm(d,ba,disp)
    def _mem_modrm(self,reg,base,disp):
        low=base&7
        mod=0 if disp==0 and low!=5 else (1 if -128<=disp<=127 else 2)
        if low==4:
            self.modrm(mod,reg,4); self.sib(0,4,low)
        else: self.modrm(mod,reg,low)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and low==5): self.i32(disp)
    def imul_imm(self,dst,src,imm,bits=32,imm8=False):
        d=REG[dst]; s=REG[src]; self.rex(bits==64,d,0,s)
        if imm8 and -128<=imm<=127:
            self.emit(0x6B); self.modrm(3,d,s); self.emit(imm&255)
        else:
            self.emit(0x69); self.modrm(3,d,s); self.u32(imm)
    def shift_imm(self,kind,dst,imm,bits=32):
        d=REG[dst]; ext={'shl':4,'shr':5}[kind]; self.rex(bits==64,0,0,d); self.emit(0xC1); self.modrm(3,ext,d); self.emit(imm&255)
    def shift_cl(self,kind,dst,bits=32):
        d=REG[dst]; ext={'shl':4,'shr':5}[kind]; self.rex(bits==64,0,0,d); self.emit(0xD3); self.modrm(3,ext,d)
    def rol_imm(self,dst,imm,bits=64):
        d=REG[dst]; self.rex(bits==64,0,0,d); self.emit(0xC1); self.modrm(3,0,d); self.emit(imm&255)
    def bin_rr(self,op,dst,src,bits=32):
        # rm(dst) op reg(src)
        opc={'add':0x01,'sub':0x29,'xor':0x31,'or':0x09,'and':0x21}[op]
        d=REG[dst]; s=REG[src]; self.rex(bits==64,s,0,d); self.emit(opc); self.modrm(3,s,d)
    def bin_imm(self,op,dst,imm,bits=32):
        ext={'add':0,'or':1,'and':4,'sub':5,'xor':6}[op]; d=REG[dst]
        self.rex(bits==64,0,0,d)
        if -128<=imm<=127:
            self.emit(0x83); self.modrm(3,ext,d); self.emit(imm&255)
        else:
            self.emit(0x81); self.modrm(3,ext,d); self.u32(imm)
    def lea_rip(self,dst,sym):
        d=REG[dst]; self.rex(1,d,0,0); self.emit(0x8D); self.modrm(0,d,5)
        off=self.tell(); self.u32(0); self.reloc.append((off,sym,-4))
    def xor_mem(self,dst,base,disp=0,bits=64):
        d=REG[dst]; ba=REG[base]; self.rex(bits==64,d,0,ba); self.emit(0x33); self._mem_modrm(d,ba,disp)
    def test_rr(self,a,b,bits=32):
        ra=REG[a]; rb=REG[b]; self.rex(bits==64,rb,0,ra); self.emit(0x85); self.modrm(3,rb,ra)
    def ret(self): self.emit(0xC3)
    def label(self,name):
        if name in self.labels: raise ValueError(f'duplicate label {name}')
        self.labels[name]=self.tell()
    def jcc(self,cc,label):
        opc={'z':0x84,'nz':0x85,'e':0x84,'ne':0x85,'b':0x82,'be':0x86,'a':0x87,'ae':0x83}[cc]
        self.emit(0x0F,opc); off=self.tell(); self.u32(0); self.fix.append((off,label))
    def jcc8(self,cc,label):
        opc={'z':0x74,'e':0x74,'nz':0x75,'ne':0x75,'b':0x72,'be':0x76,'a':0x77,'ae':0x73,'l':0x7c,'le':0x7e,'g':0x7f,'ge':0x7d}[cc]; self.emit(opc); off=self.tell(); self.emit(0); self.fix8.append((off,label))
    def jmp8(self,label): self.emit(0xEB); off=self.tell(); self.emit(0); self.fix8.append((off,label))
    def jmp(self,label): self.emit(0xE9); off=self.tell(); self.u32(0); self.fix.append((off,label))
    def patch(self):
        for off,label in self.fix:
            if label not in self.labels: raise ValueError(f'unknown label {label}')
            rel=self.labels[label]-(off+4); self.b[off:off+4]=struct.pack('<i',rel)
        for off,label in self.fix8:
            if label not in self.labels: raise ValueError(f'unknown label {label}')
            rel=self.labels[label]-(off+1)
            if not -128<=rel<=127: raise ValueError(f'short branch to {label} is out of range')
            self.b[off]=rel&255

# ----------------------------- register allocation -----------------------------
def is_value(tok,fn,constants): return tok in fn.vars or tok in constants or IMM_RE.fullmatch(tok)

def uses_defs(ins:Ins):
    op=ins.op; a=ins.args; use=[]; define=[]
    if op=='let': pass
    elif op=='mov': define.append(a[0]); use.append(a[1])
    elif op in ('add32','sub32','mul32','xor32','or32','and32','shl32','shr32','add64','mul64','xor64','or64','and64','shl64','shr64','eq32','ne32','lt32','le32','gt32','ge32'):
        define.append(a[0]); use+=a[1:3]
    elif op.startswith('ld'): define.append(a[0]); use+=[a[1],a[2]]
    elif op.startswith('st'): use+=a[:3]
    elif op in ('aget16','aget32','aget64'): define.append(a[0]); use.append(a[2])
    elif op=='eq22': define.append(a[0]); use += [a[1],a[3]]
    elif op=='ld32pidx': define.append(a[0]); use += [a[1],a[3]]
    elif op=='ld32p': define.append(a[0]); use += [a[1]]
    elif op=='st32p': use += [a[0],a[3]]
    elif op in ('jeq32','jne32','jlt32','jle32','jgt32','jge32'): use += a[:2]
    elif op=='jnotbetter32': use += a[:4]
    elif op in ('topkfixed','topkguarded','topkreg','topkback','topkseed','topkseed32','topk2strictreg','topk8adaptive','topkseedfall','topk2strictfall','topk4regs','topk4worstcache','topk8biadaptive','topk8bicompact','topk8bilayout','topk8bilayout16','topk2short','topk2short16','topknoninc','topkstrictasc','topknonincpair','topkstrictascpair','topknonincsse','topkstrictascsse','topk2strictasclea','topknonincsseids','topkstrictascsseids'): use += a[:1]
    elif op=='kvplan': use += a[:1]
    elif op=='kvplanfull': use += a[:1]
    elif op=='kvplanfullsse': use += a[:1]
    elif op=='kvplanfullssematrix': use += a[:1]
    elif op in ('kvplan1fast','kvplan2fast','kvplanfromempty','kvplantoempty','kvplanbothempty','kvplan3to2sse','kvplan1to5sse','kvplan5to1sse'): use += a[:1]
    elif op in ('jz','jnz'): use.append(a[0])
    elif op=='ret': use.append(a[0])
    elif op=='retif': use += [a[0],a[1]]
    return use,define

def destructive_reuse_sources(ins:Ins):
    """Sources whose register may also hold this instruction's destination.

    x86 reads all address/source operands before committing the destination.
    Two-address arithmetic naturally overwrites its left input; commutative
    operations may also reverse their inputs.  Keeping this distinction here
    lets the linear scan end a source lifetime at the defining instruction
    without making unsafe choices for subtraction or eq22.
    """
    op=ins.op; a=ins.args
    if op=='mov': return a[1:2]
    if op in ('mul32','shl32','shr32','add64','mul64','xor64','or64','and64','shl64','shr64'):
        return a[1:2]
    if op in ('add32','xor32','or32','and32'):
        return a[1:2]
    if op=='sub32': return a[1:2]
    if op.startswith('ld'): return a[1:3]
    if op in ('aget16','aget32','aget64'): return a[2:3]
    if op in ('eq32','ne32','lt32','le32','gt32','ge32'): return a[1:3]
    return []

def alloc_regs(fn:Fn,target="linux"):
    # Params: current direct backend supports up to two parameters.
    regs={}
    if len(fn.params)>2: die(f'{fn.name}: direct backend currently supports up to two parameters')
    abi=['rdi','rsi'] if target=='linux' else ['rcx','rdx']
    for (n,ty),r in zip(fn.params,abi): regs[n]=r
    topk_ops={'ld32pidx','ld32p','st32p','jeq32','jne32','jlt32','jle32','jgt32','jge32','jnotbetter32'}
    is_topk=any(ins.op in topk_ops for ins in fn.body)
    pool=(['rax','rcx','rdx','r8','r9','rsi'] if target=='linux' else ['rax','rdx','r8','r9','r10']) if is_topk else ALLOC
    first={}; last={}
    for i,ins in enumerate(fn.body):
        u,d=uses_defs(ins)
        for x in d:
            if x in fn.vars and x not in first: first[x]=i
            if x in fn.vars: last[x]=max(last.get(x,i),i)
        for x in u:
            if x in fn.vars:
                first.setdefault(x,0); last[x]=i
    intervals=sorted([(first[v],last.get(v,first[v]),v) for v in first if v not in regs])
    active=[]; free=[r for r in pool if r not in regs.values()]
    for st,en,v in intervals:
        still=[]
        for aen,av,ar in active:
            if aen < st: free.append(ar)
            else: still.append((aen,av,ar))
        active=still
        reusable=set(destructive_reuse_sources(fn.body[st]))
        reuse=next(((aen,av,ar) for aen,av,ar in active
                    if aen==st and av in reusable),None)
        if reuse is not None:
            active.remove(reuse); r=reuse[2]
            regs[v]=r; active.append((en,v,r)); active.sort()
            continue
        if not free: die(f'{fn.name}: register pressure exceeds direct backend pool near {v}')
        # stable preference to low regs for shorter encodings
        free.sort(key=lambda r:pool.index(r)); r=free.pop(0); regs[v]=r
        active.append((en,v,r)); active.sort()
    return regs

# ----------------------------- compile operations -----------------------------
def imm(tok,constants):
    if tok in constants: return int(constants[tok])
    if IMM_RE.fullmatch(tok): return int(tok,0)
    return None

def ensure_reg(c:Code,tok,fn,regs,constants,scratch='r11',bits=32):
    if tok in regs: return regs[tok]
    v=imm(tok,constants)
    if v is None: die(f'unknown value {tok}')
    c.mov_imm(scratch,v,bits); return scratch

def move_value(c:Code,dst,tok,fn,regs,constants,bits=32):
    if tok in regs:
        if regs[tok]!=dst: c.mov_rr(dst,regs[tok],bits)
    else:
        v=imm(tok,constants)
        if v is None: die(f'unknown value {tok}')
        c.mov_imm(dst,v,bits)

def _push(c:Code,r:str):
    m={'rsi':(0x56,), 'rdi':(0x57,), 'r12':(0x41,0x54), 'r13':(0x41,0x55), 'r14':(0x41,0x56), 'r15':(0x41,0x57)}
    c.emit(*m[r])
def _pop(c:Code,r:str):
    m={'rsi':(0x5e,), 'rdi':(0x5f,), 'r12':(0x41,0x5c), 'r13':(0x41,0x5d), 'r14':(0x41,0x5e), 'r15':(0x41,0x5f)}
    c.emit(*m[r])
def _better_branch(c:Code,score:str,cid:str,old_score:str,old_id:str,take:str,skip:str):
    c.cmp_rr(score,old_score,32); c.jcc('a',take); c.jcc('b',skip)
    c.cmp_rr(cid,old_id,32); c.jcc('b',take); c.jmp(skip)


def _shift_right1_pairwise(c:Code, base:str, p:int, k:int, scratch:str='r10'):
    """Shift [p..k-2] one slot right using backward qword copies when possible."""
    remain=(k-1)-p
    hi=k-1
    while remain>=2:
        dest_start=hi-1
        src_start=dest_start-1
        c.mov_mem(scratch,base,src_start*4,64)
        c.mov_store(base,dest_start*4,scratch,64)
        hi-=2; remain-=2
    if remain:
        c.mov_mem(scratch,base,p*4,32)
        c.mov_store(base,(p+1)*4,scratch,32)


def emit_topk_seed(c:Code, ctxreg:str, k:int, target:str):
    """Seed first K real candidates, stable-sort them, then reverse-insert by score only.

    Domain contract: count >= K.  Since scan IDs are strictly increasing, equal-score
    candidates can never beat an already-seen candidate under the id-ascending tie rule.
    """
    if k not in (2,4,8): die(f'topkseed unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdx','rcx','r8','r9','rdi'; saved=[]
    else:
        _push(c,'rsi'); _push(c,'rdi'); saved=['rsi','rdi']
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdi',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdi','rdx','r8','r9','rcx'

    # Materialize the first K real items.  No sentinels are needed in the fast domain.
    for i in range(k):
        c.mov_mem('rax',scores,i*4,32)
        c.mov_store(tmp,i*4,'rax',32)
        c.mov_imm_mem(out,i*4,i,32)

    # Stable insertion-sort of the seed.  Strict score comparison preserves id-ascending ties.
    for i in range(1,k):
        c.mov_mem('rax',tmp,i*4,32)
        c.mov_imm(cid,i,32)
        done_i=f'__seed_sort_done_{k}_{i}_{c.tell()}'
        labels={p:f'__seed_sort_put_{k}_{i}_{p}_{c.tell()}' for p in range(1,i+1)}
        for j in range(i-1,-1,-1):
            c.mov_mem('r10',tmp,j*4,32)
            c.cmp_rr('rax','r10',32)
            # <= keeps the older/smaller id before the new candidate.
            c.jcc('be',labels[j+1])
            c.mov_store(tmp,(j+1)*4,'r10',32)
            c.mov_mem('r10',out,j*4,32)
            c.mov_store(out,(j+1)*4,'r10',32)
        c.mov_store(tmp,0,'rax',32); c.mov_store(out,0,cid,32); c.jmp(done_i)
        for pidx in range(1,i+1):
            c.label(labels[pidx]); c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(done_i)
        c.label(done_i)

    c.mov_imm(scan,k,32)
    loop=f'__seed_loop_{k}_{c.tell()}'; done=f'__seed_done_{k}_{c.tell()}'; nxt=f'__seed_next_{k}_{c.tell()}'
    inserts=[f'__seed_insert_{k}_{p}_{c.tell()}' for p in range(k)]
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_rr(cid,scan,32)
    # Search from worst to best. Equal score is never better because cid is newer/larger.
    for j in range(k-1,-1,-1):
        c.mov_mem('r10',tmp,j*4,32)
        c.cmp_rr('rax','r10',32)
        c.jcc('be',nxt if j==k-1 else inserts[j+1])
    c.jmp(inserts[0])
    for pidx in range(k):
        c.label(inserts[pidx])
        _shift_right1_pairwise(c,tmp,pidx,k,'r10')
        _shift_right1_pairwise(c,out,pidx,k,'r10')
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(nxt)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done)
    c.mov_imm('rax',k,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()


def _align_code(c:Code, a:int=16):
    while c.tell()%a: c.emit(0x90)

def _align_code_phase(c:Code, a:int, phase:int):
    while c.tell()%a != phase: c.emit(0x90)


def _shift_right1_scalar(c:Code, base:str, p:int, k:int, scratch:str='r10'):
    for j in range(k-1,p,-1):
        c.mov_mem(scratch,base,(j-1)*4,32)
        c.mov_store(base,j*4,scratch,32)


def emit_topk_seed32(c:Code, ctxreg:str, k:int, target:str):
    """Seeded stable insertion, strict-score steady-state, scalar shifts. Domain count>=K."""
    if k not in (4,8): die(f'topkseed32 unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdx','rcx','r8','r9','rdi'; saved=[]
    else:
        _push(c,'rsi'); _push(c,'rdi'); saved=['rsi','rdi']
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdi',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdi','rdx','r8','r9','rcx'
    for i in range(k):
        c.mov_mem('rax',scores,i*4,32); c.mov_store(tmp,i*4,'rax',32); c.mov_imm_mem(out,i*4,i,32)
    for i in range(1,k):
        c.mov_mem('rax',tmp,i*4,32); c.mov_imm(cid,i,32)
        done_i=f'__s32_sort_done_{k}_{i}_{c.tell()}'
        labels={p:f'__s32_sort_put_{k}_{i}_{p}_{c.tell()}' for p in range(1,i+1)}
        for j in range(i-1,-1,-1):
            c.mov_mem('r10',tmp,j*4,32); c.cmp_rr('rax','r10',32); c.jcc('be',labels[j+1])
            c.mov_store(tmp,(j+1)*4,'r10',32); c.mov_mem('r10',out,j*4,32); c.mov_store(out,(j+1)*4,'r10',32)
        c.mov_store(tmp,0,'rax',32); c.mov_store(out,0,cid,32); c.jmp(done_i)
        for pidx in range(1,i+1):
            c.label(labels[pidx]); c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(done_i)
        c.label(done_i)
    c.mov_imm(scan,k,32)
    _align_code(c,16)
    loop=f'__s32_loop_{k}_{c.tell()}'; done=f'__s32_done_{k}_{c.tell()}'; nxt=f'__s32_next_{k}_{c.tell()}'
    inserts=[f'__s32_insert_{k}_{p}_{c.tell()}' for p in range(k)]
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_rr(cid,scan,32)
    for j in range(k-1,-1,-1):
        c.mov_mem('r10',tmp,j*4,32); c.cmp_rr('rax','r10',32); c.jcc('be',nxt if j==k-1 else inserts[j+1])
    c.jmp(inserts[0])
    for pidx in range(k):
        c.label(inserts[pidx]); _shift_right1_scalar(c,tmp,pidx,k,'r10'); _shift_right1_scalar(c,out,pidx,k,'r10')
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(nxt)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done)
    c.mov_imm('rax',k,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()


def emit_topk2_strictreg(c:Code, ctxreg:str, target:str):
    """K2 fast-domain kernel. Domain count>=2; intended promotion count>=64."""
    if target=='linux':
        _push(c,'r12'); _push(c,'r13'); saved=['r12','r13']; keepctx=ctxreg
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32)
        scores,n,scan='rsi','r8','r9'
    else:
        _push(c,'rsi'); _push(c,'r12'); _push(c,'r13'); _push(c,'r14'); saved=['rsi','r12','r13','r14']
        c.mov_rr('r14',ctxreg,64); keepctx='r14'
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32)
        scores,n,scan='rsi','r8','r9'
    # state: best=(r10d,r11d), second=(r12d,r13d)
    c.mov_mem('r10',scores,0,32); c.mov_mem('r12',scores,4,32)
    noswap=f'__k2sr_noswap_{c.tell()}'; seeded=f'__k2sr_seeded_{c.tell()}'
    c.cmp_rr('r12','r10',32); c.jcc('be',noswap)
    c.mov_rr('rax','r10',32); c.mov_rr('r10','r12',32); c.mov_rr('r12','rax',32)
    c.mov_imm('r11',1,32); c.mov_imm('r13',0,32); c.jmp(seeded)
    c.label(noswap); c.mov_imm('r11',0,32); c.mov_imm('r13',1,32); c.label(seeded)
    c.mov_imm(scan,2,32)
    _align_code(c,16)
    loop=f'__k2sr_loop_{c.tell()}'; nxt=f'__k2sr_next_{c.tell()}'; top=f'__k2sr_top_{c.tell()}'; done=f'__k2sr_done_{c.tell()}'
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    c.cmp_rr('rax','r12',32); c.jcc('be',nxt)
    c.cmp_rr('rax','r10',32); c.jcc('a',top)
    c.mov_rr('r12','rax',32); c.mov_rr('r13',scan,32); c.jmp(nxt)
    c.label(top); c.mov_rr('r12','r10',32); c.mov_rr('r13','r11',32); c.mov_rr('r10','rax',32); c.mov_rr('r11',scan,32)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done)
    c.mov_mem('rax',keepctx,16,64); c.mov_store('rax',0,'r10',32); c.mov_store('rax',4,'r12',32)
    c.mov_mem('rax',keepctx,8,64); c.mov_store('rax',0,'r11',32); c.mov_store('rax',4,'r13',32)
    c.mov_imm('rax',2,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()







def emit_topk_noninc(c:Code, ctxreg:str, k:int, target:str):
    """Known-order exact fast path. Preconditions: count>=K and scores are non-increasing."""
    if k not in (1,2,4,8): die(f'topknoninc unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64)
        scores,out,tmp='rsi','rdx','rcx'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('r8',ctxreg,16,64)
        scores,out,tmp='r10','r11','r8'
    for j in range(k):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.mov_imm('rax',k,32); c.ret()


def emit_topk_strictasc(c:Code, ctxreg:str, k:int, target:str):
    """Known-order exact fast path. Preconditions: count>=K and scores are strictly increasing."""
    if k not in (1,2,4,8): die(f'topkstrictasc unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='rsi','rdx','rcx','r8','r9'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='r10','r11','rdx','r8','r9'
    c.mov_rr(idx,n,32)
    for j in range(k):
        c.bin_imm('sub',idx,1,32); c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,j*4,'rax',32); c.mov_store(out,j*4,idx,32)
    c.mov_imm('rax',k,32); c.ret()


def emit_topk_noninc_pair(c:Code, ctxreg:str, k:int, target:str):
    """V6 known non-increasing path. Pair-copy scores with 64-bit loads/stores.

    Exact preconditions/semantics are identical to V5 noninc. K1 is intentionally
    left on V5 because pairing has no benefit there.
    """
    if k not in (2,4,8): die(f'topknonincpair unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64)
        scores,out,tmp='rsi','rdx','rcx'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('r8',ctxreg,16,64)
        scores,out,tmp='r10','r11','r8'
    # Scores are already in final order; copy two u32 lanes per memory operation.
    for j in range(0,k,2):
        c.mov_mem('rax',scores,j*4,64); c.mov_store(tmp,j*4,'rax',64)
    # IDs are the first K input positions. Keep the exact V5 representation.
    for j in range(k):
        c.mov_imm_mem(out,j*4,j,32)
    c.mov_imm('rax',k,32); c.ret()


def emit_topk_strictasc_pair(c:Code, ctxreg:str, k:int, target:str):
    """V6 known strictly-ascending path. Pair-load adjacent scores and swap dwords.

    Exact preconditions/semantics are identical to V5 strictasc. Each qword load
    obtains [older,newer]; ROL64 32 emits [newer,older] directly to tmp_scores.
    """
    if k not in (2,4,8): die(f'topkstrictascpair unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='rsi','rdx','rcx','r8','r9'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='r10','r11','rdx','r8','r9'
    c.lea_disp(idx,n,-2,32)
    # Work from the end in pairs: [n-2,n-1] -> [n-1,n-2], etc.
    for j in range(0,k,2):
        if j: c.bin_imm('sub',idx,2,32)
        c.mov_mem_index('rax',scores,idx,2,0,64)
        c.rol_imm('rax',32,64)
        c.mov_store(tmp,j*4,'rax',64)
        # Exact IDs for the two reversed lanes.
        c.lea_disp('r10',idx,1,32); c.mov_store(out,j*4,'r10',32)
        c.mov_store(out,(j+1)*4,idx,32)
    c.mov_imm('rax',k,32); c.ret()


def emit_topk_noninc_sse(c:Code, ctxreg:str, k:int, target:str):
    """SSE2 V6 candidate for known non-increasing K4/K8."""
    if k not in (4,8): die(f'topknonincsse unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64)
        scores,out,tmp='rsi','rdx','rcx'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('r8',ctxreg,16,64)
        scores,out,tmp='r10','r11','r8'
    for j in range(0,k,4):
        c.movdqu_load(0,scores,j*4); c.movdqu_store(tmp,j*4,0)
    for j in range(k): c.mov_imm_mem(out,j*4,j,32)
    c.mov_imm('rax',k,32); c.ret()


def emit_topk_strictasc_sse(c:Code, ctxreg:str, k:int, target:str):
    """SSE2 V6 candidate for known strictly-ascending K4/K8."""
    if k not in (4,8): die(f'topkstrictascsse unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='rsi','rdx','rcx','r8','r9'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='r10','r11','rdx','r8','r9'
    # Last block first; each 128-bit block is reversed lane-wise.
    c.lea_disp(idx,n,-4,32)
    for j in range(0,k,4):
        if j: c.bin_imm('sub',idx,4,32)
        c.movdqu_load_index(0,scores,idx,2,0); c.pshufd(0,0,0x1b); c.movdqu_store(tmp,j*4,0)
        # Exact candidate IDs: idx+3, idx+2, idx+1, idx.
        c.lea_disp('r10',idx,3,32); c.mov_store(out,j*4,'r10',32)
        c.lea_disp('r10',idx,2,32); c.mov_store(out,(j+1)*4,'r10',32)
        c.lea_disp('r10',idx,1,32); c.mov_store(out,(j+2)*4,'r10',32)
        c.mov_store(out,(j+3)*4,idx,32)
    c.mov_imm('rax',k,32); c.ret()


def emit_topk2_strictasc_lea(c:Code, ctxreg:str, target:str):
    """K2 strict-ascending V6 candidate: V5 scalar path with LEA initialization."""
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='rsi','rdx','rcx','r8','r9'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='r10','r11','rdx','r8','r9'
    c.lea_disp(idx,n,-1,32)
    c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,0,'rax',32); c.mov_store(out,0,idx,32)
    c.bin_imm('sub',idx,1,32)
    c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,4,'rax',32); c.mov_store(out,4,idx,32)
    c.mov_imm('rax',2,32); c.ret()


def emit_topk_noninc_sse_ids(c:Code, ctxreg:str, k:int, target:str):
    """SSE2 known non-increasing K4/K8; vector scores and fixed IDs."""
    if k not in (4,8): die(f'topknonincsseids unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64)
        scores,out,tmp='rsi','rdx','rcx'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('r8',ctxreg,16,64)
        scores,out,tmp='r10','r11','r8'
    for j in range(0,k,4):
        c.movdqu_load(0,scores,j*4); c.movdqu_store(tmp,j*4,0)
        c.movdqu_load_rip(1,'topk_ids_0_3' if j==0 else 'topk_ids_4_7'); c.movdqu_store(out,j*4,1)
    c.mov_imm('rax',k,32); c.ret()


def emit_topk_strictasc_sse_ids(c:Code, ctxreg:str, k:int, target:str):
    """SSE2 known strictly-ascending K4/K8; vector scores and dynamic IDs."""
    if k not in (4,8): die(f'topkstrictascsseids unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='rsi','rdx','rcx','r8','r9'
    else:
        c.mov_mem('r10',ctxreg,0,64); c.mov_mem('r11',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,idx='r10','r11','rdx','r8','r9'
    # Broadcast (n-1). Subtract fixed lane offsets [0..3] / [4..7].
    c.lea_disp('r10',n,-1,32); c.movd_xmm_reg32(1,'r10'); c.pshufd(1,1,0)
    if k==8: c.movdqa_rr(2,1)
    c.movdqu_load_rip(3,'topk_ids_0_3'); c.psubd(1,3); c.movdqu_store(out,0,1)
    if k==8:
        c.movdqu_load_rip(3,'topk_ids_4_7'); c.psubd(2,3); c.movdqu_store(out,16,2)
    # Scores: consume last 4 first and reverse lanes exactly.
    c.lea_disp(idx,n,-4,32)
    c.movdqu_load_index(0,scores,idx,2,0); c.pshufd(0,0,0x1b); c.movdqu_store(tmp,0,0)
    if k==8:
        c.bin_imm('sub',idx,4,32); c.movdqu_load_index(0,scores,idx,2,0); c.pshufd(0,0,0x1b); c.movdqu_store(tmp,16,0)
    c.mov_imm('rax',k,32); c.ret()

def emit_topk2_short(c:Code, ctxreg:str, target:str):
    """V4 K2 semantics with short local branches. Domain count>=2."""
    if target=='linux':
        _push(c,'r12'); _push(c,'r13'); saved=['r12','r13']; keepctx=ctxreg
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32); scores,n,scan='rsi','r8','r9'
    else:
        _push(c,'rsi'); _push(c,'r12'); _push(c,'r13'); _push(c,'r14'); saved=['rsi','r12','r13','r14']
        c.mov_rr('r14',ctxreg,64); keepctx='r14'; c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32); scores,n,scan='rsi','r8','r9'
    c.mov_mem('r10',scores,0,32); c.mov_mem('r12',scores,4,32)
    noswap=f'__k2sh_noswap_{c.tell()}'; seeded=f'__k2sh_seeded_{c.tell()}'
    c.cmp_rr('r12','r10',32); c.jcc8('be',noswap)
    c.mov_rr('rax','r10',32); c.mov_rr('r10','r12',32); c.mov_rr('r12','rax',32); c.mov_imm('r11',1,32); c.mov_imm('r13',0,32); c.jmp8(seeded)
    c.label(noswap); c.mov_imm('r11',0,32); c.mov_imm('r13',1,32); c.label(seeded); c.mov_imm(scan,2,32)
    # Keep the same favorable phase as V4: loop starts at 16-byte boundary.
    _align_code(c,16)
    loop=f'__k2sh_loop_{c.tell()}'; nxt=f'__k2sh_next_{c.tell()}'; better=f'__k2sh_better_{c.tell()}'; top=f'__k2sh_top_{c.tell()}'; done=f'__k2sh_done_{c.tell()}'
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc8('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax','r12',32); c.jcc8('a',better)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp8(loop)
    c.label(better); c.cmp_rr('rax','r10',32); c.jcc8('a',top)
    c.mov_rr('r12','rax',32); c.mov_rr('r13',scan,32); c.jmp8(nxt)
    c.label(top); c.mov_rr('r12','r10',32); c.mov_rr('r13','r11',32); c.mov_rr('r10','rax',32); c.mov_rr('r11',scan,32); c.jmp8(nxt)
    c.label(done); c.mov_mem('rax',keepctx,16,64); c.mov_store('rax',0,'r10',32); c.mov_store('rax',4,'r12',32); c.mov_mem('rax',keepctx,8,64); c.mov_store('rax',0,'r11',32); c.mov_store('rax',4,'r13',32); c.mov_imm('rax',2,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()

def emit_topk2_short16(c:Code, ctxreg:str, target:str):
    """V4 K2 semantics with short local branches. Domain count>=2."""
    if target=='linux':
        _push(c,'r12'); _push(c,'r13'); saved=['r12','r13']; keepctx=ctxreg
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32); scores,n,scan='rsi','r8','r9'
    else:
        _push(c,'rsi'); _push(c,'r12'); _push(c,'r13'); _push(c,'r14'); saved=['rsi','r12','r13','r14']
        c.mov_rr('r14',ctxreg,64); keepctx='r14'; c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32); scores,n,scan='rsi','r8','r9'
    c.mov_mem('r10',scores,0,32); c.mov_mem('r12',scores,4,32)
    noswap=f'__k2sh_noswap_{c.tell()}'; seeded=f'__k2sh_seeded_{c.tell()}'
    c.cmp_rr('r12','r10',32); c.jcc8('be',noswap)
    c.mov_rr('rax','r10',32); c.mov_rr('r10','r12',32); c.mov_rr('r12','rax',32); c.mov_imm('r11',1,32); c.mov_imm('r13',0,32); c.jmp8(seeded)
    c.label(noswap); c.mov_imm('r11',0,32); c.mov_imm('r13',1,32); c.label(seeded); c.mov_imm(scan,2,32)
    # Keep the same favorable phase as V4: loop starts at 16-byte boundary.
    _align_code_phase(c,32,16)
    loop=f'__k2sh_loop_{c.tell()}'; nxt=f'__k2sh_next_{c.tell()}'; better=f'__k2sh_better_{c.tell()}'; top=f'__k2sh_top_{c.tell()}'; done=f'__k2sh_done_{c.tell()}'
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc8('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax','r12',32); c.jcc8('a',better)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp8(loop)
    c.label(better); c.cmp_rr('rax','r10',32); c.jcc8('a',top)
    c.mov_rr('r12','rax',32); c.mov_rr('r13',scan,32); c.jmp8(nxt)
    c.label(top); c.mov_rr('r12','r10',32); c.mov_rr('r13','r11',32); c.mov_rr('r10','rax',32); c.mov_rr('r11',scan,32); c.jmp8(nxt)
    c.label(done); c.mov_mem('rax',keepctx,16,64); c.mov_store('rax',0,'r10',32); c.mov_store('rax',4,'r12',32); c.mov_mem('rax',keepctx,8,64); c.mov_store('rax',0,'r11',32); c.mov_store('rax',4,'r13',32); c.mov_imm('rax',2,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()

def emit_topk4_worstcache(c:Code, ctxreg:str, target:str):
    """V4-style seeded K4, but keep tmp[3] (current worst score) in r11d.
    Domain count>=4. Exact ranking semantics unchanged.
    """
    k=4
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdx','rcx','r8','r9','rdi'; saved=[]
    else:
        _push(c,'rsi'); _push(c,'rdi'); saved=['rsi','rdi']
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdi',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdi','rdx','r8','r9','rcx'
    # Stable real-item seed, identical policy to V4.
    for i in range(k):
        c.mov_mem('rax',scores,i*4,32); c.mov_store(tmp,i*4,'rax',32); c.mov_imm_mem(out,i*4,i,32)
    for i in range(1,k):
        c.mov_mem('rax',tmp,i*4,32); c.mov_imm(cid,i,32)
        done_i=f'__wc4_sort_done_{i}_{c.tell()}'; labels={p:f'__wc4_sort_put_{i}_{p}_{c.tell()}' for p in range(1,i+1)}
        for j in range(i-1,-1,-1):
            c.mov_mem('r10',tmp,j*4,32); c.cmp_rr('rax','r10',32); c.jcc('be',labels[j+1])
            c.mov_store(tmp,(j+1)*4,'r10',32); c.mov_mem('r10',out,j*4,32); c.mov_store(out,(j+1)*4,'r10',32)
        c.mov_store(tmp,0,'rax',32); c.mov_store(out,0,cid,32); c.jmp(done_i)
        for pidx in range(1,i+1):
            c.label(labels[pidx]); c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(done_i)
        c.label(done_i)
    c.mov_mem('r11',tmp,12,32)  # cached worst
    c.mov_imm(scan,k,32); _align_code(c,16)
    loop=f'__wc4_loop_{c.tell()}'; nxt=f'__wc4_next_{c.tell()}'; search=f'__wc4_search_{c.tell()}'; done=f'__wc4_done_{c.tell()}'
    inserts=[f'__wc4_insert_{p}_{c.tell()}' for p in range(k)]
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done); c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_rr(cid,scan,32)
    c.cmp_rr('rax','r11',32); c.jcc('a',search)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop)
    c.label(search)
    for j in range(k-2,-1,-1):
        c.mov_mem('r10',tmp,j*4,32); c.cmp_rr('rax','r10',32); c.jcc('be',inserts[j+1])
    c.jmp(inserts[0])
    for pidx in range(k):
        c.label(inserts[pidx]); _shift_right1_scalar(c,tmp,pidx,k,'r10'); _shift_right1_scalar(c,out,pidx,k,'r10')
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32)
        c.mov_mem('r11',tmp,12,32)  # refresh only after an insertion
        c.jmp(nxt)
    c.label(done); c.mov_imm('rax',k,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()

def emit_topk4_regs(c:Code, ctxreg:str, target:str):
    """K4 exact kernel with register-resident winning scores. Domain count>=4.

    Seed semantics remain stable (score descending, id ascending). After the first
    four IDs, scan IDs only increase, so equal-score newcomers cannot displace an
    existing winner. The steady-state path can therefore compare scores strictly.
    """
    if target=='linux':
        _push(c,'r12'); _push(c,'r13'); _push(c,'r15'); saved=['r12','r13','r15']
        c.mov_rr('r15',ctxreg,64); keepctx='r15'
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdx','rcx','r8','r9','rdi'
    else:
        _push(c,'rsi'); _push(c,'rdi'); _push(c,'r12'); _push(c,'r13'); _push(c,'r14'); saved=['rsi','rdi','r12','r13','r14']
        c.mov_rr('r14',ctxreg,64); keepctx='r14'
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdi',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdi','rdx','r8','r9','rcx'

    # Stable first-four seed in memory; one-time cost, then scores move to registers.
    for i in range(4):
        c.mov_mem('rax',scores,i*4,32); c.mov_store(tmp,i*4,'rax',32); c.mov_imm_mem(out,i*4,i,32)
    for i in range(1,4):
        c.mov_mem('rax',tmp,i*4,32); c.mov_imm(cid,i,32)
        done_i=f'__k4r_seed_done_{i}_{c.tell()}'
        labels={p:f'__k4r_seed_put_{i}_{p}_{c.tell()}' for p in range(1,i+1)}
        for j in range(i-1,-1,-1):
            c.mov_mem('r10',tmp,j*4,32); c.cmp_rr('rax','r10',32); c.jcc('be',labels[j+1])
            c.mov_store(tmp,(j+1)*4,'r10',32); c.mov_mem('r10',out,j*4,32); c.mov_store(out,(j+1)*4,'r10',32)
        c.mov_store(tmp,0,'rax',32); c.mov_store(out,0,cid,32); c.jmp(done_i)
        for pidx in range(1,i+1):
            c.label(labels[pidx]); c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(done_i)
        c.label(done_i)

    c.mov_mem('r10',tmp,0,32); c.mov_mem('r11',tmp,4,32); c.mov_mem('r12',tmp,8,32); c.mov_mem('r13',tmp,12,32)
    c.mov_imm(scan,4,32); _align_code(c,16)
    loop=f'__k4r_loop_{c.tell()}'; done=f'__k4r_done_{c.tell()}'; nxt=f'__k4r_next_{c.tell()}'
    p2=f'__k4r_p2_{c.tell()}'; p1=f'__k4r_p1_{c.tell()}'; p0=f'__k4r_p0_{c.tell()}'
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    # Rejection is the common fall-through path.
    c.cmp_rr('rax','r13',32); c.jcc('a',p2)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop)

    # Candidate is at least position 3. Refine upward with strict score compares.
    c.label(p2); c.cmp_rr('rax','r12',32); c.jcc('a',p1)
    # position 3
    c.mov_rr('r13','rax',32); c.mov_store(out,12,scan,32); c.jmp(nxt)

    c.label(p1); c.cmp_rr('rax','r11',32); c.jcc('a',p0)
    # position 2
    c.mov_rr('r13','r12',32); c.mov_rr('r12','rax',32)
    c.mov_mem('rax',out,8,32); c.mov_store(out,12,'rax',32); c.mov_store(out,8,scan,32); c.jmp(nxt)

    c.label(p0); c.cmp_rr('rax','r10',32)
    top=f'__k4r_top_{c.tell()}'; c.jcc('a',top)
    # position 1
    c.mov_rr('r13','r12',32); c.mov_rr('r12','r11',32); c.mov_rr('r11','rax',32)
    c.mov_mem('rax',out,8,32); c.mov_store(out,12,'rax',32)
    c.mov_mem('rax',out,4,32); c.mov_store(out,8,'rax',32); c.mov_store(out,4,scan,32); c.jmp(nxt)

    c.label(top)
    # position 0
    c.mov_rr('r13','r12',32); c.mov_rr('r12','r11',32); c.mov_rr('r11','r10',32); c.mov_rr('r10','rax',32)
    c.mov_mem('rax',out,8,32); c.mov_store(out,12,'rax',32)
    c.mov_mem('rax',out,4,32); c.mov_store(out,8,'rax',32)
    c.mov_mem('rax',out,0,32); c.mov_store(out,4,'rax',32); c.mov_store(out,0,scan,32); c.jmp(nxt)

    c.label(done)
    # Publish the exact tmp_scores state expected by the ABI.
    c.mov_mem('rax',keepctx,16,64)
    c.mov_store('rax',0,'r10',32); c.mov_store('rax',4,'r11',32); c.mov_store('rax',8,'r12',32); c.mov_store('rax',12,'r13',32)
    c.mov_imm('rax',4,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()

def emit_topk_seedfall(c:Code, ctxreg:str, k:int, target:str):
    """Seeded strict-score Top-K with rejection as fall-through. Domain count>=K."""
    if k not in (4,8): die(f'topkseedfall unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdx','rcx','r8','r9','rdi'; saved=[]
    else:
        _push(c,'rsi'); _push(c,'rdi'); saved=['rsi','rdi']
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdi',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdi','rdx','r8','r9','rcx'
    # Stable real-item seed.
    for i in range(k):
        c.mov_mem('rax',scores,i*4,32); c.mov_store(tmp,i*4,'rax',32); c.mov_imm_mem(out,i*4,i,32)
    for i in range(1,k):
        c.mov_mem('rax',tmp,i*4,32); c.mov_imm(cid,i,32)
        done_i=f'__sf_sort_done_{k}_{i}_{c.tell()}'; labels={p:f'__sf_sort_put_{k}_{i}_{p}_{c.tell()}' for p in range(1,i+1)}
        for j in range(i-1,-1,-1):
            c.mov_mem('r10',tmp,j*4,32); c.cmp_rr('rax','r10',32); c.jcc('be',labels[j+1])
            c.mov_store(tmp,(j+1)*4,'r10',32); c.mov_mem('r10',out,j*4,32); c.mov_store(out,(j+1)*4,'r10',32)
        c.mov_store(tmp,0,'rax',32); c.mov_store(out,0,cid,32); c.jmp(done_i)
        for pidx in range(1,i+1):
            c.label(labels[pidx]); c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(done_i)
        c.label(done_i)
    c.mov_imm(scan,k,32); _align_code(c,16)
    loop=f'__sf_loop_{k}_{c.tell()}'; nxt=f'__sf_next_{k}_{c.tell()}'; search=f'__sf_search_{k}_{c.tell()}'; done=f'__sf_done_{k}_{c.tell()}'
    inserts=[f'__sf_insert_{k}_{p}_{c.tell()}' for p in range(k)]
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done); c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_rr(cid,scan,32)
    c.mov_mem('r10',tmp,(k-1)*4,32); c.cmp_rr('rax','r10',32); c.jcc('a',search)
    # common rejection path: no taken forward branch
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop)
    c.label(search)
    for j in range(k-2,-1,-1):
        c.mov_mem('r10',tmp,j*4,32); c.cmp_rr('rax','r10',32); c.jcc('be',inserts[j+1])
    c.jmp(inserts[0])
    for pidx in range(k):
        c.label(inserts[pidx]); _shift_right1_scalar(c,tmp,pidx,k,'r10'); _shift_right1_scalar(c,out,pidx,k,'r10')
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(nxt)
    c.label(done); c.mov_imm('rax',k,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()


def emit_topk2_strictfall(c:Code, ctxreg:str, target:str):
    """Register K2 with rejection fall-through. Domain count>=2."""
    if target=='linux':
        _push(c,'r12'); _push(c,'r13'); saved=['r12','r13']; keepctx=ctxreg
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32); scores,n,scan='rsi','r8','r9'
    else:
        _push(c,'rsi'); _push(c,'r12'); _push(c,'r13'); _push(c,'r14'); saved=['rsi','r12','r13','r14']
        c.mov_rr('r14',ctxreg,64); keepctx='r14'; c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32); scores,n,scan='rsi','r8','r9'
    c.mov_mem('r10',scores,0,32); c.mov_mem('r12',scores,4,32)
    noswap=f'__k2sf_noswap_{c.tell()}'; seeded=f'__k2sf_seeded_{c.tell()}'
    c.cmp_rr('r12','r10',32); c.jcc('be',noswap); c.mov_rr('rax','r10',32); c.mov_rr('r10','r12',32); c.mov_rr('r12','rax',32); c.mov_imm('r11',1,32); c.mov_imm('r13',0,32); c.jmp(seeded)
    c.label(noswap); c.mov_imm('r11',0,32); c.mov_imm('r13',1,32); c.label(seeded); c.mov_imm(scan,2,32); _align_code(c,16)
    loop=f'__k2sf_loop_{c.tell()}'; nxt=f'__k2sf_next_{c.tell()}'; better=f'__k2sf_better_{c.tell()}'; top=f'__k2sf_top_{c.tell()}'; done=f'__k2sf_done_{c.tell()}'
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done); c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax','r12',32); c.jcc('a',better)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop)
    c.label(better); c.cmp_rr('rax','r10',32); c.jcc('a',top); c.mov_rr('r12','rax',32); c.mov_rr('r13',scan,32); c.jmp(nxt)
    c.label(top); c.mov_rr('r12','r10',32); c.mov_rr('r13','r11',32); c.mov_rr('r10','rax',32); c.mov_rr('r11',scan,32); c.jmp(nxt)
    c.label(done); c.mov_mem('rax',keepctx,16,64); c.mov_store('rax',0,'r10',32); c.mov_store('rax',4,'r12',32); c.mov_mem('rax',keepctx,8,64); c.mov_store('rax',0,'r11',32); c.mov_store('rax',4,'r13',32); c.mov_imm('rax',2,32)
    for r in reversed(saved): _pop(c,r)
    c.ret()

def emit_topk8_adaptive(c:Code, ctxreg:str, target:str):
    """K8 adaptive fast path, domain count>=8.
    Probe strict ascending order. If it survives, top8 is the reversed last 8.
    If it breaks after >=8 items, seed exactly from the last 8 of that prefix and continue.
    If it breaks earlier, execute the validated seeded K8 path from scratch.
    """
    # Probe uses only volatile registers so early fallback can emit its own body safely.
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); scores='rsi'; prev='r10'
    else:
        c.mov_mem('r10',ctxreg,0,64); scores='r10'; prev='r11'
    c.mov_mem('r8',ctxreg,24,32); n='r8'; scan='r9'
    c.mov_mem(prev,scores,0,32); c.mov_imm(scan,1,32)
    probe=f'__a8_probe_{c.tell()}'; allasc=f'__a8_allasc_{c.tell()}'; fail=f'__a8_fail_{c.tell()}'; late=f'__a8_late_{c.tell()}'
    c.label(probe); c.cmp_rr(scan,n,32); c.jcc('ae',allasc)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('be',fail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(probe)
    c.label(fail)
    c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('ae',late)
    # Early violation: tiny probe cost, then exact seeded path from scratch.
    emit_topk_seed32(c,ctxreg,8,target)

    c.label(allasc)
    # Strictly ascending entire input: materialize reversed last 8 directly.
    if target=='linux':
        # scores already rsi
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'
    else:
        # scores is r10; keep ctx in rcx until both pointers are loaded.
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'
    c.mov_rr(scan,n,32)
    for j in range(8):
        c.bin_imm('sub',scan,1,32); c.mov_mem_index('rax',scores,scan,2,0,32)
        c.mov_store(tmp,j*4,'rax',32); c.mov_store(out,j*4,scan,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(late)
    # Prefix [0..scan-1] is strictly ascending: its exact Top-8 is its last 8 items.
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'
    else:
        # scores is r10 from probe; move it to r11 before reusing r10 as scratch.
        c.mov_rr('r11',scores,64); scores='r11'
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'
    # rax is free; use a temporary index copy. On Linux r11, on Windows rdi is unavailable without save,
    # so reuse rax for index only during seeding and load score through scratch.
    idx='r11' if target=='linux' else 'rax'
    c.mov_rr(idx,scan,32)
    for j in range(8):
        c.bin_imm('sub',idx,1,32)
        if target=='linux':
            c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,j*4,'rax',32)
        else:
            c.mov_mem_index(scratch,scores,idx,2,0,32); c.mov_store(tmp,j*4,scratch,32)
        c.mov_store(out,j*4,idx,32)
    loop=f'__a8_loop_{c.tell()}'; done=f'__a8_done_{c.tell()}'; nxt=f'__a8_next_{c.tell()}'
    inserts=[f'__a8_insert_{p}_{c.tell()}' for p in range(8)]
    _align_code(c,16); c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    for j in range(7,-1,-1):
        c.mov_mem(scratch,tmp,j*4,32); c.cmp_rr('rax',scratch,32); c.jcc('be',nxt if j==7 else inserts[j+1])
    c.jmp(inserts[0])
    for pidx in range(8):
        c.label(inserts[pidx]); _shift_right1_scalar(c,tmp,pidx,8,scratch); _shift_right1_scalar(c,out,pidx,8,scratch)
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,scan,32); c.jmp(nxt)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done); c.mov_imm('rax',8,32); c.ret()




def emit_topk8_bilayout(c:Code, ctxreg:str, target:str):
    """Bidirectional K8 with V4-like contiguous ascending hot layout. Domain count>=8."""
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); scores='rsi'; prev='r10'
    else:
        c.mov_mem('r10',ctxreg,0,64); scores='r10'; prev='r11'
    c.mov_mem('r8',ctxreg,24,32); n='r8'; scan='r9'
    desc=f'__bil_desc_{c.tell()}'; fallback=f'__bil_fallback_{c.tell()}'; cont=f'__bil_cont_{c.tell()}'
    c.mov_mem(prev,scores,0,32); c.mov_mem('rax',scores,4,32)
    c.cmp_rr('rax',prev,32); c.jcc('be',desc)

    # ---- ascending path kept contiguous with its continuation ----
    c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    aprobe=f'__bil_aprobe_{c.tell()}'; aall=f'__bil_aall_{c.tell()}'; afail=f'__bil_afail_{c.tell()}'; alate=f'__bil_alate_{c.tell()}'
    c.label(aprobe); c.cmp_rr(scan,n,32); c.jcc('ae',aall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('be',afail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(aprobe)
    c.label(afail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('b',fallback); c.jmp(alate)
    c.label(aall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'
    else:
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'
    c.mov_rr(scan,n,32)
    for j in range(8):
        c.bin_imm('sub',scan,1,32); c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_store(tmp,j*4,'rax',32); c.mov_store(out,j*4,scan,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(alate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'; idx='r11'
    else:
        c.mov_rr('r11',scores,64); scores='r11'; c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'; idx='rax'
    c.mov_rr(idx,scan,32)
    for j in range(8):
        c.bin_imm('sub',idx,1,32)
        if target=='linux':
            c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,j*4,'rax',32)
        else:
            c.mov_mem_index(scratch,scores,idx,2,0,32); c.mov_store(tmp,j*4,scratch,32)
        c.mov_store(out,j*4,idx,32)
    # fall directly into shared continuation
    c.label(cont)
    loop=f'__bil_loop_{c.tell()}'; done=f'__bil_done_{c.tell()}'; nxt=f'__bil_next_{c.tell()}'
    ins=[f'__bil_ins_{p}_{c.tell()}' for p in range(8)]
    _align_code(c,16); c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    for j in range(7,-1,-1):
        c.mov_mem(scratch,tmp,j*4,32); c.cmp_rr('rax',scratch,32); c.jcc('be',nxt if j==7 else ins[j+1])
    c.jmp(ins[0])
    for pidx in range(8):
        c.label(ins[pidx]); _shift_right1_scalar(c,tmp,pidx,8,scratch); _shift_right1_scalar(c,out,pidx,8,scratch)
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,scan,32); c.jmp(nxt)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done); c.mov_imm('rax',8,32); c.ret()

    # ---- descending/non-increasing path lives after the ascending return ----
    c.label(desc)
    # At entry rax=s1 and prev=s0.
    c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    dprobe=f'__bil_dprobe_{c.tell()}'; dall=f'__bil_dall_{c.tell()}'; dfail=f'__bil_dfail_{c.tell()}'; dlate=f'__bil_dlate_{c.tell()}'
    c.label(dprobe); c.cmp_rr(scan,n,32); c.jcc('ae',dall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('a',dfail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(dprobe)
    c.label(dfail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('b',fallback); c.jmp(dlate)
    c.label(dall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'
    else:
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'; scores='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(dlate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'
    else:
        c.mov_rr('r11',scores,64); scores='r11'; c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.jmp(cont)

    c.label(fallback)
    emit_topk_seed32(c,ctxreg,8,target)

def emit_topk8_bilayout16(c:Code, ctxreg:str, target:str):
    """Bidirectional K8 with V4-like contiguous ascending hot layout. Domain count>=8."""
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); scores='rsi'; prev='r10'
    else:
        c.mov_mem('r10',ctxreg,0,64); scores='r10'; prev='r11'
    c.mov_mem('r8',ctxreg,24,32); n='r8'; scan='r9'
    desc=f'__bil_desc_{c.tell()}'; fallback=f'__bil_fallback_{c.tell()}'; cont=f'__bil_cont_{c.tell()}'
    c.mov_mem(prev,scores,0,32); c.mov_mem('rax',scores,4,32)
    c.cmp_rr('rax',prev,32); c.jcc('be',desc)

    # ---- ascending path kept contiguous with its continuation ----
    c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    aprobe=f'__bil_aprobe_{c.tell()}'; aall=f'__bil_aall_{c.tell()}'; afail=f'__bil_afail_{c.tell()}'; alate=f'__bil_alate_{c.tell()}'
    c.label(aprobe); c.cmp_rr(scan,n,32); c.jcc('ae',aall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('be',afail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(aprobe)
    c.label(afail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('b',fallback); c.jmp(alate)
    c.label(aall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'
    else:
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'
    c.mov_rr(scan,n,32)
    for j in range(8):
        c.bin_imm('sub',scan,1,32); c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_store(tmp,j*4,'rax',32); c.mov_store(out,j*4,scan,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(alate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'; idx='r11'
    else:
        c.mov_rr('r11',scores,64); scores='r11'; c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'; idx='rax'
    c.mov_rr(idx,scan,32)
    for j in range(8):
        c.bin_imm('sub',idx,1,32)
        if target=='linux':
            c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,j*4,'rax',32)
        else:
            c.mov_mem_index(scratch,scores,idx,2,0,32); c.mov_store(tmp,j*4,scratch,32)
        c.mov_store(out,j*4,idx,32)
    # fall directly into shared continuation
    c.label(cont)
    loop=f'__bil_loop_{c.tell()}'; done=f'__bil_done_{c.tell()}'; nxt=f'__bil_next_{c.tell()}'
    ins=[f'__bil_ins_{p}_{c.tell()}' for p in range(8)]
    _align_code_phase(c,32,16); c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    for j in range(7,-1,-1):
        c.mov_mem(scratch,tmp,j*4,32); c.cmp_rr('rax',scratch,32); c.jcc('be',nxt if j==7 else ins[j+1])
    c.jmp(ins[0])
    for pidx in range(8):
        c.label(ins[pidx]); _shift_right1_scalar(c,tmp,pidx,8,scratch); _shift_right1_scalar(c,out,pidx,8,scratch)
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,scan,32); c.jmp(nxt)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done); c.mov_imm('rax',8,32); c.ret()

    # ---- descending/non-increasing path lives after the ascending return ----
    c.label(desc)
    # At entry rax=s1 and prev=s0.
    c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    dprobe=f'__bil_dprobe_{c.tell()}'; dall=f'__bil_dall_{c.tell()}'; dfail=f'__bil_dfail_{c.tell()}'; dlate=f'__bil_dlate_{c.tell()}'
    c.label(dprobe); c.cmp_rr(scan,n,32); c.jcc('ae',dall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('a',dfail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(dprobe)
    c.label(dfail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('b',fallback); c.jmp(dlate)
    c.label(dall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'
    else:
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'; scores='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(dlate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'
    else:
        c.mov_rr('r11',scores,64); scores='r11'; c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.jmp(cont)

    c.label(fallback)
    emit_topk_seed32(c,ctxreg,8,target)

def emit_topk8_bicompact(c:Code, ctxreg:str, target:str):
    """Compact bidirectional adaptive K8. Domain count>=8.
    Shares one fallback body and one post-prefix continuation loop to limit I-cache cost.
    """
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); scores='rsi'; prev='r10'
    else:
        c.mov_mem('r10',ctxreg,0,64); scores='r10'; prev='r11'
    c.mov_mem('r8',ctxreg,24,32); n='r8'; scan='r9'
    fallback=f'__bic_fallback_{c.tell()}'; cont=f'__bic_cont_{c.tell()}'
    c.mov_mem(prev,scores,0,32); c.mov_mem('rax',scores,4,32)
    asc=f'__bic_asc_{c.tell()}'; desc=f'__bic_desc_{c.tell()}'
    c.cmp_rr('rax',prev,32); c.jcc('a',asc); c.jmp(desc)

    # ---- ascending probe ----
    c.label(asc); c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    aprobe=f'__bic_aprobe_{c.tell()}'; aall=f'__bic_aall_{c.tell()}'; afail=f'__bic_afail_{c.tell()}'; alate=f'__bic_alate_{c.tell()}'
    c.label(aprobe); c.cmp_rr(scan,n,32); c.jcc('ae',aall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('be',afail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(aprobe)
    c.label(afail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('b',fallback); c.jmp(alate)

    c.label(aall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'
    else:
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'
    c.mov_rr(scan,n,32)
    for j in range(8):
        c.bin_imm('sub',scan,1,32); c.mov_mem_index('rax',scores,scan,2,0,32)
        c.mov_store(tmp,j*4,'rax',32); c.mov_store(out,j*4,scan,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(alate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'; idx='r11'
    else:
        c.mov_rr('r11',scores,64); scores='r11'; c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'; idx='rax'
    c.mov_rr(idx,scan,32)
    for j in range(8):
        c.bin_imm('sub',idx,1,32)
        if target=='linux':
            c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,j*4,'rax',32)
        else:
            c.mov_mem_index(scratch,scores,idx,2,0,32); c.mov_store(tmp,j*4,scratch,32)
        c.mov_store(out,j*4,idx,32)
    c.jmp(cont)

    # ---- non-increasing probe ----
    c.label(desc); c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    dprobe=f'__bic_dprobe_{c.tell()}'; dall=f'__bic_dall_{c.tell()}'; dfail=f'__bic_dfail_{c.tell()}'; dlate=f'__bic_dlate_{c.tell()}'
    c.label(dprobe); c.cmp_rr(scan,n,32); c.jcc('ae',dall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('a',dfail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(dprobe)
    c.label(dfail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('b',fallback); c.jmp(dlate)

    c.label(dall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'
    else:
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'; scores='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(dlate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'
    else:
        c.mov_rr('r11',scores,64); scores='r11'; c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.jmp(cont)

    # Shared continuation after an exact monotonic-prefix seed.
    c.label(cont)
    loop=f'__bic_loop_{c.tell()}'; done=f'__bic_done_{c.tell()}'; nxt=f'__bic_next_{c.tell()}'
    ins=[f'__bic_ins_{p}_{c.tell()}' for p in range(8)]
    _align_code(c,16); c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    for j in range(7,-1,-1):
        c.mov_mem(scratch,tmp,j*4,32); c.cmp_rr('rax',scratch,32); c.jcc('be',nxt if j==7 else ins[j+1])
    c.jmp(ins[0])
    for pidx in range(8):
        c.label(ins[pidx]); _shift_right1_scalar(c,tmp,pidx,8,scratch); _shift_right1_scalar(c,out,pidx,8,scratch)
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,scan,32); c.jmp(nxt)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done); c.mov_imm('rax',8,32); c.ret()

    # One shared exact fallback for early non-monotonic inputs.
    c.label(fallback)
    emit_topk_seed32(c,ctxreg,8,target)

def emit_topk8_biadaptive(c:Code, ctxreg:str, target:str):
    """Exact K8 with direction-selected monotonic probe.

    If s1>s0, probe strict ascending (same opportunity as V4).
    Otherwise probe non-increasing, where the first eight items are already exact Top-8.
    On a late break, materialize the exact prefix Top-8 and continue at the break.
    On an early break (<8), fall back to the validated seeded path from scratch.
    Domain: count>=8.
    """
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); scores='rsi'; prev='r10'
    else:
        c.mov_mem('r10',ctxreg,0,64); scores='r10'; prev='r11'
    c.mov_mem('r8',ctxreg,24,32); n='r8'; scan='r9'
    c.mov_mem(prev,scores,0,32)
    c.mov_mem('rax',scores,4,32)
    asc=f'__bi8_asc_{c.tell()}'; desc=f'__bi8_desc_{c.tell()}'
    c.cmp_rr('rax',prev,32); c.jcc('a',asc); c.jmp(desc)

    # ---------- strict ascending ----------
    c.label(asc); c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    aprobe=f'__bi8_aprobe_{c.tell()}'; aall=f'__bi8_aall_{c.tell()}'; afail=f'__bi8_afail_{c.tell()}'; alate=f'__bi8_alate_{c.tell()}'
    c.label(aprobe); c.cmp_rr(scan,n,32); c.jcc('ae',aall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('be',afail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(aprobe)
    c.label(afail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('ae',alate)
    emit_topk_seed32(c,ctxreg,8,target)

    c.label(aall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'
    else:
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'
    c.mov_rr(scan,n,32)
    for j in range(8):
        c.bin_imm('sub',scan,1,32); c.mov_mem_index('rax',scores,scan,2,0,32)
        c.mov_store(tmp,j*4,'rax',32); c.mov_store(out,j*4,scan,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(alate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'; idx='r11'
    else:
        c.mov_rr('r11',scores,64); scores='r11'
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'; idx='rax'
    c.mov_rr(idx,scan,32)
    for j in range(8):
        c.bin_imm('sub',idx,1,32)
        if target=='linux':
            c.mov_mem_index('rax',scores,idx,2,0,32); c.mov_store(tmp,j*4,'rax',32)
        else:
            c.mov_mem_index(scratch,scores,idx,2,0,32); c.mov_store(tmp,j*4,scratch,32)
        c.mov_store(out,j*4,idx,32)
    aloop=f'__bi8_aloop_{c.tell()}'; adone=f'__bi8_adone_{c.tell()}'; anxt=f'__bi8_anext_{c.tell()}'
    ains=[f'__bi8_ains_{p}_{c.tell()}' for p in range(8)]
    _align_code(c,16); c.label(aloop); c.cmp_rr(scan,n,32); c.jcc('ae',adone)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    for j in range(7,-1,-1):
        c.mov_mem(scratch,tmp,j*4,32); c.cmp_rr('rax',scratch,32); c.jcc('be',anxt if j==7 else ains[j+1])
    c.jmp(ains[0])
    for pidx in range(8):
        c.label(ains[pidx]); _shift_right1_scalar(c,tmp,pidx,8,scratch); _shift_right1_scalar(c,out,pidx,8,scratch)
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,scan,32); c.jmp(anxt)
    c.label(anxt); c.bin_imm('add',scan,1,32); c.jmp(aloop); c.label(adone); c.mov_imm('rax',8,32); c.ret()

    # ---------- non-increasing ----------
    c.label(desc); c.mov_rr(prev,'rax',32); c.mov_imm(scan,2,32)
    dprobe=f'__bi8_dprobe_{c.tell()}'; dall=f'__bi8_dall_{c.tell()}'; dfail=f'__bi8_dfail_{c.tell()}'; dlate=f'__bi8_dlate_{c.tell()}'
    c.label(dprobe); c.cmp_rr(scan,n,32); c.jcc('ae',dall)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.cmp_rr('rax',prev,32); c.jcc('a',dfail)
    c.mov_rr(prev,'rax',32); c.bin_imm('add',scan,1,32); c.jmp(dprobe)
    c.label(dfail); c.mov_imm('rax',8,32); c.cmp_rr(scan,'rax',32); c.jcc('ae',dlate)
    emit_topk_seed32(c,ctxreg,8,target)

    c.label(dall)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'
    else:
        # scores still r10; pointers can be loaded from ctx before rcx is repurposed.
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('r11',ctxreg,16,64); out,tmp='rdx','r11'; scores='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    c.mov_imm('rax',8,32); c.ret()

    c.label(dlate)
    if target=='linux':
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scores='rsi'; scratch='r10'
    else:
        c.mov_rr('r11',scores,64); scores='r11'
        c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); out,tmp='rdx','rcx'; scratch='r10'
    for j in range(8):
        c.mov_mem('rax',scores,j*4,32); c.mov_store(tmp,j*4,'rax',32); c.mov_imm_mem(out,j*4,j,32)
    dloop=f'__bi8_dloop_{c.tell()}'; ddone=f'__bi8_ddone_{c.tell()}'; dnxt=f'__bi8_dnext_{c.tell()}'
    dins=[f'__bi8_dins_{p}_{c.tell()}' for p in range(8)]
    _align_code(c,16); c.label(dloop); c.cmp_rr(scan,n,32); c.jcc('ae',ddone)
    c.mov_mem_index('rax',scores,scan,2,0,32)
    for j in range(7,-1,-1):
        c.mov_mem(scratch,tmp,j*4,32); c.cmp_rr('rax',scratch,32); c.jcc('be',dnxt if j==7 else dins[j+1])
    c.jmp(dins[0])
    for pidx in range(8):
        c.label(dins[pidx]); _shift_right1_scalar(c,tmp,pidx,8,scratch); _shift_right1_scalar(c,out,pidx,8,scratch)
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,scan,32); c.jmp(dnxt)
    c.label(dnxt); c.bin_imm('add',scan,1,32); c.jmp(dloop); c.label(ddone); c.mov_imm('rax',8,32); c.ret()

def emit_topk_back(c:Code, ctxreg:str, k:int, target:str):
    if k not in (2,4,8): die(f'topkback unsupported K={k}')
    if target=='linux':
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdx','rcx','r8','r9','rdi'; saved=[]
    else:
        _push(c,'rsi'); _push(c,'rdi'); saved=['rsi','rdi']
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdi',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdi','rdx','r8','r9','rcx'
    for j in range(k):
        c.mov_imm_mem(tmp,j*4,0,32); c.mov_imm_mem(out,j*4,0xffffffff,32)
    c.mov_imm(scan,0,32)
    loop=f'__back_loop_{k}_{c.tell()}'; done=f'__back_done_{k}_{c.tell()}'; nxt=f'__back_next_{k}_{c.tell()}'
    inserts=[f'__back_insert_{k}_{p}_{c.tell()}' for p in range(k)]
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_rr(cid,scan,32)
    # Find insertion point from worst to best; reject with one compare when candidate misses Top-K.
    for j in range(k-1,-1,-1):
        off=j*4; better=f'__back_better_{k}_{j}_{c.tell()}'
        notbetter=nxt if j==k-1 else inserts[j+1]
        c.mov_mem('r10',tmp,off,32); c.mov_mem('r11',out,off,32)
        c.cmp_rr('rax','r10',32); c.jcc('a',better); c.jcc('b',notbetter)
        c.cmp_rr(cid,'r11',32); c.jcc('ae',notbetter); c.label(better)
    c.jmp(inserts[0])
    # Shift only the suffix that actually moves, then install candidate once.
    for pidx in range(k):
        c.label(inserts[pidx])
        for j in range(k-1,pidx,-1):
            c.mov_mem('r10',tmp,(j-1)*4,32); c.mov_store(tmp,j*4,'r10',32)
            c.mov_mem('r11',out,(j-1)*4,32); c.mov_store(out,j*4,'r11',32)
        c.mov_store(tmp,pidx*4,'rax',32); c.mov_store(out,pidx*4,cid,32); c.jmp(nxt)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done)
    c.mov_imm('r10',k,32); c.cmp_rr(n,'r10',32); retn=f'__back_retn_{k}_{c.tell()}'; ep=f'__back_ep_{k}_{c.tell()}'
    c.jcc('b',retn); c.mov_imm('rax',k,32); c.jmp(ep); c.label(retn); c.mov_rr('rax',n,32); c.label(ep)
    for r in reversed(saved): _pop(c,r)
    c.ret()

def emit_topk_reg(c:Code, ctxreg:str, k:int, target:str):
    if k not in (1,2): die(f'topkreg supports only K=1/2, got {k}')
    if target=='linux':
        # ctx rdi retained; scores rsi, n r8, scan r9, cs rax, cid rdx.
        saved=[]
        if k==1:
            bs,bi='rcx','r10'; states=[(bs,bi)]
        else:
            _push(c,'r12'); saved=['r12']; states=[('rcx','r10'),('r11','r12')]
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32)
        scores,n,scan,cs,cid='rsi','r8','r9','rax','rdx'
    else:
        # ctx rcx retained; RSI and R12/R13 preserved as required by Windows x64 ABI.
        _push(c,'rsi'); saved=['rsi']
        if k==1:
            states=[('r10','r11')]
        else:
            _push(c,'r12'); _push(c,'r13'); saved=['rsi','r12','r13']; states=[('r10','r11'),('r12','r13')]
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('r8',ctxreg,24,32)
        scores,n,scan,cs,cid='rsi','r8','r9','rax','rdx'
    for ss,ii in states:
        c.mov_imm(ss,0,32); c.mov_imm(ii,0xffffffff,32)
    c.mov_imm(scan,0,32)
    loop=f'__reg_loop_{k}_{c.tell()}'; done=f'__reg_done_{k}_{c.tell()}'; nxt=f'__reg_next_{k}_{c.tell()}'
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index(cs,scores,scan,2,0,32); c.mov_rr(cid,scan,32)
    if k==1:
        take=f'__reg_take0_{c.tell()}'; skip=nxt
        _better_branch(c,cs,cid,states[0][0],states[0][1],take,skip)
        c.label(take); c.mov_rr(states[0][0],cs,32); c.mov_rr(states[0][1],cid,32)
    else:
        take0=f'__reg_take0_{c.tell()}'; chk1=f'__reg_chk1_{c.tell()}'
        _better_branch(c,cs,cid,states[0][0],states[0][1],take0,chk1)
        c.label(take0)
        c.mov_rr(states[1][0],states[0][0],32); c.mov_rr(states[1][1],states[0][1],32)
        c.mov_rr(states[0][0],cs,32); c.mov_rr(states[0][1],cid,32); c.jmp(nxt)
        c.label(chk1)
        take1=f'__reg_take1_{c.tell()}'
        _better_branch(c,cs,cid,states[1][0],states[1][1],take1,nxt)
        c.label(take1); c.mov_rr(states[1][0],cs,32); c.mov_rr(states[1][1],cid,32)
    c.label(nxt); c.bin_imm('add',scan,1,32); c.jmp(loop); c.label(done)
    # Materialize exactly the same observable top IDs and temp scores as V2.
    if target=='linux':
        c.mov_mem('rsi',ctxreg,16,64)
        for j,(ss,ii) in enumerate(states): c.mov_store('rsi',j*4,ss,32)
        c.mov_mem('rsi',ctxreg,8,64)
        for j,(ss,ii) in enumerate(states): c.mov_store('rsi',j*4,ii,32)
    else:
        c.mov_mem('rsi',ctxreg,16,64)
        for j,(ss,ii) in enumerate(states): c.mov_store('rsi',j*4,ss,32)
        c.mov_mem('rsi',ctxreg,8,64)
        for j,(ss,ii) in enumerate(states): c.mov_store('rsi',j*4,ii,32)
    c.mov_imm('r10' if target=='linux' else 'r10',k,32); c.cmp_rr(n,'r10',32)
    retn=f'__reg_retn_{k}_{c.tell()}'; ep=f'__reg_ep_{k}_{c.tell()}'
    c.jcc('b',retn); c.mov_imm('rax',k,32); c.jmp(ep); c.label(retn); c.mov_rr('rax',n,32); c.label(ep)
    for r in reversed(saved): _pop(c,r)
    c.ret()

def emit_topk_fixed(c:Code, ctxreg:str, k:int, target:str, guarded:bool=False):
    if k not in (1,2,4,8): die(f'topkfixed unsupported K={k}')
    # Cache all ABI pointers/count once. No external calls, heap, or relocations.
    if target=='linux':
        # ctx=rdi -> scores=rsi, out=rdx, tmp=rcx, n=r8d, scan=r9d,
        # candidate score=eax, candidate id=edi, old score=r10d, old id=r11d.
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdx',ctxreg,8,64); c.mov_mem('rcx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdx','rcx','r8','r9','rdi'
        saved=[]
    else:
        # Windows x64: preserve nonvolatile RSI/RDI; ctx=rcx may be reused as candidate id after setup.
        c.emit(0x56,0x57)  # push rsi; push rdi
        c.mov_mem('rsi',ctxreg,0,64); c.mov_mem('rdi',ctxreg,8,64); c.mov_mem('rdx',ctxreg,16,64); c.mov_mem('r8',ctxreg,24,32)
        scores,out,tmp,n,scan,cid='rsi','rdi','rdx','r8','r9','rcx'
        saved=['rdi','rsi']
    for j in range(k):
        off=j*4; c.mov_imm_mem(tmp,off,0,32); c.mov_imm_mem(out,off,0xffffffff,32)
    c.mov_imm(scan,0,32)
    loop=f'__topk_loop_{k}_{c.tell()}'; done=f'__topk_done_{k}_{c.tell()}'
    nextscan=f'__topk_nextscan_{k}_{c.tell()}'
    c.label(loop); c.cmp_rr(scan,n,32); c.jcc('ae',done)
    c.mov_mem_index('rax',scores,scan,2,0,32); c.mov_rr(cid,scan,32)
    if guarded and k>1:
        off=(k-1)*4
        c.mov_mem('r10',tmp,off,32); c.mov_mem('r11',out,off,32)
        take=f'__topk_guard_take_{k}_{c.tell()}'
        c.cmp_rr('rax','r10',32); c.jcc('b',nextscan); c.jcc('a',take)
        c.cmp_rr(cid,'r11',32); c.jcc('ae',nextscan); c.label(take)
    for j in range(k):
        off=j*4; skip=f'__topk_skip_{k}_{j}_{c.tell()}'; take=f'__topk_take_{k}_{j}_{c.tell()}'
        c.mov_mem('r10',tmp,off,32); c.mov_mem('r11',out,off,32)
        c.cmp_rr('rax','r10',32); c.jcc('b',skip); c.jcc('a',take)
        c.cmp_rr(cid,'r11',32); c.jcc('ae',skip); c.label(take)
        c.mov_store(tmp,off,'rax',32); c.mov_store(out,off,cid,32)
        if j+1<k:
            c.mov_rr('rax','r10',32); c.mov_rr(cid,'r11',32)
        c.label(skip)
    c.label(nextscan); c.bin_imm('add',scan,1,32); c.jmp(loop)
    c.label(done)
    # return min(n,k)
    c.mov_imm('r10',k,32); c.cmp_rr(n,'r10',32)
    ret_n=f'__topk_retn_{k}_{c.tell()}'; ep=f'__topk_ep_{k}_{c.tell()}'
    c.jcc('b',ret_n); c.mov_imm('rax',k,32); c.jmp(ep)
    c.label(ret_n); c.mov_rr('rax',n,32); c.label(ep)
    if target!='linux': c.emit(0x5F,0x5E)  # pop rdi; pop rsi
    c.ret()




def _kv_store_masks_ret(c:Code,ctx:str,enter:int|str,leave:int|str,changed:int):
    c.mov_mem('r8',ctx,16,64)
    if isinstance(enter,int): c.mov_imm_mem('r8',0,enter,32)
    else: c.mov_store('r8',0,enter,32)
    if isinstance(leave,int): c.mov_imm_mem('r8',4,leave,32)
    else: c.mov_store('r8',4,leave,32)
    c.mov_imm('rax',changed,32); c.ret()

def emit_kvplan_from_empty(c:Code,ctx:str,target='linux'):
    # Preconditions: current_count == 0, 1 <= target_count <= 8.
    c.mov_mem('rcx',ctx,28,32)
    c.mov_imm('rax',1,32); c.shift_cl('shl','rax',32); c.bin_imm('sub','rax',1,32)
    c.mov_mem('r8',ctx,16,64); c.mov_store('r8',0,'rax',32); c.mov_imm_mem('r8',4,0,32)
    c.mov_imm('rax',1,32); c.ret()

def emit_kvplan_to_empty(c:Code,ctx:str,target='linux'):
    # Preconditions: target_count == 0, 1 <= current_count <= 8.
    c.mov_mem('rcx',ctx,24,32)
    c.mov_imm('rax',1,32); c.shift_cl('shl','rax',32); c.bin_imm('sub','rax',1,32)
    c.mov_mem('r8',ctx,16,64); c.mov_imm_mem('r8',0,0,32); c.mov_store('r8',4,'rax',32)
    c.mov_imm('rax',1,32); c.ret()

def emit_kvplan_both_empty(c:Code,ctx:str,target='linux'):
    # Preconditions: current_count == target_count == 0.
    c.mov_mem('r8',ctx,16,64); c.mov_imm_mem('r8',0,0,32); c.mov_imm_mem('r8',4,0,32)
    c.mov_imm('rax',0,32); c.ret()

def emit_kvplan1fast(c:Code,ctx:str,target='linux'):
    # Full K=1 exact set transition: one comparison determines both masks.
    c.mov_mem('r8',ctx,0,64); c.mov_mem('r9',ctx,8,64)
    c.mov_mem('rax','r8',0,32); c.cmp_mem('rax','r9',0,32)
    changed=f'__kv1_changed_{c.tell()}'
    c.jcc('ne',changed)
    _kv_store_masks_ret(c,ctx,0,0,0)
    c.label(changed)
    _kv_store_masks_ret(c,ctx,1,1,1)

def emit_kvplan2fast(c:Code,ctx:str,target='linux'):
    # Full K=2, unique IDs. Decision tree uses <=4 equality checks.
    c.mov_mem('r8',ctx,0,64); c.mov_mem('r9',ctx,8,64)
    # c0 in eax, c1 in edx
    c.mov_mem('rax','r8',0,32); c.mov_mem('rdx','r8',4,32)
    c.cmp_mem('rax','r9',0,32)
    c0_t0=f'__kv2_c0t0_{c.tell()}'; c0_t1=f'__kv2_c0t1_{c.tell()}'; no_c0=f'__kv2_noc0_{c.tell()}'
    c.jcc('e',c0_t0)
    c.cmp_mem('rax','r9',4,32); c.jcc('e',c0_t1); c.jmp(no_c0)
    # c0==t0: only second pair can differ.
    c.label(c0_t0); c.cmp_mem('rdx','r9',4,32)
    diff11=f'__kv2_diff11_{c.tell()}'; c.jcc('ne',diff11)
    _kv_store_masks_ret(c,ctx,0,0,0)
    c.label(diff11); _kv_store_masks_ret(c,ctx,2,2,1)
    # c0==t1: either swap (unchanged set) or t0 enters / c1 leaves.
    c.label(c0_t1); c.cmp_mem('rdx','r9',0,32)
    c0t1_diff=f'__kv2_c0t1diff_{c.tell()}'; c.jcc('ne',c0t1_diff)
    _kv_store_masks_ret(c,ctx,0,0,0)
    c.label(c0t1_diff); _kv_store_masks_ret(c,ctx,1,2,1)
    # c0 matches neither target. Check c1 against t0/t1.
    c.label(no_c0); c.cmp_mem('rdx','r9',0,32)
    c1_t0=f'__kv2_c1t0_{c.tell()}'; c1_t1=f'__kv2_c1t1_{c.tell()}'; none=f'__kv2_none_{c.tell()}'
    c.jcc('e',c1_t0); c.cmp_mem('rdx','r9',4,32); c.jcc('e',c1_t1); c.jmp(none)
    c.label(c1_t0); _kv_store_masks_ret(c,ctx,2,1,1)
    c.label(c1_t1); _kv_store_masks_ret(c,ctx,1,1,1)
    c.label(none); _kv_store_masks_ret(c,ctx,3,3,1)

def emit_kvplanfull(c:Code,ctx:str,k:int,target='linux'):
    if k not in (1,2,4,8): die('kvplanfull K must be 1/2/4/8')
    # Preconditions: current_count == target_count == K and both lists contain unique IDs.
    c.mov_mem('r8',ctx,0,64)
    c.mov_mem('r9',ctx,8,64)
    c.mov_imm('r10',0,32)
    c.mov_imm('r11',0,32)
    for i in range(k):
        found=f'__kvf_e_found_{k}_{i}_{c.tell()}'
        c.mov_mem('rax','r9',i*4,32)
        for j in range(k):
            c.cmp_mem('rax','r8',j*4,32)
            c.jcc('e',found)
        c.bin_imm('or','r10',1<<i,32)
        c.label(found)
    for i in range(k):
        found=f'__kvf_l_found_{k}_{i}_{c.tell()}'
        c.mov_mem('rax','r8',i*4,32)
        for j in range(k):
            c.cmp_mem('rax','r9',j*4,32)
            c.jcc('e',found)
        c.bin_imm('or','r11',1<<i,32)
        c.label(found)
    c.mov_mem('r8',ctx,16,64)
    c.mov_store('r8',0,'r10',32)
    c.mov_store('r8',4,'r11',32)
    c.mov_rr('rax','r10',32)
    c.bin_rr('or','rax','r11',32)
    unchanged=f'__kvf_unchanged_{k}_{c.tell()}'
    c.test_rr('rax','rax',32)
    c.jcc('z',unchanged)
    c.mov_imm('rax',1,32)
    c.ret()
    c.label(unchanged)
    c.mov_imm('rax',0,32)
    c.ret()

def emit_kvplanfullssematrix(c:Code,ctx:str,k:int,target='linux'):
    if k not in (4,8): die('kvplanfullssematrix K must be 4/8')
    # Exact set-membership matrix: target->current comparisons also identify all current lanes present,
    # so leave_mask is complement of accumulated matched current lanes.
    c.mov_mem('r8',ctx,0,64); c.mov_mem('r9',ctx,8,64)
    c.mov_imm('r10',0,32); c.mov_imm('r11',0,32)
    shufs=(0x00,0x55,0xAA,0xFF)
    if k==4:
        c.movdqu_load(0,'r8',0); c.movdqu_load(1,'r9',0)
        for i,im in enumerate(shufs):
            c.movdqa_rr(2,1); c.pshufd(2,2,im); c.movdqa_rr(3,0); c.pcmpeqd(3,2); c.movmskps('rax',3)
            c.bin_rr('or','r11','rax',32)
            f=f'__kvm_e4_{i}_{c.tell()}'; c.test_rr('rax','rax',32); c.jcc('ne',f); c.bin_imm('or','r10',1<<i,32); c.label(f)
        c.bin_imm('xor','r11',0x0f,32)
    else:
        c.movdqu_load(0,'r8',0); c.movdqu_load(1,'r8',16); c.movdqu_load(2,'r9',0); c.movdqu_load(3,'r9',16)
        for i in range(8):
            src=2 if i<4 else 3; im=shufs[i&3]
            c.movdqa_rr(4,src); c.pshufd(4,4,im)
            c.movdqa_rr(5,0); c.pcmpeqd(5,4); c.movmskps('rax',5)
            c.pcmpeqd(4,1); c.movmskps('rdx',4); c.shift_imm('shl','rdx',4,32)
            c.bin_rr('or','rax','rdx',32); c.bin_rr('or','r11','rax',32)
            f=f'__kvm_e8_{i}_{c.tell()}'; c.test_rr('rax','rax',32); c.jcc('ne',f); c.bin_imm('or','r10',1<<i,32); c.label(f)
        c.bin_imm('xor','r11',0xff,32)
    c.mov_mem('r8',ctx,16,64); c.mov_store('r8',0,'r10',32); c.mov_store('r8',4,'r11',32)
    c.mov_rr('rdx','r10',32); c.bin_rr('or','rdx','r11',32); c.mov_imm('rax',0,32); c.test_rr('rdx','rdx',32); c.setcc('ne','rax'); c.ret()

def emit_kvplanfullsse(c:Code,ctx:str,k:int,target='linux'):
    if k not in (4,8): die('kvplanfullsse K must be 4/8')
    c.mov_mem('r8',ctx,0,64); c.mov_mem('r9',ctx,8,64)
    c.mov_imm('r10',0,32); c.mov_imm('r11',0,32)
    shufs=(0x00,0x55,0xAA,0xFF)
    if k==4:
        c.movdqu_load(0,'r8',0); c.movdqu_load(1,'r9',0)
        for i,im in enumerate(shufs):
            c.movdqa_rr(2,1); c.pshufd(2,2,im); c.movdqa_rr(3,0); c.pcmpeqd(3,2); c.movmskps('rax',3)
            f=f'__kvfsse_e4_{i}_{c.tell()}'; c.test_rr('rax','rax',32); c.jcc('ne',f); c.bin_imm('or','r10',1<<i,32); c.label(f)
        for i,im in enumerate(shufs):
            c.movdqa_rr(2,0); c.pshufd(2,2,im); c.movdqa_rr(3,1); c.pcmpeqd(3,2); c.movmskps('rax',3)
            f=f'__kvfsse_l4_{i}_{c.tell()}'; c.test_rr('rax','rax',32); c.jcc('ne',f); c.bin_imm('or','r11',1<<i,32); c.label(f)
    else:
        c.movdqu_load(0,'r8',0); c.movdqu_load(1,'r8',16); c.movdqu_load(2,'r9',0); c.movdqu_load(3,'r9',16)
        for i in range(8):
            src=2 if i<4 else 3; im=shufs[i&3]
            c.movdqa_rr(4,src); c.pshufd(4,4,im); c.movdqa_rr(5,0); c.pcmpeqd(5,4); c.pcmpeqd(4,1); c.por_xmm(5,4); c.movmskps('rax',5)
            f=f'__kvfsse_e8_{i}_{c.tell()}'; c.test_rr('rax','rax',32); c.jcc('ne',f); c.bin_imm('or','r10',1<<i,32); c.label(f)
        for i in range(8):
            src=0 if i<4 else 1; im=shufs[i&3]
            c.movdqa_rr(4,src); c.pshufd(4,4,im); c.movdqa_rr(5,2); c.pcmpeqd(5,4); c.pcmpeqd(4,3); c.por_xmm(5,4); c.movmskps('rax',5)
            f=f'__kvfsse_l8_{i}_{c.tell()}'; c.test_rr('rax','rax',32); c.jcc('ne',f); c.bin_imm('or','r11',1<<i,32); c.label(f)
    c.mov_mem('r8',ctx,16,64); c.mov_store('r8',0,'r10',32); c.mov_store('r8',4,'r11',32)
    c.mov_rr('rdx','r10',32); c.bin_rr('or','rdx','r11',32); c.mov_imm('rax',0,32); c.test_rr('rdx','rdx',32); c.setcc('ne','rax'); c.ret()


def emit_kvplan3to2sse(c:Code,ctx:str,target='linux'):
    # Preconditions: current_count=3, target_count=2, IDs unique in each list.
    # Exact SSE2 membership matrix, safe for arrays sized exactly to valid counts.
    c.mov_mem('r8',ctx,0,64); c.mov_mem('r9',ctx,8,64)
    # xmm0 = [c0,c1,c2,0] without reading beyond current_count.
    c.movq_xmm_mem(0,'r8',0)
    c.mov_mem('rax','r8',8,32); c.movd_xmm_reg32(1,'rax'); c.punpcklqdq(0,1)
    # m0 in eax for target[0].
    c.mov_mem('rax','r9',0,32); c.movd_xmm_reg32(2,'rax'); c.pshufd(2,2,0x00)
    c.movdqa_rr(3,0); c.pcmpeqd(3,2); c.movmskps('rax',3); c.bin_imm('and','rax',7,32)
    # m1 in edx for target[1].
    c.mov_mem('rdx','r9',4,32); c.movd_xmm_reg32(2,'rdx'); c.pshufd(2,2,0x00)
    c.movdqa_rr(3,0); c.pcmpeqd(3,2); c.movmskps('rdx',3); c.bin_imm('and','rdx',7,32)
    # enter = (m0==0) | ((m1==0)<<1)
    c.mov_imm('r10',0,32); c.test_rr('rax','rax',32); c.setcc('e','r10')
    c.mov_imm('r8',0,32); c.test_rr('rdx','rdx',32); c.setcc('e','r8'); c.shift_imm('shl','r8',1,32); c.bin_rr('or','r10','r8',32)
    # leave = ~(m0|m1) & 7
    c.mov_rr('r11','rax',32); c.bin_rr('or','r11','rdx',32); c.bin_imm('xor','r11',7,32)
    c.mov_mem('r8',ctx,16,64); c.mov_store('r8',0,'r10',32); c.mov_store('r8',4,'r11',32)
    c.mov_imm('rax',1,32); c.ret()

def emit_kvplan1to5sse(c:Code,ctx:str,target='linux'):
    # Preconditions: current_count=1, target_count=5, IDs unique in target.
    c.mov_mem('r8',ctx,0,64); c.mov_mem('r9',ctx,8,64)
    c.mov_mem('rax','r8',0,32)
    c.movd_xmm_reg32(0,'rax'); c.pshufd(0,0,0x00)
    c.movdqu_load(1,'r9',0); c.pcmpeqd(0,1); c.movmskps('rdx',0); c.bin_imm('and','rdx',0x0f,32)
    c.mov_imm('r8',0,32); c.cmp_mem('rax','r9',16,32); c.setcc('e','r8'); c.shift_imm('shl','r8',4,32); c.bin_rr('or','rdx','r8',32)
    c.mov_rr('r10','rdx',32); c.bin_imm('xor','r10',0x1f,32)
    c.mov_imm('r11',0,32); c.test_rr('rdx','rdx',32); c.setcc('e','r11')
    c.mov_mem('r8',ctx,16,64); c.mov_store('r8',0,'r10',32); c.mov_store('r8',4,'r11',32)
    c.mov_imm('rax',1,32); c.ret()

def emit_kvplan5to1sse(c:Code,ctx:str,target='linux'):
    # Preconditions: current_count=5, target_count=1, IDs unique in current.
    c.mov_mem('r8',ctx,0,64); c.mov_mem('r9',ctx,8,64)
    c.mov_mem('rax','r9',0,32)
    c.movd_xmm_reg32(0,'rax'); c.pshufd(0,0,0x00)
    c.movdqu_load(1,'r8',0); c.pcmpeqd(0,1); c.movmskps('rdx',0); c.bin_imm('and','rdx',0x0f,32)
    c.mov_imm('r9',0,32); c.cmp_mem('rax','r8',16,32); c.setcc('e','r9'); c.shift_imm('shl','r9',4,32); c.bin_rr('or','rdx','r9',32)
    c.mov_rr('r11','rdx',32); c.bin_imm('xor','r11',0x1f,32)
    c.mov_imm('r10',0,32); c.test_rr('rdx','rdx',32); c.setcc('e','r10')
    c.mov_mem('r8',ctx,16,64); c.mov_store('r8',0,'r10',32); c.mov_store('r8',4,'r11',32)
    c.mov_imm('rax',1,32); c.ret()

def emit_kvplan(c:Code,ctx:str,k:int,target='linux'):
    if k < 1 or k > 8: die('kvplan K must be 1..8')
    # ABI: +0 current_ids*, +8 target_ids*, +16 out_masks*, +24 current_count, +28 target_count.
    # Volatile-only register plan for both SysV and Win64:
    # r8=current ptr, r9=target ptr, r10d=enter mask, r11d=leave mask,
    # eax=value/scratch, edx=count.
    c.mov_mem('r8',ctx,0,64)
    c.mov_mem('r9',ctx,8,64)
    c.mov_imm('r10',0,32)
    c.mov_imm('r11',0,32)

    # target slot i absent from current => enter bit i
    for i in range(k):
        skip=f'__kv_e_skip_{k}_{i}_{c.tell()}'
        found=f'__kv_e_found_{k}_{i}_{c.tell()}'
        missing=f'__kv_e_missing_{k}_{i}_{c.tell()}'
        c.mov_mem('rdx',ctx,28,32)
        c.mov_imm('rax',i+1,32)
        c.cmp_rr('rdx','rax',32)
        c.jcc('b',skip)
        c.mov_mem('rax','r9',i*4,32)
        c.mov_mem('rdx',ctx,24,32)
        c.test_rr('rdx','rdx',32)
        c.jcc('z',missing)
        for j in range(k):
            c.cmp_mem('rax','r8',j*4,32)
            c.jcc('e',found)
            if j != k-1:
                c.bin_imm('sub','rdx',1,32)
                c.jcc('z',missing)
        c.label(missing)
        c.bin_imm('or','r10',1<<i,32)
        c.label(found)
        c.label(skip)

    # current slot i absent from target => leave bit i
    for i in range(k):
        skip=f'__kv_l_skip_{k}_{i}_{c.tell()}'
        found=f'__kv_l_found_{k}_{i}_{c.tell()}'
        missing=f'__kv_l_missing_{k}_{i}_{c.tell()}'
        c.mov_mem('rdx',ctx,24,32)
        c.mov_imm('rax',i+1,32)
        c.cmp_rr('rdx','rax',32)
        c.jcc('b',skip)
        c.mov_mem('rax','r8',i*4,32)
        c.mov_mem('rdx',ctx,28,32)
        c.test_rr('rdx','rdx',32)
        c.jcc('z',missing)
        for j in range(k):
            c.cmp_mem('rax','r9',j*4,32)
            c.jcc('e',found)
            if j != k-1:
                c.bin_imm('sub','rdx',1,32)
                c.jcc('z',missing)
        c.label(missing)
        c.bin_imm('or','r11',1<<i,32)
        c.label(found)
        c.label(skip)

    c.mov_mem('r8',ctx,16,64)
    c.mov_store('r8',0,'r10',32)
    c.mov_store('r8',4,'r11',32)
    c.mov_rr('rax','r10',32)
    c.bin_rr('or','rax','r11',32)
    unchanged=f'__kv_unchanged_{k}_{c.tell()}'
    c.test_rr('rax','rax',32)
    c.jcc('z',unchanged)
    c.mov_imm('rax',1,32)
    c.ret()
    c.label(unchanged)
    c.mov_imm('rax',0,32)
    c.ret()

def compile_fn(fn:Fn,constants,data_offsets=None,target='linux')->tuple[bytes,list[tuple[int,str,int]]]:
    regs=alloc_regs(fn,target); c=Code(); internal=0; sticky_data=None; data_offsets=data_offsets or {}
    data_scratch='rsi' if target=='linux' else 'r10'
    skip_ins=0
    # skip let: allocation is static and x86 locals need no initialization unless used before def.
    for pos,ins in enumerate(fn.body):
        if skip_ins:
            skip_ins-=1; continue
        op=ins.op; a=ins.args
        if op=='let': continue
        if op in ('kvplan1fast','kvplan2fast','kvplanfromempty','kvplantoempty','kvplanbothempty','kvplan3to2sse','kvplan1to5sse','kvplan5to1sse'):
            ctx=a[0]
            if ctx not in regs: die(f'{op} expects ctx register',ins.line)
            if op=='kvplan1fast': emit_kvplan1fast(c,regs[ctx],target)
            elif op=='kvplan2fast': emit_kvplan2fast(c,regs[ctx],target)
            elif op=='kvplanfromempty': emit_kvplan_from_empty(c,regs[ctx],target)
            elif op=='kvplantoempty': emit_kvplan_to_empty(c,regs[ctx],target)
            elif op=='kvplanbothempty': emit_kvplan_both_empty(c,regs[ctx],target)
            elif op=='kvplan3to2sse': emit_kvplan3to2sse(c,regs[ctx],target)
            elif op=='kvplan1to5sse': emit_kvplan1to5sse(c,regs[ctx],target)
            else: emit_kvplan5to1sse(c,regs[ctx],target)
            continue
        if op=='kvplanfull':
            ctx,k=a; kv=imm(k,constants)
            if ctx not in regs or kv is None: die('kvplanfull expects ctx register and immediate K',ins.line)
            emit_kvplanfull(c,regs[ctx],kv,target)
            continue
        if op=='kvplanfullsse':
            ctx,k=a; kv=imm(k,constants)
            if ctx not in regs or kv is None: die('kvplanfullsse expects ctx register and immediate K',ins.line)
            emit_kvplanfullsse(c,regs[ctx],kv,target)
            continue
        if op=='kvplanfullssematrix':
            ctx,k=a; kv=imm(k,constants)
            if ctx not in regs or kv is None: die('kvplanfullssematrix expects ctx register and immediate K',ins.line)
            emit_kvplanfullssematrix(c,regs[ctx],kv,target)
            continue
        if op=='kvplan':
            ctx,k=a; kv=imm(k,constants)
            if ctx not in regs or kv is None: die('kvplan expects ctx register and immediate K',ins.line)
            emit_kvplan(c,regs[ctx],kv,target)
            continue
        if op in ('topkfixed','topkguarded','topkreg','topkback','topkseed','topkseed32','topk2strictreg','topk8adaptive','topkseedfall','topk2strictfall','topk4regs','topk4worstcache','topk8biadaptive','topk8bicompact','topk8bilayout','topk8bilayout16','topk2short','topk2short16','topknoninc','topkstrictasc','topknonincpair','topkstrictascpair','topknonincsse','topkstrictascsse','topk2strictasclea','topknonincsseids','topkstrictascsseids'):
            ctx,k=a; kv=imm(k,constants)
            if ctx not in regs or kv is None: die(f'{op} expects ctx register and immediate K',ins.line)
            if op=='topkreg': emit_topk_reg(c,regs[ctx],kv,target)
            elif op=='topkback': emit_topk_back(c,regs[ctx],kv,target)
            elif op=='topkseed': emit_topk_seed(c,regs[ctx],kv,target)
            elif op=='topkseed32': emit_topk_seed32(c,regs[ctx],kv,target)
            elif op=='topk2strictreg':
                if kv!=2: die('topk2strictreg requires K=2',ins.line)
                emit_topk2_strictreg(c,regs[ctx],target)
            elif op=='topk8adaptive':
                if kv!=8: die('topk8adaptive requires K=8',ins.line)
                emit_topk8_adaptive(c,regs[ctx],target)
            elif op=='topkseedfall': emit_topk_seedfall(c,regs[ctx],kv,target)
            elif op=='topk2strictfall':
                if kv!=2: die('topk2strictfall requires K=2',ins.line)
                emit_topk2_strictfall(c,regs[ctx],target)
            elif op=='topk4regs':
                if kv!=4: die('topk4regs requires K=4',ins.line)
                emit_topk4_regs(c,regs[ctx],target)
            elif op=='topk4worstcache':
                if kv!=4: die('topk4worstcache requires K=4',ins.line)
                emit_topk4_worstcache(c,regs[ctx],target)
            elif op=='topk8biadaptive':
                if kv!=8: die('topk8biadaptive requires K=8',ins.line)
                emit_topk8_biadaptive(c,regs[ctx],target)
            elif op=='topk8bicompact':
                if kv!=8: die('topk8bicompact requires K=8',ins.line)
                emit_topk8_bicompact(c,regs[ctx],target)
            elif op=='topk8bilayout':
                if kv!=8: die('topk8bilayout requires K=8',ins.line)
                emit_topk8_bilayout(c,regs[ctx],target)
            elif op=='topk8bilayout16':
                if kv!=8: die('topk8bilayout16 requires K=8',ins.line)
                emit_topk8_bilayout16(c,regs[ctx],target)
            elif op=='topk2short':
                if kv!=2: die('topk2short requires K=2',ins.line)
                emit_topk2_short(c,regs[ctx],target)
            elif op=='topk2short16':
                if kv!=2: die('topk2short16 requires K=2',ins.line)
                emit_topk2_short16(c,regs[ctx],target)
            elif op=='topknoninc':
                emit_topk_noninc(c,regs[ctx],kv,target)
            elif op=='topkstrictasc':
                emit_topk_strictasc(c,regs[ctx],kv,target)
            elif op=='topknonincpair':
                emit_topk_noninc_pair(c,regs[ctx],kv,target)
            elif op=='topkstrictascpair':
                emit_topk_strictasc_pair(c,regs[ctx],kv,target)
            elif op=='topknonincsse':
                emit_topk_noninc_sse(c,regs[ctx],kv,target)
            elif op=='topkstrictascsse':
                emit_topk_strictasc_sse(c,regs[ctx],kv,target)
            elif op=='topk2strictasclea':
                if kv!=2: die('topk2strictasclea requires K=2',ins.line)
                emit_topk2_strictasc_lea(c,regs[ctx],target)
            elif op=='topknonincsseids':
                emit_topk_noninc_sse_ids(c,regs[ctx],kv,target)
            elif op=='topkstrictascsseids':
                emit_topk_strictasc_sse_ids(c,regs[ctx],kv,target)
            else: emit_topk_fixed(c,regs[ctx],kv,target,guarded=(op=='topkguarded'))
            continue
        # eq22 commonly feeds an immediate retif followed by the miss return.
        # Fuse the three V0L operations so no boolean is materialized and each
        # comparison branches directly to the miss epilogue.
        if op=='eq22' and pos+2<len(fn.body):
            nxt=fn.body[pos+1]; last=fn.body[pos+2]
            if nxt.op=='retif' and last.op=='ret' and nxt.args[0]==a[0]:
                _,p,sym,idx=a; fail=f'__eqretfail_{internal}'; internal+=1
                c.lea_rip('r10',sym)
                c.imul_imm('r11',regs[idx],22,64,imm8=True)
                c.bin_rr('add','r10','r11',64)
                c.mov_mem('r11',regs[p],0,64); c.cmp_mem('r11','r10',0,64); c.jcc8('nz',fail)
                c.mov_mem('r11',regs[p],8,64); c.cmp_mem('r11','r10',8,64); c.jcc8('nz',fail)
                c.mov_mem('r11',regs[p],16,32); c.cmp_mem('r11','r10',16,32); c.jcc8('nz',fail)
                c.movzx16_mem('r11',regs[p],20); c.cmp_mem('r11','r10',20,16); c.jcc8('nz',fail)
                move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret()
                c.label(fail); move_value(c,'rax',last.args[0],fn,regs,constants,32); c.ret()
                skip_ins=2; continue
        if op=='ld8':
            dst,ptr,off=a; base=regs.get(ptr)
            if base is None: die('ld8 pointer must be register',ins.line)
            ov=imm(off,constants)
            if ov is not None:
                # fixed byte offset via temporary zero index if nonzero; common zero case uses direct indexed-free load encoded through r11d.
                if ov==0:
                    # movzx r32, byte [base]
                    d=REG[regs[dst]]; ba=REG[base]; c.rex(0,d,0,ba); c.emit(0x0F,0xB6); c._mem_modrm(d,ba,0)
                else:
                    c.mov_imm('r11',ov,32); c.movzx8_mem_index(regs[dst],base,'r11',0,0)
            else:
                if off not in regs: die('ld8 offset must be immediate or register',ins.line)
                c.movzx8_mem_index(regs[dst],base,regs[off],0,0)
        elif op=='ld32':
            dst,ptr,off=a; base=regs.get(ptr)
            if base is None: die('ld32 pointer must be register',ins.line)
            ov=imm(off,constants)
            if ov is None: die('ld32 offset must be immediate',ins.line)
            c.mov_mem(regs[dst],base,ov,32)
        elif op=='ld64':
            dst,ptr,off=a; ov=imm(off,constants); c.mov_mem(regs[dst],regs[ptr],ov or 0,64)
        elif op=='ld32pidx':
            dst,ctx,ptr_off,index=a; po=imm(ptr_off,constants)
            if po is None: die('ld32pidx ptr offset must be immediate',ins.line)
            c.mov_mem('r11',regs[ctx],po,64); c.mov_mem_index(regs[dst],'r11',regs[index],2,0,32)
        elif op=='ld32p':
            dst,ctx,ptr_off,elem_off=a; po=imm(ptr_off,constants); eo=imm(elem_off,constants)
            if po is None or eo is None: die('ld32p offsets must be immediate',ins.line)
            c.mov_mem('r11',regs[ctx],po,64); c.mov_mem(regs[dst],'r11',eo,32)
        elif op=='st32p':
            ctx,ptr_off,elem_off,src=a; po=imm(ptr_off,constants); eo=imm(elem_off,constants)
            if po is None or eo is None: die('st32p offsets must be immediate',ins.line)
            c.mov_mem('r11',regs[ctx],po,64); sv=imm(src,constants)
            if sv is not None: c.mov_imm_mem('r11',eo,sv,32)
            elif src in regs: c.mov_store('r11',eo,regs[src],32)
            else: die('st32p source must be immediate or register',ins.line)
        elif op=='mov': move_value(c,regs[a[0]],a[1],fn,regs,constants,TYPE_BITS[fn.vars[a[0]]])
        elif op in ('mul32','add32','sub32','xor32','or32','and32','shl32','shr32'):
            dst,x,y=a; dr=regs[dst]; xr=regs.get(x); yi=imm(y,constants); xi=imm(x,constants)
            if op=='mul32' and yi is not None and xr is not None:
                c.imul_imm(dr,xr,yi,32)
            elif op in ('shl32','shr32') and yi is not None:
                if xr is None:
                    move_value(c,dr,x,fn,regs,constants,32)
                elif dr!=xr: c.mov_rr(dr,xr,32)
                c.shift_imm('shl' if op=='shl32' else 'shr',dr,yi,32)
            else:
                if xr is None: move_value(c,dr,x,fn,regs,constants,32)
                elif dr!=xr: c.mov_rr(dr,xr,32)
                bop=op[:-2]
                if yi is not None: c.bin_imm(bop,dr,yi,32)
                else: c.bin_rr(bop,dr,regs[y],32)
        elif op in ('eq32','ne32','lt32','le32','gt32','ge32'):
            dst,x,y=a; xr=ensure_reg(c,x,fn,regs,constants,'r10',32); yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
            c.cmp_rr(xr,yr,32); c.mov_imm(regs[dst],0,32)
            cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]; c.setcc(cc,regs[dst])
        elif op in ('jeq32','jne32','jlt32','jle32','jgt32','jge32'):
            x,y,label=a; xr=ensure_reg(c,x,fn,regs,constants,'r10',32); yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
            c.cmp_rr(xr,yr,32); cc={'jeq32':'e','jne32':'ne','jlt32':'b','jle32':'be','jgt32':'a','jge32':'ae'}[op]; c.jcc(cc,label)
        elif op=='jnotbetter32':
            score,cid,old_score,old_id,label=a
            sr=ensure_reg(c,score,fn,regs,constants,'r10',32); osr=ensure_reg(c,old_score,fn,regs,constants,'r11',32)
            take=f'__notbetter_take_{internal}'; internal+=1
            c.cmp_rr(sr,osr,32); c.jcc('b',label); c.jcc('a',take)
            ir=ensure_reg(c,cid,fn,regs,constants,'r10',32); oir=ensure_reg(c,old_id,fn,regs,constants,'r11',32)
            c.cmp_rr(ir,oir,32); c.jcc('ae',label); c.label(take)
        elif op=='aget16':
            dst,sym,index=a
            if sticky_data is None or sticky_data not in data_offsets or sym not in data_offsets:
                c.lea_rip(data_scratch,sym); sticky_data=sym; delta=0
            else:
                delta=data_offsets[sym]-data_offsets[sticky_data]
            c.movzx16_mem_index(regs[dst],data_scratch,regs[index],1,delta)
        elif op=='eq22':
            dst,p,sym,idx=a; fail=f'__eqfail_{internal}'; done=f'__eqdone_{internal}'; internal+=1
            # r10 = &keys[id*22]
            c.lea_rip('r10',sym)
            c.imul_imm('r11',regs[idx],22,64,imm8=True)
            c.bin_rr('add','r10','r11',64)
            c.mov_imm(regs[dst],0,32)
            # 8 + 8 + 4 + 2 exact bytes. Early miss branches.
            c.mov_mem('r11',regs[p],0,64); c.cmp_mem('r11','r10',0,64); c.jcc8('nz',fail)
            c.mov_mem('r11',regs[p],8,64); c.cmp_mem('r11','r10',8,64); c.jcc8('nz',fail)
            c.mov_mem('r11',regs[p],16,32); c.cmp_mem('r11','r10',16,32); c.jcc8('nz',fail)
            c.movzx16_mem('r11',regs[p],20); c.cmp_mem('r11','r10',20,16); c.jcc8('nz',fail)
            c.mov_imm(regs[dst],1,32); c.label(fail)
        elif op=='retif':
            cond,val=a; skip=f'__retskip_{internal}'; internal+=1
            cr=regs[cond]; c.test_rr(cr,cr,32); c.jcc8('z',skip)
            move_value(c,'rax',val,fn,regs,constants,32); c.ret(); c.label(skip)
        elif op=='ret':
            move_value(c,'rax',a[0],fn,regs,constants,32); c.ret()
        elif op=='label': c.label(a[0])
        elif op=='jmp': c.jmp(a[0])
        elif op in ('jz','jnz'):
            cr=regs[a[0]]; c.test_rr(cr,cr,32); c.jcc('z' if op=='jz' else 'nz',a[1])
        else:
            die(f'direct x64 backend does not yet implement {op}',ins.line)
    c.patch(); return bytes(c.b),c.reloc

# ----------------------------- minimal ELF64 object writer -----------------------------
def align_up(x,a): return (x+a-1)&~(a-1)

def make_strtab(names):
    b=bytearray(b'\0'); off={}
    for n in names:
        if n in off: continue
        off[n]=len(b); b.extend(n.encode()+b'\0')
    return bytes(b),off

def emit_elf(text:bytes, rodata:bytes, funcs, objects, relocs, out:pathlib.Path):
    # section indexes
    TEXT,RODATA,RELA,SYMTAB,STRTAB,SHSTRTAB=1,2,3,4,5,6
    global_names=[f['name'] for f in funcs]+[o['name'] for o in objects]
    strtab,stroff=make_strtab(global_names)
    shnames=['','.text','.rodata','.rela.text','.symtab','.strtab','.shstrtab']
    shstr,shoffname=make_strtab(shnames[1:])
    # symbols: null, local section symbols, then globals
    syms=[(0,0,0,0,0,0),(0,0x03,0,TEXT,0,0),(0,0x03,0,RODATA,0,0)]
    symidx={}
    for f in funcs:
        symidx[f['name']]=len(syms); syms.append((stroff[f['name']],0x12,0,TEXT,f['off'],f['size']))
    for o in objects:
        symidx[o['name']]=len(syms); syms.append((stroff[o['name']],0x11,0,RODATA,o['off'],o['size']))
    symtab=bytearray()
    for s in syms: symtab.extend(struct.pack('<IBBHQQ',*s))
    rela=bytearray()
    for off,sym,add in relocs:
        if sym not in symidx: raise SystemExit(f'relocation references unknown symbol {sym}')
        info=(symidx[sym]<<32)|2 # R_X86_64_PC32
        rela.extend(struct.pack('<QQq',off,info,add))
    # lay out sections after ELF header
    cur=64; sec={}
    for idx,data,al in [(TEXT,text,16),(RODATA,rodata,64),(RELA,bytes(rela),8),(SYMTAB,bytes(symtab),8),(STRTAB,strtab,1),(SHSTRTAB,shstr,1)]:
        cur=align_up(cur,al); sec[idx]=(cur,data,al); cur+=len(data)
    shoff=align_up(cur,8); shnum=7
    outb=bytearray(shoff+64*shnum)
    ident=bytearray(16); ident[:4]=b'\x7fELF'; ident[4]=2; ident[5]=1; ident[6]=1
    outb[:64]=struct.pack('<16sHHIQQQIHHHHHH',bytes(ident),1,62,1,0,0,shoff,0,64,0,0,64,shnum,SHSTRTAB)
    for idx,(off,data,al) in sec.items(): outb[off:off+len(data)]=data
    # section headers
    def sh(idx,name,typ,flags,off,size,link=0,info=0,align=1,entsz=0):
        base=shoff+idx*64; outb[base:base+64]=struct.pack('<IIQQQQIIQQ',shoffname.get(name,0),typ,flags,0,off,size,link,info,align,entsz)
    sh(TEXT,'.text',1,0x6,*sec[TEXT][:1],len(text),align=16)
    sh(RODATA,'.rodata',1,0x2,*sec[RODATA][:1],len(rodata),align=64)
    sh(RELA,'.rela.text',4,0,*sec[RELA][:1],len(rela),link=SYMTAB,info=TEXT,align=8,entsz=24)
    sh(SYMTAB,'.symtab',2,0,*sec[SYMTAB][:1],len(symtab),link=STRTAB,info=3,align=8,entsz=24)
    sh(STRTAB,'.strtab',3,0,*sec[STRTAB][:1],len(strtab),align=1)
    sh(SHSTRTAB,'.shstrtab',3,0,*sec[SHSTRTAB][:1],len(shstr),align=1)
    out.write_bytes(outb)


# ----------------------------- minimal COFF x86-64 object writer -----------------------------
def emit_coff(text:bytes, rodata:bytes, funcs, objects, relocs, out:pathlib.Path):
    # IMAGE_FILE_MACHINE_AMD64, two sections (.text/.rdata), no optional header.
    names=[f['name'] for f in funcs]+[o['name'] for o in objects]
    strdata=bytearray(); stroff={}
    for n in names:
        if len(n.encode())>8:
            stroff[n]=4+len(strdata); strdata.extend(n.encode()+b'\0')
    def nfield(n):
        b=n.encode()
        if len(b)<=8: return b.ljust(8,b'\0')
        return struct.pack('<II',0,stroff[n])
    symidx={}; symtab=bytearray(); idx=0
    for f in funcs:
        symidx[f['name']]=idx; idx+=1
        symtab.extend(struct.pack('<8sIhHBB',nfield(f['name']),f['off'],1,0x20,2,0))
    for o in objects:
        symidx[o['name']]=idx; idx+=1
        symtab.extend(struct.pack('<8sIhHBB',nfield(o['name']),o['off'],2,0,2,0))
    reloc=bytearray()
    for off,sym,add in relocs:
        if sym not in symidx: raise SystemExit(f'COFF relocation references unknown symbol {sym}')
        # IMAGE_REL_AMD64_REL32 is relative to the byte following the 32-bit field; no ELF -4 addend.
        reloc.extend(struct.pack('<IIH',off,symidx[sym],0x0004))
    header_sz=20+2*40
    text_off=align_up(header_sz,16)
    rdata_off=align_up(text_off+len(text),64)
    reloc_off=align_up(rdata_off+len(rodata),4)
    sym_off=reloc_off+len(reloc)
    strings=struct.pack('<I',4+len(strdata))+bytes(strdata)
    total=sym_off+len(symtab)+len(strings)
    b=bytearray(total)
    # COFF file header
    b[:20]=struct.pack('<HHIIIHH',0x8664,2,0,sym_off,len(symtab)//18,0,0)
    # section headers
    text_chars=0x60000020|0x00500000 # code/read/execute + align16
    data_chars=0x40000040|0x00700000 # initialized/read + align64
    b[20:60]=struct.pack('<8sIIIIIIHHI',b'.text\0\0\0',0,0,len(text),text_off,reloc_off,0,len(reloc)//10,0,text_chars)
    b[60:100]=struct.pack('<8sIIIIIIHHI',b'.rdata\0\0',0,0,len(rodata),rdata_off,0,0,0,0,data_chars)
    b[text_off:text_off+len(text)]=text
    b[rdata_off:rdata_off+len(rodata)]=rodata
    b[reloc_off:reloc_off+len(reloc)]=reloc
    b[sym_off:sym_off+len(symtab)]=symtab
    b[sym_off+len(symtab):]=strings
    out.write_bytes(b)

# ----------------------------- driver -----------------------------
def main():
    ap=argparse.ArgumentParser(description='V0L direct x86-64 backend (no C, no assembler)')
    ap.add_argument('input',type=pathlib.Path); ap.add_argument('output',type=pathlib.Path)
    ap.add_argument('--map',dest='mapfile',type=pathlib.Path)
    ap.add_argument('--raw-dir',type=pathlib.Path,help='also dump each function as raw machine-code bytes')
    ap.add_argument('--function',action='append',help='emit only selected function(s); may be repeated')
    ap.add_argument('--target',choices=['linux','windows'],default='linux',help='x86-64 object ABI/container')
    ns=ap.parse_args()
    txt=ns.input.read_text(); mod=parse_source(txt); constants,arrays=load_v0d(ns.input,mod.data_files)
    if ns.function:
        wanted=set(ns.function); mod.fns=[f for f in mod.fns if f.name in wanted]
        missing=wanted-{f.name for f in mod.fns}
        if missing: die('unknown function(s): '+', '.join(sorted(missing)))
    used_arrays=set()
    for fn in mod.fns:
        for ins in fn.body:
            if ins.op.startswith('aget') and len(ins.args)>=2: used_arrays.add(ins.args[1])
            elif ins.op=='eq22' and len(ins.args)>=3: used_arrays.add(ins.args[2])
            elif ins.op in ('topknonincsseids','topkstrictascsseids'):
                used_arrays.add('topk_ids_0_3')
                if len(ins.args)>=2 and int(ins.args[1],0)==8: used_arrays.add('topk_ids_4_7')
    arrays=[ar for ar in arrays if ar['name'] in used_arrays]
    ro=bytearray(); objects=[]; data_offsets={}
    for ar in arrays:
        al=int(ar.get('align',1))
        while len(ro)%al: ro.append(0)
        off=len(ro); dat=bytes.fromhex(ar['data_hex']); ro.extend(dat)
        objects.append({'name':ar['name'],'off':off,'size':len(dat)}); data_offsets[ar['name']]=off
    text=bytearray(); funcs=[]; allrel=[]
    for fn in mod.fns:
        while len(text)%16:text.append(0x90)
        start=len(text); code,rels=compile_fn(fn,constants,data_offsets,ns.target); text.extend(code)
        funcs.append({'name':fn.name,'off':start,'size':len(code)})
        allrel += [(start+o,s,a) for o,s,a in rels]
    if ns.target=='linux': emit_elf(bytes(text),bytes(ro),funcs,objects,allrel,ns.output)
    else: emit_coff(bytes(text),bytes(ro),funcs,objects,allrel,ns.output)
    if ns.raw_dir:
        ns.raw_dir.mkdir(parents=True,exist_ok=True)
        for f in funcs:
            (ns.raw_dir/(f['name']+'.bin')).write_bytes(bytes(text[f['off']:f['off']+f['size']]))
    if ns.mapfile:
        ns.mapfile.write_text(json.dumps({'target':('x86_64-sysv' if ns.target=='linux' else 'x86_64-windows'),'text_bytes':len(text),'rodata_bytes':len(ro),'functions':funcs,'objects':objects,'relocations':len(allrel)},indent=2))
    print(f'{ns.output}: text={len(text)} B rodata={len(ro)} B funcs={len(funcs)} relocs={len(allrel)}')
    return 0
if __name__=='__main__': raise SystemExit(main())

# Dispatcher candidato — Artefato 20

- Consulta individual ou sem requisito de snapshot comum: **V13 SAFE**.
- Oito predicados `matches` que DEVEM observar o mesmo snapshot de `enabled_mask`: **V14 `v0_mm_matches8_snapshot_v14`**, somente com AVX2 + OS YMM.
- `count >= 8`: usar V14 em grupos de 8 somente quando a semântica do caller for snapshot comum; resto 1..7 usa V13.
- Se o caller espera que consultas separadas possam observar atualizações concorrentes diferentes, manter V13.

V14 é aditivo. Não substitui nem modifica os 10 entry points V13.

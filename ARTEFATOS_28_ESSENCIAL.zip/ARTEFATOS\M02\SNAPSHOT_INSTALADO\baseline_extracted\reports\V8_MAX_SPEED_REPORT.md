# V0 Decision V8 MAX SPEED — Optimization Report

Date: 2026-09-24

## Status

**PASS — speed-only optimization with exact decision equivalence on the validated domain.**

The existing V7 compatibility objects are preserved byte-for-byte. The V8 adaptive supervisor policy is unchanged: 2,048-request A/B probes, 65,536 active window, 5% hysteresis. More aggressive controller settings were not promoted because they were more noise-sensitive in synthetic sweeps.

## What changed

- Added a scalar-score V0L ABI. The hot kernel receives one 32-bit score in a register instead of loading an 8-byte signal struct and rebuilding value/cost/bias.
- Added a fused native V0L evaluator returning preflight + tier in one call.
- Added a force-inline in-process MAX path for callers that can compile the decision directly into their hot loop.
- Added a 24-byte exact bias LUT for the raw-input hot path; arithmetic fallback is included and validated equivalent.
- Windows resident host now uses the fused V0L evaluator for `DECIDE`, removes per-response `FlushFileBuffers`, and keeps a named-pipe connection alive for repeated commands while remaining compatible with one-command V3 clients.
- Windows host build enables `/O2 /GL /Gw /Gy` and `/LTCG /OPT:REF /OPT:ICF`.

## Exact quality/correctness validation

- Exhaustive scalar score domain: **131,646 / 131,646 exact**, 0 divergences.
- Random valid raw inputs vs validated V7: **20,000,000 / 20,000,000 exact**, 0 divergences.
- Fast LUT score vs arithmetic score: 0 divergences.
- Native preflight, native decision, native fused result, and inline fused result all matched V7.
- V7 Linux and Windows objects in this package have the same SHA-256 as the source V3 package.

## Native code size

- V8 fast preflight function: **8 bytes** on Linux x86-64.
- V8 fast decision function: **33 bytes** on Linux x86-64.
- V8 fast fused evaluator: **46 bytes** on Linux x86-64.
- Full V8 fast Linux `.text` with all three exports: **110 bytes**.
- Full V8 fast Windows COFF `.text`: **115 bytes**.
- No undefined/external symbols in the V8 fast Linux object.

## Benchmark

Environment: Intel Xeon E5-2673 v4 @ 2.30 GHz, KVM/Linux, `-O3 -march=native`, batch=1 style loops. Values below are the **median of the p50 from 9 independent process runs**. Absolute nanoseconds are environment-sensitive; the paired relative delta is the useful part.

| Path | V7 | V8 MAX | Reduction | Speedup |
|---|---:|---:|---:|---:|
| Kernel preflight | 2.843 ns | 2.134 ns | **24.9%** | **1.33x** |
| Kernel decision | 3.338 ns | 2.703 ns | **19.0%** | **1.23x** |
| Raw + preflight (native V0L) | 4.021 ns | 2.945 ns | **26.8%** | **1.37x** |
| Raw + preflight + decision (fused native V0L) | 7.934 ns | 5.308 ns | **33.1%** | **1.49x** |
| Raw + preflight (MAX inline) | 4.021 ns | 1.948 ns | **51.6%** | **2.06x** |
| Raw + preflight + decision (MAX inline fused) | 7.934 ns | 3.844 ns | **51.6%** | **2.06x** |

### Important interpretation

The scalar-score V0L ABI removes pointer loads and repeated score reconstruction. The fused API removes duplicate work when both outputs are needed. The inline MAX path additionally removes the function-call ABI; it is therefore the lowest-latency option for code that can include the header in-process.

The named-pipe service is still a control/integration interface, not a nanosecond data plane. For the absolute hot path, call `v0_decision_v8_score()` + `v0_preflight_v8_inline()` / `v0_eval_v8_inline()` directly, or use the native V0L scalar-score object when a stable ABI boundary is required.

## Compatibility

- Original `v0_decision_v7.h` and V7 native objects remain in the package unchanged.
- V8 adaptive header and default controller policy remain unchanged.
- Existing ASCII commands remain available: `PING`, `STATUS`, `RESET`, `DECIDE`, `PLAN`, `COMPLETE`.
- Old clients that connect, send one command, read one reply, and disconnect still work.

#ifndef V0_BATCH_V27_H
#define V0_BATCH_V27_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#ifndef V0_BATCH_SPAN_DEFINED
#define V0_BATCH_SPAN_DEFINED
typedef struct v0_batch_span { uint32_t start; uint32_t count; } v0_batch_span;
#endif
/* Optional AVX2 accelerator. Valid only when items is exactly 1024, 2048, 3072, or 4096. */
uint32_t v0_batch_plan64_avx2_quadload_v27(v0_batch_span *out, uint32_t items);
#ifdef __cplusplus
}
#endif
#endif

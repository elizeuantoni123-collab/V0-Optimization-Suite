#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct { uint32_t id, score, key, valid; } rec_t;
extern uint64_t v0_semantic_id_score64_trusted(const rec_t*);
extern uint64_t v0_semantic_key_valid64_trusted(const rec_t*);

static uint64_t rng=0x9e3779b97f4a7c15ULL;
static uint32_t rnd32(void){rng^=rng>>12; rng^=rng<<25; rng^=rng>>27; return (uint32_t)((rng*2685821657736338717ULL)>>32);}
int main(void){
  uint64_t checks=0, divs=0;
  for(uint32_t i=0;i<10000000u;i++){
    rec_t r={rnd32(),rnd32(),rnd32(),rnd32()&1u};
    uint64_t a=v0_semantic_id_score64_trusted(&r);
    uint64_t b=v0_semantic_key_valid64_trusted(&r);
    uint64_t ar=((uint64_t)r.score<<32)|r.id;
    uint64_t br=((uint64_t)r.valid<<32)|r.key;
    checks+=2;
    divs += (a!=ar); divs += (b!=br);
  }
  printf("checks=%llu divergences=%llu\n",(unsigned long long)checks,(unsigned long long)divs);
  return divs?1:0;
}

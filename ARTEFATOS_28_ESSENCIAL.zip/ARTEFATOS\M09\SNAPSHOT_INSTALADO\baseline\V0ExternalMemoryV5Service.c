
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <winioctl.h>
#include <sddl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "V0_EXTERNAL_MEMORY_ABI.h"
#include "V0_EXTERNAL_MEMORY_PROTOCOL_V5.h"
#include "V0_EXTERNAL_MEMORY_CLIENT_V5.h"

#define SEGMENTS 8u
#define SEGMENT_BYTES (2ULL*1024ULL*1024ULL*1024ULL)
#define TOTAL_BYTES (SEGMENTS*SEGMENT_BYTES)
#define SLOT_CAPACITY 4096u
#define PIPE_NAME L"\\\\.\\pipe\\V0ExternalMemoryV9"
#define READY_EVENT L"Global\\V0ExternalMemoryV9Ready"
#define ROOT_DIR L"C:\\ProgramData\\V0\\ExternalMemory16GBV9"
#define BACKING_PATH L"C:\\ProgramData\\V0\\ExternalMemory16GBV9\\backing_16gb.bin"
#define STATUS_PATH L"C:\\ProgramData\\V0\\ExternalMemory16GBV9\\STATUS.txt"

typedef struct { HANDLE file,mapping; uint8_t *base; } Backing;
typedef struct {
    uint64_t puts,gets,exists_calls,removes,bytes_in,bytes_out;
    uint64_t parity_errors;
} Counters;

static V0ExternalStore g_stores[SEGMENTS];
static Backing g_backing;
static Counters g_c;
static PSECURITY_DESCRIPTOR g_pipe_sd = NULL;

#define HOT_CAP 512u
typedef struct HotEntryV7 {
    uint32_t id;
    uint32_t len;
    const uint8_t *ptr;
} HotEntryV7;
static HotEntryV7 g_hot[HOT_CAP];

static __forceinline uint32_t hot_index_v7(uint32_t id){
    return (id * 2654435761u) & (HOT_CAP - 1u);
}
static __forceinline const uint8_t *hot_get_v7(uint32_t id, uint32_t *len){
    HotEntryV7 *e=&g_hot[hot_index_v7(id)];
    if(e->id==id && e->ptr){
        *len=e->len;
        return e->ptr;
    }
    return NULL;
}
static __forceinline void hot_set_v7(uint32_t id, const void *ptr, uint32_t len){
    HotEntryV7 *e=&g_hot[hot_index_v7(id)];
    e->ptr=(const uint8_t*)ptr;
    e->len=len;
    e->id=id;
}
static __forceinline void hot_invalidate_v7(uint32_t id){
    HotEntryV7 *e=&g_hot[hot_index_v7(id)];
    if(e->id==id){ e->ptr=NULL; e->len=0; e->id=0; }
}

static __forceinline uint32_t route_id(uint32_t id) {
    return (uint32_t)(((uint64_t)id * 0x9E3779B1u) >> 29) & 7u;
}
static int wr(HANDLE h,const void *p,DWORD n){
    const uint8_t *b=(const uint8_t*)p; DWORD done=0,w;
    while(done<n){ if(!WriteFile(h,b+done,n-done,&w,NULL)||!w)return 0; done+=w; }
    return 1;
}
static int rd(HANDLE h,void *p,DWORD n){
    uint8_t *b=(uint8_t*)p; DWORD done=0,r;
    while(done<n){ if(!ReadFile(h,b+done,n-done,&r,NULL)||!r)return 0; done+=r; }
    return 1;
}
static int init_backing(void){
    CreateDirectoryW(L"C:\\ProgramData\\V0",NULL);
    CreateDirectoryW(ROOT_DIR,NULL);
    g_backing.file=CreateFileW(BACKING_PATH,GENERIC_READ|GENERIC_WRITE,
        FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,
        FILE_ATTRIBUTE_NORMAL|FILE_FLAG_RANDOM_ACCESS,NULL);
    if(g_backing.file==INVALID_HANDLE_VALUE)return 0;
    DWORD junk=0; DeviceIoControl(g_backing.file,FSCTL_SET_SPARSE,NULL,0,NULL,0,&junk,NULL);
    LARGE_INTEGER sz; sz.QuadPart=(LONGLONG)TOTAL_BYTES;
    if(!SetFilePointerEx(g_backing.file,sz,NULL,FILE_BEGIN)||!SetEndOfFile(g_backing.file))return 0;
    g_backing.mapping=CreateFileMappingW(g_backing.file,NULL,PAGE_READWRITE,
        (DWORD)(TOTAL_BYTES>>32),(DWORD)TOTAL_BYTES,NULL);
    if(!g_backing.mapping)return 0;
    g_backing.base=(uint8_t*)MapViewOfFile(g_backing.mapping,FILE_MAP_ALL_ACCESS,0,0,(SIZE_T)TOTAL_BYTES);
    if(!g_backing.base)return 0;
    memset(g_stores,0,sizeof(g_stores));
    for(uint32_t i=0;i<SEGMENTS;i++){
        g_stores[i].slots=(V0ExtSlot*)calloc(SLOT_CAPACITY,sizeof(V0ExtSlot));
        if(!g_stores[i].slots)return 0;
        g_stores[i].arena=g_backing.base+(uint64_t)i*SEGMENT_BYTES;
        g_stores[i].capacity=SLOT_CAPACITY;
        g_stores[i].mask=SLOT_CAPACITY-1u;
        g_stores[i].arena_capacity=(uint32_t)SEGMENT_BYTES; /* 3 GiB fits u32 */
    }
    return 1;
}
static void status(void){
    FILE *f=_wfopen(STATUS_PATH,L"wb"); if(!f)return;
    uint64_t used=0; uint32_t live=0;
    for(uint32_t i=0;i<SEGMENTS;i++){used+=g_stores[i].arena_used;live+=g_stores[i].count;}
    fprintf(f,"MODULE=V0_EXTERNAL_MEMORY_16GB_TARGET_V9_ADAPTIVE_SHM_SAFE\r\n"
              "MODE=GENERAL_BLOB_BRIDGE\r\nNVME_BACKING_GB=16\r\nSEGMENTS=8\r\nSEGMENT_GB=2\r\n"
              "LIVE=%u\r\nARENA_USED=%llu\r\nPUTS=%llu\r\nGETS=%llu\r\nEXISTS=%llu\r\n"
              "REMOVES=%llu\r\nBYTES_IN=%llu\r\nBYTES_OUT=%llu\r\nPARITY_ERRORS=%llu\r\n",
              live,(unsigned long long)used,(unsigned long long)g_c.puts,
              (unsigned long long)g_c.gets,(unsigned long long)g_c.exists_calls,
              (unsigned long long)g_c.removes,(unsigned long long)g_c.bytes_in,
              (unsigned long long)g_c.bytes_out,(unsigned long long)g_c.parity_errors);
    fclose(f);
}

static int init_pipe_security(SECURITY_ATTRIBUTES *sa){
    /*
       SYSTEM + Administrators: full access
       Authenticated Users: read/write.
       This is intentional: V5 is a machine-local IPC bridge.
    */
    if(!ConvertStringSecurityDescriptorToSecurityDescriptorW(
        L"D:P(A;;GA;;;SY)(A;;GA;;;BA)(A;;GRGW;;;AU)",
        SDDL_REVISION_1,&g_pipe_sd,NULL)) return 0;
    memset(sa,0,sizeof(*sa));
    sa->nLength=sizeof(*sa);
    sa->lpSecurityDescriptor=g_pipe_sd;
    sa->bInheritHandle=FALSE;
    return 1;
}


typedef struct V9ClientShm { HANDLE mapping; uint8_t *view; DWORD pid; } V9ClientShm;
static void v9_close_shm(V9ClientShm*s){if(s->view)UnmapViewOfFile(s->view);if(s->mapping)CloseHandle(s->mapping);memset(s,0,sizeof(*s));}
static int v9_open_shm(V9ClientShm*s,DWORD pid){
    wchar_t name[128];
    swprintf_s(name,128,L"Global\\V0ExternalMemoryV9_%lu",(unsigned long)pid);

    /* Service runs as SYSTEM/session 0. Create the mapping here so it is visible
       cross-session, and give the interactive client read/write access. */
    SECURITY_DESCRIPTOR sd;
    SECURITY_ATTRIBUTES sa;
    if(!InitializeSecurityDescriptor(&sd,SECURITY_DESCRIPTOR_REVISION)) return 0;
    if(!SetSecurityDescriptorDacl(&sd,TRUE,NULL,FALSE)) return 0;
    memset(&sa,0,sizeof(sa));
    sa.nLength=sizeof(sa);
    sa.lpSecurityDescriptor=&sd;
    sa.bInheritHandle=FALSE;

    s->mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,&sa,PAGE_READWRITE,0,V0X_V9_SHM_BYTES,name);
    if(!s->mapping) return 0;
    s->view=(uint8_t*)MapViewOfFile(s->mapping,FILE_MAP_ALL_ACCESS,0,0,V0X_V9_SHM_BYTES);
    if(!s->view){CloseHandle(s->mapping);s->mapping=NULL;return 0;}
    s->pid=pid;
    return 1;
}
static __forceinline uint32_t v9_select_batch(uint32_t n){
    if(n<=16u*1024u)return 64u;
    if(n<=64u*1024u)return 32u;
    if(n<=256u*1024u)return 16u;
    return 2u;
}

static int handle_client(HANDLE h){
    V9ClientShm cshm;memset(&cshm,0,sizeof(cshm));
    for(;;){
        V0XReqV5 q;
        if(!rd(h,&q,sizeof(q))){v9_close_shm(&cshm);return 1;}
        if(q.magic!=V0X_MAGIC||q.version!=V0X_VERSION){v9_close_shm(&cshm);return 0;}
        if(q.op==V0X_BATCH_OPEN_V9||q.op==V0X_BATCH_GET_V9||q.op==V0X_BATCH_CLOSE_V9){
            V0XBatchReqV9 bq;memset(&bq,0,sizeof(bq));memcpy(&bq,&q,sizeof(q));
            if(!rd(h,((uint8_t*)&bq)+sizeof(q),(DWORD)(sizeof(bq)-sizeof(q)))){v9_close_shm(&cshm);return 1;}
            V0XBatchRespV9 br;memset(&br,0,sizeof(br));br.magic=V0X_MAGIC;br.version=V0X_VERSION;
            if(bq.op==V0X_BATCH_OPEN_V9){v9_close_shm(&cshm);br.ok=v9_open_shm(&cshm,bq.client_pid);if(!wr(h,&br,sizeof(br)))return 1;continue;}
            if(bq.op==V0X_BATCH_CLOSE_V9){v9_close_shm(&cshm);br.ok=1;if(!wr(h,&br,sizeof(br)))return 1;continue;}
            if(!cshm.view||!bq.count||bq.count>V0X_V9_MAX_BATCH||bq.count>v9_select_batch(bq.payload_hint)){if(!wr(h,&br,sizeof(br)))return 1;continue;}
            uint32_t cursor=0;br.ok=1;br.count=bq.count;
            for(uint32_t i=0;i<bq.count;i++){
                uint32_t id=bq.ids[i],len=0;const uint8_t*p=hot_get_v7(id,&len);
                if(!p){uint32_t si=route_id(id);V0ExternalRequest x={0};x.store=&g_stores[si];x.id=id;if(v0_external_get_v1(&x)){hot_set_v7(id,x.out_data,x.len);p=x.out_data;len=x.len;}}
                if(!p||len>V0X_V9_SHM_BYTES-cursor){br.ok=0;br.count=i;break;}
                br.offsets[i]=cursor;br.lens[i]=len;memcpy(cshm.view+cursor,p,len);cursor+=len;g_c.gets++;g_c.bytes_out+=len;
            }
            br.used_bytes=cursor;if(!wr(h,&br,sizeof(br)))return 1;continue;
        }
        V0XRespV5 r={V0X_MAGIC,V0X_VERSION,0,0};uint32_t si=route_id(q.id);V0ExternalRequest x={0};x.store=&g_stores[si];x.id=q.id;
        if(q.op==V0X_PUT){
            if(!q.len||q.len>(256u*1024u*1024u)){if(!wr(h,&r,sizeof(r)))return 0;continue;}
            void*buf=malloc(q.len);if(!buf){if(!wr(h,&r,sizeof(r)))return 0;continue;}if(!rd(h,buf,q.len)){free(buf);return 1;}
            x.data=buf;x.len=q.len;r.ok=v0_external_put_v1(&x);if(r.ok){g_c.puts++;g_c.bytes_in+=q.len;V0ExternalRequest cg={0};cg.store=&g_stores[si];cg.id=q.id;if(v0_external_get_v1(&cg))hot_set_v7(q.id,cg.out_data,cg.len);}free(buf);if(!wr(h,&r,sizeof(r)))return 1;
        } else if(q.op==V0X_GET){
            g_c.gets++;uint32_t n=0;const uint8_t*p=hot_get_v7(q.id,&n);
            if(p){r.ok=1;r.len=n;g_c.bytes_out+=n;if(!wr(h,&r,sizeof(r))||!wr(h,p,n))return 1;}
            else if(v0_external_get_v1(&x)){hot_set_v7(q.id,x.out_data,x.len);r.ok=1;r.len=x.len;g_c.bytes_out+=x.len;if(!wr(h,&r,sizeof(r))||!wr(h,x.out_data,x.len))return 1;}
            else if(!wr(h,&r,sizeof(r)))return 1;
        } else if(q.op==V0X_EXISTS){g_c.exists_calls++;r.ok=v0_external_exists_v1(&x);if(!wr(h,&r,sizeof(r)))return 1;}
        else if(q.op==V0X_REMOVE){r.ok=v0_external_remove_v1(&x);if(r.ok){g_c.removes++;hot_invalidate_v7(q.id);}if(!wr(h,&r,sizeof(r)))return 1;}
        else if(q.op==V0X_STATS){
            V0XStatsV5 stt;memset(&stt,0,sizeof(stt));for(uint32_t i=0;i<SEGMENTS;i++){stt.arena_used+=g_stores[i].arena_used;stt.live+=g_stores[i].count;}
            stt.arena_capacity=(uint64_t)TOTAL_BYTES;stt.puts=g_c.puts;stt.gets=g_c.gets;stt.exists_calls=g_c.exists_calls;stt.removes=g_c.removes;stt.bytes_in=g_c.bytes_in;stt.bytes_out=g_c.bytes_out;stt.parity_errors=(g_c.parity_errors>UINT32_MAX)?UINT32_MAX:(uint32_t)g_c.parity_errors;
            r.ok=1;r.len=sizeof(stt);if(!wr(h,&r,sizeof(r))||!wr(h,&stt,sizeof(stt)))return 1;
        } else if(!wr(h,&r,sizeof(r)))return 1;
    }
}
int wmain(int argc,wchar_t **argv){
    if(!init_backing())return 20;
    if(argc>1 && wcscmp(argv[1],L"--selftest")==0){
        uint8_t p[4096]; for(uint32_t i=0;i<4096;i++)p[i]=(uint8_t)(i*17u+3u);
        uint32_t id=0xF1234567u,s=route_id(id);
        V0ExternalRequest x={0};x.store=&g_stores[s];x.id=id;x.data=p;x.len=sizeof(p);
        if(!v0_external_put_v1(&x))return 30;
        memset(&x,0,sizeof(x));x.store=&g_stores[s];x.id=id;
        if(!v0_external_get_v1(&x)||x.len!=sizeof(p)||memcmp(x.out_data,p,sizeof(p)))return 31;
        puts("PASS V0 V9 ADAPTIVE SHM FIX3 SERVICE SELFTEST | V0L core parity OK | 16 GiB segmented backing");
        return 0;
    }
    SECURITY_ATTRIBUTES psa;
    if(!init_pipe_security(&psa)) return 22;

    HANDLE ready=CreateEventW(NULL,TRUE,FALSE,READY_EVENT);
    if(ready) SetEvent(ready);

    for(;;){
        HANDLE pipe=CreateNamedPipeW(PIPE_NAME,PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_BYTE|PIPE_READMODE_BYTE|PIPE_WAIT,PIPE_UNLIMITED_INSTANCES,
            1<<20,1<<20,0,&psa);
        if(pipe==INVALID_HANDLE_VALUE)return 21;
        BOOL c=ConnectNamedPipe(pipe,NULL)?TRUE:(GetLastError()==ERROR_PIPE_CONNECTED);
        if(c)handle_client(pipe);
        FlushFileBuffers(pipe);DisconnectNamedPipe(pipe);CloseHandle(pipe);
    }
}

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_fast.h"

#define N (1u << 20)
#define REPS 9

typedef struct raw_item { uint16_t value, cost; uint8_t temp, pinned; } raw_item_t;
static raw_item_t *raw;
static v0_decision_signal_v7_t *sig7;
static int32_t *score8;
static volatile uint64_t sink;

static uint64_t now_ns(void) {
    struct timespec x; clock_gettime(CLOCK_MONOTONIC_RAW, &x);
    return (uint64_t)x.tv_sec * 1000000000ull + (uint64_t)x.tv_nsec;
}
static uint64_t rng64(uint64_t *s) { uint64_t x=*s; x^=x<<13; x^=x>>7; x^=x<<17; return *s=x; }
static int cmpd(const void *a, const void *b) { double x=*(const double*)a,y=*(const double*)b; return x<y?-1:x>y; }
static void pin0(void) { cpu_set_t c; CPU_ZERO(&c); CPU_SET(0,&c); (void)sched_setaffinity(0,sizeof(c),&c); }

static double v7_kernel_pre(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_preflight_v0l_v7(&sig7[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v8_kernel_pre(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_preflight_v0l_v8_fast((uint32_t)score8[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v7_kernel_dec(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_decide_v0l_v7(&sig7[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v8_kernel_dec(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_decide_v0l_v8_fast((uint32_t)score8[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v7_raw_pre(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++){raw_item_t*x=&raw[i];v0_decision_signal_v7_t s=v0_decision_v7_pack(x->value,x->cost,x->temp,x->pinned);z+=v0_preflight_v0l_v7(&s);}uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v8_raw_pre(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++){raw_item_t*x=&raw[i];int32_t s=v0_decision_v8_score(x->value,x->cost,x->temp,x->pinned);z+=v0_preflight_v0l_v8_fast((uint32_t)s);}uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v7_raw_both(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++){raw_item_t*x=&raw[i];v0_decision_signal_v7_t s=v0_decision_v7_pack(x->value,x->cost,x->temp,x->pinned);z+=v0_preflight_v0l_v7(&s);z+=v0_decide_v0l_v7(&s);}uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v8_raw_fused(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++){raw_item_t*x=&raw[i];int32_t s=v0_decision_v8_score(x->value,x->cost,x->temp,x->pinned);uint32_t e8=v0_eval_v0l_v8_fast((uint32_t)s);z+=v0_eval_v8_preflight(e8)+v0_eval_v8_decision(e8);}uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v8_inline_pre(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++){raw_item_t*x=&raw[i];int32_t s=v0_decision_v8_score(x->value,x->cost,x->temp,x->pinned);z+=v0_preflight_v8_inline(s);}uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
static double v8_inline_fused(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++){raw_item_t*x=&raw[i];int32_t s=v0_decision_v8_score(x->value,x->cost,x->temp,x->pinned);uint32_t e8=v0_eval_v8_inline(s);z+=v0_eval_v8_preflight(e8)+v0_eval_v8_decision(e8);}uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}

static void bench(const char *name, double (*fn)(void)) {
    double v[REPS]; for(int i=0;i<2;i++) (void)fn();
    for(int i=0;i<REPS;i++) v[i]=fn(); qsort(v,REPS,sizeof(double),cmpd);
    printf("%-20s p50=%8.3f ns/op best=%8.3f\n", name, v[REPS/2], v[0]);
}

int main(void) {
    pin0();
    raw=aligned_alloc(64,N*sizeof(*raw)); sig7=aligned_alloc(64,N*sizeof(*sig7)); score8=aligned_alloc(64,N*sizeof(*score8));
    if(!raw||!sig7||!score8) return 2;
    uint64_t st=0x9e3779b97f4a7c15ULL;
    for(uint32_t i=0;i<N;i++){
        raw[i].value=(uint16_t)rng64(&st); raw[i].cost=(uint16_t)rng64(&st);
        raw[i].temp=(uint8_t)(rng64(&st)%3u); raw[i].pinned=(uint8_t)(rng64(&st)&1u);
        sig7[i]=v0_decision_v7_pack(raw[i].value,raw[i].cost,raw[i].temp,raw[i].pinned);
        score8[i]=v0_decision_v8_score(raw[i].value,raw[i].cost,raw[i].temp,raw[i].pinned);
    }
    bench("V7 kernel pre",v7_kernel_pre); bench("V8 score pre",v8_kernel_pre);
    bench("V7 kernel decision",v7_kernel_dec); bench("V8 score decision",v8_kernel_dec);
    bench("V7 raw+pre",v7_raw_pre); bench("V8 raw+pre",v8_raw_pre);
    bench("V7 raw+both",v7_raw_both); bench("V8 raw+fused",v8_raw_fused);
    bench("V8 inline pre",v8_inline_pre); bench("V8 inline fused",v8_inline_fused);
    printf("sink=%llu\n",(unsigned long long)sink);
    return 0;
}

# Dispatch candidate

Keep the existing Tier Manager dispatch as authority:

- untrusted / universal input -> `v0_tier_select_v2`
- scalar `preferred <= 4` -> `v0_tier_select_valid_v3`
- exactly 8 independent requests with every `preferred <= 4` -> candidate `v0_tier_select_batch8_v12`
- remainder 1..7 -> scalar V3

V12 is additive. It is **not** a universal replacement for V3 and is not promoted until the target Windows gate passes.

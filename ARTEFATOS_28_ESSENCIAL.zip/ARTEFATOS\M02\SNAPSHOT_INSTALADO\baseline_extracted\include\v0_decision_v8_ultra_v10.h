#ifndef V0_DECISION_V8_ULTRA_V10_H
#define V0_DECISION_V8_ULTRA_V10_H

/*
 * V0 Decision V8 ULTRA V10
 *
 * Additive exact acceleration layer over ULTRA V9.
 * No inherited V9 file is modified by this header.
 *
 * Promoted ideas:
 *  1) one-shot raw classification is recentered around 0x8000.  Once the
 *     temperature bonus and cost/2 are folded into that bias, the final
 *     Decision state is obtained from:
 *
 *       sum = sat_u16(value + (0x8000 + bonus - cost/2))
 *       idx = min(sat_u16((sum >> 6) - 511), 7)
 *
 *     The 8-entry LUT maps idx exactly to 0/4/5/5/6/6/6/7.  This removes
 *     the V9 dependent subtract/preflight-mask/+1 sequence.
 *
 *  2) gate16 is the same exact recentering precomputed once:
 *
 *       gate16 = 0xffff                             when pinned
 *              = 0x8000 + bonus - (cost >> 1)      otherwise
 *
 *     It contains every cost/temperature/pinned fact consumed by Decision.
 *     Reusing gate16 removes cost, temperature and pinned from the hot path.
 *     The descriptor is exact on the legal Decision domain (temp 0..2,
 *     pinned 0/1); it is not an approximation or quantization.
 *
 *  3) gate16 preflight is simply bit15 of sat_u16(value + gate16).
 *
 * V9 preflight remains the one-shot default because the corresponding V10
 * one-shot experiment did not beat V9 consistently.
 */
#include "v0_decision_v8_ultra_v9.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef uint16_t v0_decision_gate16_v10_t;

V0X_FORCEINLINE v0_decision_gate16_v10_t v0_decision_gate16_v10(
    uint16_t cost, uint8_t temperature, uint8_t pinned) {
    if (pinned) return (v0_decision_gate16_v10_t)0xffffu;
    {
        const uint32_t tq = (uint32_t)temperature + ((uint32_t)temperature >> 1);
        const uint32_t bonus = tq << 6;
        return (v0_decision_gate16_v10_t)(0x8000u + bonus - ((uint32_t)cost >> 1));
    }
}

V0X_FORCEINLINE uint32_t v0_eval_gate16_v10_inline(
    uint16_t value, v0_decision_gate16_v10_t gate) {
    uint32_t s = (uint32_t)value + (uint32_t)gate;
    if (s > 0xffffu) s = 0xffffu;
    if (s < 0x8000u) return 0u;
    if (s < 0x8040u) return 4u;
    if (s < 0x80c0u) return 5u;
    if (s < 0x8180u) return 6u;
    return 7u;
}

V0X_FORCEINLINE uint32_t v0_preflight_gate16_v10_inline(
    uint16_t value, v0_decision_gate16_v10_t gate) {
    return ((uint32_t)value + (uint32_t)gate) >= 0x8000u;
}

#if defined(__AVX2__) || defined(_M_AVX2)

V0X_FORCEINLINE __m128i v0_temperature_bonus8_ultra_v10_avx2(
    const uint8_t *temperature) {
    const __m128i t = _mm_loadu_si128((const __m128i *)(const void *)temperature);
    const __m128i lut = _mm_setr_epi8(
        0, 64, (char)192, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0);
    return _mm_shuffle_epi8(lut, t);
}

/* One-shot exact raw V10 block.  Pinned remains byte-sized and is applied
 * after packing; expanding it to 16-bit regressed on AVX2 in paired tests. */
V0X_FORCEINLINE __m128i v0_eval_v10_raw_block16_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i hh = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost), 1);
    const __m128i p8 = _mm_loadu_si128((const __m128i *)(const void *)pinned);
    const __m256i bonus = _mm256_cvtepu8_epi16(
        v0_temperature_bonus8_ultra_v10_avx2(temperature));
    const __m256i gate = _mm256_sub_epi16(
        _mm256_add_epi16(_mm256_set1_epi16((short)0x8000), bonus), hh);
    const __m256i ss = _mm256_adds_epu16(vv, gate);
    __m256i idx = _mm256_subs_epu16(
        _mm256_srli_epi16(ss, 6), _mm256_set1_epi16(511));
    idx = _mm256_min_epu16(idx, _mm256_set1_epi16(7));
    {
        __m128i i8 = _mm_packus_epi16(
            _mm256_castsi256_si128(idx), _mm256_extracti128_si256(idx, 1));
        i8 = _mm_blendv_epi8(
            i8, _mm_set1_epi8(7),
            _mm_cmpeq_epi8(p8, _mm_set1_epi8(1)));
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0), i8);
    }
}

/* Two independent blocks overlap the dependency chains without the slower
 * 256-bit store fusion tested during V10 selection. */
static inline void v0_eval_v10_raw_batch_avx2_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i = 0;
    for (; i + 32 <= n; i += 32) {
        const __m128i a = v0_eval_v10_raw_block16_avx2(
            value+i, cost+i, temperature+i, pinned+i);
        const __m128i b = v0_eval_v10_raw_block16_avx2(
            value+i+16, cost+i+16, temperature+i+16, pinned+i+16);
        _mm_storeu_si128((__m128i *)(void *)(out+i), a);
        _mm_storeu_si128((__m128i *)(void *)(out+i+16), b);
    }
    if (i + 16 <= n) {
        _mm_storeu_si128((__m128i *)(void *)(out+i),
            v0_eval_v10_raw_block16_avx2(
                value+i, cost+i, temperature+i, pinned+i));
        i += 16;
    }
    if (i < n) {
        const size_t rem = n - i;
        for (size_t k = 0; k < rem; ++k)
            out[i+k] = (uint8_t)v0_eval_v8_raw_ultra_inline(
                value[i+k], cost[i+k], temperature[i+k], pinned[i+k]);
    }
}

/* gate16 builder: exact preprocessing, not part of one-shot raw timing. */
V0X_FORCEINLINE __m256i v0_build_gate16_block16_v10_avx2(
    const uint16_t *cost, const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i hh = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost), 1);
    const __m128i p8 = _mm_loadu_si128((const __m128i *)(const void *)pinned);
    const __m256i bonus = _mm256_cvtepu8_epi16(
        v0_temperature_bonus8_ultra_v10_avx2(temperature));
    __m256i gate = _mm256_sub_epi16(
        _mm256_add_epi16(_mm256_set1_epi16((short)0x8000), bonus), hh);
    {
        const __m256i pm = _mm256_sub_epi16(
            _mm256_setzero_si256(), _mm256_cvtepu8_epi16(p8));
        gate = _mm256_or_si256(gate, pm);
    }
    return gate;
}

static inline void v0_build_gate16_batch_v10_avx2(
    const uint16_t *cost, const uint8_t *temperature, const uint8_t *pinned,
    v0_decision_gate16_v10_t *gate, size_t n) {
    size_t i = 0;
    for (; i + 16 <= n; i += 16)
        _mm256_storeu_si256((__m256i *)(void *)(gate+i),
            v0_build_gate16_block16_v10_avx2(cost+i, temperature+i, pinned+i));
    for (; i < n; ++i)
        gate[i] = v0_decision_gate16_v10(cost[i], temperature[i], pinned[i]);
}

/* Cached gate16 evaluator.  Because the thresholds are all multiples of 64,
 * q=(sum>>6), sat(q-511) produces exactly indices 0..7 required by the LUT. */
V0X_FORCEINLINE __m128i v0_eval_gate16_block16_v10_avx2(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate) {
    const __m256i ss = _mm256_adds_epu16(
        _mm256_loadu_si256((const __m256i *)(const void *)value),
        _mm256_loadu_si256((const __m256i *)(const void *)gate));
    __m256i idx = _mm256_subs_epu16(
        _mm256_srli_epi16(ss, 6), _mm256_set1_epi16(511));
    idx = _mm256_min_epu16(idx, _mm256_set1_epi16(7));
    {
        const __m128i i8 = _mm_packus_epi16(
            _mm256_castsi256_si128(idx), _mm256_extracti128_si256(idx, 1));
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0), i8);
    }
}

static inline void v0_eval_gate16_batch_v10_avx2_u8(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate,
    uint8_t *out, size_t n) {
    size_t i = 0;
    for (; i + 16 <= n; i += 16)
        _mm_storeu_si128((__m128i *)(void *)(out+i),
            v0_eval_gate16_block16_v10_avx2(value+i, gate+i));
    for (; i < n; ++i)
        out[i] = (uint8_t)v0_eval_gate16_v10_inline(value[i], gate[i]);
}

/* For gate16 preflight, bit15 of the saturated sum is the exact preflight bit.
 * movemask returns both bytes of each u16; odd bits are the high bytes. */
/* Large write-only gate16 output.  This path is deliberately opt-in: it
 * wins when output is not immediately read and the destination is 16-byte
 * aligned.  Small/unaligned calls fall back to the normal cached evaluator. */
static inline void v0_eval_gate16_batch_v10_stream_avx2_u8(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate,
    uint8_t *out, size_t n) {
    size_t i = 0;
    if ((((uintptr_t)out) & 15u) != 0u || n < 256u) {
        v0_eval_gate16_batch_v10_avx2_u8(value, gate, out, n);
        return;
    }
    for (; i + 16 <= n; i += 16)
        _mm_stream_si128((__m128i *)(void *)(out+i),
            v0_eval_gate16_block16_v10_avx2(value+i, gate+i));
    _mm_sfence();
    for (; i < n; ++i)
        out[i] = (uint8_t)v0_eval_gate16_v10_inline(value[i], gate[i]);
}

static inline uint64_t v0_preflight_gate16_count_v10_avx2(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 16 <= n; i += 16) {
        const __m256i ss = _mm256_adds_epu16(
            _mm256_loadu_si256((const __m256i *)(const void *)(value+i)),
            _mm256_loadu_si256((const __m256i *)(const void *)(gate+i)));
        const unsigned m = (unsigned)_mm256_movemask_epi8(ss) & 0xAAAAAAAAu;
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(m);
#else
        count += (uint32_t)__builtin_popcount(m);
#endif
    }
    for (; i < n; ++i)
        count += (uint64_t)v0_preflight_gate16_v10_inline(value[i], gate[i]);
    return count;
}

#endif /* AVX2 */

#if defined(__AVX512BW__) && defined(__AVX512VL__)

/* Native V10 raw AVX-512VL path.  256-bit arithmetic was faster than widening
 * to 512 bits on the paired Zen 4 host.  Pinned is folded into gate before the
 * dependent classify chain, and two blocks are overlapped in the batch loop. */
V0X_FORCEINLINE __m128i v0_eval_v10_raw_block16_avx512vl(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i hh = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost), 1);
    const __m128i p8 = _mm_loadu_si128((const __m128i *)(const void *)pinned);
    const __m256i bonus = _mm256_cvtepu8_epi16(
        v0_temperature_bonus8_ultra_v10_avx2(temperature));
    __m256i gate = _mm256_sub_epi16(
        _mm256_add_epi16(_mm256_set1_epi16((short)0x8000), bonus), hh);
    gate = _mm256_mask_mov_epi16(
        gate,
        _mm_cmpneq_epi8_mask(p8, _mm_setzero_si128()),
        _mm256_set1_epi16((short)0xffff));
    {
        const __m256i ss = _mm256_adds_epu16(vv, gate);
        __m256i idx = _mm256_subs_epu16(
            _mm256_srli_epi16(ss, 6), _mm256_set1_epi16(511));
        idx = _mm256_min_epu16(idx, _mm256_set1_epi16(7));
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),
            _mm256_cvtusepi16_epi8(idx));
    }
}

static inline void v0_eval_v10_raw_batch_avx512vl_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i = 0;
    for (; i + 32 <= n; i += 32) {
        const __m128i a = v0_eval_v10_raw_block16_avx512vl(
            value+i, cost+i, temperature+i, pinned+i);
        const __m128i b = v0_eval_v10_raw_block16_avx512vl(
            value+i+16, cost+i+16, temperature+i+16, pinned+i+16);
        _mm_storeu_si128((__m128i *)(void *)(out+i), a);
        _mm_storeu_si128((__m128i *)(void *)(out+i+16), b);
    }
    if (i < n)
        v0_eval_v10_raw_batch_avx2_u8(
            value+i, cost+i, temperature+i, pinned+i, out+i, n-i);
}

V0X_FORCEINLINE __m512i v0_build_gate16_block32_v10_avx512(
    const uint16_t *cost, const uint8_t *temperature, const uint8_t *pinned) {
    const __m512i hh = _mm512_srli_epi16(_mm512_loadu_si512((const void *)cost), 1);
    const __m256i t8 = _mm256_loadu_si256((const __m256i *)(const void *)temperature);
    const __m256i p8 = _mm256_loadu_si256((const __m256i *)(const void *)pinned);
    const __m256i lut = _mm256_setr_epi8(
        0,64,(char)192,0,0,0,0,0,0,0,0,0,0,0,0,0,
        0,64,(char)192,0,0,0,0,0,0,0,0,0,0,0,0,0);
    const __m512i bonus = _mm512_cvtepu8_epi16(_mm256_shuffle_epi8(lut, t8));
    __m512i gate = _mm512_sub_epi16(
        _mm512_add_epi16(_mm512_set1_epi16((short)0x8000), bonus), hh);
    gate = _mm512_mask_mov_epi16(
        gate,
        _mm256_cmpneq_epi8_mask(p8, _mm256_setzero_si256()),
        _mm512_set1_epi16((short)0xffff));
    return gate;
}

static inline void v0_build_gate16_batch_v10_avx512(
    const uint16_t *cost, const uint8_t *temperature, const uint8_t *pinned,
    v0_decision_gate16_v10_t *gate, size_t n) {
    size_t i = 0;
    for (; i + 32 <= n; i += 32)
        _mm512_storeu_si512((void *)(gate+i),
            v0_build_gate16_block32_v10_avx512(cost+i, temperature+i, pinned+i));
    if (i < n)
        v0_build_gate16_batch_v10_avx2(
            cost+i, temperature+i, pinned+i, gate+i, n-i);
}

static inline uint64_t v0_preflight_gate16_count_v10_avx512(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 32 <= n; i += 32) {
        const __m512i ss = _mm512_adds_epu16(
            _mm512_loadu_si512((const void *)(value+i)),
            _mm512_loadu_si512((const void *)(gate+i)));
        const uint32_t m = (uint32_t)_mm512_movepi16_mask(ss);
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(m);
#else
        count += (uint32_t)__builtin_popcount(m);
#endif
    }
    if (i < n)
        count += v0_preflight_gate16_count_v10_avx2(value+i, gate+i, n-i);
    return count;
}

#endif /* AVX512BW && AVX512VL */

#ifdef __cplusplus
}
#endif
#endif

# Windows gate

Execute em um Developer PowerShell com MSVC:

```powershell
.\RUN_WINDOWS_GATE.ps1
```

Para escolher outro processador lógico:

```powershell
$env:V0_CPU=8
.\RUN_WINDOWS_GATE.ps1
```

O gate não instala nem registra nada. Apenas compila o harness, verifica AVX2/YMM, testa paridade e executa A/B.

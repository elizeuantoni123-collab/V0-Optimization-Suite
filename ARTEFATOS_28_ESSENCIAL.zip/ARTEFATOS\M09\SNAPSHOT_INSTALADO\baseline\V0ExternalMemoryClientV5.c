
#define V0X_EXPORTS 1
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "V0_EXTERNAL_MEMORY_CLIENT_V5.h"
#include "V0_EXTERNAL_MEMORY_PROTOCOL_V5.h"
#define PIPE_NAME L"\\\\.\\pipe\\V0ExternalMemoryV9"

static int wr(HANDLE h,const void *p,DWORD n){const uint8_t*b=p;DWORD d=0,w;while(d<n){if(!WriteFile(h,b+d,n-d,&w,NULL)||!w)return 0;d+=w;}return 1;}
static int rd(HANDLE h,void *p,DWORD n){uint8_t*b=p;DWORD d=0,r;while(d<n){if(!ReadFile(h,b+d,n-d,&r,NULL)||!r)return 0;d+=r;}return 1;}
static __declspec(thread) HANDLE tls_pipe = INVALID_HANDLE_VALUE;

static HANDLE connect_pipe(void){
    for(int i=0;i<200;i++){
        HANDLE h=CreateFileW(PIPE_NAME,GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL);
        if(h!=INVALID_HANDLE_VALUE) return h;
        DWORD e=GetLastError();
        if(e==ERROR_PIPE_BUSY){ WaitNamedPipeW(PIPE_NAME,50); continue; }
        if(e==ERROR_FILE_NOT_FOUND || e==ERROR_PIPE_NOT_CONNECTED){ Sleep(5); continue; }
        SetLastError(e);
        break;
    }
    return INVALID_HANDLE_VALUE;
}

static HANDLE get_pipe(void){
    if(tls_pipe==INVALID_HANDLE_VALUE) tls_pipe=connect_pipe();
    return tls_pipe;
}

static void drop_pipe(void){
    if(tls_pipe!=INVALID_HANDLE_VALUE){ CloseHandle(tls_pipe); tls_pipe=INVALID_HANDLE_VALUE; }
}

static uint32_t call_once(uint32_t op,uint32_t id,const void *in,uint32_t len,void*out,uint32_t cap,uint32_t*out_len){
    HANDLE h=get_pipe(); if(h==INVALID_HANDLE_VALUE)return 0;
    V0XReqV5 q={V0X_MAGIC,V0X_VERSION,op,id,len,0}; V0XRespV5 r;
    if(!wr(h,&q,sizeof(q)) || (len&&in&&!wr(h,in,len)) || !rd(h,&r,sizeof(r))){drop_pipe();return 0;}
    if(r.magic!=V0X_MAGIC||r.version!=V0X_VERSION||!r.ok){return 0;}
    if(out_len)*out_len=r.len;
    if(r.len){
        if(!out||cap<r.len){return 0;}
        if(!rd(h,out,r.len)){drop_pipe();return 0;}
    }
    return 1;
}

static uint32_t call(uint32_t op,uint32_t id,const void *in,uint32_t len,void*out,uint32_t cap,uint32_t*out_len){
    if(call_once(op,id,in,len,out,cap,out_len)) return 1;
    /* reconnect once for a broken/stale pipe, but do not loop forever */
    drop_pipe();
    return call_once(op,id,in,len,out,cap,out_len);
}
V0X_API uint32_t v0x_put_v5(uint32_t id,const void*d,uint32_t n){return call(V0X_PUT,id,d,n,NULL,0,NULL);}
V0X_API uint32_t v0x_get_v5(uint32_t id,void*out,uint32_t cap,uint32_t*out_len){return call(V0X_GET,id,NULL,0,out,cap,out_len);}
V0X_API uint32_t v0x_exists_v5(uint32_t id){return call(V0X_EXISTS,id,NULL,0,NULL,0,NULL);}
V0X_API uint32_t v0x_remove_v5(uint32_t id){return call(V0X_REMOVE,id,NULL,0,NULL,0,NULL);}
V0X_API uint32_t v0x_stats_v5(V0XStatsV5 *s){uint32_t n=0;return call(V0X_STATS,0,NULL,0,s,sizeof(*s),&n)&&n==sizeof(*s);}

typedef struct V9State{HANDLE mapping;uint8_t*view;DWORD pid;int opened;}V9State;
static __declspec(thread) V9State v9s={0};
static int v9_ensure(void){
    if(v9s.view&&v9s.opened)return 1;
    v9s.pid=GetCurrentProcessId();

    /* Ask the SYSTEM service to create the cross-session Global mapping first. */
    HANDLE h=get_pipe();if(h==INVALID_HANDLE_VALUE)return 0;
    V0XBatchReqV9 q;memset(&q,0,sizeof(q));
    q.magic=V0X_MAGIC;q.version=V0X_VERSION;q.op=V0X_BATCH_OPEN_V9;q.client_pid=v9s.pid;
    V0XBatchRespV9 r;
    if(!wr(h,&q,sizeof(q))||!rd(h,&r,sizeof(r))||!r.ok){drop_pipe();return 0;}

    wchar_t name[128];
    swprintf_s(name,128,L"Global\\V0ExternalMemoryV9_%lu",(unsigned long)v9s.pid);
    v9s.mapping=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,name);
    if(!v9s.mapping){drop_pipe();return 0;}
    v9s.view=(uint8_t*)MapViewOfFile(v9s.mapping,FILE_MAP_ALL_ACCESS,0,0,V0X_V9_SHM_BYTES);
    if(!v9s.view){CloseHandle(v9s.mapping);v9s.mapping=NULL;drop_pipe();return 0;}

    v9s.opened=1;
    return 1;
}
V0X_API uint32_t v0x_select_batch_v9(uint32_t n){if(n<=16u*1024u)return 64u;if(n<=64u*1024u)return 32u;if(n<=256u*1024u)return 16u;return 2u;}
V0X_API uint32_t v0x_get_batch_v9(const uint32_t*ids,uint32_t count,void*out,uint32_t cap,uint32_t*offs,uint32_t*lens){
    if(!ids||!out||!offs||!lens||!count||count>V0X_V9_MAX_BATCH)return 0;uint32_t hint=cap/count;if(!hint||count>v0x_select_batch_v9(hint)||!v9_ensure())return 0;
    V0XBatchReqV9 q;memset(&q,0,sizeof(q));q.magic=V0X_MAGIC;q.version=V0X_VERSION;q.op=V0X_BATCH_GET_V9;q.count=count;q.payload_hint=hint;q.client_pid=v9s.pid;memcpy(q.ids,ids,count*4);
    HANDLE h=get_pipe();if(h==INVALID_HANDLE_VALUE)return 0;V0XBatchRespV9 r;if(!wr(h,&q,sizeof(q))||!rd(h,&r,sizeof(r))||!r.ok){drop_pipe();v9s.opened=0;return 0;}
    if(r.used_bytes>cap)return 0;memcpy(out,v9s.view,r.used_bytes);for(uint32_t i=0;i<r.count;i++){offs[i]=r.offsets[i];lens[i]=r.lens[i];}return r.count;
}

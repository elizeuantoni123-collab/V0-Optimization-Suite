#ifndef V0_SEMANTIC_BRIDGE_H
#define V0_SEMANTIC_BRIDGE_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct v0_semantic_record {
    uint32_t semantic_id;
    uint32_t semantic_score; /* opaque, bit-exact pass-through */
    uint32_t exact_key;
    uint32_t valid;          /* canonical boolean: exactly 0 or 1 */
} v0_semantic_record;

enum { V0_SEMANTIC_INVALID_U32 = 0xFFFFFFFFu };

/* V1 SAFE universal/fallback — preserved byte-identical. */
uint32_t v0_semantic_id_trusted(const v0_semantic_record* ctx);
uint32_t v0_semantic_score_trusted(const v0_semantic_record* ctx);
uint32_t v0_semantic_key_trusted(const v0_semantic_record* ctx);
uint32_t v0_semantic_valid_trusted(const v0_semantic_record* ctx);
uint32_t v0_semantic_id_safe(const v0_semantic_record* ctx);
uint32_t v0_semantic_key_safe(const v0_semantic_record* ctx);

/* V2 SAFE — adjacent pair fast paths. Little-endian x86-64 packing. */
uint64_t v0_semantic_id_score64_trusted(const v0_semantic_record* ctx); /* low32=id, high32=score */
uint64_t v0_semantic_key_valid64_trusted(const v0_semantic_record* ctx); /* low32=key, high32=valid */

/* V3 SAFE — score + key pair. */
uint64_t v0_semantic_score_key64_trusted(const v0_semantic_record* ctx); /* low32=score, high32=key */

/* V4 SAFE — entire normalized 16-byte record in XMM0. */
#if defined(_MSC_VER)
#  include <emmintrin.h>
typedef __m128i v0_semantic_v128;
#elif defined(__GNUC__) || defined(__clang__)
typedef long long v0_semantic_v128 __attribute__((vector_size(16)));
#else
#  error "V0 Semantic Bridge V4 requires an x86-64 compiler with 128-bit vector ABI support"
#endif
v0_semantic_v128 v0_semantic_record128_trusted(const v0_semantic_record* ctx);

/* V5 SAFE — contiguous batch validity masks; bit i = record[i].valid. */
uint32_t v0_semantic_valid4_mask(const v0_semantic_record* ctx);
uint32_t v0_semantic_valid8_mask(const v0_semantic_record* ctx);

#ifdef __cplusplus
}
#endif
#endif

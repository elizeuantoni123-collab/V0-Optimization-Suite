#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_ultra_v12.h"
#define CHUNK (1u<<20)
#define ROUNDS 20
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return*s=x;}
static uint64_t checked,bad;
static void fail(const char*tag,uint64_t i,uint32_t got,uint32_t ref){if(bad<16)fprintf(stderr,"FAIL %s i=%llu got=%u ref=%u\n",tag,(unsigned long long)i,got,ref);bad++;}
int main(void){
    uint16_t *v,*c,*g; uint8_t *t,*p; uint64_t s=0xD6E8FEB86659FD93ULL;
    if(posix_memalign((void**)&v,64,CHUNK*2)||posix_memalign((void**)&c,64,CHUNK*2)||posix_memalign((void**)&g,64,CHUNK*2)||posix_memalign((void**)&t,64,CHUNK)||posix_memalign((void**)&p,64,CHUNK)) return 2;
    for(uint32_t sum=0;sum<=131070u;sum++){
        uint16_t vv=(sum>65535u)?65535u:(uint16_t)sum;
        uint16_t gg=(uint16_t)(sum-(uint32_t)vv);
        uint32_t a=v0_eval_gate16_v10_inline(vv,gg),b=v0_eval_gate16_v12_scalar_direct_inline(vv,gg);
        if(a!=b)fail("sum-exhaustive",sum,b,a); checked++;
    }
    for(uint32_t cost=0;cost<65536u;cost++) for(uint32_t temp=0;temp<3u;temp++) for(uint32_t pin=0;pin<2u;pin++){
        uint16_t a=v0_decision_gate16_v10((uint16_t)cost,(uint8_t)temp,(uint8_t)pin);
        uint16_t b=v0_decision_gate16_v12_branchless((uint16_t)cost,(uint8_t)temp,(uint8_t)pin);
        if(a!=b)fail("gate-exhaustive",((uint64_t)cost*6u)+(temp*2u)+pin,b,a); checked++;
    }
    for(unsigned r=0;r<ROUNDS && !bad;r++){
        for(size_t i=0;i<CHUNK;i++){
            v[i]=(uint16_t)rng64(&s); c[i]=(uint16_t)rng64(&s); t[i]=(uint8_t)(rng64(&s)%3u); p[i]=(uint8_t)(rng64(&s)&1u);
            g[i]=v0_decision_gate16_v12_branchless(c[i],t[i],p[i]);
        }
        for(size_t i=0;i<CHUNK;i++){
            const uint8_t ref=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);
            const uint8_t got=(uint8_t)v0_eval_gate16_v12_scalar_direct_inline(v[i],g[i]);
            const uint8_t pre=(uint8_t)v0_preflight_gate16_v12_scalar_inline(v[i],g[i]);
            if(got!=ref)fail("random-eval",i,got,ref);
            if(pre!=(ref>>2))fail("random-preflight",i,pre,ref>>2);
            checked++;
        }
    }
    printf("checked=%llu divergences=%llu\n",(unsigned long long)checked,(unsigned long long)bad);
    printf("status=%s\n",bad?"FAIL":"PASS");
    return bad?3:0;
}

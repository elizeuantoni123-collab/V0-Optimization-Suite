#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_batch.h"
extern uint32_t v0_batch_plan64_avx2_v14(v0_batch_span*,uint32_t);
extern uint32_t v0_batch_plan64_avx2_dual_v19(v0_batch_span*,uint32_t);
#if defined(__GNUC__)
#define NOINLINE __attribute__((noinline))
#else
#define NOINLINE
#endif
static volatile uint64_t sink;static inline uint64_t mix(uint64_t a,uint32_t s,uint32_t c){a^=((uint64_t)s<<32)|c;a^=a<<13;a^=a>>7;a^=a<<17;return a;}
static NOINLINE uint64_t mat(v0_batch_span*b,uint32_t n,uint32_t reps){uint64_t a=0x123456789abcdef0ULL;for(uint32_t r=0;r<reps;r++){uint32_t k=(n>=385&&n<=262144)?v0_batch_plan64_avx2_dual_v19(b,n):v0_batch_plan64_avx2_v14(b,n);for(uint32_t i=0;i<k;i++)a=mix(a,b[i].start,b[i].count);}sink^=a;return a;}
static NOINLINE uint64_t imp(uint32_t n,uint32_t reps){uint64_t a=0x123456789abcdef0ULL;for(uint32_t r=0;r<reps;r++){uint32_t f=n>>6,t=n&63u;for(uint32_t i=0;i<f;i++)a=mix(a,i<<6,64);if(t)a=mix(a,f<<6,t);}sink^=a;return a;}
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}static int cmp(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}static double med(double*x,int n){qsort(x,n,sizeof(*x),cmp);return x[n/2];}
int main(void){cpu_set_t set;CPU_ZERO(&set);CPU_SET(0,&set);sched_setaffinity(0,sizeof(set),&set);const uint32_t sz[]={4096,5120,6144,8192,12288,16384,24576,32768,49152,65536,98304,131072,196608,262144,524288,1048576};enum{R=21};uint32_t maxk=((1048576-1)>>6)+1;v0_batch_span*b;posix_memalign((void**)&b,64,(size_t)(maxk+8)*sizeof(*b));puts("items,spans,mat_ns,imp_ns,speedup_imp");for(unsigned q=0;q<sizeof(sz)/sizeof(sz[0]);q++){uint32_t n=sz[q],k=(n+63)>>6,reps=4000000u/k;if(reps<500)reps=500;if(reps>50000)reps=50000;double A[R],B[R];mat(b,n,50);imp(n,50);for(int r=0;r<R;r++){uint64_t t0,t1,t2;if(r&1){t0=ns();imp(n,reps);t1=ns();mat(b,n,reps);t2=ns();B[r]=(double)(t1-t0)/reps;A[r]=(double)(t2-t1)/reps;}else{t0=ns();mat(b,n,reps);t1=ns();imp(n,reps);t2=ns();A[r]=(double)(t1-t0)/reps;B[r]=(double)(t2-t1)/reps;}}double a=med(A,R),c=med(B,R);printf("%u,%u,%.3f,%.3f,%.4f\n",n,k,a,c,a/c);}free(b);fprintf(stderr,"sink=%llu\n",(unsigned long long)sink);}

#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<20)
#define REPS 11
static v0_decision_signal_v7_t *sig; static uint8_t*out; static volatile uint64_t sink;
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static double now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return t.tv_sec*1e9+t.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static double scalar(void){uint64_t z=0;double a=now_ns();for(size_t i=0;i<N;i++)z+=v0_eval_v8_signal_ultra_inline(sig+i);double b=now_ns();sink=z;return(b-a)/N;}
static double avx2(void){double a=now_ns();v0_eval_v8_signal_batch_ultra_v7_avx2_u8(sig,out,N);double b=now_ns();sink+=out[777];return(b-a)/N;}
#if defined(__AVX512BW__) && defined(__AVX512VL__)
static double avx512(void){double a=now_ns();v0_eval_v8_signal_batch_ultra_v7_avx512_u8(sig,out,N);double b=now_ns();sink+=out[777];return(b-a)/N;}
#endif
static void bench(const char*n,double(*f)(void)){double x[REPS];for(int i=0;i<4;i++)f();for(int i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmpd);printf("%-31s p50=%8.5f best=%8.5f ns/item\n",n,x[REPS/2],x[0]);}
int main(void){if(posix_memalign((void**)&sig,64,N*sizeof(*sig))||posix_memalign((void**)&out,64,N))return 2;uint64_t r=0x9e3779b97f4a7c15ULL;for(size_t i=0;i<N;i++)sig[i]=v0_decision_v7_pack((uint16_t)rng64(&r),(uint16_t)rng64(&r),(uint8_t)(rng64(&r)%3u),(uint8_t)(rng64(&r)&1u));bench("V7 packed signal scalar",scalar);bench("V7 packed signal AVX2",avx2);
#if defined(__AVX512BW__) && defined(__AVX512VL__)
bench("V7 packed signal AVX512",avx512);
#endif
printf("sink=%llu\n",(unsigned long long)sink);free(sig);free(out);return 0;}

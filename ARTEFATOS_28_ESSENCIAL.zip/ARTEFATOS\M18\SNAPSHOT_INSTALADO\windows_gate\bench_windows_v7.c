#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct { uint32_t id, score, key, valid; } rec;
extern uint32_t v0_semantic_id_safe(const rec*);
extern uint32_t v0_semantic_key_safe(const rec*);
extern uint64_t v0_semantic_id_key64_safe(const rec*);
static volatile uint64_t sink;
static uint64_t rng=0x9e3779b97f4a7c15ULL;
static uint64_t rnd64(void){ rng^=rng>>12; rng^=rng<<25; rng^=rng>>27; return rng*2685821657736338717ULL; }
static uint64_t ref_pair(const rec*p){ return (uint64_t)v0_semantic_id_safe(p)|((uint64_t)v0_semantic_key_safe(p)<<32); }
static double sec(void){ LARGE_INTEGER q,f; QueryPerformanceCounter(&q); QueryPerformanceFrequency(&f); return (double)q.QuadPart/(double)f.QuadPart; }
static double run_b(const rec*a,uint32_t n){uint64_t x=0;double s=sec();for(uint32_t i=0;i<n;i++){const rec*p=&a[(i*13u)&4095u];x^=ref_pair(p)+i;}double e=sec();sink=x;return (e-s)*1e9/n;}
static double run_c(const rec*a,uint32_t n){uint64_t x=0;double s=sec();for(uint32_t i=0;i<n;i++){const rec*p=&a[(i*13u)&4095u];x^=v0_semantic_id_key64_safe(p)+i;}double e=sec();sink=x;return (e-s)*1e9/n;}
static void fill(rec*a,int mode){for(uint32_t i=0;i<4096;i++){a[i].id=(uint32_t)rnd64();a[i].score=(uint32_t)rnd64();a[i].key=(uint32_t)rnd64();a[i].valid=mode==0?0:mode==1?1:mode==50?(i&1u):((i%100u)!=0u);}}
int main(void){
 static rec a[4096]; uint64_t bad=0,checks=0;
 for(uint32_t i=0;i<5000000u;i++){rec r={(uint32_t)rnd64(),(uint32_t)rnd64(),(uint32_t)rnd64(),(uint32_t)(rnd64()&1u)};uint64_t b=ref_pair(&r),c=v0_semantic_id_key64_safe(&r);checks++;bad+=(b!=c);}
 printf("PARITY checks=%llu bad=%llu\n",(unsigned long long)checks,(unsigned long long)bad); if(bad)return 2;
 const int modes[4]={0,50,99,1}; const char*names[4]={"invalid0","mixed50","valid99","valid100"}; const uint32_t N=20000000u;
 for(int m=0;m<4;m++){fill(a,modes[m]);for(int r=0;r<15;r++){double b,c;if(!(r&1)){b=run_b(a,N);c=run_c(a,N);}else{c=run_c(a,N);b=run_b(a,N);}printf("%s,%d,%.9f,%.9f,%.6f\n",names[m],r,b,c,b/c);}}
 return 0;
}

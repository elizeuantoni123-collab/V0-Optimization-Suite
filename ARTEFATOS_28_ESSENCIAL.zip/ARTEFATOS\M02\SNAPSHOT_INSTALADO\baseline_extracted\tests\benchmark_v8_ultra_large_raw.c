#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<25)
#define REPS 9
static uint16_t *value,*cost; static uint8_t *temp,*pin,*out8; static volatile uint64_t sink;
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+(uint64_t)x.tv_nsec;}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static void pin0(void){cpu_set_t c;CPU_ZERO(&c);CPU_SET(0,&c);(void)sched_setaffinity(0,sizeof(c),&c);}
#if defined(__AVX2__) || defined(_M_AVX2)
static double avx2_normal(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_avx2_u8(value,cost,temp,pin,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double avx2_stream(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_stream_avx2_u8(value,cost,temp,pin,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
static double avx512_normal(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_avx512_u8(value,cost,temp,pin,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double avx512_stream(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_stream_avx512_u8(value,cost,temp,pin,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
#endif
static void bench(const char*n,double(*fn)(void)){double v[REPS];for(int i=0;i<2;i++)(void)fn();for(int i=0;i<REPS;i++)v[i]=fn();qsort(v,REPS,sizeof(double),cmpd);printf("%-31s p50=%8.4f ns/decision best=%8.4f\n",n,v[REPS/2],v[0]);}
int main(void){pin0();value=aligned_alloc(64,N*2);cost=aligned_alloc(64,N*2);temp=aligned_alloc(64,N);pin=aligned_alloc(64,N);out8=aligned_alloc(64,N);if(!value||!cost||!temp||!pin||!out8)return 2;uint64_t s=0xA9D43E37ULL;for(size_t i=0;i<N;i++){value[i]=(uint16_t)rng64(&s);cost[i]=(uint16_t)rng64(&s);temp[i]=(uint8_t)(rng64(&s)%3u);pin[i]=(uint8_t)(rng64(&s)&1u);}printf("N=%u decisions (large/write-only test)\n",N);
#if defined(__AVX2__) || defined(_M_AVX2)
bench("raw AVX2 cached stores",avx2_normal);bench("raw AVX2 streaming stores",avx2_stream);
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
bench("raw AVX512 cached stores",avx512_normal);bench("raw AVX512 streaming stores",avx512_stream);
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

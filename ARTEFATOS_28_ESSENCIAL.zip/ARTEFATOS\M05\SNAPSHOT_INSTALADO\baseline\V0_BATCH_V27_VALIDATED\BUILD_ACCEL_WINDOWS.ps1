$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Out = Join-Path $Root "build\windows"
New-Item -ItemType Directory -Force -Path $Out | Out-Null
python "$Root\compiler\v0lc_plan64x4.py" "$Root\src\v0_batch_plan64_small4.v0l" "$Out\v0_batch_plan64_small4.obj" --target windows
python "$Root\compiler\v0lc_batch_avx2_v14.py" "$Root\src\v0_batch_plan64_avx2_v14.v0l" "$Out\v0_batch_plan64_avx2_v14.obj" --target windows
Write-Host "V13/V14 Windows x86-64 COFF objects rebuilt."

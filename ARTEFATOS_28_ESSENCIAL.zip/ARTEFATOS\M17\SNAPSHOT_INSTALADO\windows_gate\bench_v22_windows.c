#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
uint32_t v0_remap_apply4_prechecked_v19(void*,void*);
uint32_t v0_remap_apply4_prechecked_v22(void*,void*);
typedef struct{uint32_t x[9];}D; typedef struct{uint32_t x[5];}R;
static volatile uint64_t sinkv; static uint64_t s=0xBE5466CF34E90C6CULL;
static uint32_t r32(void){s^=s<<7;s^=s>>9;s^=s<<8;return(uint32_t)s;}
static uint32_t gd(D*d){return d->x[0]^d->x[1]^d->x[2]^d->x[3]^0xA5C39E71u;}
static void prep(D*d,R*r){d->x[0]=r32();d->x[1]=r32();if(d->x[1]==0xffffffffu)d->x[1]--;d->x[2]=r32();if(d->x[2]==0xffffffffu)d->x[2]-=17;d->x[3]=r32();d->x[4]=r32();d->x[5]=r32();d->x[6]=r32();d->x[8]=r32()&1u;d->x[7]=gd(d);r->x[0]=d->x[1];r->x[1]=d->x[2];r->x[2]=d->x[3];r->x[3]=r32();if(r->x[3]==0xffffffffu)r->x[3]--;r->x[4]=r32();}
static LARGE_INTEGER fq;
static uint64_t tick(void){LARGE_INTEGER x;QueryPerformanceCounter(&x);return(uint64_t)x.QuadPart;}
static double run(int cand,D*t,R*r,D*w,size_t ws,size_t total){uint64_t tt=0,a,b,acc=0;size_t done=0;while(done<total){memcpy(w,t,ws*sizeof(D));size_t n=ws;if(n>total-done)n=total-done;n&=~(size_t)3;MemoryBarrier();a=tick();if(cand){for(size_t i=0;i<n;i+=4)acc+=v0_remap_apply4_prechecked_v22(&w[i],&r[i]);}else{for(size_t i=0;i<n;i+=4)acc+=v0_remap_apply4_prechecked_v19(&w[i],&r[i]);}MemoryBarrier();b=tick();tt+=b-a;done+=n;}sinkv+=acc;return ((double)tt*1e9/(double)fq.QuadPart)/(double)total;}
static int cmpd(const void*a,const void*b){double x=*(double*)a,y=*(double*)b;return(x>y)-(x<y);}
int main(void){QueryPerformanceFrequency(&fq);const size_t total=2097152;const int reps=15;size_t wss[]={256,4096,65536};int offs[]={0,4,16};int wins=0,rows=0;double worst=1e9;puts("ws,offset,order,v19_ns_per_desc,v22_ns_per_desc,speedup");for(int oi=0;oi<3;oi++)for(int wi=0;wi<3;wi++){size_t ws=wss[wi],bytes=ws*sizeof(D)+64;void*bt=_aligned_malloc(bytes,64),*bw=_aligned_malloc(bytes,64);R*r=(R*)_aligned_malloc(ws*sizeof(R),64);if(!bt||!bw||!r)return 2;D*t=(D*)((char*)bt+offs[oi]),*w=(D*)((char*)bw+offs[oi]);for(size_t i=0;i<ws;i++)prep(&t[i],&r[i]);for(int order=0;order<2;order++){double a[15],b[15];for(int j=0;j<reps;j++){if(!order){a[j]=run(0,t,r,w,ws,total);b[j]=run(1,t,r,w,ws,total);}else{b[j]=run(1,t,r,w,ws,total);a[j]=run(0,t,r,w,ws,total);}}qsort(a,reps,sizeof(double),cmpd);qsort(b,reps,sizeof(double),cmpd);double sp=a[7]/b[7];printf("%zu,%d,%s,%.6f,%.6f,%.6f\n",ws,offs[oi],order?"v22first":"v19first",a[7],b[7],sp);rows++;if(sp>1.0)wins++;if(sp<worst)worst=sp;}_aligned_free(bt);_aligned_free(bw);_aligned_free(r);}fprintf(stderr,"wins=%d/%d worst=%.6f sink=%llu\n",wins,rows,worst,(unsigned long long)sinkv);return (wins==rows && worst>=1.0)?0:3;}

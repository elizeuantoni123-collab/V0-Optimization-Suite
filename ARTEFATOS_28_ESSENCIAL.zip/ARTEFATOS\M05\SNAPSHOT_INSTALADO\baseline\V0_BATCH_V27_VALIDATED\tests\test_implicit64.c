#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../include/v0_batch.h"

static uint32_t rng_state=0x9e3779b9u;
static uint32_t xr(void){ rng_state^=rng_state<<13; rng_state^=rng_state>>17; rng_state^=rng_state<<5; return rng_state; }

static uint32_t implicit_span(uint32_t items, uint32_t idx, v0_batch_span *s){
    uint32_t k=v0_batch_count64(items);
    if(idx>=k) return 0;
    uint32_t start=idx<<6;
    uint32_t rem=items-start;
    s->start=start;
    s->count=rem>64u?64u:rem;
    return 1;
}

int main(void){
    uint64_t checks=0;
    v0_batch_span ref[65538];
    const uint32_t edge[]={0,1,2,63,64,65,127,128,129,255,256,257,4095,4096,65535,65536,1048576,4194240};
    for(unsigned e=0;e<sizeof(edge)/sizeof(edge[0]);++e){
        uint32_t n=edge[e];
        uint32_t k=(n?((n-1u)>>6)+1u:0u);
        uint32_t z=(n<=256)?v0_batch_plan64(ref,n):v0_batch_plan64x4(ref,n);
        if(z!=k){fprintf(stderr,"count edge mismatch n=%u %u %u\n",n,z,k);return 1;}
        for(uint32_t i=0;i<k;i++){
            v0_batch_span got;
            if(!implicit_span(n,i,&got) || memcmp(&got,&ref[i],sizeof got)){fprintf(stderr,"span edge mismatch n=%u i=%u\n",n,i);return 2;}
            checks++;
        }
    }
    for(uint32_t t=0;t<1000000u;t++){
        uint32_t n=xr()%4194241u; /* <= 65535 spans */
        uint32_t k=v0_batch_count64(n);
        uint32_t z=(n<=256)?v0_batch_plan64(ref,n):v0_batch_plan64x4(ref,n);
        if(z!=k){fprintf(stderr,"count rnd mismatch n=%u %u %u\n",n,z,k);return 3;}
        /* Exact descriptor checks at first, middle, last + 2 random indices. */
        if(k){
            uint32_t idxs[5]={0,k/2,k-1,xr()%k,xr()%k};
            for(int q=0;q<5;q++){
                uint32_t i=idxs[q]; v0_batch_span got;
                implicit_span(n,i,&got);
                if(memcmp(&got,&ref[i],sizeof got)){fprintf(stderr,"span rnd mismatch n=%u i=%u\n",n,i);return 4;}
                checks++;
            }
        }
        checks++;
    }
    printf("PASS implicit64 checks=%llu\n",(unsigned long long)checks);
    return 0;
}

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_fast.h"

static uint64_t rng64(uint64_t *s) {
    uint64_t x = *s;
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    *s = x; return x;
}

static uint32_t ref_pre(int32_t score) { return (uint32_t)(score >= 0); }
static uint32_t ref_dec(int32_t score) {
    return (uint32_t)(score >= 64)
         + (uint32_t)(score >= 192)
         + (uint32_t)(score >= 384);
}

int main(void) {
    uint64_t bad_score_domain = 0, bad_raw = 0, total_raw = 0;

    /* Exhaust every score value that valid raw inputs can produce. */
    for (int32_t score = -32767; score <= 98878; ++score) {
        const uint32_t bits = (uint32_t)score;
        const uint32_t pre = v0_preflight_v0l_v8_fast(bits);
        const uint32_t dec = v0_decide_v0l_v8_fast(bits);
        const uint32_t ev  = v0_eval_v0l_v8_fast(bits);
        const uint32_t inl = v0_eval_v8_inline(score);
        const uint32_t rp = ref_pre(score), rd = ref_dec(score);
        if (pre != rp || dec != rd ||
            v0_eval_v8_preflight(ev) != rp || v0_eval_v8_decision(ev) != rd ||
            v0_eval_v8_preflight(inl) != rp || v0_eval_v8_decision(inl) != rd) {
            ++bad_score_domain;
        }
    }

    /* Raw-input equivalence vs byte-identical validated V7 kernel. */
    uint64_t st = 0x123456789abcdefULL;
    for (uint32_t i = 0; i < 20000000u; ++i) {
        const uint16_t value = (uint16_t)rng64(&st);
        const uint16_t cost = (uint16_t)rng64(&st);
        const uint8_t temp = (uint8_t)(rng64(&st) % 3u);
        const uint8_t pinned = (uint8_t)(rng64(&st) & 1u);
        const v0_decision_signal_v7_t s7 = v0_decision_v7_pack(value, cost, temp, pinned);
        const int32_t score_fast = v0_decision_v8_score(value, cost, temp, pinned);
        const int32_t score_arith = v0_decision_v8_score_arith(value, cost, temp, pinned);
        const uint32_t p7 = v0_preflight_v0l_v7(&s7);
        const uint32_t d7 = v0_decide_v0l_v7(&s7);
        const uint32_t p8 = v0_preflight_v0l_v8_fast((uint32_t)score_fast);
        const uint32_t d8 = v0_decide_v0l_v8_fast((uint32_t)score_fast);
        const uint32_t ev = v0_eval_v0l_v8_fast((uint32_t)score_fast);
        const uint32_t inl = v0_eval_v8_inline(score_fast);
        ++total_raw;
        if (score_fast != score_arith || p8 != p7 || d8 != d7 ||
            v0_eval_v8_preflight(ev) != p7 || v0_eval_v8_decision(ev) != d7 ||
            v0_eval_v8_preflight(inl) != p7 || v0_eval_v8_decision(inl) != d7) {
            ++bad_raw;
        }
    }

    printf("V8 FAST VALIDATION\n");
    printf("score_domain_cases=%u score_domain_bad=%llu\n",
           (unsigned)(98878 - (-32767) + 1), (unsigned long long)bad_score_domain);
    printf("raw_random_cases=%llu raw_bad=%llu\n",
           (unsigned long long)total_raw, (unsigned long long)bad_raw);
    printf("status=%s\n", (bad_score_domain == 0 && bad_raw == 0) ? "PASS" : "FAIL");
    return (bad_score_domain == 0 && bad_raw == 0) ? 0 : 2;
}

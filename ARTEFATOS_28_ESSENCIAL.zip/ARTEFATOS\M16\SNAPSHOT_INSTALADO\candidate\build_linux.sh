#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 compiler/v0lc_x64_tier_batch8.py src/v0_tier_batch8_v12.v0l build/linux/v0_tier_batch8_v12.o --target linux
sha256sum build/linux/v0_tier_batch8_v12.o

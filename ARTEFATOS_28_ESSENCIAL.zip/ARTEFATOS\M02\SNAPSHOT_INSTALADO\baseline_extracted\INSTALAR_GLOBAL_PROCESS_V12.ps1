$ErrorActionPreference = "Stop"

function Assert-Administrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Abra o PowerShell como Administrador e execute novamente."
    }
}

Assert-Administrator

$Root = $PSScriptRoot
$ServiceName = "V0DecisionV8"
$DisplayName = "V0 Decision V12 Global Process Broker"
$Description = "V0 Decision V12 global process-aware broker. Tracks Windows process coverage and exposes PID-scoped Decision APIs without DLL injection."
$InstallDir = Join-Path $env:ProgramFiles "V0DecisionV8"
$BuildDir = Join-Path $Root "windows_global\build"
$Source = Join-Path $Root "windows_global\src\v0_decision_v12_global_service.c"
$IncludeDir = Join-Path $Root "include"
$FastDecisionObj = Join-Path $Root "build\windows\v0_decision_v8_fast.obj"
$BuiltExe = Join-Path $BuildDir "V0DecisionV12GlobalService.exe"
$InstalledExe = Join-Path $InstallDir "V0DecisionV12GlobalService.exe"
$OldInstalledExe = Join-Path $InstallDir "V0DecisionV8Service.exe"
$RegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " V0 DECISION V12 - GLOBAL PROCESS BROKER FIX1" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

$required = @(
    $Source,
    $FastDecisionObj,
    (Join-Path $IncludeDir "v0_decision_v7.h"),
    (Join-Path $IncludeDir "v0_decision_v8_adaptive.h"),
    (Join-Path $IncludeDir "v0_decision_v8_fast.h"),
    (Join-Path $IncludeDir "v0_decision_v8_extreme.h"),
    (Join-Path $IncludeDir "v0_decision_v8_ultra_v12.h")
)
foreach ($f in $required) {
    if (-not (Test-Path $f)) { throw "Arquivo obrigatorio nao encontrado: $f" }
}

$vcvarsCandidates = @(
    "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
)
$VcVars = $vcvarsCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $VcVars) { throw "Visual Studio 2022 C++ Build Tools nao encontrado." }

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$ServiceObj = Join-Path $BuildDir "v0_decision_v12_global_service.obj"

Write-Host "[1/7] Compilando broker global x64..." -ForegroundColor Yellow
$compile = "`"$VcVars`" && cl /nologo /O2 /Ot /Oi /Ob3 /GL /Gw /Gy /MT /c /I`"$IncludeDir`" `"$Source`" /Fo:`"$ServiceObj`""
cmd /c $compile
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $ServiceObj)) {
    throw "Falha ao compilar broker global."
}

Write-Host "[2/7] Linkando V12 Global + nucleo Decision..." -ForegroundColor Yellow
$link = "`"$VcVars`" && cl /nologo /GL `"$ServiceObj`" `"$FastDecisionObj`" /Fe:`"$BuiltExe`" /link /LTCG /OPT:REF /OPT:ICF Advapi32.lib"
cmd /c $link
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $BuiltExe)) {
    throw "Falha ao linkar V0DecisionV12GlobalService.exe"
}

Write-Host "[3/7] Parando host anterior..." -ForegroundColor Yellow
$existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existing) {
    if ($existing.Status -ne 'Stopped') {
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        try { (Get-Service -Name $ServiceName).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(10)) } catch {}
    }
    & sc.exe delete $ServiceName | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Falha ao remover o registro anterior de $ServiceName." }
    $deadline = (Get-Date).AddSeconds(10)
    do {
        Start-Sleep -Milliseconds 250
        $existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    } while ($existing -and (Get-Date) -lt $deadline)
    if ($existing) { throw "Servico antigo ainda marcado para exclusao. Reinicie o Windows e rode este instalador novamente." }
}

Write-Host "[4/7] Instalando executavel global..." -ForegroundColor Yellow
Copy-Item $BuiltExe $InstalledExe -Force
if (-not (Test-Path $InstalledExe)) { throw "Falha ao instalar $InstalledExe" }

# Mantem o executavel antigo apenas como rollback, nunca como processo/servico ativo.
if (Test-Path $OldInstalledExe) {
    $backup = Join-Path $InstallDir "V0DecisionV8Service.rollback.exe"
    Copy-Item $OldInstalledExe $backup -Force
}

Write-Host "[5/7] Registrando um unico servico..." -ForegroundColor Yellow
$BinaryPathName = '"' + $InstalledExe + '"'
New-Service -Name $ServiceName `
    -BinaryPathName $BinaryPathName `
    -DisplayName $DisplayName `
    -Description $Description `
    -StartupType Automatic | Out-Null

if (-not (Test-Path $RegistryPath)) { throw "Registro do servico nao encontrado." }
Set-ItemProperty -Path $RegistryPath -Name DelayedAutoStart -Type DWord -Value 1
Set-ItemProperty -Path $RegistryPath -Name Description -Type String -Value $Description

Write-Host "[6/7] Iniciando broker global..." -ForegroundColor Yellow
Start-Service -Name $ServiceName
(Get-Service -Name $ServiceName).WaitForStatus('Running', [TimeSpan]::FromSeconds(10))
Start-Sleep -Milliseconds 500

Write-Host "[7/7] Validando versao e cobertura..." -ForegroundColor Yellow
$client = Join-Path $Root "CLIENTE_DECISION_V8.ps1"
$ping = & $client -Command "PING"
$version = & $client -Command "VERSION"
$global = & $client -Command "GLOBALSTATUS"
$status = & $client -Command "STATUS"

Write-Host "PING        : $ping"
Write-Host "VERSION     : $version"
Write-Host "GLOBALSTATUS: $global"
Write-Host "STATUS      : $status"

if ($version -notmatch 'V12-GLOBAL-PROCESS-V1') {
    throw "Broker iniciou, mas VERSION nao confirmou V12-GLOBAL-PROCESS-V1."
}

$cim = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'"
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " V0 DECISION V12 GLOBAL PROCESS: ATIVO" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "Servico : $($cim.Name) / $($cim.State)"
Write-Host "Display : $DisplayName"
Write-Host "Binario : $($cim.PathName)"
Write-Host "Pipe    : \\.\pipe\V0DecisionV8 (compatibilidade preservada)"
Write-Host ""
Write-Host "Cobertura: processos vivos do Windows sao descobertos continuamente." -ForegroundColor Green
Write-Host "IMPORTANTE: este broker NAO injeta DLL e NAO intercepta automaticamente toda operacao interna de cada processo." -ForegroundColor DarkYellow
Write-Host "Ele fornece cobertura global por PID e APIs DECIDEPID/GATEDECIDEPID. Interceptores de arquivo/rede/etc. devem ser ligados separadamente." -ForegroundColor DarkYellow

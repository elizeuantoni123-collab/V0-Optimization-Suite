#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_ultra_v11.h"
static volatile uint64_t sink;
static uint64_t now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return*s=x;}
static void pin0(void){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);}
static double one(size_t n,int newer,const uint16_t*v,const uint16_t*g,uint8_t*out){int R=(int)(2000000u/n);if(R<50000)R=50000;uint64_t a=now_ns();for(int r=0;r<R;r++){if(newer)v0_eval_gate16_batch_v11_avx2_u8(v,g,out,n);else v0_eval_gate16_batch_v10_avx2_u8(v,g,out,n);sink+=out[(unsigned)r%n];}uint64_t z=now_ns();return(double)(z-a)/(R*n);}
int main(void){pin0();uint16_t v[64],g[64];uint8_t out[64];uint64_t s=0xBF58476D1CE4E5B9ULL;for(int i=0;i<64;i++){v[i]=(uint16_t)rng64(&s);g[i]=(uint16_t)rng64(&s);}const size_t lens[]={1,2,4,8,10,15,17,31};for(size_t k=0;k<sizeof(lens)/sizeof(lens[0]);k++){size_t n=lens[k];double a=one(n,0,v,g,out),b=one(n,1,v,g,out);printf("n=%2zu V10=%8.4f V11=%8.4f speedup=%5.2fx\n",n,a,b,a/b);}printf("sink=%llu\n",(unsigned long long)sink);return 0;}

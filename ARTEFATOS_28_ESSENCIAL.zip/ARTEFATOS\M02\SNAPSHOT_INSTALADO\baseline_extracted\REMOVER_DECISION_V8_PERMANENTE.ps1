$ErrorActionPreference = "Stop"
function Assert-Administrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Abra o PowerShell como Administrador."
    }
}
Assert-Administrator
$ServiceName = "V0DecisionV8"
$InstallDir = Join-Path $env:ProgramFiles "V0DecisionV8"
$svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($svc) {
    if ($svc.Status -ne 'Stopped') {
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        try { (Get-Service -Name $ServiceName).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(10)) } catch {}
    }
    sc.exe delete $ServiceName | Out-Null
    Start-Sleep -Milliseconds 500
}
if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force }
Write-Host "V0 Decision V8 permanente removido." -ForegroundColor Green

// V0 Global Memory policy bridge — V8.17 policy cleanup path.
//
// The current V0 policy is intentionally pass-through: V0 produces a resident
// policy token while the EPT map is compiled, but it does not reject or alter a
// leaf mapping.  In V8.5 the trusted token path hashed a pointer that the caller
// had just derived from key_index.  For every resident key, that perfect-hash
// lookup returns exactly key_index (verified exhaustively for all 1024 keys).
//
// V8.6 therefore computes the identical token directly.  This preserves the EPT
// mapping decisions and the telemetry checksum while removing the redundant
// key-pointer construction + V0L trusted lookup from the EPT-build hot path.
// The original V0L lookups and tables remain unchanged in the package and are
// used by the validation benchmark; they are simply not needed in this EPT
// build path when the caller already owns key_index.

#include "v0_policy.h"
#include <intrin.h>
#include "log.h"

static const ULONG kV0KeyCount = 1024;
static const ULONG kV0MaxCpuSlots = 1024;
static const ULONG64 kV0SampleMask = 0x3ffull;  // sample 1/1024 compiled pages
static const ULONG64 kV0PagesPer2Mb = 512;
static const ULONG64 kV0TwoMbBytes = 2ull * 1024ull * 1024ull;

static volatile ULONG64 g_v0_pages[kV0MaxCpuSlots];
static volatile ULONG64 g_v0_sample_cycles[kV0MaxCpuSlots];
static volatile ULONG64 g_v0_samples[kV0MaxCpuSlots];
static volatile ULONG g_v0_sink[kV0MaxCpuSlots];

static __forceinline ULONG V0PolicyCpuSlot() {
  // V8.17: KeGetCurrentProcessorNumberEx already returns the system-wide
  // processor index.  No PROCESSOR_NUMBER write/reconstruction is needed.
  // kV0MaxCpuSlots is 1024 (power of two), so modulo is exactly a mask.
  return KeGetCurrentProcessorNumberEx(nullptr) & (kV0MaxCpuSlots - 1u);
}

static __forceinline ULONG V0PolicyKeyIndex(ULONG64 physical_address) {
  // V8.19: exact two-stage XOR fold. Algebraically this is identical to
  // page ^ (page >> 10) ^ (page >> 20) ^ (page >> 30), but needs only
  // two shifts and two XORs instead of three of each.
  ULONG64 page = physical_address >> PAGE_SHIFT;
  page ^= page >> 20;
  page ^= page >> 10;
  return static_cast<ULONG>(page & (kV0KeyCount - 1));
}

// V8.10: XOR of all integers in [0, value] in O(1). Because the V0 token fold
// is composed only of XOR, shifts and a low-10-bit mask, XOR distributes over
// the fold. This lets an arbitrary consecutive physical-page range preserve
// the exact scalar checksum without visiting every page.
static __forceinline ULONG64 V0PolicyXorUpTo(ULONG64 value) {
  switch (value & 3ull) {
    case 0: return value;
    case 1: return 1ull;
    case 2: return value + 1ull;
    default: return 0ull;
  }
}

static __forceinline ULONG V0PolicyRangeTokenXor(ULONG64 physical_address,
                                                  ULONG64 page_count) {
  if (page_count == 0) {
    return 0;
  }
  const ULONG64 first_page = physical_address >> PAGE_SHIFT;
  const ULONG64 last_page = first_page + page_count - 1;
  const ULONG64 pages_xor =
      V0PolicyXorUpTo(last_page) ^
      (first_page ? V0PolicyXorUpTo(first_page - 1) : 0ull);
  ULONG64 token_xor = pages_xor;
  token_xor ^= token_xor >> 20;
  token_xor ^= token_xor >> 10;
  return static_cast<ULONG>(token_xor & (kV0KeyCount - 1));
}

static __forceinline ULONG V0PolicyTimedToken(ULONG64 physical_address,
                                               ULONG64* cycles_out) {
  _mm_lfence();
  const ULONG64 t0 = __rdtsc();
  // Volatile is intentional: the timed token must really execute between
  // the two RDTSC reads even when a batch caller discards the return value.
  volatile ULONG token = V0PolicyKeyIndex(physical_address);
  const ULONG64 t1 = __rdtsc();
  _mm_lfence();
  *cycles_out += (t1 - t0);
  return token;
}

extern "C" void V0PolicyCompilePhysicalPage(ULONG64 physical_address) {
  const ULONG cpu = V0PolicyCpuSlot();
  const ULONG64 n = g_v0_pages[cpu];
  ULONG token = 0;

  if ((n & kV0SampleMask) == 0) {
    ULONG64 sample_cycles = 0;
    token = V0PolicyTimedToken(physical_address, &sample_cycles);
    g_v0_sample_cycles[cpu] += sample_cycles;
    g_v0_samples[cpu] += 1;
  } else {
    token = V0PolicyKeyIndex(physical_address);
  }

  g_v0_sink[cpu] ^= token;
  g_v0_pages[cpu] = n + 1;
}

extern "C" void V0PolicyCompilePhysicalRange(ULONG64 physical_address,
                                               ULONG64 page_count) {
  if (page_count == 0) {
    return;
  }

  const ULONG cpu = V0PolicyCpuSlot();
  ULONG64 n = g_v0_pages[cpu];

  // V8.17: a one-page range is exactly the scalar path.  Avoid the generic
  // prefix-XOR machinery while preserving sample phase/checksum/counters.
  if (page_count == 1) {
    ULONG token = 0;
    if ((n & kV0SampleMask) == 0) {
      ULONG64 sample_cycles = 0;
      token = V0PolicyTimedToken(physical_address, &sample_cycles);
      g_v0_sample_cycles[cpu] += sample_cycles;
      g_v0_samples[cpu] += 1;
    } else {
      token = V0PolicyKeyIndex(physical_address);
    }
    g_v0_sink[cpu] ^= token;
    g_v0_pages[cpu] = n + 1;
    return;
  }

  // A 2 MiB-aligned block contains exactly 512 consecutive 4 KiB pages.
  // For the 10-bit XOR fold above, XOR(token[0..511]) is exactly zero for
  // every such aligned block.  Therefore any whole number of aligned 2 MiB
  // blocks can update the telemetry in O(samples), not O(pages), while keeping
  // the final page count and checksum bit-for-bit identical to the scalar path.
  if ((physical_address & (kV0TwoMbBytes - 1)) == 0 &&
      (page_count % kV0PagesPer2Mb) == 0) {
    const ULONG64 first_sample = (0ull - n) & kV0SampleMask;
    ULONG64 sample_cycles_total = 0;
    ULONG64 sample_count = 0;
    for (ULONG64 i = first_sample; i < page_count;
         i += (kV0SampleMask + 1)) {
      (void)V0PolicyTimedToken(physical_address + (i << PAGE_SHIFT),
                               &sample_cycles_total);
      ++sample_count;
    }
    g_v0_sample_cycles[cpu] += sample_cycles_total;
    g_v0_samples[cpu] += sample_count;
    g_v0_pages[cpu] = n + page_count;
    return;
  }

  // V8.10: arbitrary-range fast path. The checksum is algebraically identical
  // to the scalar loop, while only the true 1/1024 timed samples are visited.
  const ULONG checksum_delta =
      V0PolicyRangeTokenXor(physical_address, page_count);
  const ULONG64 first_sample = (0ull - n) & kV0SampleMask;
  ULONG64 sample_cycles_total = 0;
  ULONG64 sample_count = 0;
  for (ULONG64 i = first_sample; i < page_count;
       i += (kV0SampleMask + 1)) {
    (void)V0PolicyTimedToken(physical_address + (i << PAGE_SHIFT),
                             &sample_cycles_total);
    ++sample_count;
  }

  g_v0_sink[cpu] ^= checksum_delta;
  g_v0_sample_cycles[cpu] += sample_cycles_total;
  g_v0_samples[cpu] += sample_count;
  g_v0_pages[cpu] = n + page_count;
}

extern "C" void V0PolicyLogSummary(void) {
  ULONG64 pages = 0;
  ULONG64 cycles = 0;
  ULONG64 samples = 0;
  ULONG checksum = 0;
  for (ULONG i = 0; i < kV0MaxCpuSlots; ++i) {
    pages += g_v0_pages[i];
    cycles += g_v0_sample_cycles[i];
    samples += g_v0_samples[i];
    checksum ^= g_v0_sink[i];
  }

  const ULONG64 avg_cycles = samples ? (cycles / samples) : 0;
  HYPERPLATFORM_LOG_INFO(
      "V0 GLOBAL: EPT leaf mappings compiled=%llu, sampled_calls=%llu, "
      "sampled_avg_cycles=%llu, checksum=%lu",
      pages, samples, avg_cycles, checksum);
  HYPERPLATFORM_LOG_INFO(
      "V0 GLOBAL: policy=v0-pass-through-fast; trusted token is computed "
      "directly from the already-known key index; no guest load/store hook.");
}

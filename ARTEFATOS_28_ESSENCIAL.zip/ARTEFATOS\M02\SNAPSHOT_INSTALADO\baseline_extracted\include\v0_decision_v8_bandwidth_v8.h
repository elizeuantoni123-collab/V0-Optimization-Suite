#ifndef V0_DECISION_V8_BANDWIDTH_V8_H
#define V0_DECISION_V8_BANDWIDTH_V8_H
#include "v0_decision_v8_ultra_v8.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Optional exact 1-byte state for bandwidth-bound pipelines.
 * low2 = temperature Q6 bonus (0,1,3), bit7 = pinned.
 * It preserves every distinction Decision consumes, but is intentionally not
 * the default hot-cache representation: bias16 remains faster for small data. */
typedef uint8_t v0_decision_meta8_v8_t;
V0X_FORCEINLINE v0_decision_meta8_v8_t v0_decision_v8_meta8(uint8_t temperature,uint8_t pinned){
    const uint8_t tq=(uint8_t)(temperature+(temperature>>1));
    return (uint8_t)(tq | (uint8_t)((pinned&1u)<<7));
}
V0X_FORCEINLINE uint32_t v0_eval_v8_meta8_ultra_inline(
    uint16_t value,uint16_t cost,v0_decision_meta8_v8_t meta){
    if (meta&0x80u) return 7u;
    return v0_eval_v8_bias_ultra_inline(value,cost,(uint16_t)((meta&3u)<<6));
}

#if defined(__AVX2__) || defined(_M_AVX2)
V0X_FORCEINLINE __m128i v0_eval_v8_meta8_block16_avx2(
    const uint16_t*value,const uint16_t*cost,const v0_decision_meta8_v8_t*meta){
    const __m256i vv=_mm256_loadu_si256((const __m256i*)(const void*)value);
    const __m256i hh=_mm256_srli_epi16(_mm256_loadu_si256((const __m256i*)(const void*)cost),1);
    const __m256i mm=_mm256_cvtepu8_epi16(_mm_loadu_si128((const __m128i*)(const void*)meta));
    const __m256i tq=_mm256_and_si256(mm,_mm256_set1_epi16(3));
    const __m256i bonus=_mm256_slli_epi16(tq,6);
    const __m256i ss=_mm256_adds_epu16(vv,bonus);
    const __m256i dd=_mm256_subs_epu16(ss,hh);
    const __m256i pre=_mm256_cmpeq_epi16(_mm256_max_epu16(ss,hh),ss);
    __m256i idx=_mm256_min_epu16(
        _mm256_add_epi16(_mm256_srli_epi16(dd,6),_mm256_set1_epi16(1)),
        _mm256_set1_epi16(7));
    idx=_mm256_and_si256(idx,pre);
    {
        const __m256i pinmask=_mm256_srai_epi16(_mm256_slli_epi16(mm,8),15);
        idx=_mm256_blendv_epi8(idx,_mm256_set1_epi16(7),pinmask);
    }
    {
        const __m128i i8=_mm_packus_epi16(
            _mm256_castsi256_si128(idx),_mm256_extracti128_si256(idx,1));
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),i8);
    }
}
static inline void v0_eval_v8_meta8_batch_avx2_u8(
    const uint16_t*value,const uint16_t*cost,const v0_decision_meta8_v8_t*meta,
    uint8_t*out,size_t n){
    size_t i=0;
    for(;i+16<=n;i+=16)
        _mm_storeu_si128((__m128i*)(void*)(out+i),
            v0_eval_v8_meta8_block16_avx2(value+i,cost+i,meta+i));
    for(;i<n;i++) out[i]=(uint8_t)v0_eval_v8_meta8_ultra_inline(value[i],cost[i],meta[i]);
}

#if defined(__AVX512BW__) && defined(__AVX512VL__)
V0X_FORCEINLINE __m256i v0_eval_v8_meta8_block32_avx512(
    const uint16_t*value,const uint16_t*cost,const v0_decision_meta8_v8_t*meta){
    const __m512i vv=_mm512_loadu_si512((const void*)value);
    const __m512i hh=_mm512_srli_epi16(_mm512_loadu_si512((const void*)cost),1);
    const __m512i mm=_mm512_cvtepu8_epi16(_mm256_loadu_si256((const __m256i*)(const void*)meta));
    const __m512i tq=_mm512_and_si512(mm,_mm512_set1_epi16(3));
    const __m512i ss=_mm512_adds_epu16(vv,_mm512_slli_epi16(tq,6));
    const __m512i dd=_mm512_subs_epu16(ss,hh);
    const __mmask32 pre=_mm512_cmpge_epu16_mask(ss,hh);
    const __mmask32 pin=_mm512_cmpneq_epi16_mask(
        _mm512_and_si512(mm,_mm512_set1_epi16(0x80)),_mm512_setzero_si512());
    __m512i idx=_mm512_min_epu16(
        _mm512_add_epi16(_mm512_srli_epi16(dd,6),_mm512_set1_epi16(1)),
        _mm512_set1_epi16(7));
    idx=_mm512_maskz_mov_epi16(pre,idx);
    idx=_mm512_mask_mov_epi16(idx,pin,_mm512_set1_epi16(7));
    {
        const __m256i i8=_mm512_cvtusepi16_epi8(idx);
        return _mm256_shuffle_epi8(
            _mm256_setr_epi8(
                0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
                0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),i8);
    }
}
static inline void v0_eval_v8_meta8_batch_avx512_u8(
    const uint16_t*value,const uint16_t*cost,const v0_decision_meta8_v8_t*meta,
    uint8_t*out,size_t n){
    size_t i=0;
    for(;i+32<=n;i+=32)
        _mm256_storeu_si256((__m256i*)(void*)(out+i),
            v0_eval_v8_meta8_block32_avx512(value+i,cost+i,meta+i));
    if(i<n) v0_eval_v8_meta8_batch_avx2_u8(value+i,cost+i,meta+i,out+i,n-i);
}
static inline void v0_eval_v8_meta8_batch_avx512_nibble(
    const uint16_t*value,const uint16_t*cost,const v0_decision_meta8_v8_t*meta,
    uint8_t*out,size_t n){
    size_t i=0,j=0;
    for(;i+32<=n;i+=32,j+=16)
        _mm_storeu_si128((__m128i*)(void*)(out+j),
            v0_pack_v8_e3_nibbles32_avx2(
                v0_eval_v8_meta8_block32_avx512(value+i,cost+i,meta+i)));
    if(i<n){uint8_t acc=0;unsigned half=0;for(;i<n;i++){uint8_t e=(uint8_t)v0_eval_v8_meta8_ultra_inline(value[i],cost[i],meta[i]);if(!half){acc=e;half=1;}else{out[j++]=(uint8_t)(acc|(uint8_t)(e<<4));half=0;}}if(half)out[j]=acc;}
}
static inline void v0_eval_v8_meta8_batch_stream_avx512_nibble(
    const uint16_t*value,const uint16_t*cost,const v0_decision_meta8_v8_t*meta,
    uint8_t*out,size_t n){
    size_t i=0,j=0;
    if((((uintptr_t)out)&15u)!=0u||n<256u){v0_eval_v8_meta8_batch_avx512_nibble(value,cost,meta,out,n);return;}
    for(;i+32<=n;i+=32,j+=16)
        _mm_stream_si128((__m128i*)(void*)(out+j),
            v0_pack_v8_e3_nibbles32_avx2(
                v0_eval_v8_meta8_block32_avx512(value+i,cost+i,meta+i)));
    _mm_sfence();
    if(i<n){uint8_t acc=0;unsigned half=0;for(;i<n;i++){uint8_t e=(uint8_t)v0_eval_v8_meta8_ultra_inline(value[i],cost[i],meta[i]);if(!half){acc=e;half=1;}else{out[j++]=(uint8_t)(acc|(uint8_t)(e<<4));half=0;}}if(half)out[j]=acc;}
}
#endif /* AVX512 */
#endif /* AVX2 */

#ifdef __cplusplus
}
#endif
#endif

# Artefato 18 — Semantic Bridge V7 SAFE Pair

Baseline: **V0 Semantic Bridge V5 SAFE**.

Candidate: additive `v0_semantic_id_key64_safe()` for callers that need both safe ID and safe key from one record.

Local result:

- 20,000,072 long differential checks, 0 divergence;
- 300/300 timed A/B wins;
- median speedup ~1.74x to 1.86x across tested validity profiles;
- existing V1–V5 paths remain unchanged.

Status: **LOCAL_PASS / WINDOWS_GATE_REQUIRED**.

See `REPORT.md` and `DISPATCH_CANDIDATE.md`.

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
New-Item -ItemType Directory -Force -Path (Join-Path $Root "build\windows") | Out-Null
python (Join-Path $Root "compiler\v0lc_batch_avx2_dual_v19.py") `
  (Join-Path $Root "src\v0_batch_plan64_avx2_dual_v19.v0l") `
  (Join-Path $Root "build\windows\v0_batch_plan64_avx2_dual_v19.obj") `
  --target windows
Write-Host "V19 Windows object rebuilt."

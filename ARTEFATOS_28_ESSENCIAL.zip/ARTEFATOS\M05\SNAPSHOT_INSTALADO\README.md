# Batch Planner / Batch — packaged result

Status: **KEEP_BASELINE (V27)**.

Start with `REPORT.md`.

- `baseline/V0_BATCH_V27_VALIDATED/` — complete validated baseline.
- `evidence/` — fresh revalidation and fresh diagnostic performance screening.
- `rejected_experiments/` — source/harness for the rejected exact-size unrolled experiment.

No candidate is promoted by this package.

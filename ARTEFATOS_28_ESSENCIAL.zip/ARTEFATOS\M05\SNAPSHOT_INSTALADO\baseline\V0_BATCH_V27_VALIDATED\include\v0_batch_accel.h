#ifndef V0_BATCH_ACCEL_H
#define V0_BATCH_ACCEL_H
#include "v0_batch.h"
#ifdef __cplusplus
extern "C" {
#endif

/* V13: exact materialized planner specialized for 0..256 items.
   Validation host: promoted only for 64..256; keep v0_batch_plan64 below that
   unless the target host benchmark proves otherwise. */
uint32_t v0_batch_plan64_small4(v0_batch_span *out, uint32_t items);

/* V14: AVX2 materialized planner. Same exact output ABI as v0_batch_plan64x4.
   CALL ONLY when AVX2 + OS YMM state support are available.
   V11 remains the mandatory fallback. */
uint32_t v0_batch_plan64_avx2_v14(v0_batch_span *out, uint32_t items);

#ifdef __cplusplus
}
#endif
#endif

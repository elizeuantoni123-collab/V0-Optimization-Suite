# V0 Decision V8 ULTRA V12 — Technical Report

## Status

**PROMOTED as an additive scalar gate16 optimization.**

V12 does not change Decision thresholds, states, adaptive-controller policy, V11 SIMD code, raw one-shot code, compact-output code, or streaming defaults.

## Promoted changes

### Direct 2 KiB scalar gate16 LUT

For `uint16 value` and `uint16 gate16`, the unsaturated sum is in `0..131070`, therefore:

`q = (value + gate16) >> 6` is exactly in `0..2047`.

All `q >= 518` map to Decision state 7. V12 stores the exact mapping for all 2048 indices, so the scalar hot path becomes essentially `add -> shift -> byte lookup`; no scalar clamp/saturation is needed.

### Branchless scalar gate16 builder

For the legal Decision input domain (`temperature=0..2`, `pinned=0/1`) V12 builds the exact V10 descriptor using a branchless pinned mask. This removes the unpredictable `if (pinned)` branch from scalar descriptor construction.

## Correctness validation

V12 validation was compiled and executed in three configurations:

- scalar-only/SSE2: **21,495,807 checked, 0 divergences**
- AVX2-only: **21,495,807 checked, 0 divergences**
- native/AVX-512: **21,495,807 checked, 0 divergences**

The suite includes:

- every possible `value + gate16` sum from 0 through 131070;
- every `cost` value 0..65535 × temperature 0..2 × pinned 0/1 for gate construction;
- 20 × 1,048,576 random legal raw signals;
- exact preflight comparison.

Inherited V11 validation rebuilt from inside the V12 tree also passed in AVX2 and native modes with **21,135,744 checked, 0 divergences** per build.

## Integrity

**267/267 inherited V11 files are SHA-256 identical.** No inherited file is missing or modified.

## Performance

Five independent benchmark processes were run on the same host. Values below are the **median of the five process medians**. They are throughput cost per independent item in a hot loop, not single dependent-call latency.

| Path | Previous | V12 | Change |
|---|---:|---:|---:|
| scalar gate16 evaluation | 0.771775 ns/item | **0.482806 ns/item** | **37.44% lower; 1.60× throughput** |
| scalar gate16 construction | 5.638549 ns/item | **1.246215 ns/item** | **77.90% lower; 4.52× throughput** |

The scalar-builder benchmark uses volatile input loads specifically to prevent the compiler from removing the unpredictable-input behavior being measured.

## Rejected candidates

V12 does **not** promote changes that failed the no-regression rule. Rejected experiments include:

- software-saturated 1 KiB LUT;
- automatic batch-tail replacement;
- AVX-512 nibble evaluator/streaming;
- wider grouped non-temporal stores;
- using branchless gate + 2 KiB LUT as a raw scalar one-shot replacement.

See `V12_REJECTED_CANDIDATES.txt` for details.

## Integration rule

Use V12 only where it wins:

- scalar gate16 construction → V12 branchless builder;
- scalar evaluation with gate16 already available → V12 direct 2 KiB LUT;
- raw one-shot, SIMD batch, preflight, compact output, streaming → keep inherited promoted paths.

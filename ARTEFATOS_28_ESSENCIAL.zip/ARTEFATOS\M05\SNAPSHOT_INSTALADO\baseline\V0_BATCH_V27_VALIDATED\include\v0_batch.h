#ifndef V0_BATCH_H
#define V0_BATCH_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct v0_batch_span {
    uint32_t start;
    uint32_t count;
} v0_batch_span;

/* Generic primitives. UINT32_MAX means invalid limit (limit == 0). */
uint32_t v0_batch_count(uint32_t items, uint32_t limit);
uint32_t v0_batch_take(uint32_t remaining, uint32_t limit);

/* Fixed-64 fast primitives. */
uint32_t v0_batch_count64(uint32_t items);
uint32_t v0_batch_take64(uint32_t remaining);

/* out must hold at least v0_batch_count64(items) spans when items > 0. */
uint32_t v0_batch_plan64(v0_batch_span *out, uint32_t items);

/* Optional large-plan accelerator; same exact output as v0_batch_plan64. */
uint32_t v0_batch_plan64x4(v0_batch_span *out, uint32_t items);

#ifdef __cplusplus
}
#endif
#endif

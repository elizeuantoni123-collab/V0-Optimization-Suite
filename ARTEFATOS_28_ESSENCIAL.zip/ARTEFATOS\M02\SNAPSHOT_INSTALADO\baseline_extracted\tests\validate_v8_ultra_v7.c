#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_extreme.h"

#define CHUNK 4096u
#define RANDOM_TOTAL 20000000u
static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint8_t ref_eval(uint16_t v,uint16_t c,uint16_t b){
    int32_t s=(int32_t)(uint32_t)v-(int32_t)((uint32_t)c>>1)+(int32_t)(uint32_t)b;
    return (uint8_t)(((uint32_t)(s>=0)<<2)+(uint32_t)(s>=64)+(uint32_t)(s>=192)+(uint32_t)(s>=384));
}
static int test_directed(void){
    static const uint16_t edge[]={0,1,2,62,63,64,65,126,127,128,191,192,193,383,384,385,32767,32768,65534,65535};
    for(unsigned ti=0;ti<3;ti++)for(unsigned pi=0;pi<2;pi++){
        uint16_t b=v0_decision_v7_bias((uint8_t)ti,(uint8_t)pi);
        for(size_t i=0;i<sizeof(edge)/sizeof(edge[0]);i++)for(size_t j=0;j<sizeof(edge)/sizeof(edge[0]);j++){
            uint16_t v=edge[i],c=edge[j]; uint8_t r=ref_eval(v,c,b);
            if(v0_eval_v8_bias_ultra_inline(v,c,b)!=r) return 10;
            if(v0_preflight_v8_bias_ultra_inline(v,c,b)!=(r>>2)) return 11;
            if(v0_decide_v8_bias_ultra_inline(v,c,b)!=(r&3)) return 12;
        }
    }
    return 0;
}
static int test_residual_identity(void){
    for(int vr=0;vr<64;vr++)for(int cr=0;cr<64;cr++)for(int br=0;br<64;br++){
        int d=vr+br-cr;
        int floor64=(d<0)?-1:(d>=64?1:0);
        if((d>>6)!=floor64) return 20;
    }
    return 0;
}
int main(void){
    int rc=test_directed(); if(rc){printf("directed FAIL %d\n",rc);return rc;}
    rc=test_residual_identity(); if(rc){printf("residual FAIL %d\n",rc);return rc;}
    uint16_t *v=aligned_alloc(64,CHUNK*2),*c=aligned_alloc(64,CHUNK*2),*b=aligned_alloc(64,CHUNK*2);
    uint8_t *out=aligned_alloc(64,CHUNK),*ref=aligned_alloc(64,CHUNK);
    if(!v||!c||!b||!out||!ref)return 30;
    uint64_t st=0x9e3779b97f4a7c15ULL,total=0,pre_ref=0;
    while(total<RANDOM_TOTAL){
        size_t n=(RANDOM_TOTAL-total<CHUNK)?(size_t)(RANDOM_TOTAL-total):CHUNK;
        pre_ref=0;
        for(size_t i=0;i<n;i++){
            uint8_t t=(uint8_t)(rng64(&st)%3u),p=(uint8_t)(rng64(&st)&1u);
            v[i]=(uint16_t)rng64(&st); c[i]=(uint16_t)rng64(&st); b[i]=v0_decision_v7_bias(t,p);
            ref[i]=ref_eval(v[i],c[i],b[i]); pre_ref += ref[i]>>2;
            if(v0_eval_v8_bias_ultra_inline(v[i],c[i],b[i])!=ref[i]){printf("scalar mismatch at %llu\n",(unsigned long long)(total+i));return 31;}
        }
#if defined(__AVX2__) || defined(_M_AVX2)
        memset(out,0,n); v0_eval_v8_bias_batch_ultra_v7_avx2_u8(v,c,b,out,n);
        if(memcmp(out,ref,n)){for(size_t i=0;i<n;i++)if(out[i]!=ref[i]){printf("avx2 mismatch at %llu\n",(unsigned long long)(total+i));break;}return 32;}
        if(v0_preflight_v8_bias_count_ultra_v7_avx2(v,c,b,n)!=pre_ref){printf("pre avx2 count mismatch\n");return 33;}
#if defined(__AVX512BW__) && defined(__AVX512VL__)
        memset(out,0,n); v0_eval_v8_bias_batch_ultra_v7_avx512_u8(v,c,b,out,n);
        if(memcmp(out,ref,n)){printf("avx512 mismatch\n");return 34;}
        if(v0_preflight_v8_bias_count_ultra_v7_avx512(v,c,b,n)!=pre_ref){printf("pre avx512 count mismatch\n");return 35;}
#if defined(__AVX512VBMI__)
        memset(out,0,n); v0_eval_v8_bias_batch_ultra_v7_avx512vbmi_u8(v,c,b,out,n);
        if(memcmp(out,ref,n)){printf("avx512vbmi mismatch\n");return 36;}
#endif
#endif
#endif
        total+=n;
    }
    /* Tail coverage for every small n and stream path. */
    for(size_t n=0;n<=257;n++){
        uint64_t pr=0;
        for(size_t i=0;i<n;i++){uint8_t t=(uint8_t)(rng64(&st)%3u),p=(uint8_t)(rng64(&st)&1u);v[i]=(uint16_t)rng64(&st);c[i]=(uint16_t)rng64(&st);b[i]=v0_decision_v7_bias(t,p);ref[i]=ref_eval(v[i],c[i],b[i]);pr+=ref[i]>>2;}
#if defined(__AVX2__) || defined(_M_AVX2)
        memset(out,0,n);v0_eval_v8_bias_batch_ultra_v7_avx2_u8(v,c,b,out,n);if(memcmp(out,ref,n))return 40;
        if(v0_preflight_v8_bias_count_ultra_v7_avx2(v,c,b,n)!=pr)return 41;
        memset(out,0,n);v0_eval_v8_bias_batch_ultra_v7_stream_avx2_u8(v,c,b,out,n);if(memcmp(out,ref,n))return 42;
#if defined(__AVX512BW__) && defined(__AVX512VL__)
        memset(out,0,n);v0_eval_v8_bias_batch_ultra_v7_avx512_u8(v,c,b,out,n);if(memcmp(out,ref,n))return 43;
        if(v0_preflight_v8_bias_count_ultra_v7_avx512(v,c,b,n)!=pr)return 44;
        memset(out,0,n);v0_eval_v8_bias_batch_ultra_v7_stream_avx512_u8(v,c,b,out,n);if(memcmp(out,ref,n))return 45;
#if defined(__AVX512VBMI__)
        memset(out,0,n);v0_eval_v8_bias_batch_ultra_v7_avx512vbmi_u8(v,c,b,out,n);if(memcmp(out,ref,n))return 46;
#endif
#endif
#endif
    }
    printf("V7 VALIDATION PASS\n");
    printf("directed edge matrix: PASS\nresidual identity 64^3: PASS\nrandom signals: %u, divergences: 0\ntails 0..257: PASS\n",RANDOM_TOTAL);
#if defined(__AVX512BW__) && defined(__AVX512VL__)
    printf("AVX2 + AVX-512BW/VL paths: PASS\n");
#elif defined(__AVX2__) || defined(_M_AVX2)
    printf("AVX2 path: PASS\n");
#endif
    return 0;
}

#define _GNU_SOURCE
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <inttypes.h>
#include <sched.h>
#include "keys.inc"
#include "tables32.inc"
extern int v0_lookup_trusted(const unsigned char*);
static volatile uint64_t sink; static inline uint64_t ns(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
__attribute__((always_inline,target("avx2"))) static inline void chunk8(const uint8_t*const*p,uint32_t*out){__m256i x=_mm256_setr_epi32(*(const uint32_t*)p[0],*(const uint32_t*)p[1],*(const uint32_t*)p[2],*(const uint32_t*)p[3],*(const uint32_t*)p[4],*(const uint32_t*)p[5],*(const uint32_t*)p[6],*(const uint32_t*)p[7]);__m256i h1=_mm256_mullo_epi32(x,_mm256_set1_epi32((int)3184451869u)),h2=_mm256_mullo_epi32(x,_mm256_set1_epi32((int)1144681085u));h1=_mm256_srli_epi32(h1,24);h2=_mm256_srli_epi32(h2,21);__m256i d=_mm256_i32gather_epi32((const int*)disp32,h1,4);h2=_mm256_and_si256(_mm256_add_epi32(h2,d),_mm256_set1_epi32(2047));__m256i id=_mm256_i32gather_epi32((const int*)slot32,h2,4);_mm256_storeu_si256((__m256i*)out,id);}
__attribute__((noinline,target("avx2"))) static void batch16(const uint8_t*const*p,uint32_t*out){chunk8(p,out);chunk8(p+8,out+8);}
__attribute__((noinline,target("avx2"))) static void batch32(const uint8_t*const*p,uint32_t*out){chunk8(p,out);chunk8(p+8,out+8);chunk8(p+16,out+16);chunk8(p+24,out+24);}
static uint32_t rs=1; static inline uint32_t rng(void){uint32_t x=rs;x^=x<<13;x^=x>>17;x^=x<<5;return rs=x;}
static void fill(uint16_t*a,int n,int p){for(int i=0;i<n;i++){if(p==0)a[i]=i&1023;else if(p==1)a[i]=rng()&1023;else if(p==2)a[i]=rng()&15;else if(p==3)a[i]=rng()&63;else if(p==4)a[i]=rng()&255;else a[i]=(i*4051u+17u)&1023;}}
static void pin(void){cpu_set_t s;if(!sched_getaffinity(0,sizeof(s),&s))for(int c=0;c<CPU_SETSIZE;c++)if(CPU_ISSET(c,&s)){cpu_set_t o;CPU_ZERO(&o);CPU_SET(c,&o);sched_setaffinity(0,sizeof(o),&o);break;}}
int main(){pin();const int N=1<<22;uint16_t*ix=aligned_alloc(64,N*2);const uint8_t**pp=aligned_alloc(64,(size_t)N*8);uint32_t*out=aligned_alloc(64,(size_t)N*4);puts("batch,profile,round,base_ns,cand_ns,speedup");for(int batchi=0;batchi<2;batchi++){int B=batchi?32:16;for(int p=0;p<6;p++){rs=1234+p;fill(ix,N,p);for(int i=0;i<N;i++)pp[i]=keys[ix[i]];for(int r=0;r<8;r++){uint64_t b0=ns();for(int i=0;i<N;i++)sink+=(uint32_t)v0_lookup_trusted(pp[i]);uint64_t b1=ns();uint64_t c0=ns();for(int i=0;i<N;i+=B){if(B==16)batch16(pp+i,out+i);else batch32(pp+i,out+i);sink+=out[i];}uint64_t c1=ns();uint64_t c2=ns();for(int i=0;i<N;i+=B){if(B==16)batch16(pp+i,out+i);else batch32(pp+i,out+i);sink+=out[i];}uint64_t c3=ns();uint64_t b2=ns();for(int i=0;i<N;i++)sink+=(uint32_t)v0_lookup_trusted(pp[i]);uint64_t b3=ns();if(r==0)for(int i=0;i<N;i++)if(out[i]!=(uint32_t)v0_lookup_trusted(pp[i]))return 3;double bn=((b1-b0)+(b3-b2))/(2.0*N),cn=((c1-c0)+(c3-c2))/(2.0*N);printf("%d,%d,%d,%.6f,%.6f,%.6f\n",B,p,r,bn,cn,bn/cn);}}}fprintf(stderr,"sink=%" PRIu64 "\n",sink);}

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/v0_decision_v8_ultra_v10.h"
#define N (1u<<20)
#define REPS 15
static uint16_t*v,*c,*g;static uint8_t*t,*p,*o;static LARGE_INTEGER fq;static volatile uint64_t sink;
static uint64_t rg(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static double ns(void){LARGE_INTEGER q;QueryPerformanceCounter(&q);return(double)q.QuadPart*1e9/(double)fq.QuadPart;}
static int cmp(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static double v9raw(void){double a=ns();v0_eval_v8_raw_batch_ultra_v9_avx2_u8(v,c,t,p,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v10raw(void){double a=ns();v0_eval_v10_raw_batch_avx2_u8(v,c,t,p,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v9pre(void){double a=ns();uint64_t q=v0_preflight_v8_raw_count_ultra_v9_avx2(v,c,t,p,N);double z=ns();sink+=q;return(z-a)/N;}
static double gbuild(void){double a=ns();v0_build_gate16_batch_v10_avx2(c,t,p,g,N);double z=ns();sink+=g[777];return(z-a)/N;}
static double geval(void){double a=ns();v0_eval_gate16_batch_v10_avx2_u8(v,g,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double gpre(void){double a=ns();uint64_t q=v0_preflight_gate16_count_v10_avx2(v,g,N);double z=ns();sink+=q;return(z-a)/N;}
static void be(const char*n,double(*f)(void)){double x[REPS];int i;for(i=0;i<5;i++)f();for(i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmp);printf("%-31s p50=%9.4f ns/item best=%9.4f\n",n,x[REPS/2],x[0]);}
int main(void){size_t i;uint64_t r=0x9e3779b97f4a7c15ULL;QueryPerformanceFrequency(&fq);SetThreadAffinityMask(GetCurrentThread(),1);v=(uint16_t*)_aligned_malloc(N*2,64);c=(uint16_t*)_aligned_malloc(N*2,64);g=(uint16_t*)_aligned_malloc(N*2,64);t=(uint8_t*)_aligned_malloc(N,64);p=(uint8_t*)_aligned_malloc(N,64);o=(uint8_t*)_aligned_malloc(N,64);if(!v||!c||!g||!t||!p||!o)return 2;for(i=0;i<N;i++){v[i]=(uint16_t)rg(&r);c[i]=(uint16_t)rg(&r);t[i]=(uint8_t)(rg(&r)%3u);p[i]=(uint8_t)(rg(&r)&1u);g[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);}puts("V0 Decision V8 ULTRA V10 - Windows AVX2 paired benchmark");printf("N=%u, p50 of %d timed runs; batch throughput, not single-call latency\n",N,REPS);be("V9 raw AVX2",v9raw);be("V10 raw AVX2",v10raw);be("V9 one-shot preflight AVX2",v9pre);be("V10 gate16 build AVX2",gbuild);be("V10 gate16 eval AVX2",geval);be("V10 gate16 preflight AVX2",gpre);printf("sink=%llu\n",(unsigned long long)sink);return 0;}

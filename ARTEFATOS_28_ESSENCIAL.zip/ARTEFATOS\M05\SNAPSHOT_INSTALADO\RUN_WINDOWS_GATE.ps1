$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Base = Join-Path $Root "baseline\V0_BATCH_V27_VALIDATED"
Write-Host "V0 Batch Planner V27 - Windows rebuild gate" -ForegroundColor Cyan
& (Join-Path $Base "BUILD_WINDOWS.ps1")
if ($LASTEXITCODE -ne 0) { throw "Base Windows build failed" }
& (Join-Path $Base "BUILD_ACCEL_WINDOWS.ps1")
if ($LASTEXITCODE -ne 0) { throw "Accel Windows build failed" }
& (Join-Path $Base "BUILD_V19_WINDOWS.ps1")
if ($LASTEXITCODE -ne 0) { throw "V19 Windows build failed" }
& (Join-Path $Base "BUILD_V27_WINDOWS.ps1")
if ($LASTEXITCODE -ne 0) { throw "V27 Windows build failed" }
Write-Host "Build gate complete. V27 remains baseline; no new candidate is promoted by this artifact." -ForegroundColor Green

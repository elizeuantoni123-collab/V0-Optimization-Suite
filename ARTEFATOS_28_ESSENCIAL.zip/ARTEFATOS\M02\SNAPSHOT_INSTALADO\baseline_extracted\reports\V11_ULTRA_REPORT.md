# V0 Decision V8 ULTRA V11 — technical report

## Status

**PROMOTED as an additive exact optimization over V10.**

V11 does not modify any inherited V10 file and does not replace V10 raw SIMD, V9 one-shot preflight, or the standard V10 u8 gate16 batch API.

## Correctness

Final V11 validation:

| Build | Cases | Divergences |
|---|---:|---:|
| AVX2-only | 21,135,744 | **0** |
| Native / AVX-512 host | 21,135,744 | **0** |

Coverage includes:

- every possible unsaturated `value + gate16` sum from 0 through 131,070;
- 20 million legal random raw signals converted to gate16;
- scalar LUT evaluation against V10 gate16 reference;
- exact nibble encode/decode checks;
- streaming nibble encode/decode checks;
- every tail length 0..257.

The inherited V10 validation was also rerun under the V11 tree:

- AVX2-only: **23,758,620 cases, 0 divergences**;
- native: **23,758,620 cases, 0 divergences**.

## Scalar gate16 LUT

V10 scalar gate16 uses threshold branches. V11 maps the saturated 16-bit sum through a direct 1024-byte table indexed by `sum >> 6`. The table is exact because all Decision boundaries are aligned to 64-unit bins.

Five independent processes, median of each process p50, then median across processes:

- V10 scalar gate16: **4.935135 ns/item**
- V11 scalar LUT: **0.628584 ns/item**
- throughput speedup: **7.851x**
- per-item time reduction: **87.26%**

This path is intended for scalar cached-gate evaluation with unpredictable inputs. It is additive; no SIMD path is replaced.

## Large write-only gate16 output

V11 adds an optional exact nibble representation: two states per byte. Low nibble is the even item, high nibble is the odd item. State values remain exactly `0/4/5/6/7` and decode losslessly.

For a 16M-item write-only batch with non-temporal stores, five-process median p50:

- V10 u8 streaming output: **0.127101 ns/item**
- V11 nibble streaming output: **0.119838 ns/item**
- speedup: **1.061x**
- per-item time reduction: **5.71%**
- output traffic: **1 byte/item -> 0.5 byte/item**

The nibble path is opt-in because it changes the output representation and is not faster for every hot-cache/read-immediately workload.

## Rejected work

V11 also tested gate evaluator unrolling, wide 512-bit gate evaluation, AVX-512VL gate construction, AVX-512VL one-shot preflight, shared-load raw AVX2, raw scalar direct LUT, branchless saturation variants, automatic short-batch replacement, and universal nibble replacement. These did not meet the no-regression rule and were rejected. See `V11_REJECTED_CANDIDATES.txt`.

## Integrity

`V11_INHERITED_V10_INTEGRITY.txt` compares every inherited V10 file by SHA-256:

- files compared: **234**
- missing: **0**
- mismatches: **0**

## Interpretation

Sub-nanosecond SIMD numbers are amortized throughput per item, not dependent single-call latency. Absolute results vary with CPU, compiler, cache state, frequency and host noise. Promotion decisions use paired comparisons and repeated processes.

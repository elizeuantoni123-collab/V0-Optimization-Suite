Artefato 2 antigo = V0 Decision V8. Baseline V12 preservada; V13 e candidato aditivo somente para gate16 builder. Veja REPORT.md.

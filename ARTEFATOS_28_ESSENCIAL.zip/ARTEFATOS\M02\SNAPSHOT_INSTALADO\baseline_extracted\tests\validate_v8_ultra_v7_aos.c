#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_extreme.h"
#define MAXN 1024
static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int check(const v0_decision_signal_v7_t*s,const uint8_t*o,size_t n){for(size_t i=0;i<n;i++)if(o[i]!=(uint8_t)v0_eval_v8_signal_ultra_inline(s+i)){fprintf(stderr,"diverge %zu got=%u ref=%u\n",i,o[i],(unsigned)v0_eval_v8_signal_ultra_inline(s+i));return 0;}return 1;}
int main(void){
 v0_decision_signal_v7_t *s; uint8_t *o; if(posix_memalign((void**)&s,64,MAXN*sizeof(*s))||posix_memalign((void**)&o,64,MAXN)) return 2;
 uint64_t r=0xD1B54A32D192ED03ULL;
 for(size_t n=0;n<=257;n++){
  for(size_t i=0;i<n;i++)s[i]=v0_decision_v7_pack((uint16_t)rng64(&r),(uint16_t)rng64(&r),(uint8_t)(rng64(&r)%3u),(uint8_t)(rng64(&r)&1u));
#if defined(__AVX2__) || defined(_M_AVX2)
  memset(o,0xcc,MAXN); v0_eval_v8_signal_batch_ultra_v7_avx2_u8(s,o,n); if(!check(s,o,n)) return 3;
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
  memset(o,0xcc,MAXN); v0_eval_v8_signal_batch_ultra_v7_avx512_u8(s,o,n); if(!check(s,o,n)) return 4;
#endif
 }
 const size_t CH=MAXN; uint64_t total=0;
 for(unsigned pass=0;pass<19532;pass++) { /* >20M signals */
  for(size_t i=0;i<CH;i++)s[i]=v0_decision_v7_pack((uint16_t)rng64(&r),(uint16_t)rng64(&r),(uint8_t)(rng64(&r)%3u),(uint8_t)(rng64(&r)&1u));
#if defined(__AVX2__) || defined(_M_AVX2)
  v0_eval_v8_signal_batch_ultra_v7_avx2_u8(s,o,CH); if(!check(s,o,CH)) return 5;
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
  v0_eval_v8_signal_batch_ultra_v7_avx512_u8(s,o,CH); if(!check(s,o,CH)) return 6;
#endif
  total+=CH;
 }
 printf("V7 PACKED-AOS VALIDATION PASS\nrandom signals: %llu, divergences: 0\ntails 0..257: PASS\n",(unsigned long long)total);
#if defined(__AVX512BW__) && defined(__AVX512VL__)
 puts("AVX2 + AVX-512 packed paths: PASS");
#else
 puts("AVX2 packed path: PASS");
#endif
 free(s);free(o);return 0;
}

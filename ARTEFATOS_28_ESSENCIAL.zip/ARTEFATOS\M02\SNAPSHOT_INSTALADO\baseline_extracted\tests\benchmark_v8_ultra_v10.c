#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_ultra_v10.h"

#define N (1u<<20)
#define REPS 17
static uint16_t *v,*c,*gate; static uint8_t *t,*p,*out; static volatile uint64_t sink;
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}
static void pin0(void){cpu_set_t x;CPU_ZERO(&x);CPU_SET(0,&x);sched_setaffinity(0,sizeof(x),&x);}

#define BATCH_FN(name, call, consume) static double name(void){uint64_t a=now_ns();call;uint64_t z=now_ns();consume;return(double)(z-a)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
BATCH_FN(v9raw2, v0_eval_v8_raw_batch_ultra_v9_avx2_u8(v,c,t,p,out,N), sink+=out[777])
BATCH_FN(v10raw2, v0_eval_v10_raw_batch_avx2_u8(v,c,t,p,out,N), sink+=out[777])
BATCH_FN(v9pre2, sink=v0_preflight_v8_raw_count_ultra_v9_avx2(v,c,t,p,N), (void)0)
BATCH_FN(gbuild2, v0_build_gate16_batch_v10_avx2(c,t,p,gate,N), sink+=gate[777])
BATCH_FN(geval2, v0_eval_gate16_batch_v10_avx2_u8(v,gate,out,N), sink+=out[777])
BATCH_FN(gpre2, sink=v0_preflight_gate16_count_v10_avx2(v,gate,N), (void)0)
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
BATCH_FN(v8raw5, v0_eval_v8_raw_batch_ultra_v8_avx512_u8(v,c,t,p,out,N), sink+=out[777])
BATCH_FN(v10raw5, v0_eval_v10_raw_batch_avx512vl_u8(v,c,t,p,out,N), sink+=out[777])
BATCH_FN(gbuild5, v0_build_gate16_batch_v10_avx512(c,t,p,gate,N), sink+=gate[777])
BATCH_FN(gpre5, sink=v0_preflight_gate16_count_v10_avx512(v,gate,N), (void)0)
#endif
#undef BATCH_FN

static double gate_amortized(unsigned uses){
#if defined(__AVX2__) || defined(_M_AVX2)
    uint64_t a=now_ns();
    v0_build_gate16_batch_v10_avx2(c,t,p,gate,N);
    for(unsigned k=0;k<uses;k++)v0_eval_gate16_batch_v10_avx2_u8(v,gate,out,N);
    uint64_t z=now_ns();sink+=out[123];return(double)(z-a)/(N*uses);
#else
    (void)uses; return 0.0;
#endif
}
static double raw_repeated(unsigned uses){
#if defined(__AVX2__) || defined(_M_AVX2)
    uint64_t a=now_ns();
    for(unsigned k=0;k<uses;k++)v0_eval_v10_raw_batch_avx2_u8(v,c,t,p,out,N);
    uint64_t z=now_ns();sink+=out[123];return(double)(z-a)/(N*uses);
#else
    (void)uses; return 0.0;
#endif
}

#if defined(__AVX512BW__) && defined(__AVX512VL__)
static double gate_amortized_native(unsigned uses){
    uint64_t a=now_ns();
    v0_build_gate16_batch_v10_avx512(c,t,p,gate,N);
    for(unsigned k=0;k<uses;k++)v0_eval_gate16_batch_v10_avx2_u8(v,gate,out,N);
    uint64_t z=now_ns();sink+=out[123];return(double)(z-a)/(N*uses);
}
static double raw_repeated_native(unsigned uses){
    uint64_t a=now_ns();
    for(unsigned k=0;k<uses;k++)v0_eval_v10_raw_batch_avx512vl_u8(v,c,t,p,out,N);
    uint64_t z=now_ns();sink+=out[123];return(double)(z-a)/(N*uses);
}
static void bench_reuse_native(unsigned uses){
    double a[REPS],b[REPS];
    for(int j=0;j<5;j++){raw_repeated_native(uses);gate_amortized_native(uses);}
    for(int i=0;i<REPS;i++){a[i]=raw_repeated_native(uses);b[i]=gate_amortized_native(uses);}
    qsort(a,REPS,sizeof(double),cmpd);qsort(b,REPS,sizeof(double),cmpd);
    printf("native reuse=%u rawV10=%9.5f gateV10_amort=%9.5f speedup=%6.3fx\n",
           uses,a[REPS/2],b[REPS/2],a[REPS/2]/b[REPS/2]);
}
#endif

static void bench(const char*n,double(*f)(void)){
    double x[REPS]; for(int i=0;i<7;i++)f(); for(int i=0;i<REPS;i++)x[i]=f();
    qsort(x,REPS,sizeof(double),cmpd);
    printf("%-31s p50=%9.5f best=%9.5f ns/item\n",n,x[REPS/2],x[0]);
}
static void bench_reuse(unsigned uses){
    double a[REPS],b[REPS];
    for(int j=0;j<5;j++){raw_repeated(uses);gate_amortized(uses);}
    for(int i=0;i<REPS;i++){a[i]=raw_repeated(uses);b[i]=gate_amortized(uses);}
    qsort(a,REPS,sizeof(double),cmpd);qsort(b,REPS,sizeof(double),cmpd);
    printf("reuse=%u rawV10=%9.5f gateV10_amort=%9.5f speedup=%6.3fx\n",
           uses,a[REPS/2],b[REPS/2],a[REPS/2]/b[REPS/2]);
}

int main(void){
    pin0();
    if(posix_memalign((void**)&v,64,N*2)||posix_memalign((void**)&c,64,N*2)||
       posix_memalign((void**)&gate,64,N*2)||posix_memalign((void**)&t,64,N)||
       posix_memalign((void**)&p,64,N)||posix_memalign((void**)&out,64,N))return 2;
    uint64_t s=0x243f6a8885a308d3ULL;
    for(size_t i=0;i<N;i++){v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);gate[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);}
#if defined(__AVX2__) || defined(_M_AVX2)
    bench("V9 raw AVX2",v9raw2);
    bench("V10 raw AVX2",v10raw2);
    bench("V9 one-shot preflight AVX2",v9pre2);
    bench("V10 gate16 build AVX2",gbuild2);
    bench("V10 gate16 eval AVX2",geval2);
    bench("V10 gate16 preflight AVX2",gpre2);
    bench_reuse(1);bench_reuse(2);bench_reuse(3);bench_reuse(4);bench_reuse(8);
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
    bench("V8 raw AVX512 old",v8raw5);
    bench("V10 raw AVX512VL",v10raw5);
    bench("V10 gate16 build AVX512",gbuild5);
    bench("V10 gate16 preflight AVX512",gpre5);
    bench_reuse_native(1);bench_reuse_native(2);bench_reuse_native(3);bench_reuse_native(4);bench_reuse_native(8);
#endif
    printf("sink=%llu\n",(unsigned long long)sink);
    return 0;
}

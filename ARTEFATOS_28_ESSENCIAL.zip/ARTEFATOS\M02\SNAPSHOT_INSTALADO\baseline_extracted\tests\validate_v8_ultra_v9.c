#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_ultra_v9.h"

#define CHUNK (1u<<20)
#define ROUNDS 20
#define PAD 320

static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint64_t checked=0,bad=0;
static void fail(const char*tag,size_t i,uint32_t got,uint32_t ref){if(bad<12)fprintf(stderr,"FAIL %s i=%zu got=%u ref=%u\n",tag,i,got,ref);bad++;}

static int check(const uint16_t*v,const uint16_t*c,const uint8_t*t,const uint8_t*p,uint8_t*out,uint8_t*ref,size_t n){
    size_t i; uint64_t want_pre=0;
    for(i=0;i<n;i++){ref[i]=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);want_pre+=(uint64_t)(ref[i]>>2);}
#if defined(__AVX2__) || defined(_M_AVX2)
    memset(out,0xA5,n+64);
    v0_eval_v8_raw_batch_ultra_v9_avx2_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i])fail("v9-raw-avx2",i,out[i],ref[i]);
    memset(out,0xA5,n+64);
    v0_eval_v8_raw_batch_ultra_v8_avx2_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i])fail("v8-regression-avx2",i,out[i],ref[i]);
    {
        uint64_t got=v0_preflight_v8_raw_count_ultra_v9_avx2(v,c,t,p,n);
        if(got!=want_pre)fail("v9-pre-count",0,(uint32_t)got,(uint32_t)want_pre);
    }
    for(i=0;i+16<=n;i+=16){
        uint16_t got=v0_preflight_v8_raw_mask16_ultra_v9_avx2(v+i,c+i,t+i,p+i),want=0;unsigned k;
        for(k=0;k<16;k++)want|=(uint16_t)((ref[i+k]>>2)<<k);
        if(got!=want)fail("v9-pre-mask16",i,got,want);
    }
#endif
    checked+=n;
    return bad?1:0;
}

int main(void){
    uint16_t *v,*c;uint8_t*t,*p,*out,*ref;uint64_t s=0x9e3779b97f4a7c15ULL;size_t i,n;
    if(posix_memalign((void**)&v,64,(CHUNK+PAD)*2)||posix_memalign((void**)&c,64,(CHUNK+PAD)*2)||posix_memalign((void**)&t,64,CHUNK+PAD)||posix_memalign((void**)&p,64,CHUNK+PAD)||posix_memalign((void**)&out,64,CHUNK+PAD+64)||posix_memalign((void**)&ref,64,CHUNK+PAD+64))return 2;
    for(unsigned r=0;r<ROUNDS && !bad;r++){
        for(i=0;i<CHUNK;i++){v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);}
        check(v,c,t,p,out,ref,CHUNK);
    }
    /* Directed thresholds with every legal temperature/pinned state and varied cost. */
    {static const int th[]={0,64,192,384};static const uint16_t costs[]={0,1,2,63,64,65,127,128,255,256,1023,32767,32768,65534,65535};n=0;
      for(unsigned ti=0;ti<3;ti++)for(unsigned pi=0;pi<2;pi++)for(size_t ci=0;ci<sizeof(costs)/sizeof(costs[0]);ci++){
        int h=(int)(costs[ci]>>1);int bias=(int)v0_decision_v7_bias((uint8_t)ti,(uint8_t)pi);
        for(size_t k=0;k<sizeof(th)/sizeof(th[0]);k++)for(int d=-3;d<=3;d++){int x=th[k]+d+h-bias;if(x>=0&&x<=65535&&n<CHUNK){v[n]=(uint16_t)x;c[n]=costs[ci];t[n]=(uint8_t)ti;p[n]=(uint8_t)pi;n++;}}
      }
      check(v,c,t,p,out,ref,n);
    }
    /* Every tail length, including less than one vector. */
    for(n=0;n<=257 && !bad;n++){
        for(i=0;i<n;i++){v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);}
        check(v,c,t,p,out,ref,n);
    }
    printf("checked=%llu divergences=%llu\n",(unsigned long long)checked,(unsigned long long)bad);
    printf("status=%s\n",bad?"FAIL":"PASS");
    return bad?3:0;
}

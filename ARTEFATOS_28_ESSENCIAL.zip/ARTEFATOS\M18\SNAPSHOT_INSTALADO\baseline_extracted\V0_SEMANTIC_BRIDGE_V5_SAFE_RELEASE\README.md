# V0 Semantic Bridge V5 SAFE

Baseline promovida aditiva do Semantic Bridge em V0L.

## Regra permanente

Uma versão posterior só pode substituir/estender esta baseline se, no domínio declarado:

1. não quebrar compatibilidade nem funcionamento;
2. não perder correção/qualidade semântica;
3. não perder velocidade contra o melhor caminho já promovido.

Qualquer candidato regressivo é descartado.

## Fronteira arquitetural

O Semantic Bridge **não executa o modelo semântico**. A inferência de linguagem/paráfrase permanece fora do hot path determinístico. O bridge recebe uma saída já normalizada e a expõe ao restante do V0 como `semantic_id`, `semantic_score`, `exact_key` e `valid`.

O V0 Global permanece separado e intocado.

## ABI normalizada

Registro fixo de 16 bytes:

- +0 `u32 semantic_id`
- +4 `u32 semantic_score` — opaco, pass-through bit-exato
- +8 `u32 exact_key`
- +12 `u32 valid` — deve ser exatamente 0 ou 1

## Caminhos promovidos

- V1 SAFE: getters individuais + `id_safe`/`key_safe` universal.
- V2 SAFE: `id+score` e `key+valid` em `u64`.
- V3 SAFE: `score+key` em `u64`.
- V4 SAFE: registro inteiro de 16 bytes retornado em XMM0 (`MOVDQU`).
- V5 SAFE: máscaras de validade para lotes contíguos de 4 e 8 registros.

Todos os caminhos anteriores permanecem disponíveis como fallback.

## Resultados novos desta rodada

- V3: 20.000.000 checks, 0 divergências; speedup mediano 1,993876x, 15/15 vitórias.
- V4: 16.000.000 checks cobrindo 16 desalinhamentos, 0 divergências; speedup mediano 1,883672x contra duas chamadas V2, 15/15 vitórias.
- V5: 10.000.000 comparações, 0 divergências, observando 40.000.000 registros; `valid4` 4,022652x e `valid8` 5,104795x de speedup mediano, ambos 15/15.

## Rejeições desta rodada

- SAFE com `cmp [mem],0`: menor, porém não ganhou universalmente e regrediu no caminho válido.
- V6 `valid16` direto: correto, porém 7/15 vitórias; mediana 0,999598x contra `2 x valid8`.
- V6 `valid16` rebaseado: correto, porém 4/15 vitórias; mediana 0,974038x contra `2 x valid8`.

Logo, para 16 registros, a composição promovida continua sendo duas chamadas `v0_semantic_valid8_mask`.

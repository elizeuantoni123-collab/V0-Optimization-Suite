#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_ultra_v9.h"
#define N (1u<<20)
#define REPS 15
static uint16_t *v,*c;static uint8_t*t,*p,*out;static volatile uint64_t sink;
static uint64_t rg(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint64_t ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}
static void pin0(void){cpu_set_t x;CPU_ZERO(&x);CPU_SET(0,&x);sched_setaffinity(0,sizeof(x),&x);}
#define BF(name,call,consume) static double name(void){uint64_t a=ns();call;uint64_t z=ns();consume;return(double)(z-a)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
BF(v8raw2,v0_eval_v8_raw_batch_ultra_v8_avx2_u8(v,c,t,p,out,N),sink+=out[777])
BF(v9raw2,v0_eval_v8_raw_batch_ultra_v9_avx2_u8(v,c,t,p,out,N),sink+=out[777])
BF(v8pre2,sink=v0_preflight_v8_raw_count_ultra_v8_avx2(v,c,t,p,N),(void)0)
BF(v9pre2,sink=v0_preflight_v8_raw_count_ultra_v9_avx2(v,c,t,p,N),(void)0)
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
BF(v8raw5,v0_eval_v8_raw_batch_ultra_v8_avx512_u8(v,c,t,p,out,N),sink+=out[777])
BF(v8pre5,sink=v0_preflight_v8_raw_count_ultra_v8_avx512(v,c,t,p,N),(void)0)
#endif
#undef BF
static void bench(const char*n,double(*f)(void)){double x[REPS];for(int i=0;i<7;i++)f();for(int i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmpd);printf("%-30s p50=%9.5f best=%9.5f ns/item\n",n,x[REPS/2],x[0]);}
int main(void){pin0();if(posix_memalign((void**)&v,64,N*2)||posix_memalign((void**)&c,64,N*2)||posix_memalign((void**)&t,64,N)||posix_memalign((void**)&p,64,N)||posix_memalign((void**)&out,64,N))return 2;uint64_t s=0x243f6a8885a308d3ULL;for(size_t i=0;i<N;i++){v[i]=(uint16_t)rg(&s);c[i]=(uint16_t)rg(&s);t[i]=(uint8_t)(rg(&s)%3u);p[i]=(uint8_t)(rg(&s)&1u);}
#if defined(__AVX2__) || defined(_M_AVX2)
bench("V8 raw AVX2",v8raw2);bench("V9 raw AVX2",v9raw2);bench("V8 raw preflight AVX2",v8pre2);bench("V9 raw preflight AVX2",v9pre2);
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
bench("V8 raw AVX512 (unchanged)",v8raw5);bench("V8 pre AVX512 (unchanged)",v8pre5);
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

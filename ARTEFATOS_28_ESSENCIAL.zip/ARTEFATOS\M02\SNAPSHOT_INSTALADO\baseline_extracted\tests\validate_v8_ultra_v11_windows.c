#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_ultra_v11.h"
#define CHUNK 4096u
#define TOTAL 10000000u
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int verify(const uint16_t*v,const uint16_t*c,const uint8_t*t,const uint8_t*p,uint16_t*g,uint8_t*out,uint8_t*nib,uint8_t*ref,size_t n){
    size_t i;
    for(i=0;i<n;i++){
        ref[i]=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);
        g[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);
        if((uint8_t)v0_eval_gate16_v11_scalar_lut_inline(v[i],g[i])!=ref[i]){printf("FAIL scalar i=%zu\n",i);return 0;}
    }
    v0_eval_gate16_batch_v10_avx2_u8(v,g,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i]){printf("FAIL V10 u8 i=%zu\n",i);return 0;}
    v0_eval_gate16_batch_v11_avx2_nibble(v,g,nib,n);
    for(i=0;i<n;i++){uint8_t x=(i&1u)?(uint8_t)(nib[i>>1]>>4):(uint8_t)(nib[i>>1]&15u);if(x!=ref[i]){printf("FAIL nibble i=%zu got=%u ref=%u\n",i,x,ref[i]);return 0;}}
    if(n>=256){v0_eval_gate16_batch_v11_stream_avx2_nibble(v,g,nib,n);for(i=0;i<n;i++){uint8_t x=(i&1u)?(uint8_t)(nib[i>>1]>>4):(uint8_t)(nib[i>>1]&15u);if(x!=ref[i]){printf("FAIL stream nibble i=%zu\n",i);return 0;}}}
    return 1;
}
int main(void){
    uint16_t*v=(uint16_t*)_aligned_malloc(CHUNK*2,64),*c=(uint16_t*)_aligned_malloc(CHUNK*2,64),*g=(uint16_t*)_aligned_malloc(CHUNK*2,64);
    uint8_t*t=(uint8_t*)_aligned_malloc(CHUNK,64),*p=(uint8_t*)_aligned_malloc(CHUNK,64),*out=(uint8_t*)_aligned_malloc(CHUNK+64,64),*nib=(uint8_t*)_aligned_malloc(CHUNK/2+128,64),*ref=(uint8_t*)_aligned_malloc(CHUNK+64,64);
    uint64_t r=0xA0761D6478BD642FULL;unsigned done=0;size_t i,n;
    if(!v||!c||!g||!t||!p||!out||!nib||!ref)return 2;
    for(uint32_t sum=0;sum<=131070u;sum++){uint16_t vv=(sum>65535u)?65535u:(uint16_t)sum;uint16_t gg=(uint16_t)(sum-(uint32_t)vv);uint32_t a=v0_eval_gate16_v10_inline(vv,gg),b=v0_eval_gate16_v11_scalar_lut_inline(vv,gg);if(a!=b){printf("FAIL exhaustive sum=%u\n",sum);return 3;}}
    while(done<TOTAL){n=(TOTAL-done)>CHUNK?CHUNK:(TOTAL-done);for(i=0;i<n;i++){t[i]=(uint8_t)(rng64(&r)%3u);p[i]=(uint8_t)(rng64(&r)&1u);v[i]=(uint16_t)rng64(&r);c[i]=(uint16_t)rng64(&r);}if(!verify(v,c,t,p,g,out,nib,ref,n))return 4;done+=(unsigned)n;}
    for(n=0;n<=257;n++){for(i=0;i<n;i++){t[i]=(uint8_t)(rng64(&r)%3u);p[i]=(uint8_t)(rng64(&r)&1u);v[i]=(uint16_t)rng64(&r);c[i]=(uint16_t)rng64(&r);}if(!verify(v,c,t,p,g,out,nib,ref,n))return 5;}
    printf("V0 Decision V8 ULTRA V11 Windows AVX2 validation PASS\n");
    printf("exhaustive sums 0..131070: PASS\nrandom signals: %u, divergences: 0\ntails 0..257: PASS\n",TOTAL);
    _aligned_free(v);_aligned_free(c);_aligned_free(g);_aligned_free(t);_aligned_free(p);_aligned_free(out);_aligned_free(nib);_aligned_free(ref);return 0;
}

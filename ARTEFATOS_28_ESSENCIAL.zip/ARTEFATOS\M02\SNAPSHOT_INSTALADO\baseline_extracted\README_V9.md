# V0 Decision V8 ULTRA V9

V9 is an **additive** optimization layer over ULTRA V8. It does not replace or modify the validated V8 implementation.

## Promoted change

The AVX2 raw path now maps the legal temperature states directly in byte form:

- COLD `0 -> 0`
- WARM `1 -> 64`
- HOT `2 -> 192`

The V8 raw path widened temperature to 16 bits and then computed the same mapping arithmetically. V9 uses one byte `PSHUFB` lookup and widens only the final bonus. `pinned` also remains byte-sized until the final packed-result stage.

This is an exact representation change, not a threshold or semantic change.

## What is unchanged

- thresholds: `0 / 64 / 192 / 384`
- V7/V8 scalar behavior
- V8 bias path
- V8 AVX-512 path
- packed AoS path
- adaptive controller, `probe_count`, `active_count`, and 5% hysteresis
- all inherited V8 source/object files

## Recommended dispatch

- AVX-512BW+VL available: keep the existing ULTRA V8 AVX-512 raw path.
- AVX2 without AVX-512BW+VL: use `v0_eval_v8_raw_batch_ultra_v9_avx2_u8` and `v0_preflight_v8_raw_count_ultra_v9_avx2`.
- Other CPUs: retain the existing validated fallbacks.

See `reports/V9_ULTRA_REPORT.md` and run `TESTAR_ULTRA_V9.ps1` / `BENCHMARK_ULTRA_V9_WINDOWS.ps1` on Windows.

# V0 Decision V8 EXTREME V5 — Optimization Report

Date: 2026-09-24

## Status

**PASS — additional speed paths promoted with exact Decision equivalence.**

V5 does not change the V8 thresholds, pinned behavior, temperature behavior, output encoding, or adaptive-controller policy. It changes representation and execution strategy only.

## Core observation: exact Q6 coordinate

All Decision boundaries are exact multiples of 64: `0`, `64`, `192`, `384`.

For signed score `s`, define `q6 = s >> 6` using the x86 arithmetic signed shift. The four predicates become exactly:

- `s >= 0` iff `q6 >= 0`
- `s >= 64` iff `q6 >= 1`
- `s >= 192` iff `q6 >= 3`
- `s >= 384` iff `q6 >= 6`

The valid score range `-32767..98878` maps to `q6=-512..1544`; this fits in `int16_t`. Stored hot state therefore drops from **4 bytes to 2 bytes** without discarding any information observable by Decision V8.

## Correctness validation

- exhaustive valid score domain: **131,646 cases, 0 divergences**
- random valid raw inputs against validated V7: **20,000,000 cases, 0 divergences**
- native Q6 V0L preflight/decision/fused: exact
- scalar Q6 inline: exact
- SSE2 Q6 batch: exact
- AVX2 Q6 batch: exact
- AVX2 32-bit score batch: exact
- SSE2-only compile/run with AVX and AVX2 disabled: PASS

## Native object size

- Linux Q6 V0L `.text`: **88 bytes** for all three exports
- Windows Q6 V0L `.text`: **93 bytes** for all three exports
- `.rodata`: **0 bytes**

## Benchmark protocol

Environment:

- Intel Xeon E5-2673 v4 @ 2.30 GHz
- x86-64 / KVM Linux
- GCC `-O3 -march=native`
- CPU affinity pinned to one logical CPU
- prebuilt score/Q6 arrays; score construction excluded from the timed region for these representation benchmarks
- 1,048,576 decisions per timed pass
- each line is the median p50 across **9 independent process runs**

| Path | Median p50 | Approx throughput |
|---|---:|---:|
| Native 32-bit score decision | 2.7509 ns/decision | 0.364 B decisions/s |
| Native Q6 decision | **2.3392 ns/decision** | **0.428 B decisions/s** |
| Inline 32-bit fused scalar | 2.2537 ns/decision | 0.444 B decisions/s |
| Inline Q6 fused scalar | 2.2414 ns/decision | 0.446 B decisions/s |
| Q6 SSE2 full batch | 0.2158 ns/decision | 4.63 B decisions/s |
| 32-bit score AVX2 full batch | 0.3262 ns/decision | 3.07 B decisions/s |
| Q6 AVX2 full batch | **0.1404 ns/decision** | **7.12 B decisions/s** |
| Q6 AVX2 preflight mask/count | **0.0782 ns/decision** | **12.79 B decisions/s** |

## Improvements that are safe to claim

- Native Q6 decision vs native 32-bit-score decision: about **15.0% lower median latency** in this run set.
- Q6 AVX2 full batch vs 32-bit-score AVX2 full batch: about **57.0% lower time per decision** / **2.32x throughput**.
- Q6 state storage: **50% smaller** than the V4 32-bit score representation.
- Preflight mask/count avoids per-decision output stores and reached ~**0.078 ns/decision** in this streaming benchmark.

## What was not promoted

The Q6 native fused ABI was not faster consistently enough to replace the V4 native fused score ABI. It remains included for completeness and exact compatibility, but the recommended scalar fused path is still V4 inline/score unless Q6 already exists for storage/reuse.

Branch-heavy scalar tier trees and more aggressive adaptive-controller settings were also rejected because their speed was workload-sensitive or their selection stability was worse.

## Interpretation

The bulk numbers are throughput measurements over precomputed arrays; they do **not** include raw score construction, IPC, named-pipe overhead, downstream work, or memory/EPT work. The preflight-mask path is intentionally specialized for scan/filter workloads. At ~0.08 ns/decision in this environment, the limiting factor is increasingly data movement/cache bandwidth rather than Decision arithmetic.

#!/usr/bin/env python3
"""V0L -> x86-64 direct backend.

Emits ELF64 relocatable objects itself. No C backend and no assembler are used.
Target ABI: System V AMD64, little-endian x86-64.
"""
from __future__ import annotations
import argparse, json, pathlib, re, struct, sys
from dataclasses import dataclass, field

# ----------------------------- parsing -----------------------------
TYPE_BITS={'u8':8,'u16':16,'u32':32,'u64':64,'i32':32,'ptr':64}
IMM_RE=re.compile(r'-?0x[0-9a-fA-F]+|-?\d+$')
NAME_RE=re.compile(r'[A-Za-z_]\w*$')

@dataclass
class Ins:
    op:str; args:list[str]; line:int
@dataclass
class Fn:
    name:str; params:list[tuple[str,str]]; ret:str; body:list[Ins]=field(default_factory=list); vars:dict[str,str]=field(default_factory=dict)
@dataclass
class Module:
    data_files:list[str]; fns:list[Fn]

def die(msg,line=None):
    p=f'line {line}: ' if line else ''
    raise SystemExit(p+msg)

def parse_source(txt:str)->Module:
    data_files=[]; fns=[]; cur=None
    for ln,raw in enumerate(txt.splitlines(),1):
        s=raw.split('#',1)[0].strip()
        if not s: continue
        t=s.split(); op=t[0]
        if op=='data':
            if cur: die('data directive inside function',ln)
            if len(t)!=2: die('data expects one path',ln)
            data_files.append(t[1]); continue
        if op=='fn':
            if cur: die('nested fn',ln)
            if '->' not in t: die('fn requires -> return-type',ln)
            k=t.index('->'); name=t[1]; ret=t[k+1]
            if not NAME_RE.fullmatch(name) or ret not in TYPE_BITS: die('bad function signature',ln)
            params=[]; vars={}
            for a in t[2:k]:
                if ':' not in a: die('parameter must be name:type',ln)
                n,ty=a.split(':',1)
                if not NAME_RE.fullmatch(n) or ty not in TYPE_BITS: die('bad parameter',ln)
                params.append((n,ty)); vars[n]=ty
            cur=Fn(name,params,ret,vars=vars); fns.append(cur); continue
        if op=='end':
            if not cur: die('end outside fn',ln)
            cur=None; continue
        if not cur: die('instruction outside function',ln)
        if op=='let':
            if len(t)!=3 or t[2] not in TYPE_BITS: die('bad let',ln)
            cur.vars[t[1]]=t[2]
        cur.body.append(Ins(op,t[1:],ln))
    if cur: die('unterminated function')
    return Module(data_files,fns)

# ----------------------------- V0D data -----------------------------
def load_v0d(src_path:pathlib.Path, names:list[str]):
    constants={}; arrays=[]
    for n in names:
        p=(src_path.parent.parent/'generated'/n) if not (src_path.parent/n).exists() else (src_path.parent/n)
        if not p.exists():
            p=src_path.parent/n
        if not p.exists(): die(f'data file not found: {n}')
        d=json.loads(p.read_text())
        if d.get('format')!='V0D1': die(f'unsupported data format in {p}')
        constants.update({k:int(v) for k,v in d.get('constants',{}).items()})
        arrays.extend(d.get('arrays',[]))
    return constants,arrays

# ----------------------------- x86 encoder -----------------------------
REG={
 'rax':0,'rcx':1,'rdx':2,'rbx':3,'rsp':4,'rbp':5,'rsi':6,'rdi':7,
 'r8':8,'r9':9,'r10':10,'r11':11,'r12':12,'r13':13,'r14':14,'r15':15,
}
# allocator pool; rsi/r10/r11 are backend scratch, rdi is first pointer arg.
ALLOC=['rax','rcx','rdx','r8','r9']

class Code:
    def __init__(self): self.b=bytearray(); self.reloc=[]; self.labels={}; self.fix=[]; self.fix8=[]
    def tell(self): return len(self.b)
    def emit(self,*xs): self.b.extend(xs)
    def u32(self,x): self.b.extend(struct.pack('<I',x & 0xffffffff))
    def i32(self,x): self.b.extend(struct.pack('<i',x))
    def rex(self,w=0,r=0,x=0,b=0,force=False):
        v=0x40|(w<<3)|((r>>3)&1)<<2|((x>>3)&1)<<1|((b>>3)&1)
        if v!=0x40 or force: self.emit(v)
    def modrm(self,mod,reg,rm): self.emit(((mod&3)<<6)|((reg&7)<<3)|(rm&7))
    def sib(self,scale,index,base): self.emit(((scale&3)<<6)|((index&7)<<3)|(base&7))
    def mov_rr(self,dst,src,bits=32):
        d=REG[dst]; s=REG[src]; self.rex(bits==64,s,0,d); self.emit(0x89); self.modrm(3,s,d)
    def mov_imm(self,dst,val,bits=32):
        d=REG[dst]
        if bits==64:
            # Prefer shorter encodings when the value fits.  A 32-bit register
            # write zero-extends to 64 bits; C7 /0 sign-extends imm32.
            if 0 <= val <= 0xffffffff:
                self.rex(0,0,0,d); self.emit(0xB8+(d&7)); self.u32(val)
            elif -0x80000000 <= val <= 0x7fffffff:
                self.rex(1,0,0,d); self.emit(0xC7); self.modrm(3,0,d); self.u32(val)
            else:
                self.rex(1,0,0,d); self.emit(0xB8+(d&7)); self.b.extend(struct.pack('<Q',val & 0xffffffffffffffff))
        else:
            self.rex(0,0,0,d); self.emit(0xB8+(d&7)); self.u32(val)
    def mov_mem(self,dst,base,disp=0,bits=32):
        d=REG[dst]; ba=REG[base]; self.rex(bits==64,d,0,ba); self.emit(0x8B)
        self._mem_modrm(d,ba,disp)
    def store_mem(self,src,base,disp=0,bits=32):
        s=REG[src]; ba=REG[base]
        self.rex(bits==64,s,0,ba); self.emit(0x89)
        self._mem_modrm(s,ba,disp)
    def movzx8_mem(self,dst,base,disp=0):
        d=REG[dst]; ba=REG[base]
        self.rex(0,d,0,ba); self.emit(0x0F,0xB6); self._mem_modrm(d,ba,disp)
    def movzx8_mem_index(self,dst,base,index,scale=0,disp=0):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(0,d,ix,ba); self.emit(0x0F,0xB6)
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def cmp_rr(self,a,b,bits=32):
        # flags from a-b
        ra=REG[a]; rb=REG[b]; self.rex(bits==64,rb,0,ra); self.emit(0x39); self.modrm(3,rb,ra)
    def cmp_mem(self,reg,base,disp=0,bits=32):
        r=REG[reg]; ba=REG[base]
        if bits==16: self.emit(0x66)
        self.rex(bits==64,r,0,ba); self.emit(0x3B); self._mem_modrm(r,ba,disp)
    def cmp_mem_index(self,reg,base,index,scale=0,disp=0,bits=32):
        r=REG[reg]; ba=REG[base]; ix=REG[index]
        if bits==16: self.emit(0x66)
        self.rex(bits==64,r,ix,ba); self.emit(0x3B)
        low=ba&7
        mod=0 if disp==0 and low!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,r,4); self.sib(scale,ix,low)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and low==5): self.i32(disp)
    def setcc(self,cc,dst):
        d=REG[dst]; op={'e':0x94,'ne':0x95,'b':0x92,'be':0x96,'a':0x97,'ae':0x93}[cc]
        self.rex(0,0,0,d,force=(d>=8)); self.emit(0x0F,op); self.modrm(3,0,d)

    def movzx16_mem_index(self,dst,base,index,scale=1,disp=0):
        d=REG[dst]; ba=REG[base]; ix=REG[index]
        self.rex(0,d,ix,ba); self.emit(0x0F,0xB7)
        # indexed address always SIB
        mod=0 if disp==0 and (ba&7)!=5 else (1 if -128<=disp<=127 else 2)
        self.modrm(mod,d,4); self.sib(scale,ix,ba)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and (ba&7)==5): self.i32(disp)
    def movzx16_mem(self,dst,base,disp=0):
        d=REG[dst]; ba=REG[base]; self.rex(0,d,0,ba); self.emit(0x0F,0xB7); self._mem_modrm(d,ba,disp)
    def _mem_modrm(self,reg,base,disp):
        low=base&7
        mod=0 if disp==0 and low!=5 else (1 if -128<=disp<=127 else 2)
        if low==4:
            self.modrm(mod,reg,4); self.sib(0,4,low)
        else: self.modrm(mod,reg,low)
        if mod==1:self.emit(disp&255)
        elif mod==2 or (mod==0 and low==5): self.i32(disp)
    def imul_imm(self,dst,src,imm,bits=32,imm8=False):
        d=REG[dst]; s=REG[src]; self.rex(bits==64,d,0,s)
        if imm8 and -128<=imm<=127:
            self.emit(0x6B); self.modrm(3,d,s); self.emit(imm&255)
        else:
            self.emit(0x69); self.modrm(3,d,s); self.u32(imm)
    def shift_imm(self,kind,dst,imm,bits=32):
        d=REG[dst]; ext={'shl':4,'shr':5}[kind]; self.rex(bits==64,0,0,d)
        mask=63 if bits==64 else 31
        if (imm & mask)==1:
            self.emit(0xD1); self.modrm(3,ext,d)
        else:
            self.emit(0xC1); self.modrm(3,ext,d); self.emit(imm&255)
    def bin_rr(self,op,dst,src,bits=32):
        # rm(dst) op reg(src)
        opc={'add':0x01,'sub':0x29,'xor':0x31,'or':0x09,'and':0x21}[op]
        d=REG[dst]; s=REG[src]; self.rex(bits==64,s,0,d); self.emit(opc); self.modrm(3,s,d)
    def bin_imm(self,op,dst,imm,bits=32):
        ext={'add':0,'or':1,'and':4,'sub':5,'xor':6}[op]; d=REG[dst]
        self.rex(bits==64,0,0,d)
        if -128<=imm<=127:
            self.emit(0x83); self.modrm(3,ext,d); self.emit(imm&255)
        else:
            self.emit(0x81); self.modrm(3,ext,d); self.u32(imm)
    def lea_rip(self,dst,sym):
        d=REG[dst]; self.rex(1,d,0,0); self.emit(0x8D); self.modrm(0,d,5)
        off=self.tell(); self.u32(0); self.reloc.append((off,sym,-4))
    def xor_mem(self,dst,base,disp=0,bits=64):
        d=REG[dst]; ba=REG[base]; self.rex(bits==64,d,0,ba); self.emit(0x33); self._mem_modrm(d,ba,disp)
    def test_rr(self,a,b,bits=32):
        ra=REG[a]; rb=REG[b]; self.rex(bits==64,rb,0,ra); self.emit(0x85); self.modrm(3,rb,ra)
    def div_u32(self,src):
        s=REG[src]; self.rex(0,0,0,s); self.emit(0xF7); self.modrm(3,6,s)
    def ret(self): self.emit(0xC3)
    def label(self,name):
        if name in self.labels: raise ValueError(f'duplicate label {name}')
        self.labels[name]=self.tell()
    def jcc(self,cc,label):
        opc={'z':0x84,'e':0x84,'nz':0x85,'ne':0x85,'b':0x82,'ae':0x83,'be':0x86,'a':0x87}[cc]
        self.emit(0x0F,opc); off=self.tell(); self.u32(0); self.fix.append((off,label))
    def jcc8(self,cc,label):
        opc={'z':0x74,'e':0x74,'nz':0x75,'ne':0x75,'b':0x72,'ae':0x73,'be':0x76,'a':0x77}[cc]
        self.emit(opc); off=self.tell(); self.emit(0); self.fix8.append((off,label))
    def jmp(self,label): self.emit(0xE9); off=self.tell(); self.u32(0); self.fix.append((off,label))
    def patch(self):
        for off,label in self.fix:
            if label not in self.labels: raise ValueError(f'unknown label {label}')
            rel=self.labels[label]-(off+4); self.b[off:off+4]=struct.pack('<i',rel)
        for off,label in self.fix8:
            if label not in self.labels: raise ValueError(f'unknown label {label}')
            rel=self.labels[label]-(off+1)
            if not -128<=rel<=127: raise ValueError(f'short branch to {label} is out of range')
            self.b[off]=rel&255

# ----------------------------- register allocation -----------------------------
def is_value(tok,fn,constants): return tok in fn.vars or tok in constants or IMM_RE.fullmatch(tok)

def uses_defs(ins:Ins):
    op=ins.op; a=ins.args; use=[]; define=[]
    if op=='let': pass
    elif op=='mov': define.append(a[0]); use.append(a[1])
    elif op in ('add32','sub32','mul32','xor32','or32','and32','shl32','shr32','add64','sub64','mul64','xor64','or64','and64','shl64','shr64','eq32','ne32','lt32','le32','gt32','ge32','div32u'):
        define.append(a[0]); use+=a[1:3]
    elif op.startswith('ld'): define.append(a[0]); use+=[a[1],a[2]]
    elif op.startswith('st'): use+=a[:3]
    elif op in ('aget16','aget32','aget64'): define.append(a[0]); use.append(a[2])
    elif op=='eq22': define.append(a[0]); use += [a[1],a[3]]
    elif op in ('jz','jnz'): use.append(a[0])
    elif op=='ret': use.append(a[0])
    elif op=='retif': use += [a[0],a[1]]
    return use,define

def destructive_reuse_sources(ins:Ins):
    """Sources whose register may also hold this instruction's destination.

    x86 reads all address/source operands before committing the destination.
    Two-address arithmetic naturally overwrites its left input; commutative
    operations may also reverse their inputs.  Keeping this distinction here
    lets the linear scan end a source lifetime at the defining instruction
    without making unsafe choices for subtraction or eq22.
    """
    op=ins.op; a=ins.args
    if op=='mov': return a[1:2]
    if op in ('mul32','shl32','shr32','add64','mul64','xor64','or64','and64','shl64','shr64'):
        return a[1:2]
    if op in ('add32','xor32','or32','and32'):
        return a[1:2]
    if op=='sub32': return a[1:2]
    if op=='div32u': return a[1:2]
    if op.startswith('ld'): return a[1:3]
    if op in ('aget16','aget32','aget64'): return a[2:3]
    if op in ('eq32','ne32','lt32','le32','gt32','ge32'): return a[1:3]
    return []

def alloc_regs(fn:Fn,target="linux"):
    # Params: current direct backend supports first pointer parameter in RDI.
    regs={}
    if len(fn.params)>2: die(f'{fn.name}: direct backend currently supports up to two parameters')
    abi=['rdi','rsi'] if target=='linux' else ['rcx','rdx']
    for (n,ty),r in zip(fn.params,abi): regs[n]=r
    first={}; last={}
    for i,ins in enumerate(fn.body):
        u,d=uses_defs(ins)
        for x in d:
            if x in fn.vars and x not in first: first[x]=i
            if x in fn.vars: last[x]=max(last.get(x,i),i)
        for x in u:
            if x in fn.vars:
                first.setdefault(x,0); last[x]=i
    intervals=sorted([(first[v],last.get(v,first[v]),v) for v in first if v not in regs])
    active=[]; free=[r for r in ALLOC if r not in regs.values()]
    for st,en,v in intervals:
        still=[]
        for aen,av,ar in active:
            if aen < st: free.append(ar)
            else: still.append((aen,av,ar))
        active=still
        reusable=set(destructive_reuse_sources(fn.body[st]))
        reuse=next(((aen,av,ar) for aen,av,ar in active
                    if aen==st and av in reusable),None)
        if reuse is not None:
            active.remove(reuse); r=reuse[2]
            regs[v]=r; active.append((en,v,r)); active.sort()
            continue
        if not free: die(f'{fn.name}: register pressure exceeds direct backend pool near {v}')
        # stable preference to low regs for shorter encodings
        free.sort(key=lambda r:ALLOC.index(r)); r=free.pop(0); regs[v]=r
        active.append((en,v,r)); active.sort()
    return regs

# ----------------------------- compile operations -----------------------------
def imm(tok,constants):
    if tok in constants: return int(constants[tok])
    if IMM_RE.fullmatch(tok): return int(tok,0)
    return None

def ensure_reg(c:Code,tok,fn,regs,constants,scratch='r11',bits=32):
    if tok in regs: return regs[tok]
    v=imm(tok,constants)
    if v is None: die(f'unknown value {tok}')
    c.mov_imm(scratch,v,bits); return scratch

def move_value(c:Code,dst,tok,fn,regs,constants,bits=32):
    if tok in regs:
        if regs[tok]!=dst: c.mov_rr(dst,regs[tok],bits)
    else:
        v=imm(tok,constants)
        if v is None: die(f'unknown value {tok}')
        c.mov_imm(dst,v,bits)

def compile_fn(fn:Fn,constants,data_offsets=None,target='linux')->tuple[bytes,list[tuple[int,str,int]]]:
    regs=alloc_regs(fn,target); c=Code(); internal=0; sticky_data=None; data_offsets=data_offsets or {}
    data_scratch='rsi' if target=='linux' else 'r10'
    skip_ins=0
    # skip let: allocation is static and x86 locals need no initialization unless used before def.
    for pos,ins in enumerate(fn.body):
        if skip_ins:
            skip_ins-=1; continue
        op=ins.op; a=ins.args
        if op=='let': continue
        # eq22 commonly feeds an immediate retif followed by the miss return.
        # Fuse the three V0L operations so no boolean is materialized and each
        # comparison branches directly to the miss epilogue.
        if op=='eq22' and pos+2<len(fn.body):
            nxt=fn.body[pos+1]; last=fn.body[pos+2]
            if nxt.op=='retif' and last.op=='ret' and nxt.args[0]==a[0]:
                _,p,sym,idx=a; fail=f'__eqretfail_{internal}'; internal+=1
                c.lea_rip('r10',sym)
                # The index may itself be the value returned by retif (as in the
                # full V0 lookup).  Only clobber/reuse its register when it is
                # provably dead on both terminal paths.  Otherwise preserve it and
                # use the OPT2 address sequence.
                idx_is_live = (nxt.args[1] == idx or last.args[0] == idx)
                if idx_is_live:
                    c.imul_imm('r11',regs[idx],22,64,imm8=True)
                    c.bin_rr('add','r10','r11',64)
                    c.mov_mem('r11',regs[p],0,64); c.cmp_mem('r11','r10',0,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],8,64); c.cmp_mem('r11','r10',8,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],14,64); c.cmp_mem('r11','r10',14,64); c.jcc8('nz',fail)
                else:
                    idxr=regs[idx]
                    c.imul_imm(idxr,idxr,22,64,imm8=True)
                    c.mov_mem('r11',regs[p],0,64); c.cmp_mem_index('r11','r10',idxr,0,0,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],8,64); c.cmp_mem_index('r11','r10',idxr,0,8,64); c.jcc8('nz',fail)
                    c.mov_mem('r11',regs[p],14,64); c.cmp_mem_index('r11','r10',idxr,0,14,64); c.jcc8('nz',fail)
                move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret()
                c.label(fail)
                z=imm(last.args[0],constants)
                if z==0: c.bin_rr('xor','rax','rax',32)
                else: move_value(c,'rax',last.args[0],fn,regs,constants,32)
                c.ret()
                skip_ins=2; continue
        # eq22 followed directly by `ret result` is also terminal.  The index
        # is dead on both outcomes, so use the same folded-address exact check
        # and return the boolean directly without materializing it first.
        if op=='eq22' and pos+1<len(fn.body):
            nxt=fn.body[pos+1]
            if nxt.op=='ret' and nxt.args[0]==a[0]:
                _,p,sym,idx=a; fail=f'__eqretboolfail_{internal}'; internal+=1
                c.lea_rip('r10',sym)
                idxr=regs[idx]
                c.imul_imm(idxr,idxr,22,64,imm8=True)
                c.mov_mem('r11',regs[p],0,64); c.cmp_mem_index('r11','r10',idxr,0,0,64); c.jcc8('nz',fail)
                c.mov_mem('r11',regs[p],8,64); c.cmp_mem_index('r11','r10',idxr,0,8,64); c.jcc8('nz',fail)
                c.mov_mem('r11',regs[p],14,64); c.cmp_mem_index('r11','r10',idxr,0,14,64); c.jcc8('nz',fail)
                c.mov_imm('rax',1,32); c.ret()
                c.label(fail); c.bin_rr('xor','rax','rax',32); c.ret()
                skip_ins=1; continue
        # Comparison -> retif with dead boolean result. Keep flags live and
        # return immediately on the true condition, but continue compiling the
        # false path. This is exact and removes SETcc+TEST from guard checks.
        cmp_ops=('eq32','ne32','lt32','le32','gt32','ge32')
        if op in cmp_ops and pos+1<len(fn.body):
            nxt=fn.body[pos+1]
            if nxt.op=='retif' and nxt.args[0]==a[0]:
                cond=a[0]
                # Safe only when the boolean temporary is not referenced later.
                live_later=False
                for later in fn.body[pos+2:]:
                    u,d=uses_defs(later)
                    if cond in u:
                        live_later=True; break
                    if cond in d:
                        break
                if not live_later:
                    _,x,y=a
                    xi=imm(x,constants); yi=imm(y,constants)
                    if op in ('eq32','ne32') and yi==0 and x in regs:
                        xr=regs[x]; c.test_rr(xr,xr,32)
                    elif op in ('eq32','ne32') and xi==0 and y in regs:
                        yr=regs[y]; c.test_rr(yr,yr,32)
                    else:
                        xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
                        yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
                        c.cmp_rr(xr,yr,32)
                    true_cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]
                    false_cc={'e':'ne','ne':'e','b':'ae','be':'a','a':'be','ae':'b'}[true_cc]
                    skip=f'__cmpguardskip_{internal}'; internal+=1
                    c.jcc8(false_cc,skip)
                    rv=imm(nxt.args[1],constants)
                    if rv==0: c.bin_rr('xor','rax','rax',32)
                    else: move_value(c,'rax',nxt.args[1],fn,regs,constants,32)
                    c.ret()
                    c.label(skip)
                    skip_ins=1; continue
        # Comparison -> retif -> ret is another common hot-path shape.  Keep
        # flags live and branch directly instead of materializing a 0/1 value
        # only to test it again in retif.
        if op in cmp_ops and pos+2<len(fn.body):
            nxt=fn.body[pos+1]; last=fn.body[pos+2]
            if nxt.op=='retif' and last.op=='ret' and nxt.args[0]==a[0]:
                _,x,y=a
                xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
                yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
                c.cmp_rr(xr,yr,32)
                true_cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]
                false_cc={'e':'ne','ne':'e','b':'ae','be':'a','a':'be','ae':'b'}[true_cc]
                fail=f'__cmpretfail_{internal}'; internal+=1
                c.jcc8(false_cc,fail)
                move_value(c,'rax',nxt.args[1],fn,regs,constants,32); c.ret()
                c.label(fail); move_value(c,'rax',last.args[0],fn,regs,constants,32); c.ret()
                skip_ins=2; continue
        if op=='ld8':
            dst,ptr,off=a; base=regs.get(ptr)
            if base is None: die('ld8 pointer must be register',ins.line)
            ov=imm(off,constants)
            if ov is not None:
                # Constant offsets belong in ModRM/SIB displacement directly;
                # do not burn a scratch register + extra instruction.
                c.movzx8_mem(regs[dst],base,ov)
            else:
                if off not in regs: die('ld8 offset must be immediate or register',ins.line)
                c.movzx8_mem_index(regs[dst],base,regs[off],0,0)
        elif op=='ld32':
            dst,ptr,off=a; base=regs.get(ptr)
            if base is None: die('ld32 pointer must be register',ins.line)
            ov=imm(off,constants)
            if ov is None: die('ld32 offset must be immediate',ins.line)
            c.mov_mem(regs[dst],base,ov,32)
        elif op=='ld64':
            dst,ptr,off=a; ov=imm(off,constants); c.mov_mem(regs[dst],regs[ptr],ov or 0,64)
        elif op=='st32':
            ptr,off,val=a; base=regs.get(ptr)
            if base is None: die('st32 pointer must be register',ins.line)
            ov=imm(off,constants)
            if ov is None: die('st32 offset must be immediate',ins.line)
            src=ensure_reg(c,val,fn,regs,constants,'r11',32)
            c.store_mem(src,base,ov,32)
        elif op=='mov': move_value(c,regs[a[0]],a[1],fn,regs,constants,TYPE_BITS[fn.vars[a[0]]])
        elif op in ('mul32','add32','sub32','xor32','or32','and32','shl32','shr32'):
            dst,x,y=a; dr=regs[dst]; xr=regs.get(x); yi=imm(y,constants); xi=imm(x,constants)
            if op=='mul32' and yi is not None and xr is not None:
                c.imul_imm(dr,xr,yi,32)
            elif op in ('shl32','shr32') and yi is not None:
                if xr is None:
                    move_value(c,dr,x,fn,regs,constants,32)
                elif dr!=xr: c.mov_rr(dr,xr,32)
                c.shift_imm('shl' if op=='shl32' else 'shr',dr,yi,32)
            else:
                if xr is None: move_value(c,dr,x,fn,regs,constants,32)
                elif dr!=xr: c.mov_rr(dr,xr,32)
                bop=op[:-2]
                if yi is not None: c.bin_imm(bop,dr,yi,32)
                else: c.bin_rr(bop,dr,regs[y],32)
        elif op in ('add64','sub64'):
            dst,x,y=a; dr=regs[dst]; xr=regs.get(x); yi=imm(y,constants)
            if xr is None: move_value(c,dr,x,fn,regs,constants,64)
            elif dr!=xr: c.mov_rr(dr,xr,64)
            bop=op[:-2]
            if yi is not None: c.bin_imm(bop,dr,yi,64)
            else: c.bin_rr(bop,dr,regs[y],64)
        elif op=='div32u':
            dst,x,y=a
            xr=ensure_reg(c,x,fn,regs,constants,'r10',32)
            yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
            if yr in ('rax','rdx'):
                c.mov_rr('r11',yr,32); yr='r11'
            if xr!='rax': c.mov_rr('rax',xr,32)
            c.bin_rr('xor','rdx','rdx',32)
            c.div_u32(yr)
            if regs[dst]!='rax': c.mov_rr(regs[dst],'rax',32)
        elif op in ('eq32','ne32','lt32','le32','gt32','ge32'):
            dst,x,y=a; xr=ensure_reg(c,x,fn,regs,constants,'r10',32); yr=ensure_reg(c,y,fn,regs,constants,'r11',32)
            dr=regs[dst]
            # xor-zero is shorter than mov imm32, but it clobbers flags and may
            # destroy a source if linear-scan reused its register.  Use it only
            # when the destination is independent, before the compare.
            if dr!=xr and dr!=yr:
                c.bin_rr('xor',dr,dr,32); c.cmp_rr(xr,yr,32)
            else:
                c.cmp_rr(xr,yr,32); c.mov_imm(dr,0,32)
            cc={'eq32':'e','ne32':'ne','lt32':'b','le32':'be','gt32':'a','ge32':'ae'}[op]; c.setcc(cc,dr)
        elif op=='aget16':
            dst,sym,index=a
            if sticky_data is None or sticky_data not in data_offsets or sym not in data_offsets:
                c.lea_rip(data_scratch,sym); sticky_data=sym; delta=0
            else:
                delta=data_offsets[sym]-data_offsets[sticky_data]
            c.movzx16_mem_index(regs[dst],data_scratch,regs[index],1,delta)
        elif op=='eq22':
            dst,p,sym,idx=a; fail=f'__eqfail_{internal}'; done=f'__eqdone_{internal}'; internal+=1
            # r10 = &keys[id*22]
            c.lea_rip('r10',sym)
            c.imul_imm('r11',regs[idx],22,64,imm8=True)
            c.bin_rr('add','r10','r11',64)
            c.mov_imm(regs[dst],0,32)
            # Three qwords cover 0..21 exactly, with a 2-byte overlap in the tail.
            c.mov_mem('r11',regs[p],0,64); c.cmp_mem('r11','r10',0,64); c.jcc8('nz',fail)
            c.mov_mem('r11',regs[p],8,64); c.cmp_mem('r11','r10',8,64); c.jcc8('nz',fail)
            c.mov_mem('r11',regs[p],14,64); c.cmp_mem('r11','r10',14,64); c.jcc8('nz',fail)
            c.mov_imm(regs[dst],1,32); c.label(fail)
        elif op=='retif':
            cond,val=a; skip=f'__retskip_{internal}'; internal+=1
            cr=regs[cond]; c.test_rr(cr,cr,32); c.jcc8('z',skip)
            move_value(c,'rax',val,fn,regs,constants,32); c.ret(); c.label(skip)
        elif op=='ret':
            move_value(c,'rax',a[0],fn,regs,constants,32); c.ret()
        elif op=='label': c.label(a[0])
        elif op=='jmp': c.jmp(a[0])
        elif op in ('jz','jnz'):
            cr=regs[a[0]]; c.test_rr(cr,cr,32); c.jcc('z' if op=='jz' else 'nz',a[1])
        else:
            die(f'direct x64 backend does not yet implement {op}',ins.line)
    c.patch(); return bytes(c.b),c.reloc

# ----------------------------- minimal ELF64 object writer -----------------------------
def align_up(x,a): return (x+a-1)&~(a-1)

def make_strtab(names):
    b=bytearray(b'\0'); off={}
    for n in names:
        if n in off: continue
        off[n]=len(b); b.extend(n.encode()+b'\0')
    return bytes(b),off

def emit_elf(text:bytes, rodata:bytes, funcs, objects, relocs, out:pathlib.Path):
    # section indexes
    TEXT,RODATA,RELA,SYMTAB,STRTAB,SHSTRTAB=1,2,3,4,5,6
    global_names=[f['name'] for f in funcs]+[o['name'] for o in objects]
    strtab,stroff=make_strtab(global_names)
    shnames=['','.text','.rodata','.rela.text','.symtab','.strtab','.shstrtab']
    shstr,shoffname=make_strtab(shnames[1:])
    # symbols: null, local section symbols, then globals
    syms=[(0,0,0,0,0,0),(0,0x03,0,TEXT,0,0),(0,0x03,0,RODATA,0,0)]
    symidx={}
    for f in funcs:
        symidx[f['name']]=len(syms); syms.append((stroff[f['name']],0x12,0,TEXT,f['off'],f['size']))
    for o in objects:
        symidx[o['name']]=len(syms); syms.append((stroff[o['name']],0x11,0,RODATA,o['off'],o['size']))
    symtab=bytearray()
    for s in syms: symtab.extend(struct.pack('<IBBHQQ',*s))
    rela=bytearray()
    for off,sym,add in relocs:
        if sym not in symidx: raise SystemExit(f'relocation references unknown symbol {sym}')
        info=(symidx[sym]<<32)|2 # R_X86_64_PC32
        rela.extend(struct.pack('<QQq',off,info,add))
    # lay out sections after ELF header
    cur=64; sec={}
    for idx,data,al in [(TEXT,text,16),(RODATA,rodata,64),(RELA,bytes(rela),8),(SYMTAB,bytes(symtab),8),(STRTAB,strtab,1),(SHSTRTAB,shstr,1)]:
        cur=align_up(cur,al); sec[idx]=(cur,data,al); cur+=len(data)
    shoff=align_up(cur,8); shnum=7
    outb=bytearray(shoff+64*shnum)
    ident=bytearray(16); ident[:4]=b'\x7fELF'; ident[4]=2; ident[5]=1; ident[6]=1
    outb[:64]=struct.pack('<16sHHIQQQIHHHHHH',bytes(ident),1,62,1,0,0,shoff,0,64,0,0,64,shnum,SHSTRTAB)
    for idx,(off,data,al) in sec.items(): outb[off:off+len(data)]=data
    # section headers
    def sh(idx,name,typ,flags,off,size,link=0,info=0,align=1,entsz=0):
        base=shoff+idx*64; outb[base:base+64]=struct.pack('<IIQQQQIIQQ',shoffname.get(name,0),typ,flags,0,off,size,link,info,align,entsz)
    sh(TEXT,'.text',1,0x6,*sec[TEXT][:1],len(text),align=16)
    sh(RODATA,'.rodata',1,0x2,*sec[RODATA][:1],len(rodata),align=64)
    sh(RELA,'.rela.text',4,0,*sec[RELA][:1],len(rela),link=SYMTAB,info=TEXT,align=8,entsz=24)
    sh(SYMTAB,'.symtab',2,0,*sec[SYMTAB][:1],len(symtab),link=STRTAB,info=3,align=8,entsz=24)
    sh(STRTAB,'.strtab',3,0,*sec[STRTAB][:1],len(strtab),align=1)
    sh(SHSTRTAB,'.shstrtab',3,0,*sec[SHSTRTAB][:1],len(shstr),align=1)
    out.write_bytes(outb)


# ----------------------------- minimal COFF x86-64 object writer -----------------------------
def emit_coff(text:bytes, rodata:bytes, funcs, objects, relocs, out:pathlib.Path):
    # IMAGE_FILE_MACHINE_AMD64, two sections (.text/.rdata), no optional header.
    names=[f['name'] for f in funcs]+[o['name'] for o in objects]
    strdata=bytearray(); stroff={}
    for n in names:
        if len(n.encode())>8:
            stroff[n]=4+len(strdata); strdata.extend(n.encode()+b'\0')
    def nfield(n):
        b=n.encode()
        if len(b)<=8: return b.ljust(8,b'\0')
        return struct.pack('<II',0,stroff[n])
    symidx={}; symtab=bytearray(); idx=0
    for f in funcs:
        symidx[f['name']]=idx; idx+=1
        symtab.extend(struct.pack('<8sIhHBB',nfield(f['name']),f['off'],1,0x20,2,0))
    for o in objects:
        symidx[o['name']]=idx; idx+=1
        symtab.extend(struct.pack('<8sIhHBB',nfield(o['name']),o['off'],2,0,2,0))
    reloc=bytearray()
    for off,sym,add in relocs:
        if sym not in symidx: raise SystemExit(f'COFF relocation references unknown symbol {sym}')
        # IMAGE_REL_AMD64_REL32 is relative to the byte following the 32-bit field; no ELF -4 addend.
        reloc.extend(struct.pack('<IIH',off,symidx[sym],0x0004))
    header_sz=20+2*40
    text_off=align_up(header_sz,16)
    rdata_off=align_up(text_off+len(text),64)
    reloc_off=align_up(rdata_off+len(rodata),4)
    sym_off=reloc_off+len(reloc)
    strings=struct.pack('<I',4+len(strdata))+bytes(strdata)
    total=sym_off+len(symtab)+len(strings)
    b=bytearray(total)
    # COFF file header
    b[:20]=struct.pack('<HHIIIHH',0x8664,2,0,sym_off,len(symtab)//18,0,0)
    # section headers
    text_chars=0x60000020|0x00500000 # code/read/execute + align16
    data_chars=0x40000040|0x00700000 # initialized/read + align64
    b[20:60]=struct.pack('<8sIIIIIIHHI',b'.text\0\0\0',0,0,len(text),text_off,reloc_off,0,len(reloc)//10,0,text_chars)
    b[60:100]=struct.pack('<8sIIIIIIHHI',b'.rdata\0\0',0,0,len(rodata),rdata_off,0,0,0,0,data_chars)
    b[text_off:text_off+len(text)]=text
    b[rdata_off:rdata_off+len(rodata)]=rodata
    b[reloc_off:reloc_off+len(reloc)]=reloc
    b[sym_off:sym_off+len(symtab)]=symtab
    b[sym_off+len(symtab):]=strings
    out.write_bytes(b)

# ----------------------------- driver -----------------------------
def main():
    ap=argparse.ArgumentParser(description='V0L direct x86-64 backend (no C, no assembler)')
    ap.add_argument('input',type=pathlib.Path); ap.add_argument('output',type=pathlib.Path)
    ap.add_argument('--map',dest='mapfile',type=pathlib.Path)
    ap.add_argument('--raw-dir',type=pathlib.Path,help='also dump each function as raw machine-code bytes')
    ap.add_argument('--function',action='append',help='emit only selected function(s); may be repeated')
    ap.add_argument('--target',choices=['linux','windows'],default='linux',help='x86-64 object ABI/container')
    ns=ap.parse_args()
    txt=ns.input.read_text(); mod=parse_source(txt); constants,arrays=load_v0d(ns.input,mod.data_files)
    if ns.function:
        wanted=set(ns.function); mod.fns=[f for f in mod.fns if f.name in wanted]
        missing=wanted-{f.name for f in mod.fns}
        if missing: die('unknown function(s): '+', '.join(sorted(missing)))
    used_arrays=set()
    for fn in mod.fns:
        for ins in fn.body:
            if ins.op.startswith('aget') and len(ins.args)>=2: used_arrays.add(ins.args[1])
            elif ins.op=='eq22' and len(ins.args)>=3: used_arrays.add(ins.args[2])
    arrays=[ar for ar in arrays if ar['name'] in used_arrays]
    ro=bytearray(); objects=[]; data_offsets={}
    for ar in arrays:
        al=int(ar.get('align',1))
        while len(ro)%al: ro.append(0)
        off=len(ro); dat=bytes.fromhex(ar['data_hex']); ro.extend(dat)
        objects.append({'name':ar['name'],'off':off,'size':len(dat)}); data_offsets[ar['name']]=off
    text=bytearray(); funcs=[]; allrel=[]
    for fn in mod.fns:
        while len(text)%16:text.append(0x90)
        start=len(text); code,rels=compile_fn(fn,constants,data_offsets,ns.target); text.extend(code)
        funcs.append({'name':fn.name,'off':start,'size':len(code)})
        allrel += [(start+o,s,a) for o,s,a in rels]
    if ns.target=='linux': emit_elf(bytes(text),bytes(ro),funcs,objects,allrel,ns.output)
    else: emit_coff(bytes(text),bytes(ro),funcs,objects,allrel,ns.output)
    if ns.raw_dir:
        ns.raw_dir.mkdir(parents=True,exist_ok=True)
        for f in funcs:
            (ns.raw_dir/(f['name']+'.bin')).write_bytes(bytes(text[f['off']:f['off']+f['size']]))
    if ns.mapfile:
        ns.mapfile.write_text(json.dumps({'target':('x86_64-sysv' if ns.target=='linux' else 'x86_64-windows'),'text_bytes':len(text),'rodata_bytes':len(ro),'functions':funcs,'objects':objects,'relocations':len(allrel)},indent=2))
    print(f'{ns.output}: text={len(text)} B rodata={len(ro)} B funcs={len(funcs)} relocs={len(allrel)}')
    return 0
if __name__=='__main__': raise SystemExit(main())

# V10 integration

## One-shot full Decision

For arrays of raw `value/cost/temperature/pinned` data:

- AVX-512BW + AVX-512VL available: `v0_eval_v10_raw_batch_avx512vl_u8(...)`
- otherwise AVX2: `v0_eval_v10_raw_batch_avx2_u8(...)`
- otherwise keep the inherited fallbacks.

These functions return the same Decision states as V9: `0, 4, 5, 6, 7`.

## One-shot preflight only

Keep using the inherited V9 AVX2 preflight path:

`v0_preflight_v8_raw_count_ultra_v9_avx2(...)`

The V10 one-shot preflight experiments did not beat V9 consistently, so no replacement is promoted.

## Cached gate16

Build once:

- AVX-512: `v0_build_gate16_batch_v10_avx512(...)`
- AVX2: `v0_build_gate16_batch_v10_avx2(...)`

Evaluate repeatedly:

`v0_eval_gate16_batch_v10_avx2_u8(...)`

Cached preflight:

- AVX-512: `v0_preflight_gate16_count_v10_avx512(...)`
- AVX2: `v0_preflight_gate16_count_v10_avx2(...)`

Use gate16 when the same `cost/temperature/pinned` descriptor is reused.  The conservative promotion point from the measured runs is **4 or more evaluations per build**.

## Large write-only output

For an aligned output buffer that will not be read immediately:

`v0_eval_gate16_batch_v10_stream_avx2_u8(...)`

This is deliberately opt-in.  It falls back to the normal evaluator for unaligned or small calls.

## Exact gate identity

For legal Decision inputs (`temperature=0..2`, `pinned=0/1`):

```text
bonus = (temperature + temperature/2) * 64

gate16 = 0xffff                                if pinned
         0x8000 + bonus - (cost >> 1)          otherwise

sum = sat_u16(value + gate16)
idx = min(sat_u16((sum >> 6) - 511), 7)
result = LUT[idx]
LUT = [0,4,5,5,6,6,6,7]
```

The transformation preserves the original thresholds exactly; there is no approximation or reduced precision.

# V0 Tier Manager — Artefato 16 squeeze report

## Verdict

**LOCAL_PASS / WINDOWS_GATE_REQUIRED**

Keep V0 Tier Manager V3 SAFE as the scalar baseline. Retain V12 only as an additive batch8 candidate until the Intel/Windows gate passes.

## Baseline preserved

Original package: `V0_TIER_MANAGER_V3_SAFE_R2.zip`.

Promoted baseline contract remains:

- `v0_tier_select_v2`: universal / untrusted `preferred`;
- `v0_tier_select_valid_v3`: scalar fast path for `preferred <= 4`.

The candidate compiler adds only a byte-store backend operation needed by batch output. Rebuilding V3 with that compiler produced byte-identical Linux and Windows V3 objects.

Baseline V3 hashes:

- Linux object: `2512a8c99692c7ad544558acaba355d3a2c2c28934fb0e87662aaab69fb04d20`
- Windows object: `eeeac3fb034ebac07ec0a4746eb57624fc5cf60b22563537f500bd073c46417d`

## New candidate

`v0_tier_select_batch8_v12`

Domain:

- exactly 8 independent requests;
- each `preferred` already proven to be 0..4;
- each mask may be any 32-bit value; upper bits are ignored exactly as in V3.

Implementation:

- V0L direct native x86-64;
- same 160-byte selection table semantics as V3;
- table base materialized once per 8 requests;
- eight masks normalized independently;
- eight output bytes written to the batch structure;
- only volatile registers are used on Windows x64.

Object sizes:

- Linux: 220 B `.text` + 160 B `.rodata`;
- Windows: 236 B `.text` + 160 B `.rdata`.

Candidate hashes:

- Linux: `3b9a39866fffd7be18e5750133c8ea2f35a3a6690ed11266f0be55ee37867124`
- Windows: `56ff2454ccc2a3a06b1b9b30e2764d1eff4bef69ef27bb26ee0ddb405fbf566b`

## Correctness

The batch gate compares V12 against the exact Tier policy / promoted V3 semantics.

Per process:

- every preferred 0..4 / low mask 0..31 combination is injected into every lane;
- 1,000,000 deterministic random batches with arbitrary 32-bit masks;
- total: **8,001,280 tier decisions**;
- divergences: **0**.

The same parity suite is run before every benchmark process.

## Long local A/B gate

Environment: local Linux server, AMD EPYC 9V74. This is screening evidence only; target promotion requires the user's Intel/Windows machine.

The baseline path performs eight V3 scalar calls and writes the same eight output bytes. The candidate performs one V12 batch call and writes the same outputs. Timing order alternates A/B.

Four independent processes, 9 workload shapes, 12 paired rounds each:

| Workload | V3 scalar x8 median cycles/batch | V12 batch8 median cycles/batch | Median speedup | Worst | Wins |
|---|---:|---:|---:|---:|---:|
| exact | 45.434 | 33.361 | 1.374x | 1.223x | 48/48 |
| all available | 45.358 | 33.312 | 1.346x | 1.117x | 48/48 |
| random masks | 45.943 | 33.898 | 1.365x | 1.154x | 48/48 |
| sparse | 46.187 | 33.780 | 1.372x | 1.234x | 48/48 |
| zero mask | 46.114 | 33.600 | 1.367x | 1.253x | 48/48 |
| preferred=0 | 46.101 | 33.925 | 1.382x | 1.258x | 48/48 |
| preferred=4 | 45.846 | 33.944 | 1.346x | 1.245x | 48/48 |
| spill colder | 45.781 | 33.469 | 1.385x | 1.160x | 48/48 |
| fallback hotter | 45.804 | 33.298 | 1.372x | 1.282x | 48/48 |

Aggregate:

- **432/432 wins**;
- median speedup **1.369869x**;
- minimum **1.117092x**;
- maximum **1.969771x**.

These numbers are for eight Tier selections as a batch. They are not end-to-end service numbers.

## Rejected new scalar attempts

### Transposed table

The same 160-byte table was transposed so indexing became `mask*5 + preferred`, allowing `LEA` instead of V3's `IMUL preferred,32`.

It was exact and reduced scalar text from 23 B to 20 B on Linux, but local median was only about **0.71x** V3. Rejected.

### TZCNT/BSR bit-selection

A table-free mathematical implementation was tested in branchy and branchless forms. Both were exact. The branchy version lost badly; the branchless version remained around ~0.84x V3 in typical local scenarios. Rejected.

These negative results are retained in `rejected/` so the same paths need not be rediscovered.

## Windows gate

`windows_gate/RUN_WINDOWS_GATE.ps1`:

1. verifies baseline/candidate object SHA-256;
2. uses MSVC Build Tools already installed on the machine;
3. links the exact baseline V3 Windows object and candidate V12 Windows object;
4. runs exhaustive/random parity before timing;
5. uses `QueryPerformanceCounter` and alternating A/B order;
6. optionally accepts a logical CPU number for affinity;
7. writes `windows_results.csv`;
8. installs nothing and changes no services, drivers, boot settings, EPT, VMX, or V0 Global.

## Promotion rule

Promote V12 only for its declared batch8 domain if target Windows confirms:

- 0 correctness divergences;
- no crash / ABI failure;
- no relevant performance regression;
- reproducible advantage over eight scalar V3 calls.

V2 and V3 remain mandatory fallbacks.

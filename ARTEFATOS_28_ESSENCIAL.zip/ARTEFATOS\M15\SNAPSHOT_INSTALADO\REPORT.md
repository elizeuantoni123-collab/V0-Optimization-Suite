# Artefato 15 — V0 Prefetch V2 SAFE — KEEP BASELINE

## Veredito

**KEEP_BASELINE — V0 Prefetch V2 SAFE permanece promovida.**

Nenhum candidato V3 novo passou a regra permanente de zero regressão no domínio declarado.

## Baseline preservada

Pacote original preservado byte a byte em `baseline/baseline_archive_V2_SAFE.zip`.

Baseline promovida:

- `v0_prefetch_t0_1(p)` — V1 universal/fallback: `PREFETCHT0 [p]`;
- `v0_prefetch_t0_adj2(p)` — V2 especializada: `PREFETCHT0 [p]` + `PREFETCHT0 [p+64]`;
- V2 somente para alvo frio de alta confiança, lookahead 8, consumo exato de 2 ou 4 cache lines adjacentes.

Revalidação local do pacote original:

- 1.000.000 hints;
- hash do payload preservado;
- canários preservados;
- corrupções: 0;
- V1 Linux `.text`: 9 B;
- V2 Linux `.text`: 13 B.

SHA-256 dos objetos revalidados:

- Linux V1: `f18aa890da125fdc7789911d06201801ca3e8d3d0d0b520a048ee581325ffb18`
- Linux V2: `daa70c630c5ded4aa1c3806553c4eeec591eae15da5660143c113bcb21a714dd`
- Windows V1: `d74458136f782317a7dff5ca864cf2d23b670ceba3927fbfd60fc370188fd0a0`
- Windows V2: `572dcf8f9ccee01ebbb18112d8c65d34467953feb5af962d7b574075c72e998e`

## Busca V3 nova

Foi feita uma busca que não repete as famílias principais já rejeitadas pelo pacote V2/V3 anterior.

### 1. Tipo e ordem dos dois hints

Mantidos os mesmos endereços `p` e `p+64` e lookahead 8. Foram testados:

- T0 em ordem reversa;
- T0/T1 e T1/T0;
- T0/T2 e T2/T0;
- T0/NTA e NTA/T0;
- T1/T1;
- T2/T2;
- NTA/NTA.

Screening: 64 MiB, cache lines flushadas, A/B alternado, 7 rodadas por processo, 5 processos independentes, consumo exato de 2 e 4 linhas.

Melhores medianas observadas, mas reprovadas:

- 2 linhas, `T0/T1`: mediana `1.060791x`, mínimo `0.902875x`, 3/5 processos vencedores;
- 2 linhas, ordem T0 reversa: mediana `1.014942x`, mínimo `0.973275x`, 3/5;
- 4 linhas, `T0/NTA`: mediana `1.029802x`, mínimo `0.889591x`, 4/5;
- 4 linhas, ordem T0 reversa: mediana `1.025749x`, mínimo `0.960387x`, 4/5.

Todos os candidatos tiveram pelo menos uma regressão. **Todos rejeitados.**

### 2. Lookahead curto ao redor do 8 promovido

Mantido exatamente o kernel V2 promovido. O caller foi testado com lookahead 4,5,6,7,9,10,11,12 contra lookahead 8.

Screening: 64 MiB, A/B alternado, 7 rodadas por processo, 7 processos independentes.

Resultados mais próximos:

- 2 linhas, lookahead 10: mediana `1.037717x`, mínimo `0.981696x`, 5/7;
- 2 linhas, lookahead 12: mediana `1.037800x`, mínimo `0.982255x`, 4/7;
- 4 linhas, lookahead 4: mediana `1.005817x`, mínimo `0.989760x`, 5/7.

Nenhum lookahead alternativo teve zero regressão. **Lookahead 8 permanece.**

## Interpretação

Prefetch é extremamente dependente de microarquitetura, latência de memória, pressão de cache e distância temporal. O ambiente local desta busca é AMD EPYC virtualizado e não é o Intel 12th-gen Windows alvo. Por isso estes resultados são usados apenas como filtro de rejeição; não são evidência para promover algo no PC alvo.

Como nenhum candidato sobreviveu nem ao filtro local de zero regressão, não há motivo técnico para executar um gate de promoção Windows para uma V3 nesta rodada.

## Estado final

**V0 PREFETCH V2 SAFE — PROMOTED BASELINE UNCHANGED.**

Nada foi instalado, nenhum serviço foi alterado e V0 Global não foi tocado.

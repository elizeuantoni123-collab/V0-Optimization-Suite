﻿$ErrorActionPreference = "Stop"
$ServiceName = "V0DecisionV8"
$RegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
$svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if (-not $svc) { throw "Servico nao instalado. Rode INSTALAR_E_ATIVAR_PERMANENTE.ps1 primeiro." }
Set-Service -Name $ServiceName -StartupType Automatic
if (Test-Path $RegistryPath) {
    Set-ItemProperty -Path $RegistryPath -Name DelayedAutoStart -Type DWord -Value 1
}
$svc = Get-Service -Name $ServiceName
if ($svc.Status -ne 'Running') { Start-Service -Name $ServiceName }
(Get-Service -Name $ServiceName).WaitForStatus('Running', [TimeSpan]::FromSeconds(10))
& (Join-Path $PSScriptRoot "CLIENTE_DECISION_V8.ps1") -Command "PING"
Write-Host "V0 Decision V8 permanente: ATIVO" -ForegroundColor Green

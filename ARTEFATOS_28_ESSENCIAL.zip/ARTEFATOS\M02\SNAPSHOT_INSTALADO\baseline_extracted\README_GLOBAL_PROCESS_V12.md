# V0 Decision V12 Global Process Broker

Camada aditiva sobre a V12 validada. O core do Decision nao foi alterado.

## O que esta camada faz

- mantem **um unico servico residente** (`V0DecisionV8`) por compatibilidade;
- instala um executavel explicitamente novo: `V0DecisionV12GlobalService.exe`;
- descobre continuamente os processos vivos do Windows por PID;
- preserva o pipe `\\.\pipe\V0DecisionV8` e todos os comandos antigos;
- adiciona `VERSION`, `GLOBALSTATUS`, `PIDSTATUS`, `DECIDEPID` e `GATEDECIDEPID`;
- permite que qualquer interceptor/consumidor encaminhe um sinal do Decision associado ao PID correto;
- nao injeta DLL, nao altera memoria de outros processos e nao mata/suspende processos automaticamente.

## O que ela NAO faz

Nao existe uma API user-mode generica capaz de interceptar *toda operacao interna* de todos os processos. Esta versao da cobertura global e **process-aware**, nao um hook universal.

Para enforcement real, a camada deve ser conectada por tipo de recurso:

- arquivo: Windows minifilter;
- rede: Windows Filtering Platform (WFP);
- criacao de processo: callback/controle especifico de processo;
- handles/objetos: mecanismo especifico de Object Manager;
- aplicacoes proprias: chamada direta ao hot path V12.

Esses interceptores precisam definir de onde vem `value`, `cost`, `temperature` e `pinned`; inventar esse mapeamento mudaria a semantica/qualidade do Decision e por isso nao foi feito automaticamente.

## Instalacao

Abra PowerShell como Administrador:

```powershell
Set-Location <pasta-do-pacote>
Set-ExecutionPolicy -Scope Process Bypass -Force
.\INSTALAR_GLOBAL_PROCESS_V12.ps1
.\TESTAR_GLOBAL_PROCESS_V12.ps1
.\STATUS_GLOBAL_PROCESS_V12.ps1
```

## API

```text
PING
VERSION
STATUS
GLOBALSTATUS
PIDSTATUS <pid>
DECIDE <value> <cost> <temp> <pinned>
DECIDEPID <pid> <value> <cost> <temp> <pinned>
GATEDECIDEPID <pid> <value> <gate16>
PLAN
COMPLETE <mode> <ticks> <count>
RESET
```

`DECIDEPID` e `GATEDECIDEPID` recusam PIDs que nao estejam na fotografia global de processos vivos.

## Garantia de escopo

O core V12 e todos os arquivos herdados permanecem presentes. A camada global nao substitui thresholds, LUTs, gate16, preflight ou controlador adaptativo.

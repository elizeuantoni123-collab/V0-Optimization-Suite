#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/V0_COMPRESSION_ABI.h"
extern uint32_t v0_compress_zero_avx2_v10(V0CompressionReq*);
extern uint32_t v0_compress_uniform_avx2_v10(V0CompressionReq*);
extern uint32_t v0_decompress_zero_v2(V0CompressionReq*);
extern uint32_t v0_decompress_uniform_v3(V0CompressionReq*);
extern uint32_t v0_decompress_zero_canonical_sse2_v12(V0CompressionReq*);
extern uint32_t v0_decompress_uniform_canonical_sse2_v12(V0CompressionReq*);
static uint64_t st=0xD1B54A32D192ED03ULL; static uint32_t R(void){st^=st<<7;st^=st>>9;st^=st<<8;return(uint32_t)st;}
static int one(uint32_t n,uint8_t v,uint64_t*checks){
 uint8_t *raw=malloc(n+128),*cmp=malloc(n+128),*a=malloc(n+128),*b=malloc(n+128); if(!raw||!cmp||!a||!b)return 90;
 memset(raw,v,n); V0CompressionReq c={raw,cmp,n,n+64,0,0}; uint32_t ok=v?v0_compress_uniform_avx2_v10(&c):v0_compress_zero_avx2_v10(&c); if(!ok)return 91;
 memset(a,0xcc,n+64);memset(b,0xcc,n+64); V0CompressionReq q1={cmp,a,c.out_len,n+64,0,n},q2={cmp,b,c.out_len,n+64,0,n};
 uint32_t x=v?v0_decompress_uniform_v3(&q1):v0_decompress_zero_v2(&q1); uint32_t y=v?v0_decompress_uniform_canonical_sse2_v12(&q2):v0_decompress_zero_canonical_sse2_v12(&q2); *checks+=5;
 if(x!=y||q1.out_len!=q2.out_len||!x||memcmp(a,b,n)||memcmp(a,raw,n)) return 1;
 // expected mismatch
 q2.out_len=77;q2.expected_len=n+1; if((v?v0_decompress_uniform_canonical_sse2_v12(&q2):v0_decompress_zero_canonical_sse2_v12(&q2))||q2.out_len){return 2;} *checks+=2;
 // corrupt a full pair when possible
 if(c.out_len>=4){uint8_t save=cmp[0];cmp[0]=254;q2=(V0CompressionReq){cmp,b,c.out_len,n+64,0,n}; if(v?v0_decompress_uniform_canonical_sse2_v12(&q2):v0_decompress_zero_canonical_sse2_v12(&q2)) return 3;cmp[0]=save;*checks+=2;}
 free(raw);free(cmp);free(a);free(b);return 0;
}
int main(){uint64_t checks=0,cases=0;uint32_t ds[]={256,384,512,768,1024,1536,2048,4096,8192,16384,32768,65536};for(int z=0;z<2;z++)for(size_t i=0;i<sizeof(ds)/sizeof(ds[0]);i++){int r=one(ds[i],z?0x7f:0,&checks);cases++;if(r){printf("FAIL directed r=%d n=%u z=%d\n",r,ds[i],z);return r;}}
 for(uint32_t t=0;t<500000;t++){uint32_t n=256+R()%(65536-255);uint8_t v=(R()&1)?0:(uint8_t)(1+R()%255);int r=one(n,v,&checks);cases++;if(r){printf("FAIL random r=%d t=%u n=%u v=%u\n",r,t,n,v);return r;}}
 printf("PASS V12 canonical SSE2 checks=%llu cases=%llu\n",(unsigned long long)checks,(unsigned long long)cases);}

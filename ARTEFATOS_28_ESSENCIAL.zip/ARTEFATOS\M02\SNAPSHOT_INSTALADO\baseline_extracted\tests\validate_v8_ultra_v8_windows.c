#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_bandwidth_v8.h"

#define CHUNK 4096u
#define TOTAL 10000000u

static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int verify(const uint16_t*v,const uint16_t*c,const uint16_t*b,const uint8_t*t,const uint8_t*p,
                  const v0_decision_signal_v7_t*sig,const v0_decision_meta8_v8_t*meta,
                  uint8_t*out,uint8_t*ref,size_t n){
    size_t i;
    for(i=0;i<n;i++) ref[i]=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);
    v0_eval_v8_bias_batch_ultra_v8_avx2_u8(v,c,b,out,n);
    for(i=0;i<n;i++) if(out[i]!=ref[i]){printf("FAIL bias i=%zu got=%u ref=%u\n",i,out[i],ref[i]);return 0;}
    v0_eval_v8_raw_batch_ultra_v8_avx2_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++) if(out[i]!=ref[i]){printf("FAIL raw i=%zu got=%u ref=%u\n",i,out[i],ref[i]);return 0;}
    v0_eval_v8_signal_batch_ultra_v8_avx2_u8(sig,out,n);
    for(i=0;i<n;i++) if(out[i]!=ref[i]){printf("FAIL aos i=%zu got=%u ref=%u\n",i,out[i],ref[i]);return 0;}
    v0_eval_v8_meta8_batch_avx2_u8(v,c,meta,out,n);
    for(i=0;i<n;i++) if(out[i]!=ref[i]){printf("FAIL meta8 i=%zu got=%u ref=%u\n",i,out[i],ref[i]);return 0;}
    memset(out,0,(n+1)/2+32);
    v0_eval_v8_bias_batch_ultra_v8_avx2_nibble(v,c,b,out,n);
    for(i=0;i<n;i++){uint8_t x=out[i>>1];uint8_t got=(i&1)?(uint8_t)(x>>4):(uint8_t)(x&15u);if(got!=ref[i]){printf("FAIL nibble i=%zu got=%u ref=%u\n",i,got,ref[i]);return 0;}}
    {
        uint64_t got=v0_preflight_v8_raw_count_ultra_v8_avx2(v,c,t,p,n),want=0;
        for(i=0;i<n;i++) want+=(ref[i]!=0);
        if(got!=want){printf("FAIL preflight got=%llu ref=%llu\n",(unsigned long long)got,(unsigned long long)want);return 0;}
    }
    return 1;
}
int main(void){
    uint16_t *v=(uint16_t*)_aligned_malloc(CHUNK*2,64),*c=(uint16_t*)_aligned_malloc(CHUNK*2,64),*b=(uint16_t*)_aligned_malloc(CHUNK*2,64);
    uint8_t *t=(uint8_t*)_aligned_malloc(CHUNK,64),*p=(uint8_t*)_aligned_malloc(CHUNK,64),*out=(uint8_t*)_aligned_malloc(CHUNK+64,64),*ref=(uint8_t*)_aligned_malloc(CHUNK+64,64);
    v0_decision_meta8_v8_t *meta=(v0_decision_meta8_v8_t*)_aligned_malloc(CHUNK,64);
    v0_decision_signal_v7_t *sig=(v0_decision_signal_v7_t*)_aligned_malloc(CHUNK*sizeof(*sig),64);
    uint64_t r=0xA0761D6478BD642FULL; unsigned done=0; size_t i,n;
    if(!v||!c||!b||!t||!p||!out||!ref||!meta||!sig) return 2;
    while(done<TOTAL){
        n=(TOTAL-done)>CHUNK?CHUNK:(TOTAL-done);
        for(i=0;i<n;i++){t[i]=(uint8_t)(rng64(&r)%3u);p[i]=(uint8_t)(rng64(&r)&1u);v[i]=(uint16_t)rng64(&r);c[i]=(uint16_t)rng64(&r);b[i]=v0_decision_v7_bias(t[i],p[i]);meta[i]=v0_decision_v8_meta8(t[i],p[i]);sig[i]=v0_decision_v7_pack(v[i],c[i],t[i],p[i]);}
        if(!verify(v,c,b,t,p,sig,meta,out,ref,n)) return 3;
        done+=(unsigned)n;
    }
    for(n=0;n<=257;n++){
        for(i=0;i<n;i++){t[i]=(uint8_t)(rng64(&r)%3u);p[i]=(uint8_t)(rng64(&r)&1u);v[i]=(uint16_t)rng64(&r);c[i]=(uint16_t)rng64(&r);b[i]=v0_decision_v7_bias(t[i],p[i]);meta[i]=v0_decision_v8_meta8(t[i],p[i]);sig[i]=v0_decision_v7_pack(v[i],c[i],t[i],p[i]);}
        if(!verify(v,c,b,t,p,sig,meta,out,ref,n)) return 4;
    }
    printf("V0 Decision V8 ULTRA V8 Windows AVX2 validation PASS\n");
    printf("random signals: %u, divergences: 0\n",TOTAL);
    printf("tails 0..257: PASS\n");
    printf("bias/raw/AoS/meta8/nibble/preflight: PASS\n");
    _aligned_free(v);_aligned_free(c);_aligned_free(b);_aligned_free(t);_aligned_free(p);_aligned_free(out);_aligned_free(ref);_aligned_free(meta);_aligned_free(sig);
    return 0;
}

#ifndef V0_EXTERNAL_MEMORY_CLIENT_V5_H
#define V0_EXTERNAL_MEMORY_CLIENT_V5_H
#include <stdint.h>
#ifdef _WIN32
  #ifdef V0X_EXPORTS
    #define V0X_API __declspec(dllexport)
  #else
    #define V0X_API __declspec(dllimport)
  #endif
#else
  #define V0X_API
#endif
#ifdef __cplusplus
extern "C" {
#endif
typedef struct V0XStatsV5 {
    uint64_t puts, gets, exists_calls, removes;
    uint64_t bytes_in, bytes_out;
    uint64_t arena_used, arena_capacity;
    uint32_t live;
    uint32_t parity_errors;
} V0XStatsV5;

V0X_API uint32_t v0x_put_v5(uint32_t id, const void *data, uint32_t len);
V0X_API uint32_t v0x_get_v5(uint32_t id, void *out, uint32_t out_capacity, uint32_t *out_len);
V0X_API uint32_t v0x_exists_v5(uint32_t id);
V0X_API uint32_t v0x_remove_v5(uint32_t id);
V0X_API uint32_t v0x_stats_v5(V0XStatsV5 *out_stats);

V0X_API uint32_t v0x_get_batch_v9(
    const uint32_t *ids, uint32_t count,
    void *out_buffer, uint32_t out_capacity,
    uint32_t *out_offsets, uint32_t *out_lens);
V0X_API uint32_t v0x_select_batch_v9(uint32_t payload_len);

#ifdef __cplusplus
}
#endif
#endif

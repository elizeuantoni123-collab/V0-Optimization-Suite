#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_ultra_v10.h"

#define CHUNK (1u<<20)
#define ROUNDS 20
#define PAD 320

static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint64_t checked=0,bad=0;
static void fail(const char*tag,size_t i,uint32_t got,uint32_t ref){if(bad<16)fprintf(stderr,"FAIL %s i=%zu got=%u ref=%u\n",tag,i,got,ref);bad++;}

static int check(const uint16_t*v,const uint16_t*c,const uint8_t*t,const uint8_t*p,
                 uint16_t*gate,uint8_t*out,uint8_t*ref,size_t n){
    size_t i; uint64_t want_pre=0;
    for(i=0;i<n;i++){
        ref[i]=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);
        want_pre+=(uint64_t)(ref[i]>>2);
    }
#if defined(__AVX2__) || defined(_M_AVX2)
    memset(out,0xA5,n+64);
    v0_eval_v10_raw_batch_avx2_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i])fail("v10-raw-avx2",i,out[i],ref[i]);

    memset(out,0xA5,n+64);
    v0_eval_v8_raw_batch_ultra_v9_avx2_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i])fail("v9-regression-avx2",i,out[i],ref[i]);

    v0_build_gate16_batch_v10_avx2(c,t,p,gate,n);
    for(i=0;i<n;i++){
        const uint16_t gs=v0_decision_gate16_v10(c[i],t[i],p[i]);
        if(gate[i]!=gs)fail("gate16-build-avx2",i,gate[i],gs);
    }
    memset(out,0xA5,n+64);
    v0_eval_gate16_batch_v10_avx2_u8(v,gate,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i])fail("gate16-eval-avx2",i,out[i],ref[i]);
    if (n >= 256) {
        memset(out,0xA5,n+64);
        v0_eval_gate16_batch_v10_stream_avx2_u8(v,gate,out,n);
        for(i=0;i<n;i++)if(out[i]!=ref[i])fail("gate16-stream-avx2",i,out[i],ref[i]);
    }
    {
        uint64_t got=v0_preflight_gate16_count_v10_avx2(v,gate,n);
        if(got!=want_pre)fail("gate16-pre-avx2",0,(uint32_t)got,(uint32_t)want_pre);
    }
    {
        uint64_t got=v0_preflight_v8_raw_count_ultra_v9_avx2(v,c,t,p,n);
        if(got!=want_pre)fail("v9-pre-regression",0,(uint32_t)got,(uint32_t)want_pre);
    }
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
    memset(out,0xA5,n+64);
    v0_eval_v10_raw_batch_avx512vl_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i])fail("v10-raw-avx512vl",i,out[i],ref[i]);

    v0_build_gate16_batch_v10_avx512(c,t,p,gate,n);
    for(i=0;i<n;i++){
        const uint16_t gs=v0_decision_gate16_v10(c[i],t[i],p[i]);
        if(gate[i]!=gs)fail("gate16-build-avx512",i,gate[i],gs);
    }
    memset(out,0xA5,n+64);
    v0_eval_gate16_batch_v10_avx2_u8(v,gate,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i])fail("gate16-eval-native",i,out[i],ref[i]);
    {
        uint64_t got=v0_preflight_gate16_count_v10_avx512(v,gate,n);
        if(got!=want_pre)fail("gate16-pre-avx512",0,(uint32_t)got,(uint32_t)want_pre);
    }
#endif
    checked+=n;
    return bad?1:0;
}

int main(void){
    uint16_t *v,*c,*gate;uint8_t*t,*p,*out,*ref;uint64_t s=0x9e3779b97f4a7c15ULL;size_t i,n;
    if(posix_memalign((void**)&v,64,(CHUNK+PAD)*2)||
       posix_memalign((void**)&c,64,(CHUNK+PAD)*2)||
       posix_memalign((void**)&gate,64,(CHUNK+PAD)*2)||
       posix_memalign((void**)&t,64,CHUNK+PAD)||
       posix_memalign((void**)&p,64,CHUNK+PAD)||
       posix_memalign((void**)&out,64,CHUNK+PAD+64)||
       posix_memalign((void**)&ref,64,CHUNK+PAD+64))return 2;

    for(unsigned r=0;r<ROUNDS && !bad;r++){
        for(i=0;i<CHUNK;i++){
            v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);
            t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);
        }
        check(v,c,t,p,gate,out,ref,CHUNK);
    }

    /* Directed neighborhoods around every Decision boundary. */
    {
        static const int th[]={0,64,192,384};
        static const uint16_t costs[]={0,1,2,3,63,64,65,127,128,255,256,1023,32767,32768,65534,65535};
        n=0;
        for(unsigned ti=0;ti<3;ti++)for(unsigned pi=0;pi<2;pi++)
        for(size_t ci=0;ci<sizeof(costs)/sizeof(costs[0]);ci++){
            int h=(int)(costs[ci]>>1);int bias=(int)v0_decision_v7_bias((uint8_t)ti,(uint8_t)pi);
            for(size_t k=0;k<sizeof(th)/sizeof(th[0]);k++)for(int d=-4;d<=4;d++){
                int x=th[k]+d+h-bias;
                if(x>=0&&x<=65535&&n<CHUNK){
                    v[n]=(uint16_t)x;c[n]=costs[ci];t[n]=(uint8_t)ti;p[n]=(uint8_t)pi;n++;
                }
            }
        }
        check(v,c,t,p,gate,out,ref,n);
    }

    /* Exhaust value domain for representative cost/temp/pinned combinations. */
    {
        static const uint16_t costs[]={0,1,64,255,1023,32768,65535};
        for(size_t ci=0;ci<sizeof(costs)/sizeof(costs[0]) && !bad;ci++)
        for(unsigned ti=0;ti<3 && !bad;ti++)for(unsigned pi=0;pi<2 && !bad;pi++){
            n=65536;
            for(i=0;i<n;i++){v[i]=(uint16_t)i;c[i]=costs[ci];t[i]=(uint8_t)ti;p[i]=(uint8_t)pi;}
            check(v,c,t,p,gate,out,ref,n);
        }
    }

    /* Every tail length, including less than one vector and unroll boundary. */
    for(n=0;n<=257 && !bad;n++){
        for(i=0;i<n;i++){
            v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);
            t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);
        }
        check(v,c,t,p,gate,out,ref,n);
    }

    printf("checked=%llu divergences=%llu\n",(unsigned long long)checked,(unsigned long long)bad);
    printf("status=%s\n",bad?"FAIL":"PASS");
    return bad?3:0;
}

#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sched.h>
#include <x86intrin.h>
#include <unistd.h>
#include <inttypes.h>

typedef uint32_t (*fn_t)(void*,uint32_t);
uint32_t v0_batch_plan64_avx2_quadload_v27(void*,uint32_t);
uint32_t cand_unroll_1024(void*,uint32_t);
uint32_t cand_unroll_2048(void*,uint32_t);
uint32_t cand_unroll_3072(void*,uint32_t);
uint32_t cand_unroll_4096(void*,uint32_t);

static inline uint64_t t0(){unsigned a,d; __asm__ volatile("lfence; rdtsc":"=a"(a),"=d"(d)::"memory"); return ((uint64_t)d<<32)|a;}
static inline uint64_t t1(){unsigned a,d; __asm__ volatile("rdtscp":"=a"(a),"=d"(d)::"rcx","memory"); __asm__ volatile("lfence":::"memory"); return ((uint64_t)d<<32)|a;}
static int cmpd(const void*a,const void*b){double x=*(double*)a,y=*(double*)b; return (x>y)-(x<y);} 
static double med(double*a,int n){qsort(a,n,sizeof(double),cmpd);return a[n/2];}

static void ref(void*out,uint32_t items){uint32_t *p=(uint32_t*)out; uint32_t n=items/64; for(uint32_t i=0;i<n;i++){p[2*i]=i*64;p[2*i+1]=64;}}
int main(int argc,char**argv){
 cpu_set_t set; CPU_ZERO(&set); CPU_SET(0,&set); sched_setaffinity(0,sizeof(set),&set);
 uint32_t items=argc>1?atoi(argv[1]):1024; int off=argc>2?atoi(argv[2]):0;
 fn_t cand=items==1024?cand_unroll_1024:items==2048?cand_unroll_2048:items==3072?cand_unroll_3072:cand_unroll_4096;
 void *raw1,*raw2,*rawr; posix_memalign(&raw1,64,2048);posix_memalign(&raw2,64,2048);posix_memalign(&rawr,64,2048);
 unsigned char *a=(unsigned char*)raw1+off,*b=(unsigned char*)raw2+off,*r=(unsigned char*)rawr+off;
 memset(raw1,0xCC,2048); memset(raw2,0xCC,2048); memset(rawr,0xCC,2048); ref(r,items);
 uint32_t na=v0_batch_plan64_avx2_quadload_v27(a,items), nb=cand(b,items);
 size_t bytes=(items/64)*8;
 if(na!=items/64||nb!=items/64||memcmp(a,r,bytes)||memcmp(b,r,bytes)){fprintf(stderr,"BAD correctness n=%u/%u\n",na,nb);return 2;}
 volatile uint64_t sink=0; const int rounds=31; const int iters=200000; double ba[rounds], ca[rounds];
 for(int w=0;w<10000;w++){sink+=v0_batch_plan64_avx2_quadload_v27(a,items); sink+=cand(b,items);} 
 for(int k=0;k<rounds;k++){
   uint64_t x0,x1; double bv,cv;
   if(k&1){x0=t0();for(int i=0;i<iters;i++)sink+=cand(b,items);x1=t1();cv=(double)(x1-x0)/iters; x0=t0();for(int i=0;i<iters;i++)sink+=v0_batch_plan64_avx2_quadload_v27(a,items);x1=t1();bv=(double)(x1-x0)/iters;}
   else {x0=t0();for(int i=0;i<iters;i++)sink+=v0_batch_plan64_avx2_quadload_v27(a,items);x1=t1();bv=(double)(x1-x0)/iters; x0=t0();for(int i=0;i<iters;i++)sink+=cand(b,items);x1=t1();cv=(double)(x1-x0)/iters;}
   ba[k]=bv;ca[k]=cv;
 }
 double mb=med(ba,rounds),mc=med(ca,rounds); printf("items=%u off=%d baseline=%.3f cand=%.3f speed=%.6f sink=%"PRIu64"\n",items,off,mb,mc,mb/mc,(uint64_t)sink);
 return 0;
}

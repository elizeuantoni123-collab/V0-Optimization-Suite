#ifndef V0_DECISION_V7_H
#define V0_DECISION_V7_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct v0_decision_signal_v7 {
    uint32_t value_cost; /* low16=value, high16=raw cost */
    uint16_t bias;       /* temp bonus + pinned override */
    uint16_t reserved;
} v0_decision_signal_v7_t;

static inline uint32_t v0_decision_v7_value_cost(uint16_t value, uint16_t cost) {
    return ((uint32_t)cost << 16) | (uint32_t)value;
}

/*
 * Branchless exact encoding for the valid domain:
 * temperature: 0=COLD, 1=WARM, 2=HOT -> 0,64,192
 * pinned: 0/1 -> +0/+33151
 *
 * (t + (t >> 1)) << 6 maps 0/1/2 exactly to 0/64/192.
 */
static inline uint16_t v0_decision_v7_bias(uint8_t temperature, uint8_t pinned) {
    const uint32_t t = (uint32_t)temperature;
    return (uint16_t)(((t + (t >> 1)) << 6) + ((uint32_t)pinned * 33151u));
}

static inline v0_decision_signal_v7_t v0_decision_v7_pack(
    uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    v0_decision_signal_v7_t s;
    s.value_cost = v0_decision_v7_value_cost(value, cost);
    s.bias = v0_decision_v7_bias(temperature, pinned);
    s.reserved = 0u;
    return s;
}

/* 0=DROP_CALL, 1=EXECUTE_CALL */
uint32_t v0_preflight_v0l_v7(const v0_decision_signal_v7_t *signal);
/* 0=DROP, 1=KEEP_BACKING_ONLY, 2=KEEP_METADATA, 3=KEEP_ACTIVE */
uint32_t v0_decide_v0l_v7(const v0_decision_signal_v7_t *signal);

#ifdef __cplusplus
}
#endif
#endif

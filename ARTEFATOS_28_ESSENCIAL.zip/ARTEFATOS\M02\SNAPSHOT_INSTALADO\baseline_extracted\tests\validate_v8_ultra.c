#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_fast.h"
#include "../include/v0_decision_v8_extreme.h"

static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}

static int check_score(int32_t score) {
    const int16_t q = v0_decision_v8_q6_from_score(score);
    const uint32_t ref = v0_eval_v8_inline(score);
    const uint32_t oldq = v0_eval_v8_q6_extreme_inline(q);
    const uint32_t hot = v0_eval_v8_q6_hot_lut_inline(q);
    const uint8_t e3 = v0_decision_v8_e3_from_q6(q);
    if (oldq != ref || hot != ref || e3 != ref ||
        v0_e3_v8_preflight(e3) != v0_eval_v8_preflight(ref) ||
        v0_e3_v8_decision(e3) != v0_eval_v8_decision(ref)) {
        fprintf(stderr,"score mismatch s=%d q=%d ref=%u oldq=%u hot=%u e3=%u\n",
                score,(int)q,ref,oldq,hot,(unsigned)e3);
        return 1;
    }
    return 0;
}

static int check_batch(const int16_t *q, const int32_t *score, size_t n) {
    uint8_t *a=(uint8_t*)malloc(n?n:1), *b=(uint8_t*)malloc(n?n:1);
    if(!a||!b) return 90;
    memset(a,0xA5,n); memset(b,0x5A,n);
    v0_eval_v8_q6_batch_scalar_u8(q,a,n);
#if defined(__AVX2__) || defined(_M_AVX2)
    v0_eval_v8_q6_batch_ultra_avx2_u8(q,b,n);
#else
    v0_eval_v8_q6_batch_scalar_u8(q,b,n);
#endif
    for(size_t i=0;i<n;i++) {
        uint8_t ref=(uint8_t)v0_eval_v8_inline(score[i]);
        if(a[i]!=ref || b[i]!=ref) {
            fprintf(stderr,"batch mismatch n=%zu i=%zu ref=%u old=%u ultra=%u\n",n,i,ref,a[i],b[i]);
            free(a); free(b); return 91;
        }
    }
#if defined(__AVX2__) || defined(_M_AVX2)
    {
        uint64_t cref=0;
        for(size_t i=0;i<n;i++) cref += (uint64_t)(q[i]>=0);
        uint64_t cold=v0_preflight_v8_q6_count_avx2(q,n);
        if(cref!=cold) {
            fprintf(stderr,"count mismatch n=%zu ref=%llu old=%llu\n",n,
                (unsigned long long)cref,(unsigned long long)cold);
            free(a);free(b);return 92;
        }
    }
#endif
    free(a); free(b); return 0;
}

int main(void){
    uint64_t exhaustive=0, random_checked=0;
    for(int32_t s=-32767;s<=98878;s++){ if(check_score(s)) return 2; exhaustive++; }

    enum { N=131646 };
    int16_t *q=(int16_t*)malloc(N*sizeof(*q));
    int32_t *score=(int32_t*)malloc(N*sizeof(*score));
    if(!q||!score) return 3;
    for(int i=0;i<N;i++){score[i]=-32767+i;q[i]=v0_decision_v8_q6_from_score(score[i]);}
    {
        static const size_t lens[]={0,1,2,7,15,16,17,31,32,33,63,64,65,127,128,129,511,512,513,N};
        for(size_t k=0;k<sizeof(lens)/sizeof(lens[0]);k++){int r=check_batch(q,score,lens[k]);if(r)return r;}
    }

#if defined(__AVX2__) || defined(_M_AVX2)
    {
        enum { RN=131073 };
        uint16_t *rv=(uint16_t*)malloc(RN*sizeof(uint16_t));
        uint16_t *rc=(uint16_t*)malloc(RN*sizeof(uint16_t));
        uint8_t *rt=(uint8_t*)malloc(RN), *rp=(uint8_t*)malloc(RN), *ro=(uint8_t*)malloc(RN);
        uint64_t rs=0xA55A1234DEADBEEFULL;
        if(!rv||!rc||!rt||!rp||!ro) return 93;
        for(size_t i=0;i<RN;i++){rv[i]=(uint16_t)rng64(&rs);rc[i]=(uint16_t)rng64(&rs);rt[i]=(uint8_t)(rng64(&rs)%3u);rp[i]=(uint8_t)(rng64(&rs)&1u);}
        {
            uint64_t cref=0;
            for(size_t i=0;i<RN;i++) cref += (uint64_t)(v0_eval_v8_raw_ultra_inline(rv[i],rc[i],rt[i],rp[i]) >> 2);
            { uint64_t got=v0_preflight_v8_raw_count_avx2(rv,rc,rt,rp,RN); if(got!=cref){fprintf(stderr,"raw AVX2 preflight count mismatch ref=%llu got=%llu\n",(unsigned long long)cref,(unsigned long long)got);return 98;} }
            for(size_t i=0;i+16<=RN;i+=16){uint32_t m=v0_preflight_v8_raw_mask16_avx2(rv+i,rc+i,rt+i,rp+i);for(unsigned k=0;k<16;k++){uint32_t ref=(uint32_t)(v0_eval_v8_raw_ultra_inline(rv[i+k],rc[i+k],rt[i+k],rp[i+k])>>2);if(((m>>k)&1u)!=ref){fprintf(stderr,"raw AVX2 preflight mask mismatch i=%zu k=%u\n",i,k);return 99;}}}
#if defined(__AVX512BW__) && defined(__AVX512VL__)
            { uint64_t got=v0_preflight_v8_raw_count_avx512(rv,rc,rt,rp,RN); if(got!=cref){fprintf(stderr,"raw AVX512 preflight count mismatch ref=%llu got=%llu\n",(unsigned long long)cref,(unsigned long long)got);return 100;} }
            for(size_t i=0;i+32<=RN;i+=32){uint32_t m=v0_preflight_v8_raw_mask32_avx512(rv+i,rc+i,rt+i,rp+i);for(unsigned k=0;k<32;k++){uint32_t ref=(uint32_t)(v0_eval_v8_raw_ultra_inline(rv[i+k],rc[i+k],rt[i+k],rp[i+k])>>2);if(((m>>k)&1u)!=ref){fprintf(stderr,"raw AVX512 preflight mask mismatch i=%zu k=%u\n",i,k);return 101;}}}
#endif
        }
        v0_eval_v8_raw_batch_ultra_avx2_u8(rv,rc,rt,rp,ro,RN);
        for(size_t i=0;i<RN;i++){uint8_t ref=(uint8_t)v0_eval_v8_raw_ultra_inline(rv[i],rc[i],rt[i],rp[i]);if(ro[i]!=ref){fprintf(stderr,"raw AVX2 batch mismatch i=%zu\n",i);return 94;}}
        memset(ro,0,RN);
        v0_eval_v8_raw_batch_ultra_stream_avx2_u8(rv,rc,rt,rp,ro,RN);
        for(size_t i=0;i<RN;i++){uint8_t ref=(uint8_t)v0_eval_v8_raw_ultra_inline(rv[i],rc[i],rt[i],rp[i]);if(ro[i]!=ref){fprintf(stderr,"raw AVX2 stream mismatch i=%zu\n",i);return 96;}}
#if defined(__AVX512BW__) && defined(__AVX512VL__)
        memset(ro,0,RN);
        v0_eval_v8_raw_batch_ultra_avx512_u8(rv,rc,rt,rp,ro,RN);
        for(size_t i=0;i<RN;i++){uint8_t ref=(uint8_t)v0_eval_v8_raw_ultra_inline(rv[i],rc[i],rt[i],rp[i]);if(ro[i]!=ref){fprintf(stderr,"raw AVX512 batch mismatch i=%zu\n",i);return 95;}}
        memset(ro,0,RN);
        v0_eval_v8_raw_batch_ultra_stream_avx512_u8(rv,rc,rt,rp,ro,RN);
        for(size_t i=0;i<RN;i++){uint8_t ref=(uint8_t)v0_eval_v8_raw_ultra_inline(rv[i],rc[i],rt[i],rp[i]);if(ro[i]!=ref){fprintf(stderr,"raw AVX512 stream mismatch i=%zu\n",i);return 97;}}
#endif
        free(rv);free(rc);free(rt);free(rp);free(ro);
    }
#endif

    uint64_t st=0xD1CEB00C12345678ULL;
    for(uint32_t i=0;i<20000000u;i++){
        uint16_t value=(uint16_t)rng64(&st), cost=(uint16_t)rng64(&st);
        uint8_t temp=(uint8_t)(rng64(&st)%3u), pin=(uint8_t)(rng64(&st)&1u);
        v0_decision_signal_v7_t sig=v0_decision_v7_pack(value,cost,temp,pin);
        int32_t sc=v0_decision_v8_score(value,cost,temp,pin);
        int16_t qq=v0_decision_v8_q6_from_score(sc);
        uint32_t ref=(v0_preflight_v0l_v7(&sig)<<2)|v0_decide_v0l_v7(&sig);
        uint32_t hot=v0_eval_v8_q6_hot_lut_inline(qq);
        uint32_t fused=v0_eval_v0l_v8_signal_lut(&sig);
        uint32_t packed_inline=v0_eval_v8_signal_ultra_inline(&sig);
        uint32_t raw=v0_eval_v8_raw_ultra_inline(value,cost,temp,pin);
        if(hot!=ref || fused!=ref || packed_inline!=ref || raw!=ref){fprintf(stderr,"random mismatch i=%u ref=%u hot=%u fused=%u packed_inline=%u raw=%u\n",i,ref,hot,fused,packed_inline,raw);return 8;}
        random_checked++;
    }

    printf("V8 ULTRA V6 validation PASS\n");
    printf("exhaustive_scores=%llu\n",(unsigned long long)exhaustive);
    printf("random_raw=%llu\n",(unsigned long long)random_checked);
    printf("tail_lengths=20\n");
    printf("divergences=0\n");
    return 0;
}

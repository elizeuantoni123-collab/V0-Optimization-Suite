#ifndef V0_REMAP_ABI_V22_H
#define V0_REMAP_ABI_V22_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct {
    uint32_t source_id, target_id, version, checksum_tag;
    uint32_t rollback_target, rollback_version, rollback_checksum;
    uint32_t guard, rollback_valid;
} v0_remap_desc;
typedef struct {
    uint32_t expected_target, expected_version, expected_checksum;
    uint32_t new_target, new_checksum;
} v0_remap_req;
uint32_t v0_remap_apply4_prechecked_v22(void *desc4, void *req4);
#ifdef __cplusplus
}
#endif
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_ultra_v10.h"
#define CHUNK 4096u
#define TOTAL 10000000u
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int verify(const uint16_t*v,const uint16_t*c,const uint8_t*t,const uint8_t*p,uint16_t*g,uint8_t*out,uint8_t*ref,size_t n){
    size_t i;uint64_t want=0,got;
    for(i=0;i<n;i++){ref[i]=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);want+=(uint64_t)(ref[i]>>2);}
    v0_eval_v10_raw_batch_avx2_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i]){printf("FAIL V10 raw i=%zu got=%u ref=%u\n",i,out[i],ref[i]);return 0;}
    v0_eval_v8_raw_batch_ultra_v9_avx2_u8(v,c,t,p,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i]){printf("FAIL V9 regression i=%zu got=%u ref=%u\n",i,out[i],ref[i]);return 0;}
    v0_build_gate16_batch_v10_avx2(c,t,p,g,n);
    for(i=0;i<n;i++){uint16_t q=v0_decision_gate16_v10(c[i],t[i],p[i]);if(g[i]!=q){printf("FAIL gate build i=%zu got=%u ref=%u\n",i,(unsigned)g[i],(unsigned)q);return 0;}}
    v0_eval_gate16_batch_v10_avx2_u8(v,g,out,n);
    for(i=0;i<n;i++)if(out[i]!=ref[i]){printf("FAIL gate eval i=%zu got=%u ref=%u\n",i,out[i],ref[i]);return 0;}
    got=v0_preflight_gate16_count_v10_avx2(v,g,n);if(got!=want){printf("FAIL gate pre got=%llu ref=%llu\n",(unsigned long long)got,(unsigned long long)want);return 0;}
    got=v0_preflight_v8_raw_count_ultra_v9_avx2(v,c,t,p,n);if(got!=want){printf("FAIL V9 pre regression got=%llu ref=%llu\n",(unsigned long long)got,(unsigned long long)want);return 0;}
    return 1;
}
int main(void){
    uint16_t*v=(uint16_t*)_aligned_malloc(CHUNK*2,64),*c=(uint16_t*)_aligned_malloc(CHUNK*2,64),*g=(uint16_t*)_aligned_malloc(CHUNK*2,64);
    uint8_t*t=(uint8_t*)_aligned_malloc(CHUNK,64),*p=(uint8_t*)_aligned_malloc(CHUNK,64),*out=(uint8_t*)_aligned_malloc(CHUNK+64,64),*ref=(uint8_t*)_aligned_malloc(CHUNK+64,64);
    uint64_t r=0xA0761D6478BD642FULL;unsigned done=0;size_t i,n;
    if(!v||!c||!g||!t||!p||!out||!ref)return 2;
    while(done<TOTAL){n=(TOTAL-done)>CHUNK?CHUNK:(TOTAL-done);for(i=0;i<n;i++){t[i]=(uint8_t)(rng64(&r)%3u);p[i]=(uint8_t)(rng64(&r)&1u);v[i]=(uint16_t)rng64(&r);c[i]=(uint16_t)rng64(&r);}if(!verify(v,c,t,p,g,out,ref,n))return 3;done+=(unsigned)n;}
    for(n=0;n<=257;n++){for(i=0;i<n;i++){t[i]=(uint8_t)(rng64(&r)%3u);p[i]=(uint8_t)(rng64(&r)&1u);v[i]=(uint16_t)rng64(&r);c[i]=(uint16_t)rng64(&r);}if(!verify(v,c,t,p,g,out,ref,n))return 4;}
    printf("V0 Decision V8 ULTRA V10 Windows AVX2 validation PASS\n");
    printf("random signals: %u, divergences: 0\n",TOTAL);
    printf("tails 0..257: PASS\n");
    printf("V10 raw + gate16 build/eval/preflight + V9 regression: PASS\n");
    _aligned_free(v);_aligned_free(c);_aligned_free(g);_aligned_free(t);_aligned_free(p);_aligned_free(out);_aligned_free(ref);return 0;
}

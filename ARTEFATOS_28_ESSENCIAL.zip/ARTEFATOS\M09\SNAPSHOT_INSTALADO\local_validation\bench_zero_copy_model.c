#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sched.h>

static volatile uint64_t sinkv;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static uint64_t consume(const uint8_t*p,size_t n){uint64_t x=1469598103934665603ull;for(size_t i=0;i<n;i+=64){x^=p[i];x*=1099511628211ull;} if(n) x^=p[n-1]; return x;}
static double bench_copy(uint8_t*shm,uint8_t*out,size_t n,int loops){uint64_t t=ns();for(int i=0;i<loops;i++){memcpy(out,shm,n);sinkv^=consume(out,n);}return (double)(ns()-t)/loops;}
static double bench_view(uint8_t*shm,size_t n,int loops){uint64_t t=ns();for(int i=0;i<loops;i++){sinkv^=consume(shm,n);}return (double)(ns()-t)/loops;}

int main(void){
 size_t sizes[]={256*1024,1024*1024,2*1024*1024,4*1024*1024};
 for(int s=0;s<4;s++){
   size_t n=sizes[s]; uint8_t*shm=aligned_alloc(64,n); uint8_t*out=aligned_alloc(64,n);
   if(!shm||!out)return 2; for(size_t i=0;i<n;i++)shm[i]=(uint8_t)(i*131u+7u);
   int loops=n<=256*1024?1200:n<=1024*1024?400:n<=2*1024*1024?220:120;
   double ratios[11];
   for(int r=0;r<11;r++){double a,b;if(r&1){b=bench_view(shm,n,loops);a=bench_copy(shm,out,n,loops);}else{a=bench_copy(shm,out,n,loops);b=bench_view(shm,n,loops);}ratios[r]=a/b;}
   // sort
   for(int i=0;i<11;i++)for(int j=i+1;j<11;j++)if(ratios[j]<ratios[i]){double x=ratios[i];ratios[i]=ratios[j];ratios[j]=x;}
   printf("BYTES=%zu MED=%.6f MIN=%.6f P25=%.6f MAX=%.6f\n",n,ratios[5],ratios[0],ratios[2],ratios[10]);
   free(shm);free(out);
 }
 fprintf(stderr,"sink=%llu\n",(unsigned long long)sinkv);
 return 0;
}

#include <immintrin.h>
#include <stdint.h>
#include <stddef.h>
#if defined(__GNUC__)
#define AVX2 __attribute__((target("avx2"),noinline))
#else
#define AVX2 __declspec(noinline)
#endif
AVX2 size_t v0_traffic_transfer_256_v7(const void*base,size_t source_bytes,uint32_t selected_index,uint32_t candidate_count,size_t stride,void*dst,size_t dst_capacity){
    if(!base||!dst||!candidate_count||selected_index>=candidate_count||256>dst_capacity) return 0;
    if(stride && (size_t)selected_index>SIZE_MAX/stride) return 0;
    size_t off=(size_t)selected_index*stride;
    if(off>source_bytes || 256>source_bytes-off) return 0;
    const unsigned char*s=(const unsigned char*)base+off; unsigned char*d=(unsigned char*)dst;
    for(size_t i=0;i<256;i+=32){__m256i x=_mm256_loadu_si256((const __m256i*)(s+i));_mm256_storeu_si256((__m256i*)(d+i),x);} _mm256_zeroupper(); return 256;
}

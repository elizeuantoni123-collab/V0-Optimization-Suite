#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/build/linux"
python "$ROOT/compiler/v0lc_count.py" "$ROOT/src/v0_batch_count.v0l" "$ROOT/build/linux/v0_batch_count.o"
python "$ROOT/compiler/v0lc_primitives.py" "$ROOT/src/v0_batch_take.v0l" "$ROOT/build/linux/v0_batch_take.o"
python "$ROOT/compiler/v0lc_primitives.py" "$ROOT/src/v0_batch_fixed64.v0l" "$ROOT/build/linux/v0_batch_fixed64.o"
python "$ROOT/compiler/v0lc_plan64.py" "$ROOT/src/v0_batch_plan64.v0l" "$ROOT/build/linux/v0_batch_plan64.o"
python "$ROOT/compiler/v0lc_plan64x4.py" "$ROOT/src/v0_batch_plan64x4.v0l" "$ROOT/build/linux/v0_batch_plan64x4.o"
echo "Linux objects rebuilt."

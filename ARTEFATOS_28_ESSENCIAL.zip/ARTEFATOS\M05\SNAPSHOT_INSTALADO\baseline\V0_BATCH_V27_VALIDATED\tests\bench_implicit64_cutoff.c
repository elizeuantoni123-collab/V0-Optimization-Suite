#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../include/v0_batch.h"
#if defined(__GNUC__)
#define NOINLINE __attribute__((noinline))
#else
#define NOINLINE
#endif
static volatile uint64_t sink;
static inline uint64_t mix(uint64_t a,uint32_t s,uint32_t c){a^=((uint64_t)s<<32)|c;a^=a<<13;a^=a>>7;a^=a<<17;return a;}
static NOINLINE uint64_t mat(v0_batch_span*b,uint32_t n,uint32_t reps){uint64_t a=0x123456789abcdef0ULL;for(uint32_t r=0;r<reps;r++){uint32_t k=n<=256?v0_batch_plan64(b,n):v0_batch_plan64x4(b,n);for(uint32_t i=0;i<k;i++)a=mix(a,b[i].start,b[i].count);}sink^=a;return a;}
static NOINLINE uint64_t imp(uint32_t n,uint32_t reps){uint64_t a=0x123456789abcdef0ULL;for(uint32_t r=0;r<reps;r++){uint32_t f=n>>6,t=n&63u;for(uint32_t i=0;i<f;i++)a=mix(a,i<<6,64);if(t)a=mix(a,f<<6,t);}sink^=a;return a;}
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static int cmp(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}static double med(double*x,int n){qsort(x,n,sizeof(*x),cmp);return x[n/2];}
int main(void){const uint32_t sz[]={1024,1536,2048,2560,3072,3584,4096,5120,6144,8192,12288,16384};enum{R=21};v0_batch_span*b;posix_memalign((void**)&b,64,300*sizeof(*b));puts("items,spans,mat_ns,imp_ns,speedup");for(unsigned q=0;q<sizeof(sz)/sizeof(sz[0]);q++){uint32_t n=sz[q],k=v0_batch_count64(n),reps=6000000u/k;if(reps<2000)reps=2000;if(reps>100000)reps=100000;double A[R],B[R];mat(b,n,100);imp(n,100);for(int r=0;r<R;r++){uint64_t t0,t1,t2;if(r&1){t0=ns();imp(n,reps);t1=ns();mat(b,n,reps);t2=ns();B[r]=(double)(t1-t0)/reps;A[r]=(double)(t2-t1)/reps;}else{t0=ns();mat(b,n,reps);t1=ns();imp(n,reps);t2=ns();A[r]=(double)(t1-t0)/reps;B[r]=(double)(t2-t1)/reps;}}double a=med(A,R),c=med(B,R);printf("%u,%u,%.3f,%.3f,%.4f\n",n,k,a,c,a/c);}free(b);fprintf(stderr,"sink=%llu\n",(unsigned long long)sink);}

# Artefato 2 — V0 Decision V8 — V13 Squeeze Candidate

## Baseline
V0 Decision V8 ULTRA V12 GLOBAL PROCESS FIX1. A baseline permanece intacta dentro de `baseline/`.

## Candidato novo
Somente o **construtor `gate16`** foi alterado. Em vez de reconstruir o bonus de temperatura por aritmetica, V13 usa uma tabela exata de 3 entradas: `0x8000, 0x8040, 0x80c0` e preserva o mesmo OR branchless de `pinned`.

O evaluator V12 de LUT direta 2 KiB foi retestado contra alternativas sem LUT/tiny-LUT e permaneceu superior. Nenhum caminho SIMD/raw herdado foi alterado.

## Correcao
- Exaustivo: todos os `65536 cost x 3 temperature x 2 pinned`.
- Aleatorio adicional: 20.000.000 casos.
- Total: **20.393.216 casos**.
- Divergencias: **0**.

## Screening local (nao e promocao Windows)
9 perfis separados de pinned/temperature. Speedup mediano por perfil:
- minimo: **1.5442x**
- maximo: **1.7648x**
- mediana dos 9 perfis: **1.6674x**

Todos os 9 perfis tiveram mediana positiva. O gate final deve ser repetido no Intel/Windows alvo antes de promover.

## Estado
**LOCAL_PASS / WINDOWS_GATE_REQUIRED**.

Nao instalar automaticamente. `windows/RUN_WINDOWS_GATE.ps1` compila baseline e candidato em executaveis separados e mede 9 perfis; nao altera servicos nem instala o candidato.

# V0 Batch V11 VALIDATED

Módulo de batching isolado em V0L. O hot path é V0L compilado diretamente para x86-64. C aparece apenas nos harnesses de validação.

## Estado aceito

- `v0_batch_count`: V2, cálculo genérico O(1), preservado porque venceu a versão iterativa sem divergências.
- `v0_batch_take`: V3 branch path, preservado porque tentativas posteriores não ganharam sem regressão.
- `v0_batch_count64` / `v0_batch_take64`: V3 fixed-64.
- `v0_batch_plan64`: V6, planner completo que grava `{start,count}`.
- `v0_batch_plan64x4`: V11, acelerador packed 64-bit + unroll 4x para planos grandes.

O V0 Global não é dependência deste pacote e não é modificado.

## ABI

Veja `include/v0_batch.h`.

Para `v0_batch_plan64*`, o chamador deve fornecer capacidade de pelo menos `v0_batch_count64(items)` spans. Com `items == 0`, nenhuma escrita é feita.

## Escolha do planner

No host de validação, `v0_batch_plan64` venceu até 256 itens e o V11 packed x4 venceu em todos os pontos medidos a partir de 257. Esse cutoff é microarquitetura-dependente; portanto o pacote não injeta dispatch automático. Preserve `v0_batch_plan64` como fallback e habilite o x4 após benchmark no host alvo.

## Build

Linux: `./BUILD_LINUX.sh`

Windows PowerShell: `./BUILD_WINDOWS.ps1`

Objetos pré-compilados já estão em `build/linux` e `build/windows`.

## Critério de promoção

Uma mudança só foi promovida quando manteve a saída exata e não mostrou regressão no caminho para o qual foi promovida. Tentativas mistas ficaram fora do runtime aceito. Veja `reports/ACCEPTANCE_REPORT.md`.

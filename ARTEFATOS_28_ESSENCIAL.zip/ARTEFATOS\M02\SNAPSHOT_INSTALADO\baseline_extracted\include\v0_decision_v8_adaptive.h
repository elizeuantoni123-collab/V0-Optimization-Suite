#ifndef V0_DECISION_V8_ADAPTIVE_H
#define V0_DECISION_V8_ADAPTIVE_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * V0 Decision V8 Adaptive supervisor.
 *
 * The proven Decision V7 V0L kernel remains byte-identical. V8 adds an
 * out-of-band A/B supervisor that periodically measures FILTER vs BYPASS and
 * automatically selects the cheaper path for the next active window.
 *
 * Important: this controller does NOT use floating point and is not executed
 * per Decision operation. It runs at block boundaries only.
 */

typedef enum v0_v8_mode {
    V0_V8_BYPASS = 0,
    V0_V8_FILTER = 1
} v0_v8_mode_t;

typedef enum v0_v8_phase {
    V0_V8_PROBE_A = 0,
    V0_V8_PROBE_B = 1,
    V0_V8_ACTIVE  = 2
} v0_v8_phase_t;

typedef struct v0_v8_config {
    uint32_t probe_count;             /* requests per measured A/B probe */
    uint32_t active_count;            /* requests before the next A/B check */
    uint16_t switch_margin_permille;  /* challenger must win by this margin */
    uint16_t reserved;
} v0_v8_config_t;

typedef struct v0_v8_state {
    uint32_t selected_mode;
    uint32_t phase;
    uint32_t epoch;
    uint32_t switches_to_filter;
    uint32_t switches_to_bypass;
    uint32_t probes_completed;
    uint64_t bypass_ticks;
    uint64_t filter_ticks;
    uint32_t bypass_count;
    uint32_t filter_count;
    v0_v8_config_t cfg;
} v0_v8_state_t;

typedef struct v0_v8_plan {
    uint32_t mode;          /* V0_V8_FILTER or V0_V8_BYPASS */
    uint32_t count;         /* requests to process in this block */
    uint32_t measure;       /* measure elapsed ticks when non-zero */
    uint32_t authoritative; /* current block mode is authoritative */
} v0_v8_plan_t;

/* Validated default: ~6% A/B probing overhead budget, fast enough re-check. */
static inline v0_v8_config_t v0_v8_default_config(void) {
    v0_v8_config_t c;
    c.probe_count = 2048u;
    c.active_count = 65536u;
    c.switch_margin_permille = 50u; /* 5% hysteresis */
    c.reserved = 0u;
    return c;
}

static inline void v0_v8_init(v0_v8_state_t *s, v0_v8_config_t c) {
    s->selected_mode = V0_V8_BYPASS;
    s->phase = V0_V8_PROBE_A;
    s->epoch = 0u;
    s->switches_to_filter = 0u;
    s->switches_to_bypass = 0u;
    s->probes_completed = 0u;
    s->bypass_ticks = 0u;
    s->filter_ticks = 0u;
    s->bypass_count = 0u;
    s->filter_count = 0u;
    s->cfg = c;
}

/* Alternate A/B order every epoch to reduce ordering bias. */
static inline uint32_t v0_v8_probe_mode(const v0_v8_state_t *s, uint32_t which) {
    const uint32_t filter_first = s->epoch & 1u;
    return which == 0u
        ? (filter_first ? V0_V8_FILTER : V0_V8_BYPASS)
        : (filter_first ? V0_V8_BYPASS : V0_V8_FILTER);
}

static inline v0_v8_plan_t v0_v8_plan(const v0_v8_state_t *s) {
    v0_v8_plan_t p;
    if (s->phase == V0_V8_ACTIVE) {
        p.mode = s->selected_mode;
        p.count = s->cfg.active_count;
        p.measure = 0u;
        p.authoritative = 1u;
    } else {
        const uint32_t which = (s->phase == V0_V8_PROBE_A) ? 0u : 1u;
        p.mode = v0_v8_probe_mode(s, which);
        p.count = s->cfg.probe_count;
        p.measure = 1u;
        p.authoritative = 1u;
    }
    return p;
}

/* Compare normalized block cost without floating point. */
static inline int v0_v8_ratio_better(uint64_t a_ticks, uint32_t a_count,
                                     uint64_t b_ticks, uint32_t b_count,
                                     uint16_t margin_permille) {
    if (a_count == 0u || b_count == 0u) return 0;

    /* Fast/default case: A and B probe counts are equal. */
    if (a_count == b_count) {
        return a_ticks * 1000u < b_ticks * (1000u - (uint32_t)margin_permille);
    }

    /* Fixed-point cost/request for rare partial blocks. */
    const uint64_t a_q10 = (a_ticks << 10) / (uint64_t)a_count;
    const uint64_t b_q10 = (b_ticks << 10) / (uint64_t)b_count;
    return a_q10 * 1000u < b_q10 * (1000u - (uint32_t)margin_permille);
}

/*
 * Call once after the whole planned block.
 * elapsed_ticks may be CPU cycles, nanoseconds, QPC ticks, etc.; only ratios
 * matter. For ACTIVE blocks it can be zero because no A/B comparison is made.
 */
static inline void v0_v8_complete(v0_v8_state_t *s, uint32_t mode,
                                  uint64_t elapsed_ticks, uint32_t count) {
    if (s->phase == V0_V8_ACTIVE) {
        s->phase = V0_V8_PROBE_A;
        s->epoch += 1u;
        s->bypass_ticks = 0u;
        s->filter_ticks = 0u;
        s->bypass_count = 0u;
        s->filter_count = 0u;
        return;
    }

    if (mode == V0_V8_FILTER) {
        s->filter_ticks = elapsed_ticks;
        s->filter_count = count;
    } else {
        s->bypass_ticks = elapsed_ticks;
        s->bypass_count = count;
    }

    if (s->phase == V0_V8_PROBE_A) {
        s->phase = V0_V8_PROBE_B;
        return;
    }

    s->probes_completed += 1u;

    if (s->selected_mode == V0_V8_BYPASS) {
        if (v0_v8_ratio_better(s->filter_ticks, s->filter_count,
                               s->bypass_ticks, s->bypass_count,
                               s->cfg.switch_margin_permille)) {
            s->selected_mode = V0_V8_FILTER;
            s->switches_to_filter += 1u;
        }
    } else {
        if (v0_v8_ratio_better(s->bypass_ticks, s->bypass_count,
                               s->filter_ticks, s->filter_count,
                               s->cfg.switch_margin_permille)) {
            s->selected_mode = V0_V8_BYPASS;
            s->switches_to_bypass += 1u;
        }
    }

    s->phase = V0_V8_ACTIVE;
}

#ifdef __cplusplus
}
#endif
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
size_t v0_traffic_transfer(const void*,size_t,uint32_t,uint32_t,size_t,size_t,void*,size_t);
size_t v0_traffic_transfer_256_v7(const void*,size_t,uint32_t,uint32_t,size_t,void*,size_t);
static double nowq(void){LARGE_INTEGER q,f;QueryPerformanceCounter(&q);QueryPerformanceFrequency(&f);return (double)q.QuadPart/(double)f.QuadPart;}
int main(void){
    const size_t n=320u*16384u+512u;
    unsigned char *s=(unsigned char*)_aligned_malloc(n+128u,64u);
    unsigned char *a=(unsigned char*)_aligned_malloc(320u,64u);
    unsigned char *b=(unsigned char*)_aligned_malloc(320u,64u);
    if(!s||!a||!b)return 2;
    for(size_t i=0;i<n+128u;i++)s[i]=(unsigned char)(i*29u+11u);
    for(uint32_t i=0;i<8192u;i++){
        size_t x=v0_traffic_transfer(s,n,i,8192u,320u,256u,a,256u);
        size_t y=v0_traffic_transfer_256_v7(s,n,i,8192u,320u,b,256u);
        if(x!=y||x!=256u||memcmp(a,b,256u)){printf("PARITY_FAIL id=%u base=%zu candidate=%zu\n",i,x,y);return 10;}
    }
    volatile size_t sink=0; const int rounds=15, loops=200000;
    for(int r=0;r<rounds;r++){
        double t0=nowq();
        for(int i=0;i<loops;i++)sink+=v0_traffic_transfer(s,n,(uint32_t)(i%8192),8192u,320u,256u,a,256u);
        double t1=nowq();
        for(int i=0;i<loops;i++)sink+=v0_traffic_transfer_256_v7(s,n,(uint32_t)(i%8192),8192u,320u,b,256u);
        double t2=nowq();
        double base=(t1-t0)/loops,cand=(t2-t1)/loops;
        printf("%d,%.9f,%.9f,%.6f\n",r,base,cand,base/cand);
    }
    fprintf(stderr,"sink=%zu\n",(size_t)sink);
    _aligned_free(s);_aligned_free(a);_aligned_free(b);return 0;
}

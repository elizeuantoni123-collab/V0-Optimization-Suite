#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_ultra_v10.h"
#define N (1u<<24)
#define REPS 9
static uint16_t *v,*g;static uint8_t*out;static volatile uint64_t sink;
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}
static void pin0(void){cpu_set_t x;CPU_ZERO(&x);CPU_SET(0,&x);sched_setaffinity(0,sizeof(x),&x);}
static double normal(void){uint64_t a=now_ns();v0_eval_gate16_batch_v10_avx2_u8(v,g,out,N);uint64_t z=now_ns();sink+=out[777];return(double)(z-a)/N;}
static double stream(void){uint64_t a=now_ns();v0_eval_gate16_batch_v10_stream_avx2_u8(v,g,out,N);uint64_t z=now_ns();sink+=out[777];return(double)(z-a)/N;}
static void bench(const char*n,double(*f)(void)){double x[REPS];for(int i=0;i<3;i++)f();for(int i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmpd);printf("%-24s p50=%9.5f best=%9.5f ns/item\n",n,x[REPS/2],x[0]);}
int main(void){pin0();if(posix_memalign((void**)&v,64,N*2)||posix_memalign((void**)&g,64,N*2)||posix_memalign((void**)&out,64,N))return 2;uint64_t s=0x123456789abcdefULL;for(size_t i=0;i<N;i++){v[i]=(uint16_t)rng64(&s);g[i]=(uint16_t)rng64(&s);}bench("gate16 normal store",normal);bench("gate16 streaming store",stream);printf("sink=%llu\n",(unsigned long long)sink);return 0;}

#ifndef V0_EXTERNAL_MEMORY_PROTOCOL_V5_H
#define V0_EXTERNAL_MEMORY_PROTOCOL_V5_H
#include <stdint.h>
#define V0X_MAGIC 0x35583056u /* V0X5 */
#define V0X_VERSION 5u
enum { V0X_PUT=1, V0X_GET=2, V0X_EXISTS=3, V0X_REMOVE=4, V0X_STATS=5,
V0X_BATCH_OPEN_V9=90, V0X_BATCH_GET_V9=91, V0X_BATCH_CLOSE_V9=92 };
typedef struct V0XReqV5 {
    uint32_t magic, version, op, id, len, reserved;
} V0XReqV5;
typedef struct V0XRespV5 {
    uint32_t magic, version, ok, len;
} V0XRespV5;
#endif

#define V0X_V9_MAX_BATCH 64u
#define V0X_V9_SHM_BYTES (64u*1024u*1024u)
typedef struct V0XBatchReqV9 {
    uint32_t magic, version, op, count, payload_hint, client_pid;
    uint32_t ids[V0X_V9_MAX_BATCH];
} V0XBatchReqV9;
typedef struct V0XBatchRespV9 {
    uint32_t magic, version, ok, count, used_bytes;
    uint32_t offsets[V0X_V9_MAX_BATCH];
    uint32_t lens[V0X_V9_MAX_BATCH];
} V0XBatchRespV9;

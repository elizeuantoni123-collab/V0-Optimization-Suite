#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <inttypes.h>
extern int v0_lookup_exact(const uint8_t*);
extern int v0_lookup_exact_v8(const uint8_t*);
extern const uint8_t v0l_keys[22528];
static volatile uint64_t sink;
static inline uint64_t now_ns(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static uint64_t xs=0x9e3779b97f4a7c15ULL;static uint64_t rng(){xs^=xs<<7;xs^=xs>>9;return xs;}
int main(){
 // exhaustive exact + all single-byte mutations
 for(int id=0;id<1024;id++){const uint8_t*p=v0l_keys+(size_t)id*22;int a=v0_lookup_exact(p),b=v0_lookup_exact_v8(p);if(a!=id||b!=a){fprintf(stderr,"known fail id=%d a=%d b=%d\n",id,a,b);return 2;}for(int j=0;j<22;j++){uint8_t q[22];memcpy(q,p,22);q[j]^=1;a=v0_lookup_exact(q);b=v0_lookup_exact_v8(q);if(a!=b){fprintf(stderr,"mutation fail id=%d j=%d a=%d b=%d\n",id,j,a,b);return 3;}}}
 // random parity 5M
 uint8_t q[22];for(int t=0;t<5000000;t++){for(int j=0;j<22;j++)q[j]=(uint8_t)rng();int a=v0_lookup_exact(q),b=v0_lookup_exact_v8(q);if(a!=b){fprintf(stderr,"random fail t=%d a=%d b=%d\n",t,a,b);return 4;}}
 const int total=1<<23; uint8_t*buf=aligned_alloc(64,(size_t)total*22);const uint8_t**pp=aligned_alloc(64,(size_t)total*sizeof(*pp));int*o0=aligned_alloc(64,(size_t)total*4);int*o1=aligned_alloc(64,(size_t)total*4);if(!buf||!pp||!o0||!o1)return 5;
 const char*profiles[]={"hit","lastmiss","randommiss","mix50"};printf("profile,round,order,base_ns,cand_ns,speedup,parity\n");
 for(int pr=0;pr<4;pr++){xs=0x123456789abcdefULL+pr;for(int i=0;i<total;i++){uint8_t*d=buf+(size_t)i*22;int id=(int)(((uint32_t)i*4051u+17u)&1023);memcpy(d,v0l_keys+(size_t)id*22,22);if(pr==1)d[21]^=1;else if(pr==2){for(int j=0;j<22;j++)d[j]=(uint8_t)rng();}else if(pr==3&&(i&1)){for(int j=0;j<22;j++)d[j]=(uint8_t)rng();}pp[i]=d;}
  // warm both
  for(int i=0;i<total;i++){o0[i]=v0_lookup_exact(pp[i]);o1[i]=v0_lookup_exact_v8(pp[i]);}
  for(int r=0;r<31;r++){uint64_t a,b,c,d;if(!(r&1)){a=now_ns();for(int i=0;i<total;i++)o0[i]=v0_lookup_exact(pp[i]);b=now_ns();c=now_ns();for(int i=0;i<total;i++)o1[i]=v0_lookup_exact_v8(pp[i]);d=now_ns();}else{c=now_ns();for(int i=0;i<total;i++)o1[i]=v0_lookup_exact_v8(pp[i]);d=now_ns();a=now_ns();for(int i=0;i<total;i++)o0[i]=v0_lookup_exact(pp[i]);b=now_ns();}int bad=0;for(int i=0;i<total;i++)bad+=(o0[i]!=o1[i]);uint64_t cs=0;for(int i=0;i<total;i+=4096)cs+=(uint32_t)o0[i]+(uint32_t)o1[i];sink+=cs;double bn=(double)(b-a)/total,cn=(double)(d-c)/total;printf("%s,%d,%s,%.9f,%.9f,%.9f,%d\n",profiles[pr],r+1,(r&1)?"cand-first":"base-first",bn,cn,bn/cn,bad);fflush(stdout);}
 }
fprintf(stderr,"sink=%" PRIu64 "\n",sink);return 0;}

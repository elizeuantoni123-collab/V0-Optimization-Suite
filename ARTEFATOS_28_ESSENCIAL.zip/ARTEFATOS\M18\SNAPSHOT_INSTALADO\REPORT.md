# Artefato 18 — V0 Semantic Bridge V5 SAFE -> V7 SAFE Pair Squeeze

## Status

**LOCAL_PASS / WINDOWS_GATE_REQUIRED**

V5 SAFE remains the official baseline. V7 is an additive specialized candidate only for callers that currently perform both `id_safe` and `key_safe` on the same record.

## Baseline preserved

Original archive is preserved byte-for-byte as `baseline/baseline_archive_V5.zip`.

Baseline V5 continues to provide:

- V1 SAFE individual/trusted getters;
- V2 trusted `id+score` and `key+valid` pair64;
- V3 trusted `score+key` pair64;
- V4 full record128;
- V5 valid4/valid8 masks.

No existing exported function is replaced.

## Bottleneck

A caller that needs both safe ID and safe exact-key currently performs two V1 SAFE calls. Each call reloads/tests the same canonical `valid` field.

V7 adds:

`uint64_t v0_semantic_id_key64_safe(const v0_semantic_record* ctx)`

Exact contract:

- low32 = `v0_semantic_id_safe(ctx)`
- high32 = `v0_semantic_key_safe(ctx)`
- if invalid, both halves are `0xffffffff`, exactly matching the two V1 SAFE results.

This removes one call boundary and one duplicated validity decision.

## V0L/compiler change

The candidate compiler only adds generic u64 arithmetic/return support required by this additive function.

Recompiling V1 through V5 with the extended compiler was checked byte-for-byte:

- V1 Linux/Windows: IDENTICAL
- V2 Linux/Windows: IDENTICAL
- V3 Linux/Windows: IDENTICAL
- V4 Linux/Windows: IDENTICAL
- V5 Linux/Windows: IDENTICAL

Candidate code size:

- Linux ELF function: 31 bytes
- Windows COFF function: 32 bytes
- no rodata
- no relocations

## Correctness

Long differential validation against two real V1 SAFE calls:

- edge-value matrix for ID/key and valid 0/1;
- 20,000,000 random records;
- total: **20,000,072 comparisons**;
- **0 divergences**.

The five benchmark processes also execute their own 5,016,384-case parity set before timing; all passed.

## Local performance screening

Baseline = two real V1 calls (`id_safe` + `key_safe`) packed into u64.
Candidate = one V7 SAFE Pair call.

Five separate processes, 15 paired A/B rounds per profile, 75 measurements/profile:

| Profile | Baseline median | V7 median | Median speedup | Worst round | Wins |
|---|---:|---:|---:|---:|---:|
| 0% valid | 2.728 ns | 1.460 ns | **1.857x** | 1.240x | 75/75 |
| 50% valid | 2.971 ns | 1.671 ns | **1.814x** | 1.226x | 75/75 |
| 99% valid | 2.655 ns | 1.567 ns | **1.743x** | 1.417x | 75/75 |
| 100% valid | 2.606 ns | 1.457 ns | **1.799x** | 1.622x | 75/75 |

Total timing results: **300/300 wins**.

These numbers are for the paired SAFE bridge operation, not for the full semantic model or end-to-end V0 pipeline.

## Why this does not replace V5 valid8

V5 valid8 is already extremely strong and prior V6 valid16 attempts were rejected. This V7 targets a different repeated-work pattern and does not modify validity-mask dispatch.

## Windows gate

`windows_gate/RUN_WINDOWS_GATE.ps1`:

1. does not install anything;
2. extracts only the preserved V5 archive locally if needed;
3. uses the original Windows V1 object and the candidate V7 COFF object;
4. runs 5,000,000 differential checks;
5. measures 0%, 50%, 99% and 100% valid profiles with QPC;
6. alternates A/B order;
7. writes the result CSV under `windows_gate/work/`.

Promotion requires exact parity and no relevant regression on the target Intel/Windows machine.

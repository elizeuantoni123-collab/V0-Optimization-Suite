#include <immintrin.h>
#include <stdint.h>
#include <stddef.h>

static inline __m256i q4(uint32_t s){
    uint64_t c=((uint64_t)64)<<32;
    return _mm256_set_epi64x((long long)(c+s+192),(long long)(c+s+128),(long long)(c+s+64),(long long)(c+s));
}

__attribute__((noinline,target("avx2"))) uint32_t cand_unroll_1024(void *out, uint32_t items){
    (void)items; char *p=(char*)out;
    _mm256_storeu_si256((__m256i*)(p+0), q4(0));
    _mm256_storeu_si256((__m256i*)(p+32), q4(256));
    _mm256_storeu_si256((__m256i*)(p+64), q4(512));
    _mm256_storeu_si256((__m256i*)(p+96), q4(768));
    _mm256_zeroupper(); return 16;
}
__attribute__((noinline,target("avx2"))) uint32_t cand_unroll_2048(void *out, uint32_t items){
    (void)items; char *p=(char*)out;
    for (uint32_t s=0;s<2048;s+=256,p+=32) _mm256_storeu_si256((__m256i*)p,q4(s));
    _mm256_zeroupper(); return 32;
}
__attribute__((noinline,target("avx2"))) uint32_t cand_unroll_3072(void *out, uint32_t items){
    (void)items; char *p=(char*)out;
    for (uint32_t s=0;s<3072;s+=256,p+=32) _mm256_storeu_si256((__m256i*)p,q4(s));
    _mm256_zeroupper(); return 48;
}
__attribute__((noinline,target("avx2"))) uint32_t cand_unroll_4096(void *out, uint32_t items){
    (void)items; char *p=(char*)out;
    for (uint32_t s=0;s<4096;s+=256,p+=32) _mm256_storeu_si256((__m256i*)p,q4(s));
    _mm256_zeroupper(); return 64;
}

#define Q(s) ((((uint64_t)64)<<32) | (uint64_t)(s))
__attribute__((aligned(32))) static const uint64_t table4096[64] = {
Q(0),Q(64),Q(128),Q(192),Q(256),Q(320),Q(384),Q(448),Q(512),Q(576),Q(640),Q(704),Q(768),Q(832),Q(896),Q(960),
Q(1024),Q(1088),Q(1152),Q(1216),Q(1280),Q(1344),Q(1408),Q(1472),Q(1536),Q(1600),Q(1664),Q(1728),Q(1792),Q(1856),Q(1920),Q(1984),
Q(2048),Q(2112),Q(2176),Q(2240),Q(2304),Q(2368),Q(2432),Q(2496),Q(2560),Q(2624),Q(2688),Q(2752),Q(2816),Q(2880),Q(2944),Q(3008),
Q(3072),Q(3136),Q(3200),Q(3264),Q(3328),Q(3392),Q(3456),Q(3520),Q(3584),Q(3648),Q(3712),Q(3776),Q(3840),Q(3904),Q(3968),Q(4032)};

__attribute__((noinline,target("avx2"))) uint32_t cand_table(void *out, uint32_t items){
    uint32_t n=items>>6; char *p=(char*)out;
    const __m256i *s=(const __m256i*)table4096;
    uint32_t q=n>>2;
    for(uint32_t i=0;i<q;i++) _mm256_storeu_si256((__m256i*)(p+32*i), _mm256_load_si256(s+i));
    _mm256_zeroupper(); return n;
}

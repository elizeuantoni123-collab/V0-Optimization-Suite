# Relatório M24 — V0 Global Memory V8.22 Small Range Squeeze

## Baseline

- V0 Global Memory Windows V8.21 FIX8.
- EPT, MTRR, Shared-EPT, large-page hierarchy e instalação permanente não foram alterados.

## Correção

Validação matemática/implementação do novo token curto:

- first_page: 0..65535;
- page_count: 2..1024;
- +10.000.000 casos aleatórios;
- **77.043.328 checks**;
- **0 divergências**.

## Screening local

Cálculo de range isolado, 20M ranges aleatórios: 0 divergências.
Ganho observado: ~1,42x–2,06x em tamanhos fixos e ~1,25x no workload variado.

No caminho completo modelado de `V0PolicyCompilePhysicalRange`, a especialização 2..1024 preservou pages/samples/checksum. Exemplos de medianas locais:

- count=2: ~1,45x
- count=3: ~2,83x
- count=4: ~1,25x
- count=16: ~1,28x
- count=511: ~1,23x
- workload variado 2..1024: ~1,09x e 15/15 vitórias na última rodada

Alguns tamanhos tiveram outliers abaixo de 1x neste servidor; por isso **não está promovido**. O gate Windows é obrigatório.

## Decisão

**CANDIDATE ONLY. KEEP V8.21 AS BASELINE.**

O candidato é restrito ao FastPolicy/range accounting e não muda decisões de mapeamento EPT.


Current revalidation evidence is in `REVALIDATION_2026-10-06.md`.

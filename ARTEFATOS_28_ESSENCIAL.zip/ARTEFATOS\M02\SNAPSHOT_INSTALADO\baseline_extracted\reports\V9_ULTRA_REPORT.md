# V0 Decision V8 ULTRA V9 — Technical Report

## Status

**Promoted as an additive AVX2 raw/preflight optimization.**

ULTRA V9 does not modify the inherited V8 implementation. It adds two exact AVX2 entry points and a public 16-item preflight mask.

## Exact transformation

For the legal Decision temperature domain, the bonus is exactly:

| temperature | bonus |
|---:|---:|
| 0 | 0 |
| 1 | 64 |
| 2 | 192 |

V8 widened each temperature byte to 16 bits and computed `((t + (t >> 1)) << 6)` in the vector hot path. V9 first resolves the exact bonus with `PSHUFB` in byte space, then widens the already-final `0/64/192` value once.

`pinned` remains byte-sized until after tier indices are packed. Since `pinned=1` is already proven to map to final state `7` for the legal domain, the byte result is blended to `7` before the existing final LUT.

No threshold, score rule, or state encoding changes.

## Validation

Two independent builds were run:

- AVX2-only: **21,005,735 checked, 0 divergences**.
- Native/AVX-512-capable: **21,005,735 checked, 0 divergences**.

The suite includes 20 × 1,048,576 random full-range signals, directed neighborhoods around the semantic thresholds, every legal temperature/pinned combination, varied costs including 0/65535, tails 0..257, raw output, count-only preflight, and the 16-bit execution mask.

The inherited V8 regression suite was rebuilt from the V9 tree and also reported **21,005,735 checked, 0 divergences**. The adaptive controller transition/hysteresis test remains PASS.

## Inherited integrity

**182 inherited V8 files were compared by SHA-256: 182/182 identical, 0 missing, 0 mismatches.**

## AVX2-only paired benchmark

Environment for the included Linux measurement: AMD EPYC 9V74 virtualized host, one pinned benchmark thread, batch=1,048,576, p50 of 15 timed iterations per process. Three separate benchmark processes were run.

Representative cross-process median values:

| Path | V8 | V9 | Change |
|---|---:|---:|---:|
| raw AVX2 | ~0.10539 ns/item | ~0.09043 ns/item | **~14.2% lower** |
| raw preflight AVX2 | ~0.07319 ns/item | ~0.06080 ns/item | **~16.9% lower** |

Equivalent throughput ratios are about **1.17×** for full raw Decision and **1.20×** for preflight count in that run.

These sub-nanosecond figures are amortized batch throughput, not the latency of a single independent call. Absolute values are CPU/cache/compiler-sensitive; the paired relative comparison is the useful measurement.

## AVX-512 policy

The attempted V9 byte-LUT transformation did **not** beat the existing V8 AVX-512 implementation on the test host. Therefore V9 intentionally leaves AVX-512 unchanged.

Recommended dispatch:

- AVX-512BW+VL: existing V8 AVX-512 path.
- AVX2 without the faster AVX-512 path: V9 AVX2 raw/preflight.
- other CPUs: existing validated fallbacks.

## Rejected work

See `V9_REJECTED_CANDIDATES.txt`. Every candidate that lost speed or lacked a repeatable win was excluded from the promoted V9 API.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../baseline_extracted/include/v0_decision_v8_ultra_v12.h"
#ifndef VARIANT
#define VARIANT 0
#endif
#define N (1u<<20)
#define INNER 64
static volatile uint64_t sink;
static uint16_t *c,*o; static uint8_t *t,*p;
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static __forceinline uint16_t f(uint16_t cost,uint8_t temp,uint8_t pin){
#if VARIANT==0
 return v0_decision_gate16_v12_branchless(cost,temp,pin);
#else
 static const uint16_t base[3]={0x8000u,0x8040u,0x80c0u};
 return (uint16_t)((uint32_t)(base[temp]-(cost>>1)) | (0u-(uint32_t)pin));
#endif
}
static double nowsec(void){LARGE_INTEGER q,f;QueryPerformanceCounter(&q);QueryPerformanceFrequency(&f);return (double)q.QuadPart/(double)f.QuadPart;}
int main(int argc,char**argv){int pinpct=argc>1?atoi(argv[1]):50;int tempmode=argc>2?atoi(argv[2]):-1;DWORD_PTR mask=SetThreadAffinityMask(GetCurrentThread(),1);(void)mask;c=(uint16_t*)_aligned_malloc(N*2,64);o=(uint16_t*)_aligned_malloc(N*2,64);t=(uint8_t*)_aligned_malloc(N,64);p=(uint8_t*)_aligned_malloc(N,64);if(!c||!o||!t||!p)return 2;uint64_t s=0xa0761d6478bd642fULL;for(size_t i=0;i<N;i++){c[i]=(uint16_t)rng64(&s);t[i]=(tempmode>=0)?(uint8_t)tempmode:(uint8_t)(rng64(&s)%3);p[i]=(uint8_t)((rng64(&s)%100)<(uint64_t)pinpct);}for(size_t i=0;i<N;i++){uint16_t r=v0_decision_gate16_v12_branchless(c[i],t[i],p[i]);if(f(c[i],t[i],p[i])!=r){puts("DIVERGENCE");return 3;}}for(int w=0;w<4;w++)for(size_t i=0;i<N;i++)o[i]=f(c[i],t[i],p[i]);double a=nowsec();for(int r=0;r<INNER;r++)for(size_t i=0;i<N;i++)o[i]=f(c[i],t[i],p[i]);double z=nowsec();sink+=o[777];printf("%.9f\n",(z-a)*1e9/(N*(double)INNER));return 0;}

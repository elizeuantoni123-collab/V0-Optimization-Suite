# Candidate V7 dispatch

This is a candidate only; V6 remains the promoted baseline until the Windows/Intel gate passes.

1. Keep the full V6 SAFE composite dispatch unchanged.
2. Add only these two exact-pair exceptions for nominal K8:
   - `current_count=1 && target_count=5` -> `v0_kv_window5_1to5_v7`
   - `current_count=5 && target_count=1` -> `v0_kv_window5_5to1_v7`
3. Keep V6 `v0_kv_window3_v6` for `3→2`.
4. All other count pairs continue through V6 exactly as before.

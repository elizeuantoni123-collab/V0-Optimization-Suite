# Dispatch candidate — Semantic Bridge V7 SAFE Pair

Keep the complete V5 SAFE dispatch unchanged.

Use `v0_semantic_id_key64_safe(ctx)` only when one caller needs both of these results from the same normalized record:

- `v0_semantic_id_safe(ctx)`
- `v0_semantic_key_safe(ctx)`

V7 returns their exact little-endian packed equivalent:

- low32 = `id_safe`
- high32 = `key_safe`

For every other use, retain V1/V2/V3/V4/V5 exactly as before.

The old rejected V6 `valid16` experiments remain rejected; this additive candidate is numbered V7 to avoid reusing that version number.

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_bandwidth_v8.h"

#define CHUNK (1u<<20)
#define ROUNDS 20
#define PAD 320

static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint64_t checked=0,bad=0;
static void fail(const char *tag,size_t i,uint32_t got,uint32_t ref){if(bad<12)fprintf(stderr,"FAIL %s i=%zu got=%u ref=%u\n",tag,i,got,ref);bad++;}

static uint8_t ref_raw(uint16_t v,uint16_t c,uint8_t t,uint8_t p){return (uint8_t)v0_eval_v8_raw_ultra_inline(v,c,t,p);}
static uint8_t ref_bias(uint16_t v,uint16_t c,uint16_t b){return (uint8_t)v0_eval_v8_bias_ultra_inline(v,c,b);}

static int validate_chunk(uint16_t *v,uint16_t *c,uint16_t *b,uint8_t *t,uint8_t *p,
                          v0_decision_signal_v7_t *sig,uint8_t *meta,uint8_t *out,uint8_t *tmp,size_t n){
    size_t i;
    uint64_t refpre=0;
    for(i=0;i<n;i++){tmp[i]=ref_raw(v[i],c[i],t[i],p[i]);refpre+=(tmp[i]>>2);if(tmp[i]!=ref_bias(v[i],c[i],b[i]))fail("bias-scalar",i,ref_bias(v[i],c[i],b[i]),tmp[i]);if(tmp[i]!=(uint8_t)v0_eval_v8_signal_ultra_inline(sig+i))fail("signal-scalar",i,v0_eval_v8_signal_ultra_inline(sig+i),tmp[i]);}
#if defined(__AVX2__) || defined(_M_AVX2)
    memset(out,0xA5,n+64);v0_eval_v8_bias_batch_ultra_v8_avx2_u8(v,c,b,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("bias-avx2",i,out[i],tmp[i]);
    memset(out,0xA5,n+64);v0_eval_v8_raw_batch_ultra_v8_avx2_u8(v,c,t,p,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("raw-avx2",i,out[i],tmp[i]);
    memset(out,0xA5,n+64);v0_eval_v8_signal_batch_ultra_v8_avx2_u8(sig,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("aos-avx2",i,out[i],tmp[i]);
    memset(out,0xA5,n+64);v0_eval_v8_meta8_batch_avx2_u8(v,c,meta,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("meta8-avx2",i,out[i],tmp[i]);
    {uint64_t z=v0_preflight_v8_raw_count_ultra_v8_avx2(v,c,t,p,n);if(z!=refpre)fail("raw-pre-avx2",0,(uint32_t)z,(uint32_t)refpre);}
    /* nibble exact decode */
    memset(out,0xA5,(n+1)/2+64);v0_eval_v8_bias_batch_ultra_v8_avx2_nibble(v,c,b,out,n);for(i=0;i<n;i++){uint8_t x=out[i>>1];uint8_t e=(i&1)?(uint8_t)(x>>4):(uint8_t)(x&15u);if(e!=tmp[i])fail("nibble-avx2",i,e,tmp[i]);}
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
    memset(out,0xA5,n+64);v0_eval_v8_bias_batch_ultra_v8_avx512_u8(v,c,b,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("bias-avx512",i,out[i],tmp[i]);
    memset(out,0xA5,n+64);v0_eval_v8_raw_batch_ultra_v8_avx512_u8(v,c,t,p,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("raw-avx512",i,out[i],tmp[i]);
    memset(out,0xA5,n+64);v0_eval_v8_signal_batch_ultra_v8_avx512_u8(sig,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("aos-avx512",i,out[i],tmp[i]);
    memset(out,0xA5,n+64);v0_eval_v8_meta8_batch_avx512_u8(v,c,meta,out,n);for(i=0;i<n;i++)if(out[i]!=tmp[i])fail("meta8-avx512",i,out[i],tmp[i]);
    memset(out,0xA5,(n+1)/2+64);v0_eval_v8_meta8_batch_avx512_nibble(v,c,meta,out,n);for(i=0;i<n;i++){uint8_t x=out[i>>1];uint8_t e=(i&1)?(uint8_t)(x>>4):(uint8_t)(x&15u);if(e!=tmp[i])fail("meta8-nibble-avx512",i,e,tmp[i]);}
    {uint64_t z=v0_preflight_v8_raw_count_ultra_v8_avx512(v,c,t,p,n);if(z!=refpre)fail("raw-pre-avx512",0,(uint32_t)z,(uint32_t)refpre);}
    {uint64_t z=v0_preflight_v8_signal_count_ultra_v8_avx512(sig,n);if(z!=refpre)fail("aos-pre-avx512",0,(uint32_t)z,(uint32_t)refpre);}
    /* 3-bit bitplanes exact decode */
    {size_t nb=(n+31u)>>5;uint32_t *pb=(uint32_t*)calloc(nb,sizeof(uint32_t));uint32_t *lb=(uint32_t*)calloc(nb,sizeof(uint32_t));uint32_t *hb=(uint32_t*)calloc(nb,sizeof(uint32_t));if(!pb||!lb||!hb)return 9;v0_eval_v8_bias_bitplanes_ultra_v8_avx512(v,c,b,pb,lb,hb,n);for(i=0;i<n;i++){unsigned bit=(unsigned)(i&31u);size_t j=i>>5;uint8_t e=(uint8_t)((((pb[j]>>bit)&1u)<<2)|((lb[j]>>bit)&1u)|(((hb[j]>>bit)&1u)<<1));if(e!=tmp[i])fail("bitplane-avx512",i,e,tmp[i]);}free(pb);free(lb);free(hb);}
#endif
    checked+=n;
    return bad?1:0;
}

int main(void){
    uint16_t *v,*c,*b;uint8_t *t,*p,*meta,*out,*tmp;v0_decision_signal_v7_t *sig;
    if(posix_memalign((void**)&v,64,(CHUNK+PAD)*2)||posix_memalign((void**)&c,64,(CHUNK+PAD)*2)||posix_memalign((void**)&b,64,(CHUNK+PAD)*2)||posix_memalign((void**)&t,64,CHUNK+PAD)||posix_memalign((void**)&p,64,CHUNK+PAD)||posix_memalign((void**)&meta,64,CHUNK+PAD)||posix_memalign((void**)&sig,64,(CHUNK+PAD)*sizeof(*sig))||posix_memalign((void**)&out,64,CHUNK+PAD+64)||posix_memalign((void**)&tmp,64,CHUNK+PAD+64))return 2;
    uint64_t s=0x9e3779b97f4a7c15ULL;
    for(unsigned r=0;r<ROUNDS;r++){
        for(size_t i=0;i<CHUNK;i++){v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);b[i]=v0_decision_v7_bias(t[i],p[i]);meta[i]=v0_decision_v8_meta8(t[i],p[i]);sig[i]=v0_decision_v7_pack(v[i],c[i],t[i],p[i]);}
        if(validate_chunk(v,c,b,t,p,sig,meta,out,tmp,CHUNK))break;
    }
    /* Directed boundary construction around every semantic threshold. */
    {static const int th[]={0,64,192,384};static const uint16_t costs[]={0,1,2,63,64,65,127,128,255,256,1023,32767,32768,65534,65535};size_t n=0;for(unsigned ti=0;ti<3;ti++)for(unsigned pi=0;pi<2;pi++)for(size_t ci=0;ci<sizeof(costs)/sizeof(costs[0]);ci++){uint16_t bias=v0_decision_v7_bias((uint8_t)ti,(uint8_t)pi);int h=(int)(costs[ci]>>1);for(size_t k=0;k<sizeof(th)/sizeof(th[0]);k++)for(int d=-3;d<=3;d++){int x=th[k]+d+h-(int)bias;if(x>=0&&x<=65535&&n<CHUNK){v[n]=(uint16_t)x;c[n]=costs[ci];t[n]=(uint8_t)ti;p[n]=(uint8_t)pi;b[n]=bias;meta[n]=v0_decision_v8_meta8(t[n],p[n]);sig[n]=v0_decision_v7_pack(v[n],c[n],t[n],p[n]);n++;}}}validate_chunk(v,c,b,t,p,sig,meta,out,tmp,n);}
    /* Every tail length 0..257 and sentinel preservation. */
    for(size_t n=0;n<=257;n++){
        for(size_t i=0;i<PAD;i++){v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);b[i]=v0_decision_v7_bias(t[i],p[i]);meta[i]=v0_decision_v8_meta8(t[i],p[i]);sig[i]=v0_decision_v7_pack(v[i],c[i],t[i],p[i]);}
        validate_chunk(v,c,b,t,p,sig,meta,out,tmp,n);
    }
    printf("checked=%llu divergences=%llu\n",(unsigned long long)checked,(unsigned long long)bad);
    printf("status=%s\n",bad?"FAIL":"PASS");
    return bad?3:0;
}

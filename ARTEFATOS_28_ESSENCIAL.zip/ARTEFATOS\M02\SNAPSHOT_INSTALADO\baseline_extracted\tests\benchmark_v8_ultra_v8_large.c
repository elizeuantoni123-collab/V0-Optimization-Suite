#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_ultra_v8.h"
#define N (1u<<25)
#define REPS 7
static uint16_t*v,*c,*b;static uint8_t*o,*nib;static uint32_t*pb,*lb,*hb;static volatile uint64_t sink;static uint64_t ns(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}static uint64_t rg(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return*s=x;}static int cd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}static void pin0(){cpu_set_t x;CPU_ZERO(&x);CPU_SET(0,&x);sched_setaffinity(0,sizeof(x),&x);}
static double bytes2(){uint64_t a=ns();v0_eval_v8_bias_batch_ultra_v8_avx2_u8(v,c,b,o,N);uint64_t z=ns();sink+=o[777];return(double)(z-a)/N;}static double nibble(){uint64_t a=ns();v0_eval_v8_bias_batch_ultra_v8_avx2_nibble(v,c,b,nib,N);uint64_t z=ns();sink+=nib[777];return(double)(z-a)/N;}static double nibstream(){uint64_t a=ns();v0_eval_v8_bias_batch_ultra_v8_stream_avx2_nibble(v,c,b,nib,N);uint64_t z=ns();sink+=nib[777];return(double)(z-a)/N;}
#if defined(__AVX512BW__) && defined(__AVX512VL__)
static double bytes5(){uint64_t a=ns();v0_eval_v8_bias_batch_ultra_v8_avx512_u8(v,c,b,o,N);uint64_t z=ns();sink+=o[777];return(double)(z-a)/N;}static double planes(){uint64_t a=ns();v0_eval_v8_bias_bitplanes_ultra_v8_avx512(v,c,b,pb,lb,hb,N);uint64_t z=ns();sink+=(uint64_t)pb[7]+lb[9]+hb[11];return(double)(z-a)/N;}
#endif
static void bench(const char*n,double(*f)()){double a[REPS];for(int i=0;i<REPS;i++)a[i]=f();qsort(a,REPS,sizeof(double),cd);printf("%-24s p50=%8.5f best=%8.5f ns/item\n",n,a[REPS/2],a[0]);}
int main(){pin0();size_t blocks=(N+31)/32;if(posix_memalign((void**)&v,64,N*2)||posix_memalign((void**)&c,64,N*2)||posix_memalign((void**)&b,64,N*2)||posix_memalign((void**)&o,64,N)||posix_memalign((void**)&nib,64,(N+1)/2)||posix_memalign((void**)&pb,64,blocks*4)||posix_memalign((void**)&lb,64,blocks*4)||posix_memalign((void**)&hb,64,blocks*4))return 2;uint64_t s=11;for(size_t i=0;i<N;i++){uint8_t t=rg(&s)%3,p=rg(&s)&1;v[i]=rg(&s);c[i]=rg(&s);b[i]=v0_decision_v7_bias(t,p);}bench("V8 byte AVX2",bytes2);bench("V8 nibble AVX2",nibble);bench("V8 nibble stream",nibstream);
#if defined(__AVX512BW__) && defined(__AVX512VL__)
bench("V8 byte AVX512",bytes5);bench("V8 3-bit bitplanes",planes);
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

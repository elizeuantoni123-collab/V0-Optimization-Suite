param([int]$Cpu = -1)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$base = Join-Path $root 'baseline\v0_tier_valid_v3.obj'
$cand = Join-Path $root 'candidate\build\windows\v0_tier_batch8_v12.obj'
$expectedBase = 'EEEAC3FB034EBAC07EC0A4746EB57624FC5CF60B22563537F500BD073C46417D'
$expectedCand = '56FF2454CCC2A3A06B1B9B30E2764D1EFF4BEF69EF27BB26EE0DDB405FBF566B'
if ((Get-FileHash $base -Algorithm SHA256).Hash -ne $expectedBase) { throw 'Baseline V3 OBJ hash mismatch.' }
if ((Get-FileHash $cand -Algorithm SHA256).Hash -ne $expectedCand) { throw 'Candidate V12 OBJ hash mismatch.' }
$vs = 'C:\BuildTools\Common7\Tools\VsDevCmd.bat'
if (-not (Test-Path $vs)) {
  $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
  if (Test-Path $vswhere) {
    $install = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($install) { $vs = Join-Path $install 'Common7\Tools\VsDevCmd.bat' }
  }
}
if (-not (Test-Path $vs)) { throw 'Visual Studio C++ Build Tools not found.' }
$gate = Join-Path $PSScriptRoot 'gate.c'
$exe = Join-Path $PSScriptRoot 'tier_gate.exe'
$csv = Join-Path $PSScriptRoot 'windows_results.csv'
$cmd = 'call "' + $vs + '" -arch=x64 -host_arch=x64 && cl /nologo /O2 /Oi "' + $gate + '" "' + $base + '" "' + $cand + '" /Fe:"' + $exe + '" && "' + $exe + '" ' + $Cpu + ' > "' + $csv + '"'
cmd.exe /d /c $cmd
if ($LASTEXITCODE -ne 0) { throw "Windows gate failed with exit code $LASTEXITCODE" }
Write-Host "PASS. Results: $csv"

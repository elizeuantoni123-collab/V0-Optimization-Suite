# V0 Decision V12 Global Process Broker — Technical Report

## Status

Implemented as an additive Windows process-aware broker over the validated V12 package.

The Decision core is unchanged. Inherited V12 files: **296/296 byte-identical by SHA-256**.

## Runtime model

One Windows service remains registered under the compatibility SCM name `V0DecisionV8`, but its installed executable is now explicitly named:

`C:\Program Files\V0DecisionV8\V0DecisionV12GlobalService.exe`

The legacy named pipe `\\.\pipe\V0DecisionV8` remains available, so existing clients continue to work.

## Global process coverage

A dedicated service thread takes a Windows process snapshot every 100 ms and maintains a sorted set of currently live PIDs. New process-aware commands are:

- `VERSION`
- `GLOBALSTATUS`
- `PIDSTATUS <pid>`
- `DECIDEPID <pid> <value> <cost> <temp> <pinned>`
- `GATEDECIDEPID <pid> <value> <gate16>`

PID-scoped Decision requests are rejected if the target PID is not currently present in the process snapshot.

## Safety / enforcement scope

This broker does **not** inject DLLs, patch other processes, kill/suspend processes, or install a kernel hook.

It therefore provides global **process awareness and PID-scoped Decision routing**, not universal interception of every internal operation. File, network, process-creation and object-handle enforcement require resource-specific Windows interception layers and an explicit mapping into the Decision signal fields. No such semantic mapping was invented automatically.

## Validation performed in build environment

- inherited V12 integrity: PASS, 296 files checked, 0 missing, 0 changed;
- service-name compatibility: PASS;
- named-pipe compatibility: PASS;
- V12 header included in broker: PASS;
- process snapshot scanner present: PASS;
- `GLOBALSTATUS`, `DECIDEPID`, `GATEDECIDEPID`: PASS static validation;
- installer replaces the existing SCM registration and points it to `V0DecisionV12GlobalService.exe`: PASS static validation.

The Windows-specific executable itself must be compiled by the included PowerShell installer on the target Windows machine, using the same Visual Studio 2022 Build Tools already used successfully by V12.

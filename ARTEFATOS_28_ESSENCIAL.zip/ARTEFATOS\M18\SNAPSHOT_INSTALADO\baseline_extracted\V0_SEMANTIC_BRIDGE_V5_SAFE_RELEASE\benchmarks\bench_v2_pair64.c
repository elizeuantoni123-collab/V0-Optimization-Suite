#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>

typedef struct { uint32_t id, score, key, valid; } rec_t;
extern uint32_t v0_semantic_id_trusted(const rec_t*);
extern uint32_t v0_semantic_score_trusted(const rec_t*);
extern uint32_t v0_semantic_key_trusted(const rec_t*);
extern uint32_t v0_semantic_valid_trusted(const rec_t*);
extern uint64_t v0_semantic_id_score64_trusted(const rec_t*);
extern uint64_t v0_semantic_key_valid64_trusted(const rec_t*);

static inline uint64_t ns(void){struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW,&t);return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static void pin0(void){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);}
static rec_t a[4096];
static volatile uint64_t sink;

static double two_id_score(uint32_t n){uint64_t s=0,t0=ns(); for(uint32_t i=0;i<n;i++){rec_t *r=&a[i&4095]; s += v0_semantic_id_trusted(r); s += ((uint64_t)v0_semantic_score_trusted(r)<<1);} uint64_t t1=ns();sink=s;return (double)(t1-t0)/n;}
static double pair_id_score(uint32_t n){uint64_t s=0,t0=ns(); for(uint32_t i=0;i<n;i++){rec_t *r=&a[i&4095]; uint64_t x=v0_semantic_id_score64_trusted(r); s += (uint32_t)x; s += ((uint64_t)(uint32_t)(x>>32)<<1);} uint64_t t1=ns();sink=s;return (double)(t1-t0)/n;}
static double two_key_valid(uint32_t n){uint64_t s=0,t0=ns(); for(uint32_t i=0;i<n;i++){rec_t *r=&a[i&4095]; s += v0_semantic_key_trusted(r); s += ((uint64_t)v0_semantic_valid_trusted(r)<<1);} uint64_t t1=ns();sink=s;return (double)(t1-t0)/n;}
static double pair_key_valid(uint32_t n){uint64_t s=0,t0=ns(); for(uint32_t i=0;i<n;i++){rec_t *r=&a[i&4095]; uint64_t x=v0_semantic_key_valid64_trusted(r); s += (uint32_t)x; s += ((uint64_t)(uint32_t)(x>>32)<<1);} uint64_t t1=ns();sink=s;return (double)(t1-t0)/n;}
int main(void){pin0(); for(int i=0;i<4096;i++){a[i].id=i*2654435761u; a[i].score=i*2246822519u+7; a[i].key=i*3266489917u+11;a[i].valid=i&1;} const uint32_t N=30000000u; for(int r=0;r<15;r++){double x=two_id_score(N),y=pair_id_score(N); printf("id_score %d %.9f %.9f %.6f\n",r,x,y,x/y); double k=two_key_valid(N),p=pair_key_valid(N); printf("key_valid %d %.9f %.9f %.6f\n",r,k,p,k/p);} return 0;}

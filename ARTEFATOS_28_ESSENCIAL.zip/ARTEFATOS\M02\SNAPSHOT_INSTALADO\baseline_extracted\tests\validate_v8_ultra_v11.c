#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_ultra_v11.h"

#define CHUNK (1u<<20)
#define ROUNDS 20
#define PAD 320

static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static uint64_t checked=0,bad=0;
static void fail(const char*tag,size_t i,uint32_t got,uint32_t ref){if(bad<16)fprintf(stderr,"FAIL %s i=%zu got=%u ref=%u\n",tag,i,got,ref);bad++;}

static int check_gate(const uint16_t*v,const uint16_t*g,uint8_t*out,uint8_t*nib,uint8_t*ref,size_t n){
    size_t i;
    for(i=0;i<n;i++) ref[i]=(uint8_t)v0_eval_gate16_v10_inline(v[i],g[i]);
    for(i=0;i<n;i++){
        uint8_t x=(uint8_t)v0_eval_gate16_v11_scalar_lut_inline(v[i],g[i]);
        if(x!=ref[i])fail("scalar-lut",i,x,ref[i]);
    }
#if defined(__AVX2__) || defined(_M_AVX2)
    memset(nib,0xA5,(n+1)/2+64);
    v0_eval_gate16_batch_v11_avx2_nibble(v,g,nib,n);
    for(i=0;i<n;i++){
        const uint8_t x=(i&1u)?(uint8_t)(nib[i>>1]>>4):(uint8_t)(nib[i>>1]&15u);
        if(x!=ref[i])fail("nibble",i,x,ref[i]);
    }
    if(n>=256){
        memset(nib,0xA5,(n+1)/2+64);
        v0_eval_gate16_batch_v11_stream_avx2_nibble(v,g,nib,n);
        for(i=0;i<n;i++){
            const uint8_t x=(i&1u)?(uint8_t)(nib[i>>1]>>4):(uint8_t)(nib[i>>1]&15u);
            if(x!=ref[i])fail("nibble-stream",i,x,ref[i]);
        }
    }
#endif
    checked+=n;
    return bad?1:0;
}

int main(void){
    uint16_t *v,*c,*g;uint8_t *t,*p,*out,*nib,*ref;uint64_t s=0xD1B54A32D192ED03ULL;size_t i,n;
    if(posix_memalign((void**)&v,64,(CHUNK+PAD)*2)||posix_memalign((void**)&c,64,(CHUNK+PAD)*2)||
       posix_memalign((void**)&g,64,(CHUNK+PAD)*2)||posix_memalign((void**)&t,64,CHUNK+PAD)||
       posix_memalign((void**)&p,64,CHUNK+PAD)||posix_memalign((void**)&out,64,CHUNK+PAD+64)||
       posix_memalign((void**)&nib,64,(CHUNK+PAD)/2+128)||posix_memalign((void**)&ref,64,CHUNK+PAD+64))return 2;

    /* Exhaust every possible unsaturated value+gate sum (0..131070). */
    for(uint32_t sum=0;sum<=131070u && !bad;sum++){
        const uint16_t vv=(sum>65535u)?65535u:(uint16_t)sum;
        const uint16_t gg=(uint16_t)(sum-(uint32_t)vv);
        const uint32_t a=v0_eval_gate16_v10_inline(vv,gg);
        const uint32_t b=v0_eval_gate16_v11_scalar_lut_inline(vv,gg);
        if(a!=b)fail("sum-exhaustive",sum,b,a);
        checked++;
    }

    /* 20M legal raw signals -> legal gate16 -> all V11 representations. */
    for(unsigned r=0;r<ROUNDS && !bad;r++){
        for(i=0;i<CHUNK;i++){
            v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);
            t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);
            g[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);
        }
        check_gate(v,g,out,nib,ref,CHUNK);
        for(i=0;i<CHUNK;i++){
            const uint8_t rr=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);
            if(ref[i]!=rr)fail("raw-reference",i,ref[i],rr);
        }
    }

    /* Every tail 0..257. */
    for(n=0;n<=257 && !bad;n++){
        for(i=0;i<n;i++){
            v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);
            t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);
            g[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);
        }
        check_gate(v,g,out,nib,ref,n);
    }

    printf("checked=%llu divergences=%llu\n",(unsigned long long)checked,(unsigned long long)bad);
    printf("status=%s\n",bad?"FAIL":"PASS");
    return bad?3:0;
}

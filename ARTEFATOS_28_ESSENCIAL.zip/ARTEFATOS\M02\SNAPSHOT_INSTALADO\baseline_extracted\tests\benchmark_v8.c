#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <inttypes.h>
#include <sched.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_adaptive.h"
extern int32_t v0_lookup_exact(const void*);extern const unsigned char v0l_keys[];
#define ITEMS (1u<<18)
#define PHASES 8
#define REPS 7
typedef struct{uint32_t r;uint8_t temp,pad[3];}Item;static Item*it;static volatile uint64_t sink;
static uint64_t now(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}static int cmpd(const void*a,const void*b){double x=*(double*)a,y=*(double*)b;return x<y?-1:x>y;}static inline uint32_t rng(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;*s=x;return(uint32_t)x;}static void pin0(){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);}static inline int isdrop(const Item*x,int pct){return(int)(x->r%100u)<pct;}static inline v0_decision_signal_v7_t sig(const Item*x,int pct){int d=isdrop(x,pct);return v0_decision_v7_pack(d?0:60000,d?65535:0,x->temp,0);}static inline uint32_t exact(const Item*x,uint32_t seq){uint32_t id=(x->r+seq)&1023u;return(uint32_t)v0_lookup_exact(v0l_keys+(size_t)id*22u);}__attribute__((noinline))static uint64_t heavy(uint64_t x){for(int k=0;k<12;k++){x^=x>>7;x*=0x9e3779b97f4a7c15ull;x^=x<<11;}return x;}
typedef enum{WORK_GLOBAL=0,WORK_HEAVY=1}Work;
static inline uint64_t dowork(Work w,const Item*x,uint32_t seq){return w==WORK_GLOBAL?exact(x,seq):heavy((uint64_t)x->r+seq);}
static inline int pct_at(const int p[PHASES],uint64_t idx){return p[(idx/ITEMS)%PHASES];}
static double base(Work w,const int p[PHASES]){(void)p;uint64_t total=(uint64_t)ITEMS*PHASES,a=0,t=now();for(uint64_t q=0;q<total;q++){uint32_t i=(uint32_t)(q&(ITEMS-1));a+=dowork(w,&it[i],(uint32_t)q);}uint64_t e=now();sink=a;return(double)(e-t)/total;}
static double always(Work w,const int p[PHASES]){uint64_t total=(uint64_t)ITEMS*PHASES,a=0,t=now();for(uint64_t q=0;q<total;q++){uint32_t i=(uint32_t)(q&(ITEMS-1));int dp=pct_at(p,q);v0_decision_signal_v7_t s=sig(&it[i],dp);if(v0_preflight_v0l_v7(&s))a+=dowork(w,&it[i],(uint32_t)q);}uint64_t e=now();sink=a;return(double)(e-t)/total;}
static double adaptive(Work w,const int p[PHASES],v0_v8_state_t*out){uint64_t total=(uint64_t)ITEMS*PHASES,q=0,a=0,tall=now();v0_v8_state_t st;v0_v8_init(&st,v0_v8_default_config());while(q<total){v0_v8_plan_t pl=v0_v8_plan(&st);uint32_t n=pl.count;if((uint64_t)n>total-q)n=(uint32_t)(total-q);uint64_t tb=pl.measure?now():0; if(pl.mode==V0_V8_BYPASS){for(uint32_t j=0;j<n;j++,q++){uint32_t i=(uint32_t)(q&(ITEMS-1));a+=dowork(w,&it[i],(uint32_t)q);}}else{for(uint32_t j=0;j<n;j++,q++){uint32_t i=(uint32_t)(q&(ITEMS-1));int dp=pct_at(p,q);v0_decision_signal_v7_t s=sig(&it[i],dp);if(v0_preflight_v0l_v7(&s))a+=dowork(w,&it[i],(uint32_t)q);}}uint64_t elapsed=pl.measure?(now()-tb):0;v0_v8_complete(&st,pl.mode,elapsed,n);}uint64_t e=now();sink=a;if(out)*out=st;return(double)(e-tall)/total;}
static double med(int kind,Work w,const int p[PHASES],v0_v8_state_t*out){double x[REPS];v0_v8_state_t states[REPS];for(int k=0;k<REPS;k++)x[k]=kind==0?base(w,p):(kind==1?always(w,p):adaptive(w,p,&states[k]));double y[REPS];for(int k=0;k<REPS;k++)y[k]=x[k];qsort(y,REPS,sizeof(double),cmpd);double m=y[REPS/2];if(kind==2&&out){int bi=0;for(int k=1;k<REPS;k++){double da=x[k]-m;if(da<0)da=-da;double db=x[bi]-m;if(db<0)db=-db;if(da<db)bi=k;}*out=states[bi];}return m;}
static void scenario(const char*n,Work w,const int p[PHASES]){v0_v8_state_t s;double b=med(0,w,p,0),a=med(1,w,p,0),v=med(2,w,p,&s);printf("%s baseline=%.3f alwaysV7=%.3f adaptiveV8=%.3f base/adapt=%.3fx always/adapt=%.3fx selected=%u on=%u off=%u probes=%u epochs=%u\n",n,b,a,v,b/v,a/v,s.selected_mode,s.switches_to_filter,s.switches_to_bypass,s.probes_completed,s.epoch);}
int main(){pin0();it=aligned_alloc(64,sizeof(Item)*ITEMS);if(!it)return 2;uint64_t r=0x8888777766665555ull;for(uint32_t i=0;i<ITEMS;i++){uint32_t x=rng(&r);it[i]=(Item){x,(uint8_t)(x%3u),{0,0,0}};}const int lo[PHASES]={20,20,20,20,20,20,20,20},hi[PHASES]={90,90,90,90,90,90,90,90},mix[PHASES]={90,90,20,20,90,10,85,30};scenario("global_low_drop",WORK_GLOBAL,lo);scenario("global_high_drop_random",WORK_GLOBAL,hi);scenario("global_phase_shift",WORK_GLOBAL,mix);scenario("heavy_low_drop",WORK_HEAVY,lo);scenario("heavy_high_drop",WORK_HEAVY,hi);scenario("heavy_phase_shift",WORK_HEAVY,mix);printf("sink=%"PRIu64"\n",sink);free(it);}

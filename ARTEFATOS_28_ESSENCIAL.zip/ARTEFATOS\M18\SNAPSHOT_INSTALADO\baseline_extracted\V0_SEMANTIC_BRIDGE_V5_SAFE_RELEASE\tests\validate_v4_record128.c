#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <emmintrin.h>
extern __m128i v0_semantic_record128_trusted(const void*);
static uint64_t rng=0x243f6a8885a308d3ull;
static uint64_t rnd64(void){rng^=rng<<7;rng^=rng>>9;rng^=rng<<8;return rng;}
int main(void){
    unsigned char buf[64+16], out[16]; uint64_t checks=0,bad=0;
    for(unsigned off=0;off<16;off++){
        for(uint32_t i=0;i<1000000u;i++){
            for(int j=0;j<16;j++) buf[off+j]=(unsigned char)(rnd64()>>(j&7)*8);
            __m128i v=v0_semantic_record128_trusted(buf+off);
            _mm_storeu_si128((__m128i*)out,v);
            checks++;
            if(memcmp(out,buf+off,16)!=0){bad++; if(bad<4) printf("mismatch off=%u i=%u\n",off,i);}
        }
    }
    printf("checks=%llu divergences=%llu align_offsets=16\n",(unsigned long long)checks,(unsigned long long)bad);
    return bad?1:0;
}

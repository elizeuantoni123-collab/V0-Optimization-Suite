#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <tlhelp32.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "v0_decision_v7.h"
#include "v0_decision_v8_adaptive.h"
#include "v0_decision_v8_fast.h"
#include "v0_decision_v8_extreme.h"
#include "v0_decision_v8_ultra_v12.h"

#define SERVICE_NAME_A "V0DecisionV8"
#define PIPE_NAME_A "\\\\.\\pipe\\V0DecisionV8"
#define BUILD_NAME_A "V12-GLOBAL-PROCESS-V1"
#define PROCESS_SCAN_MS 100u
#define MAX_LIVE_PIDS 16384u

static SERVICE_STATUS_HANDLE g_status_handle = NULL;
static SERVICE_STATUS g_status;
static HANDLE g_stop_event = NULL;
static HANDLE g_pipe_worker = NULL;
static HANDLE g_process_worker = NULL;
static CRITICAL_SECTION g_controller_lock;
static CRITICAL_SECTION g_process_lock;
static v0_v8_state_t g_v8;

static DWORD g_live_pids[MAX_LIVE_PIDS];
static DWORD g_live_count = 0;
static ULONGLONG g_total_seen = 0;
static ULONGLONG g_process_scans = 0;
static ULONGLONG g_scan_failures = 0;
static ULONGLONG g_truncated_scans = 0;
static ULONGLONG g_last_scan_tick = 0;
static ULONGLONG g_pid_decisions = 0;
static ULONGLONG g_pid_gate_decisions = 0;
static ULONGLONG g_pid_not_live = 0;

static const char *mode_name(uint32_t mode) {
    return mode == V0_V8_FILTER ? "FILTER" : "BYPASS";
}

static const char *phase_name(uint32_t phase) {
    switch (phase) {
        case V0_V8_PROBE_A: return "PROBE_A";
        case V0_V8_PROBE_B: return "PROBE_B";
        case V0_V8_ACTIVE:  return "ACTIVE";
        default: return "UNKNOWN";
    }
}

static int __cdecl compare_dword(const void *a, const void *b) {
    const DWORD x = *(const DWORD *)a;
    const DWORD y = *(const DWORD *)b;
    return (x > y) - (x < y);
}

static void set_service_status(DWORD state, DWORD win32_exit, DWORD wait_hint) {
    static DWORD checkpoint = 1;
    ZeroMemory(&g_status, sizeof(g_status));
    g_status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    g_status.dwCurrentState = state;
    g_status.dwWin32ExitCode = win32_exit;
    g_status.dwWaitHint = wait_hint;
    if (state == SERVICE_START_PENDING || state == SERVICE_STOP_PENDING) {
        g_status.dwControlsAccepted = 0;
        g_status.dwCheckPoint = checkpoint++;
    } else {
        g_status.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
        g_status.dwCheckPoint = 0;
    }
    if (state == SERVICE_STOPPED) g_status.dwControlsAccepted = 0;
    if (g_status_handle) SetServiceStatus(g_status_handle, &g_status);
}

static void write_response(HANDLE pipe, const char *text) {
    char out[2048];
    DWORD written = 0;
    _snprintf(out, sizeof(out) - 1, "%s\r\n", text ? text : "");
    out[sizeof(out) - 1] = '\0';
    WriteFile(pipe, out, (DWORD)strlen(out), &written, NULL);
}

static int pid_is_live(DWORD pid) {
    DWORD lo = 0, hi;
    int found = 0;
    EnterCriticalSection(&g_process_lock);
    hi = g_live_count;
    while (lo < hi) {
        DWORD mid = lo + ((hi - lo) >> 1);
        DWORD v = g_live_pids[mid];
        if (v == pid) { found = 1; break; }
        if (v < pid) lo = mid + 1;
        else hi = mid;
    }
    LeaveCriticalSection(&g_process_lock);
    return found;
}

static void query_process_image(DWORD pid, char *out, size_t cap) {
    HANDLE h;
    DWORD n;
    if (!out || cap == 0) return;
    out[0] = '\0';
    h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!h) {
        _snprintf(out, cap - 1, "<protected-or-exited>");
        out[cap - 1] = '\0';
        return;
    }
    n = (DWORD)cap;
    if (!QueryFullProcessImageNameA(h, 0, out, &n)) {
        _snprintf(out, cap - 1, "<query-failed>");
        out[cap - 1] = '\0';
    }
    CloseHandle(h);
}

static DWORD WINAPI process_scan_worker(LPVOID unused) {
    DWORD *previous = NULL;
    DWORD *current = NULL;
    DWORD previous_count = 0;
    (void)unused;

    previous = (DWORD *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
                                  MAX_LIVE_PIDS * sizeof(DWORD));
    current = (DWORD *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
                                 MAX_LIVE_PIDS * sizeof(DWORD));
    if (!previous || !current) {
        if (previous) HeapFree(GetProcessHeap(), 0, previous);
        if (current) HeapFree(GetProcessHeap(), 0, current);
        EnterCriticalSection(&g_process_lock);
        ++g_scan_failures;
        LeaveCriticalSection(&g_process_lock);
        return 1;
    }

    while (WaitForSingleObject(g_stop_event, 0) != WAIT_OBJECT_0) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        DWORD current_count = 0;
        int truncated = 0;

        if (snap == INVALID_HANDLE_VALUE) {
            EnterCriticalSection(&g_process_lock);
            ++g_scan_failures;
            LeaveCriticalSection(&g_process_lock);
            if (WaitForSingleObject(g_stop_event, PROCESS_SCAN_MS) == WAIT_OBJECT_0) break;
            continue;
        }

        {
            PROCESSENTRY32W pe;
            ZeroMemory(&pe, sizeof(pe));
            pe.dwSize = sizeof(pe);
            if (Process32FirstW(snap, &pe)) {
                do {
                    if (current_count < MAX_LIVE_PIDS) {
                        current[current_count++] = pe.th32ProcessID;
                    } else {
                        truncated = 1;
                    }
                } while (Process32NextW(snap, &pe));
            }
        }
        CloseHandle(snap);

        qsort(current, current_count, sizeof(DWORD), compare_dword);

        {
            DWORD i = 0, j = 0;
            ULONGLONG newly_seen = 0;
            while (i < current_count) {
                while (j < previous_count && previous[j] < current[i]) ++j;
                if (j >= previous_count || previous[j] != current[i]) ++newly_seen;
                ++i;
            }

            EnterCriticalSection(&g_process_lock);
            if (current_count) memcpy(g_live_pids, current, current_count * sizeof(DWORD));
            g_live_count = current_count;
            g_total_seen += newly_seen;
            ++g_process_scans;
            if (truncated) ++g_truncated_scans;
            g_last_scan_tick = GetTickCount64();
            LeaveCriticalSection(&g_process_lock);
        }

        if (current_count) memcpy(previous, current, current_count * sizeof(DWORD));
        previous_count = current_count;

        if (WaitForSingleObject(g_stop_event, PROCESS_SCAN_MS) == WAIT_OBJECT_0) break;
    }

    HeapFree(GetProcessHeap(), 0, previous);
    HeapFree(GetProcessHeap(), 0, current);
    return 0;
}

static void handle_command(HANDLE pipe, char *cmd) {
    char response[2048];
    unsigned value, cost, temp, pinned, gate;
    unsigned mode, count;
    unsigned long pid_ul;
    unsigned long long ticks;

    while (*cmd == ' ' || *cmd == '\t') ++cmd;
    for (char *p = cmd; *p; ++p) {
        if (*p == '\r' || *p == '\n') { *p = '\0'; break; }
    }

    if (_stricmp(cmd, "PING") == 0) {
        write_response(pipe, "PONG V0DecisionV8 V12-GLOBAL-PROCESS-V1");
        return;
    }

    if (_stricmp(cmd, "VERSION") == 0) {
        write_response(pipe,
            "OK build=" BUILD_NAME_A " core=V12 service=V0DecisionV8 pipe=V0DecisionV8 coverage=process-snapshot enforcement=none");
        return;
    }

    if (_stricmp(cmd, "GLOBALSTATUS") == 0) {
        DWORD live;
        ULONGLONG seen, scans, failures, truncated, last_tick, decisions, gate_decisions, not_live;
        EnterCriticalSection(&g_process_lock);
        live = g_live_count;
        seen = g_total_seen;
        scans = g_process_scans;
        failures = g_scan_failures;
        truncated = g_truncated_scans;
        last_tick = g_last_scan_tick;
        decisions = g_pid_decisions;
        gate_decisions = g_pid_gate_decisions;
        not_live = g_pid_not_live;
        LeaveCriticalSection(&g_process_lock);
        _snprintf(response, sizeof(response) - 1,
                  "OK build=%s live=%lu total_seen=%llu scans=%llu failures=%llu truncated=%llu scan_ms=%u last_tick=%llu pid_decisions=%llu gate_decisions=%llu pid_not_live=%llu enforcement=none",
                  BUILD_NAME_A, (unsigned long)live, seen, scans, failures, truncated,
                  (unsigned)PROCESS_SCAN_MS, last_tick, decisions, gate_decisions, not_live);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (sscanf(cmd, "PIDSTATUS %lu", &pid_ul) == 1) {
        char image[1024];
        DWORD pid = (DWORD)pid_ul;
        int live = pid_is_live(pid);
        query_process_image(pid, image, sizeof(image));
        _snprintf(response, sizeof(response) - 1,
                  "OK pid=%lu live=%u image=%s",
                  (unsigned long)pid, live ? 1u : 0u, image);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (_stricmp(cmd, "RESET") == 0) {
        EnterCriticalSection(&g_controller_lock);
        v0_v8_init(&g_v8, v0_v8_default_config());
        LeaveCriticalSection(&g_controller_lock);
        write_response(pipe, "OK RESET mode=BYPASS phase=PROBE_A");
        return;
    }

    if (_stricmp(cmd, "STATUS") == 0) {
        DWORD live;
        EnterCriticalSection(&g_process_lock);
        live = g_live_count;
        LeaveCriticalSection(&g_process_lock);
        EnterCriticalSection(&g_controller_lock);
        _snprintf(response, sizeof(response) - 1,
                  "OK build=%s mode=%s phase=%s epoch=%u probes=%u switches_filter=%u switches_bypass=%u probe_count=%u active_count=%u margin_permille=%u global_live=%lu",
                  BUILD_NAME_A, mode_name(g_v8.selected_mode), phase_name(g_v8.phase),
                  g_v8.epoch, g_v8.probes_completed,
                  g_v8.switches_to_filter, g_v8.switches_to_bypass,
                  g_v8.cfg.probe_count, g_v8.cfg.active_count,
                  (unsigned)g_v8.cfg.switch_margin_permille,
                  (unsigned long)live);
        LeaveCriticalSection(&g_controller_lock);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (_stricmp(cmd, "PLAN") == 0) {
        v0_v8_plan_t p;
        EnterCriticalSection(&g_controller_lock);
        p = v0_v8_plan(&g_v8);
        LeaveCriticalSection(&g_controller_lock);
        _snprintf(response, sizeof(response) - 1,
                  "OK mode=%s mode_id=%u count=%u measure=%u authoritative=%u",
                  mode_name(p.mode), p.mode, p.count, p.measure, p.authoritative);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (sscanf(cmd, "COMPLETE %u %llu %u", &mode, &ticks, &count) == 3) {
        if (mode > 1u || count == 0u) {
            write_response(pipe, "ERR COMPLETE expects: mode(0|1) ticks count>0");
            return;
        }
        EnterCriticalSection(&g_controller_lock);
        v0_v8_complete(&g_v8, mode, (uint64_t)ticks, count);
        _snprintf(response, sizeof(response) - 1,
                  "OK mode=%s phase=%s epoch=%u probes=%u switches_filter=%u switches_bypass=%u",
                  mode_name(g_v8.selected_mode), phase_name(g_v8.phase),
                  g_v8.epoch, g_v8.probes_completed,
                  g_v8.switches_to_filter, g_v8.switches_to_bypass);
        LeaveCriticalSection(&g_controller_lock);
        response[sizeof(response) - 1] = '\0';
        write_response(pipe, response);
        return;
    }

    if (sscanf(cmd, "DECIDEPID %lu %u %u %u %u", &pid_ul, &value, &cost, &temp, &pinned) == 5) {
        DWORD pid = (DWORD)pid_ul;
        if (value > 65535u || cost > 65535u || temp > 2u || pinned > 1u) {
            write_response(pipe, "ERR DECIDEPID ranges: pid>0 value/cost 0..65535 temp 0..2 pinned 0..1");
            return;
        }
        if (!pid_is_live(pid)) {
            EnterCriticalSection(&g_process_lock);
            ++g_pid_not_live;
            LeaveCriticalSection(&g_process_lock);
            write_response(pipe, "ERR PID_NOT_LIVE");
            return;
        }
        {
            const uint32_t packed = v0_eval_v8_raw_ultra_inline(
                (uint16_t)value, (uint16_t)cost, (uint8_t)temp, (uint8_t)pinned);
            const uint32_t pre = v0_eval_v8_preflight(packed);
            const uint32_t dec = v0_eval_v8_decision(packed);
            EnterCriticalSection(&g_process_lock);
            ++g_pid_decisions;
            LeaveCriticalSection(&g_process_lock);
            EnterCriticalSection(&g_controller_lock);
            _snprintf(response, sizeof(response) - 1,
                      "OK pid=%lu preflight=%u decision=%u controller_mode=%s",
                      (unsigned long)pid, pre, dec, mode_name(g_v8.selected_mode));
            LeaveCriticalSection(&g_controller_lock);
            response[sizeof(response) - 1] = '\0';
            write_response(pipe, response);
            return;
        }
    }

    if (sscanf(cmd, "GATEDECIDEPID %lu %u %u", &pid_ul, &value, &gate) == 3) {
        DWORD pid = (DWORD)pid_ul;
        if (value > 65535u || gate > 65535u) {
            write_response(pipe, "ERR GATEDECIDEPID ranges: pid>0 value/gate 0..65535");
            return;
        }
        if (!pid_is_live(pid)) {
            EnterCriticalSection(&g_process_lock);
            ++g_pid_not_live;
            LeaveCriticalSection(&g_process_lock);
            write_response(pipe, "ERR PID_NOT_LIVE");
            return;
        }
        {
            const uint32_t dec = v0_eval_gate16_v12_scalar_direct_inline(
                (uint16_t)value, (v0_decision_gate16_v10_t)gate);
            const uint32_t pre = v0_preflight_gate16_v12_scalar_inline(
                (uint16_t)value, (v0_decision_gate16_v10_t)gate);
            EnterCriticalSection(&g_process_lock);
            ++g_pid_gate_decisions;
            LeaveCriticalSection(&g_process_lock);
            _snprintf(response, sizeof(response) - 1,
                      "OK pid=%lu preflight=%u decision=%u gate16=%u",
                      (unsigned long)pid, pre, dec, gate);
            response[sizeof(response) - 1] = '\0';
            write_response(pipe, response);
            return;
        }
    }

    /* Preserve the original process-agnostic command for compatibility. */
    if (sscanf(cmd, "DECIDE %u %u %u %u", &value, &cost, &temp, &pinned) == 4) {
        if (value > 65535u || cost > 65535u || temp > 2u || pinned > 1u) {
            write_response(pipe, "ERR DECIDE ranges: value/cost 0..65535 temp 0..2 pinned 0..1");
            return;
        }
        {
            const uint32_t packed = v0_eval_v8_raw_ultra_inline(
                (uint16_t)value, (uint16_t)cost, (uint8_t)temp, (uint8_t)pinned);
            const uint32_t pre = v0_eval_v8_preflight(packed);
            const uint32_t dec = v0_eval_v8_decision(packed);
            EnterCriticalSection(&g_controller_lock);
            _snprintf(response, sizeof(response) - 1,
                      "OK preflight=%u decision=%u controller_mode=%s",
                      pre, dec, mode_name(g_v8.selected_mode));
            LeaveCriticalSection(&g_controller_lock);
            response[sizeof(response) - 1] = '\0';
            write_response(pipe, response);
            return;
        }
    }

    write_response(pipe,
        "ERR commands: PING | VERSION | STATUS | GLOBALSTATUS | PIDSTATUS pid | RESET | DECIDE value cost temp pinned | DECIDEPID pid value cost temp pinned | GATEDECIDEPID pid value gate16 | PLAN | COMPLETE mode ticks count");
}

static DWORD WINAPI pipe_worker(LPVOID unused) {
    (void)unused;
    while (WaitForSingleObject(g_stop_event, 0) != WAIT_OBJECT_0) {
        HANDLE pipe = CreateNamedPipeA(
            PIPE_NAME_A,
            PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
            PIPE_UNLIMITED_INSTANCES,
            4096, 4096, 0, NULL);

        if (pipe == INVALID_HANDLE_VALUE) {
            if (WaitForSingleObject(g_stop_event, 1000) == WAIT_OBJECT_0) break;
            continue;
        }

        {
            BOOL connected = ConnectNamedPipe(pipe, NULL)
                ? TRUE
                : (GetLastError() == ERROR_PIPE_CONNECTED);

            if (connected && WaitForSingleObject(g_stop_event, 0) != WAIT_OBJECT_0) {
                for (;;) {
                    char input[2048];
                    DWORD got = 0;
                    BOOL ok;
                    if (WaitForSingleObject(g_stop_event, 0) == WAIT_OBJECT_0) break;
                    ZeroMemory(input, sizeof(input));
                    ok = ReadFile(pipe, input, sizeof(input) - 1, &got, NULL);
                    if (!ok || got == 0) break;
                    input[got] = '\0';
                    handle_command(pipe, input);
                }
            }
        }

        DisconnectNamedPipe(pipe);
        CloseHandle(pipe);
    }
    return 0;
}

static DWORD WINAPI service_ctrl(DWORD control, DWORD event_type, LPVOID event_data, LPVOID context) {
    (void)event_type; (void)event_data; (void)context;
    if (control == SERVICE_CONTROL_STOP || control == SERVICE_CONTROL_SHUTDOWN) {
        set_service_status(SERVICE_STOP_PENDING, NO_ERROR, 3000);
        if (g_stop_event) SetEvent(g_stop_event);
        {
            HANDLE h = CreateFileA(PIPE_NAME_A, GENERIC_READ | GENERIC_WRITE,
                                   0, NULL, OPEN_EXISTING, 0, NULL);
            if (h != INVALID_HANDLE_VALUE) CloseHandle(h);
        }
        return NO_ERROR;
    }
    return NO_ERROR;
}

static VOID WINAPI service_main(DWORD argc, LPSTR *argv) {
    (void)argc; (void)argv;
    g_status_handle = RegisterServiceCtrlHandlerExA(SERVICE_NAME_A, service_ctrl, NULL);
    if (!g_status_handle) return;

    set_service_status(SERVICE_START_PENDING, NO_ERROR, 5000);

    InitializeCriticalSection(&g_controller_lock);
    InitializeCriticalSection(&g_process_lock);
    v0_v8_init(&g_v8, v0_v8_default_config());

    g_stop_event = CreateEventA(NULL, TRUE, FALSE, NULL);
    if (!g_stop_event) {
        DeleteCriticalSection(&g_process_lock);
        DeleteCriticalSection(&g_controller_lock);
        set_service_status(SERVICE_STOPPED, GetLastError(), 0);
        return;
    }

    g_process_worker = CreateThread(NULL, 0, process_scan_worker, NULL, 0, NULL);
    g_pipe_worker = CreateThread(NULL, 0, pipe_worker, NULL, 0, NULL);
    if (!g_process_worker || !g_pipe_worker) {
        DWORD e = GetLastError();
        SetEvent(g_stop_event);
        if (g_process_worker) { WaitForSingleObject(g_process_worker, 2000); CloseHandle(g_process_worker); }
        if (g_pipe_worker) { WaitForSingleObject(g_pipe_worker, 2000); CloseHandle(g_pipe_worker); }
        CloseHandle(g_stop_event); g_stop_event = NULL;
        DeleteCriticalSection(&g_process_lock);
        DeleteCriticalSection(&g_controller_lock);
        set_service_status(SERVICE_STOPPED, e, 0);
        return;
    }

    /* Give the process scanner one short chance to populate before reporting RUNNING. */
    Sleep(120);
    set_service_status(SERVICE_RUNNING, NO_ERROR, 0);
    WaitForSingleObject(g_stop_event, INFINITE);

    WaitForSingleObject(g_pipe_worker, 5000);
    WaitForSingleObject(g_process_worker, 5000);
    CloseHandle(g_pipe_worker); g_pipe_worker = NULL;
    CloseHandle(g_process_worker); g_process_worker = NULL;
    CloseHandle(g_stop_event); g_stop_event = NULL;
    DeleteCriticalSection(&g_process_lock);
    DeleteCriticalSection(&g_controller_lock);
    set_service_status(SERVICE_STOPPED, NO_ERROR, 0);
}

int main(void) {
    SERVICE_TABLE_ENTRYA table[] = {
        { SERVICE_NAME_A, service_main },
        { NULL, NULL }
    };

    if (!StartServiceCtrlDispatcherA(table)) {
        DWORD e = GetLastError();
        if (e == ERROR_FAILED_SERVICE_CONTROLLER_CONNECT) {
            fprintf(stderr, "V0Decision global service must be started by Windows Service Control Manager.\n");
            fprintf(stderr, "Use INSTALAR_GLOBAL_PROCESS_V12.ps1.\n");
        }
        return (int)e;
    }
    return 0;
}

$ErrorActionPreference = "Stop"
$client = Join-Path $PSScriptRoot "CLIENTE_DECISION_V8.ps1"
Write-Host "PING:" -ForegroundColor Cyan
& $client -Command "PING"
Write-Host "STATUS:" -ForegroundColor Cyan
& $client -Command "STATUS"
Write-Host "DECIDE (mesmo caso validado anteriormente):" -ForegroundColor Cyan
& $client -Command "DECIDE 500 200 1 0"
Write-Host "PLAN atual:" -ForegroundColor Cyan
& $client -Command "PLAN"

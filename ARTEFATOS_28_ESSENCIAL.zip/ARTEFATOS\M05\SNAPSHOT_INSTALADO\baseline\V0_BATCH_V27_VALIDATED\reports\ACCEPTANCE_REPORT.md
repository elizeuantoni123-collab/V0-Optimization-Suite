# V0 Batch — Acceptance Report

Data: 2026-09-24/25 (America/Sao_Paulo)

## Correção final

`tests/test_all` no pacote final:

- **148,146,658 verificações**
- resultado: **PASS**
- inclui full-range pseudoaleatório `uint32_t` para count/take/fixed64;
- inclui 250.000 planos aleatórios, comparação descriptor-a-descriptor e sentinela de overwrite;
- Linux ELF64: PASS;
- Windows x86-64 COFF: geração estrutural PASS.

## Evolução aceita

### V1 — referência
Planner iterativo V0L. 2,000,020 comparações iniciais, 0 divergências. Linux `.text`: 143 B para count+take.

### V2 — count O(1)
`ceil(items/limit)` passou a `(items-1)/limit+1`, com guardas exatos para zero. 10,000,722 checks, 0 divergências.

Benchmark pareado observado: V1 ~678.9 ns/op -> V2 ~1.75 ns/op no workload usado (~387x). O `take` da V2 ficou pior e foi rejeitado.

### V3 — take + fixed64
O `take` V3 venceu o V1 (~1.39x numa medição pareada) e fixed64 ganhou sobre o genérico (~1.15x count / ~1.33x take na medição inicial). O count genérico V3 perdeu para V2 e foi rejeitado.

### V6 — planner completo fundido
Escreve spans `{start,count}` diretamente. Linux `.text`: 73 B; Windows: 76 B.

Contra construir o plano chamando `take64` por lote, o planner fundido mediu aproximadamente:
- 64 itens: 1.83x;
- 65 itens: 2.04x;
- 256 itens: 2.38x;
- 1.024 itens: 2.87x;
- 4.096 itens: 2.98x.

### V8 — large-plan x4
300.020 planos completos comparados contra V6: 0 divergências.

Speedup V8 x4 vs V6 no host de validação:
- 512 itens: 1.43x;
- 1.024: 1.61x;
- 4.096: 1.94x;
- 16.384: 1.93x;
- 65.536: 2.08x;
- 262.144: 2.05x.

Varredura de cutoff mostrou V6 mais rápido de 1 a 256 itens; V8 x4 venceu em todos os pontos medidos de 257 a 1.024. O cutoff é host-specific.

## Tentativas não promovidas

- V2 `take`: regressão de velocidade -> rejeitado.
- V3 generic `count`: mais lento que V2 -> rejeitado.
- V5 compact guard: código menor, mas desempenho não uniformemente melhor -> rejeitado como substituto.
- V7 planner compacto 47 B: menor, porém perdeu para V6 em vários tamanhos pequenos -> rejeitado como substituto.
- V9 unroll 8x: ganhos mistos, com regressões em 1.024 e 65.536 itens -> rejeitado.
- V10 `CMOV take`: até ~2.90x em distribuição imprevisível, mas ligeiramente atrás no caminho altamente previsível -> não substitui o branch path aceito.

## Isolamento

Nenhum kernel aceito referencia V0 Global, EPT, VMX, driver, rede, modelo semântico ou runtime externo. O pacote é um conjunto de objetos V0L x86-64 independentes.

### V11 — packed 64-bit x4 [PROMOVIDO]
Cada span full-64 passa a ser gravado com uma única store de 64 bits: low32=start, high32=count=64. A ABI `{u32 start; u32 count;}` permanece byte-a-byte idêntica.

300.020 planos completos contra V8: **0 divergências**. Speedup V11 vs V8 observado:
- 257 itens: 1.038x;
- 512: 1.149x;
- 1.024: 1.259x;
- 4.096: 1.327x;
- 16.384: 1.109x;
- 65.536: 1.004x;
- 262.144: 1.048x;
- 1.048.576: 1.022x.

O caminho pequeno V6 é mantido como fallback conservador.

### V12 — packed 8x [REJEITADO]
Passou correção (200.000 planos), mas apresentou regressão em 16.384 itens (~0.4% no benchmark mediano). Não foi promovido.

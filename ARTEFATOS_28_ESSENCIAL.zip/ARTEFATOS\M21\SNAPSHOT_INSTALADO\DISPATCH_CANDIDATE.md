# Dispatch candidato — Telemetry V7

A baseline oficial continua V2 + V5 até o gate Windows.

```text
telemetry OFF
    -> módulo original, sem branch de telemetry no hot path

calls=1, todos os outros counters=0
    -> V5 call-only

calls=N>=2, todos os outros counters=0
    -> V7 calls_delta CANDIDATO

single hit exato V5
    -> V5 hit

single miss+fallback exato V5
    -> V5 miss+fallback

qualquer outra delta
    -> V2 universal
```

O V7 recebe o mesmo `V0TelemetryDelta*` de 72 bytes usado pela V2. Não existe repack, novo formato ou alteração do ABI de counters.

Os protótipos agregados de hit/miss foram rejeitados nesta rodada porque houve pelo menos uma medição direta abaixo de 1.0x. Eles não entram no dispatcher.

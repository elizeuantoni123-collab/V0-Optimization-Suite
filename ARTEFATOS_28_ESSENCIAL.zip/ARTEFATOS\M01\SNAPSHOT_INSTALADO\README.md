M01 V8 Squeeze candidate. Baseline is NOT replaced.

build/m01_exact_dual_linux.o contains:
- v0_lookup_exact      (canonical baseline)
- v0_lookup_exact_v8   (specialized hit-heavy candidate)

build/m01_exact_dual_windows.obj contains the same two entry points for the Windows gate.

The candidate requires SSE4.1. Do not dispatch to it without CPU feature validation and a hit-heavy workload contract. Generic traffic must continue using the baseline.

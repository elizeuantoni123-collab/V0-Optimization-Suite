#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_fast.h"
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<20)
#define REPS 15
static int16_t *q16; static uint8_t *out8,*e3,*temp,*pin; static uint16_t *value,*cost;
static v0_decision_signal_v7_t *sig; static volatile uint64_t sink;
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+(uint64_t)x.tv_nsec;}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static void pin0(void){cpu_set_t c;CPU_ZERO(&c);CPU_SET(0,&c);(void)sched_setaffinity(0,sizeof(c),&c);}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double q6_scalar_v5(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_q6_extreme_inline(q16[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double q6_scalar_v6(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_q6_hot_lut_inline(q16[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double raw_scalar_v5(void){uint64_t z=0,t0=now_ns();for(uint32_t i=0;i<N;i++){int32_t s=v0_decision_v8_score(value[i],cost[i],temp[i],pin[i]);z+=v0_eval_v8_q6_extreme_inline((int16_t)(s>>6));}uint64_t e=now_ns();sink=z;return(double)(e-t0)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double raw_scalar_v6(void){uint64_t z=0,t0=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_raw_ultra_inline(value[i],cost[i],temp[i],pin[i]);uint64_t e=now_ns();sink=z;return(double)(e-t0)/N;}
static double packed_v7_two_calls(void){uint64_t z=0,t0=now_ns();for(uint32_t i=0;i<N;i++)z+=(v0_preflight_v0l_v7(&sig[i])<<2)|v0_decide_v0l_v7(&sig[i]);uint64_t e=now_ns();sink=z;return(double)(e-t0)/N;}
static double packed_v6_fused(void){uint64_t z=0,t0=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v0l_v8_signal_lut(&sig[i]);uint64_t e=now_ns();sink=z;return(double)(e-t0)/N;}
static double packed_v6_inline(void){uint64_t z=0,t0=now_ns();for(uint32_t i=0;i<N;i++)z+=v0_eval_v8_signal_ultra_inline(&sig[i]);uint64_t e=now_ns();sink=z;return(double)(e-t0)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double cached_e3_read(void){uint64_t z=0,t=now_ns();for(uint32_t i=0;i<N;i++)z+=e3[i];uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
static double q6_batch_v5(void){uint64_t t=now_ns();v0_eval_v8_q6_batch_avx2_u8(q16,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double q6_batch_v6(void){uint64_t t=now_ns();v0_eval_v8_q6_batch_ultra_avx2_u8(q16,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double raw_batch_v6(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_avx2_u8(value,cost,temp,pin,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double raw_preflight_count_v6(void){uint64_t t=now_ns();uint64_t z=v0_preflight_v8_raw_count_avx2(value,cost,temp,pin,N);uint64_t e=now_ns();sink+=z;return(double)(e-t)/N;}
#if defined(__AVX512BW__) && defined(__AVX512VL__)
static double raw_batch_v6_avx512(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_avx512_u8(value,cost,temp,pin,out8,N);uint64_t e=now_ns();sink+=out8[777];return(double)(e-t)/N;}
static double raw_preflight_count_v6_avx512(void){uint64_t t=now_ns();uint64_t z=v0_preflight_v8_raw_count_avx512(value,cost,temp,pin,N);uint64_t e=now_ns();sink+=z;return(double)(e-t)/N;}
#endif
#endif
static void bench(const char*n,double(*fn)(void)){double v[REPS];for(int i=0;i<5;i++)(void)fn();for(int i=0;i<REPS;i++)v[i]=fn();qsort(v,REPS,sizeof(double),cmpd);printf("%-29s p50=%8.4f best=%8.4f\n",n,v[REPS/2],v[0]);}
int main(void){pin0();q16=aligned_alloc(64,N*2);out8=aligned_alloc(64,N);e3=aligned_alloc(64,N);temp=aligned_alloc(64,N);pin=aligned_alloc(64,N);value=aligned_alloc(64,N*2);cost=aligned_alloc(64,N*2);sig=aligned_alloc(64,N*sizeof(*sig));if(!q16||!out8||!e3||!temp||!pin||!value||!cost||!sig)return 2;uint64_t st=0x9e3779b97f4a7c15ULL;for(uint32_t i=0;i<N;i++){value[i]=(uint16_t)rng64(&st);cost[i]=(uint16_t)rng64(&st);temp[i]=(uint8_t)(rng64(&st)%3u);pin[i]=(uint8_t)(rng64(&st)&1u);int32_t sc=v0_decision_v8_score(value[i],cost[i],temp[i],pin[i]);q16[i]=(int16_t)(sc>>6);e3[i]=(uint8_t)v0_eval_v8_q6_hot_lut_inline(q16[i]);sig[i]=v0_decision_v7_pack(value[i],cost[i],temp[i],pin[i]);}
bench("V5 Q6 scalar fused",q6_scalar_v5);bench("V6 Q6 scalar hot LUT",q6_scalar_v6);bench("V5 raw scalar",raw_scalar_v5);bench("V6 raw scalar ultra",raw_scalar_v6);bench("V7 packed pre+decide",packed_v7_two_calls);bench("V6 packed V0L fused",packed_v6_fused);bench("V6 packed inline LUT",packed_v6_inline);bench("V6 cached E3 consume",cached_e3_read);
#if defined(__AVX2__) || defined(_M_AVX2)
bench("V5 Q6 batch AVX2",q6_batch_v5);bench("V6 Q6 batch LUT AVX2",q6_batch_v6);bench("V6 raw SoA batch AVX2",raw_batch_v6);bench("V6 raw preflight count AVX2",raw_preflight_count_v6);
#if defined(__AVX512BW__) && defined(__AVX512VL__)
bench("V6 raw SoA batch AVX512",raw_batch_v6_avx512);bench("V6 raw preflight count AVX512",raw_preflight_count_v6_avx512);
#endif
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

﻿$ErrorActionPreference = "Stop"

function Assert-Administrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Abra o PowerShell como Administrador e execute este script novamente."
    }
}

Assert-Administrator

$Root = $PSScriptRoot
$ServiceName = "V0DecisionV8"
$DisplayName = "V0 Decision V8 Permanent Host"
$Description = "V0 Decision V8 adaptive resident host. Auto-starts with Windows and exposes the V0DecisionV8 named-pipe API."
$InstallDir = Join-Path $env:ProgramFiles "V0DecisionV8"
$BuildDir = Join-Path $Root "windows_permanent\build"
$Source = Join-Path $Root "windows_permanent\src\v0_decision_v8_service.c"
$IncludeDir = Join-Path $Root "include"
$DecisionObj = Join-Path $Root "build\windows\v0_decision_v7.obj"
$FastDecisionObj = Join-Path $Root "build\windows\v0_decision_v8_fast.obj"
$BuiltExe = Join-Path $BuildDir "V0DecisionV8Service.exe"
$InstalledExe = Join-Path $InstallDir "V0DecisionV8Service.exe"
$RegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " V0 DECISION V8 ULTRA - INSTALACAO WINDOWS V6" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

foreach ($f in @($Source, $DecisionObj, $FastDecisionObj, (Join-Path $IncludeDir "v0_decision_v7.h"), (Join-Path $IncludeDir "v0_decision_v8_adaptive.h"), (Join-Path $IncludeDir "v0_decision_v8_fast.h"), (Join-Path $IncludeDir "v0_decision_v8_extreme.h"))) {
    if (-not (Test-Path $f)) { throw "Arquivo obrigatorio nao encontrado: $f" }
}

$vcvarsCandidates = @(
    "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
)
$VcVars = $vcvarsCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $VcVars) {
    throw "Visual Studio 2022 C++ Build Tools nao encontrado."
}

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
$ServiceObj = Join-Path $BuildDir "v0_decision_v8_service.obj"

Write-Host "[1/6] Compilando host residente x64..." -ForegroundColor Yellow
$compileC = "`"$VcVars`" && cl /nologo /O2 /Ot /Oi /Ob3 /GL /Gw /Gy /MT /c /I`"$IncludeDir`" `"$Source`" /Fo:`"$ServiceObj`""
cmd /c $compileC
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $ServiceObj)) {
    throw "Falha ao compilar v0_decision_v8_service.c"
}

Write-Host "[2/6] Linkando host + nucleo V0L..." -ForegroundColor Yellow
$linkCmd = "`"$VcVars`" && cl /nologo /GL `"$ServiceObj`" `"$FastDecisionObj`" /Fe:`"$BuiltExe`" /link /LTCG /OPT:REF /OPT:ICF Advapi32.lib"
cmd /c $linkCmd
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $BuiltExe)) {
    throw "Falha ao linkar V0DecisionV8Service.exe"
}

Write-Host "[3/6] Preparando arquivos permanentes..." -ForegroundColor Yellow
$existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existing) {
    if ($existing.Status -ne 'Stopped') {
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        try { (Get-Service -Name $ServiceName).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(10)) } catch {}
    }

    # Remove uma instalacao anterior para recriar o SCM de forma limpa.
    & sc.exe delete $ServiceName | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Falha ao remover registro anterior do servico $ServiceName." }

    $deadline = (Get-Date).AddSeconds(10)
    do {
        Start-Sleep -Milliseconds 250
        $existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    } while ($existing -and (Get-Date) -lt $deadline)

    if ($existing) { throw "O servico anterior ainda esta marcado para exclusao. Reinicie o Windows e rode o instalador V6 novamente." }
}

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item $BuiltExe $InstalledExe -Force
if (-not (Test-Path $InstalledExe)) { throw "Falha ao copiar binario para $InstalledExe" }

Write-Host "[4/6] Registrando servico pelo PowerShell..." -ForegroundColor Yellow
$BinaryPathName = '"' + $InstalledExe + '"'
New-Service -Name $ServiceName `
    -BinaryPathName $BinaryPathName `
    -DisplayName $DisplayName `
    -Description $Description `
    -StartupType Automatic | Out-Null

# Delayed Auto Start sem depender da sintaxe peculiar do sc.exe create/config.
if (-not (Test-Path $RegistryPath)) { throw "Registro do servico nao encontrado apos New-Service." }
Set-ItemProperty -Path $RegistryPath -Name DelayedAutoStart -Type DWord -Value 1
Set-ItemProperty -Path $RegistryPath -Name Description -Type String -Value $Description

Write-Host "[5/6] Iniciando servico..." -ForegroundColor Yellow
Start-Service -Name $ServiceName
(Get-Service -Name $ServiceName).WaitForStatus('Running', [TimeSpan]::FromSeconds(10))

Write-Host "[6/6] Testando host residente..." -ForegroundColor Yellow
Start-Sleep -Milliseconds 400
$ping = & (Join-Path $Root "CLIENTE_DECISION_V8.ps1") -Command "PING"
$status = & (Join-Path $Root "CLIENTE_DECISION_V8.ps1") -Command "STATUS"
Write-Host "PING  : $ping"
Write-Host "STATUS: $status"

$svc = Get-Service -Name $ServiceName
$cim = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " V0 DECISION V8 PERMANENTE: ATIVO" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "Servico : $($svc.Status)"
Write-Host "Inicio  : Automatico (Delayed Start)"
Write-Host "Binario : $($cim.PathName)"
Write-Host "Pipe    : \\.\pipe\V0DecisionV8"
Write-Host ""
Write-Host "O host inicia com o Windows e fica residente." -ForegroundColor Green
Write-Host "Observacao: para latencia minima, integre v0_decision_v8_extreme.h no proprio processo; use o hot-LUT/raw-ultra ou o batch AVX2 conforme o caso. O pipe e plano de controle." -ForegroundColor DarkYellow

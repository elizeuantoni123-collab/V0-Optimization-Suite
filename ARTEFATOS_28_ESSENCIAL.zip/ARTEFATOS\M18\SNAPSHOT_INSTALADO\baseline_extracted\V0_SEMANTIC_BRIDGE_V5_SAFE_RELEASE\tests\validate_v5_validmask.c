#include <stdint.h>
#include <stdio.h>
typedef struct {uint32_t id,score,key,valid;} rec;
extern uint32_t v0_semantic_valid4_mask(const rec*);
extern uint32_t v0_semantic_valid8_mask(const rec*);
static uint64_t rng=0x13198a2e03707344ull;
static uint32_t rnd(void){rng^=rng<<7;rng^=rng>>9;rng^=rng<<8;return (uint32_t)rng;}
int main(void){rec a[8];uint64_t checks=0,bad=0;for(uint32_t t=0;t<5000000u;t++){uint32_t exp4=0,exp8=0;for(int i=0;i<8;i++){a[i]=(rec){rnd(),rnd(),rnd(),rnd()&1u};exp8|=a[i].valid<<i;if(i<4)exp4|=a[i].valid<<i;}uint32_t g4=v0_semantic_valid4_mask(a),g8=v0_semantic_valid8_mask(a);checks+=2;if(g4!=exp4){bad++;if(bad<4)printf("m4 t=%u got=%x exp=%x\n",t,g4,exp4);}if(g8!=exp8){bad++;if(bad<4)printf("m8 t=%u got=%x exp=%x\n",t,g8,exp8);}}printf("checks=%llu divergences=%llu records_observed=%llu\n",(unsigned long long)checks,(unsigned long long)bad,(unsigned long long)5000000ull*8ull);return bad?1:0;}

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
"$ROOT/BUILD_LINUX.sh" >/dev/null
"$ROOT/BUILD_ACCEL_LINUX.sh" >/dev/null
cc -O3 -march=native -I"$ROOT/include" "$ROOT/tests/test_accel.c" \
  "$ROOT/build/linux/v0_batch_plan64.o" "$ROOT/build/linux/v0_batch_plan64x4.o" \
  "$ROOT/build/linux/v0_batch_plan64_small4.o" "$ROOT/build/linux/v0_batch_plan64_avx2_v14.o" \
  -o "$ROOT/tests/test_accel"
"$ROOT/tests/test_all"
"$ROOT/tests/test_implicit64"
"$ROOT/tests/test_accel"
echo "All inherited + accelerator tests passed."

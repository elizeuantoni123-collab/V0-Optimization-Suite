$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
$work = Join-Path $here 'work'
New-Item -ItemType Directory -Force $work | Out-Null
$vsdevCandidates = @(
  'C:\BuildTools\Common7\Tools\VsDevCmd.bat',
  'C:\Program Files\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat',
  'C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat'
)
$vsdev = $vsdevCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $vsdev) { throw 'MSVC Build Tools not found. This gate does not install anything.' }
$src = Join-Path $here 'bench_windows_v7.c'
$v1 = Join-Path $root 'baseline_extracted\V0_SEMANTIC_BRIDGE_V5_SAFE_RELEASE\build\windows\v0_semantic_bridge_v1.obj'
$v7 = Join-Path $root 'candidate\build\windows\v0_semantic_bridge_v7_safe_pair.obj'
if (-not (Test-Path $v1)) {
  $zip = Join-Path $root 'baseline\baseline_archive_V5.zip'
  $dest = Join-Path $root 'baseline_extracted'
  if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
  Expand-Archive -LiteralPath $zip -DestinationPath $dest
}
$exe = Join-Path $work 'semantic_v7_gate.exe'
$csv = Join-Path $work 'semantic_v7_gate.csv'
$cmd = '"' + $vsdev + '" -arch=x64 >nul && cl /nologo /O2 /GL- /Fe:"' + $exe + '" "' + $src + '" "' + $v1 + '" "' + $v7 + '"'
cmd /c $cmd
if ($LASTEXITCODE -ne 0) { throw 'MSVC compile/link failed' }
& $exe | Tee-Object -FilePath $csv
if ($LASTEXITCODE -ne 0) { throw 'Gate failed' }
Write-Host "Result: $csv"
Write-Host 'No service, driver, boot setting, EPT, or permanent system state was modified.'

# Artefato 21 — V0 Per-Module Telemetry V5 -> V7 Calls-Delta Squeeze

## Baseline

`V0_PER_MODULE_TELEMETRY_V5_SAFE` permanece a baseline oficial.

- V2: acumulador universal de 9 counters, 76 bytes `.text` no Linux.
- V5: fast paths promovidos para call-only unitário, hit unitário e miss+fallback unitário.
- slot ABI: 9 x `u64` = 72 bytes.
- single-writer por `{thread,module}` permanece inalterado.

## Gargalo útil encontrado

Uma delta já agregada `{calls=N, resto=0}` cai na V2 e, portanto, carrega/soma nove campos mesmo sabendo que oito são zero. Para `N=1` a V5 já resolve isso; para `N>=2` não existia fast path equivalente.

## Candidato V7

`v0_telemetry_calls_delta_v7(slot, delta)` usa o **mesmo `V0TelemetryDelta*`** da V2 e executa somente:

1. load de `delta.calls`;
2. add modular em `slot.calls`;
3. retorno zero.

Código nativo candidato:

- Linux `.text`: **9 bytes**;
- Windows `.text`: **9 bytes**;
- relocations: **0**;
- ISA: x86-64 escalar; sem AVX/AVX-512.

## Correção local

A bateria combinada de deltas agregadas validou 54.000.027 counter-checks contra a V2, com **0 divergências**, incluindo valores aleatórios, alinhamentos e wrap `uint64_t`. O domínio `calls-only` representa 18 milhões desses counter-checks.

A V7 final não contém os candidatos agregados de hit/miss.

## Performance direta local

Cinco processos independentes, 15 rodadas por processo, ordem A/B alternada, 10 milhões de chamadas por medição:

| calls agregadas | V2 mediana | V7 mediana | speedup mediano | pior rodada | vitórias |
|---:|---:|---:|---:|---:|---:|
| 2 | 2.605 ns | 1.509 ns | **1.693x** | **1.238x** | **75/75** |
| 8 | 2.611 ns | 1.496 ns | **1.742x** | **1.050x** | **75/75** |
| 64 | 2.602 ns | 1.492 ns | **1.746x** | **1.418x** | **75/75** |

Total do domínio final: **225/225 vitórias**.

O servidor local é AMD EPYC virtualizado, não o Intel/Windows alvo; esses números são screening, não promoção.

## Same-address control

Como funções de poucos bytes são sensíveis a layout, também foi usado um gate que copia V2/V7 para **o mesmo endereço executável**. O overhead da chamada indireta reduz a diferença absoluta e o ambiente virtualizado ainda produz outliers de scheduler, mas:

- ABBA same-address: mediana ~**1.137x**;
- todas as **16 combinações de alinhamento** tiveram mediana >1x;
- menor mediana por combinação: ~**1.093x**.

Os outliers individuais do ambiente virtualizado não são usados como prova de promoção. O gate decisivo continua sendo o Intel/Windows alvo com afinidade fixa.

## Candidatos rejeitados

- SIMD/AVX2 no acumulador/evento individual: claramente mais lento que V2/V5.
- aggregated-hit V7: mediana positiva, mas houve uma rodada direta **0.9888x** -> rejeitado.
- aggregated miss+fallback V7: mediana positiva, mas houve uma rodada direta **0.9059x** -> rejeitado.

Somente `calls_delta_v7` entra no dispatcher candidato.

## Gate Windows

`windows_gate/RUN_WINDOWS_GATE.ps1`:

- confere SHA-256 dos objetos V2/V7;
- usa MSVC já instalado; não instala nada;
- executa 2.000.001 casos de correção/wrap;
- mede `calls={2,8,64}` com QPC;
- 15 rodadas A/B por domínio;
- aceita máscara de afinidade opcional;
- exige 15/15 vitórias, mediana >=1.05x e pior rodada >=1.00x.

## Estado

**LOCAL_PASS / WINDOWS_GATE_REQUIRED**.

Até o gate no Intel/Windows, V2+V5 continuam sendo a baseline promovida.

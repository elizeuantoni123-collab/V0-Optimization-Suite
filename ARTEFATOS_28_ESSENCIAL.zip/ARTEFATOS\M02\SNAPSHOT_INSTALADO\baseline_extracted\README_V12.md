# V0 Decision V8 ULTRA V12

V12 otimiza exclusivamente os caminhos scalar de `gate16` sem alterar a lógica Decision.

- LUT direta exata de 2 KiB para `value + gate16`.
- construtor scalar `gate16` branchless.
- V11/V10 herdados permanecem intactos.
- validação em scalar-only/SSE2, AVX2 e native/AVX-512: 0 divergências.

Execute no Windows:

- `TESTAR_ULTRA_V12.ps1`
- `BENCHMARK_ULTRA_V12_WINDOWS.ps1`

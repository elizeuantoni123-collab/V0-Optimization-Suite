#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct { uint32_t id, score, key, valid; } rec;
extern uint32_t v0_semantic_id_safe(const rec*);
extern uint32_t v0_semantic_key_safe(const rec*);
extern uint64_t v0_semantic_id_key64_safe(const rec*);
static volatile uint64_t sink;
static uint64_t ns(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW,&t); return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec; }
static uint64_t ref_pair(const rec *p){ return (uint64_t)v0_semantic_id_safe(p) | ((uint64_t)v0_semantic_key_safe(p)<<32); }
static uint64_t rng=0x9e3779b97f4a7c15ull;
static uint64_t rnd(void){ rng ^= rng>>12; rng ^= rng<<25; rng ^= rng>>27; return rng*2685821657736338717ull; }
static double run_base(const rec*a,uint32_t n,uint32_t mask){ uint64_t x=0,s=ns(); for(uint32_t i=0;i<n;i++){ const rec*p=&a[(i*13u)&mask]; x ^= ref_pair(p)+(uint64_t)i; } uint64_t e=ns(); sink=x; return (double)(e-s)/n; }
static double run_v7(const rec*a,uint32_t n,uint32_t mask){ uint64_t x=0,s=ns(); for(uint32_t i=0;i<n;i++){ const rec*p=&a[(i*13u)&mask]; x ^= v0_semantic_id_key64_safe(p)+(uint64_t)i; } uint64_t e=ns(); sink=x; return (double)(e-s)/n; }
static void fill(rec*a,uint32_t cnt,int mode){ for(uint32_t i=0;i<cnt;i++){ a[i].id=(uint32_t)rnd(); a[i].score=(uint32_t)rnd(); a[i].key=(uint32_t)rnd(); if(mode==0)a[i].valid=0; else if(mode==1)a[i].valid=1; else if(mode==50)a[i].valid=(i&1); else if(mode==99)a[i].valid=((i%100)!=0); else a[i].valid=(uint32_t)(rnd()&1); }}
int main(void){
    enum { CNT=4096 }; static rec a[CNT];
    uint64_t checks=0, bad=0;
    for(uint32_t mode=0; mode<4; mode++){
        for(uint32_t i=0;i<CNT;i++){
            a[i].id=(uint32_t)rnd(); a[i].score=(uint32_t)rnd(); a[i].key=(uint32_t)rnd(); a[i].valid=(mode==0?0:mode==1?1:(uint32_t)(rnd()&1));
            uint64_t b=ref_pair(&a[i]), c=v0_semantic_id_key64_safe(&a[i]); checks++; if(b!=c) bad++;
        }
    }
    for(uint64_t i=0;i<5000000ull;i++){
        rec r={(uint32_t)rnd(),(uint32_t)rnd(),(uint32_t)rnd(),(uint32_t)(rnd()&1)};
        uint64_t b=ref_pair(&r), c=v0_semantic_id_key64_safe(&r); checks++; if(b!=c){ bad++; if(bad<8) printf("BAD %llu %016llx %016llx\n",(unsigned long long)i,(unsigned long long)b,(unsigned long long)c); }
    }
    printf("PARITY checks=%llu bad=%llu\n",(unsigned long long)checks,(unsigned long long)bad);
    if(bad) return 2;
    const int modes[4]={0,50,99,1}; const char*names[4]={"invalid0","mixed50","valid99","valid100"};
    const uint32_t N=20000000u;
    for(int m=0;m<4;m++){
        fill(a,CNT,modes[m]);
        for(int r=0;r<15;r++){
            double b,c; if(!(r&1)){b=run_base(a,N,CNT-1);c=run_v7(a,N,CNT-1);}else{c=run_v7(a,N,CNT-1);b=run_base(a,N,CNT-1);}
            printf("%s,%d,%.9f,%.9f,%.6f\n",names[m],r,b,c,b/c);
        }
    }
    return sink==0x123456789abcdef0ull;
}

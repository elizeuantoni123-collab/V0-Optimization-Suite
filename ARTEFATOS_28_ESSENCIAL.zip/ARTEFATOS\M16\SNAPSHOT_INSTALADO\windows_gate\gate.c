#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern uint32_t v0_tier_select_valid_v3(uint32_t preferred, uint32_t mask);
extern uint32_t v0_tier_select_batch8_v12(void *batch);

typedef struct { uint32_t p, m; } Rec;
typedef __declspec(align(64)) struct { Rec r[8]; uint8_t out[8]; uint8_t pad[56]; } Batch;
static volatile uint64_t sinkv;
static uint64_t rs=0x9e3779b97f4a7c15ULL;
static uint32_t rnd32(void){rs^=rs>>12;rs^=rs<<25;rs^=rs>>27;return (uint32_t)((rs*2685821657736338717ULL)>>32);}
static uint32_t ref(uint32_t p,uint32_t m){m&=31u;if(p>4u||!m)return 255u;if(m&(1u<<p))return p;for(uint32_t x=p+1;x<=4;x++)if(m&(1u<<x))return x;for(int x=(int)p-1;x>=0;x--)if(m&(1u<<(uint32_t)x))return (uint32_t)x;return 255u;}
static __declspec(noinline) uint32_t base8(Batch*b){uint32_t s=0;for(int i=0;i<8;i++){uint8_t v=(uint8_t)v0_tier_select_valid_v3(b->r[i].p,b->r[i].m);b->out[i]=v;s+=v;}return s;}
static __declspec(noinline) uint32_t cand8(Batch*b){v0_tier_select_batch8_v12(b);uint32_t s=0;for(int i=0;i<8;i++)s+=b->out[i];return s;}
static double run(uint32_t(*f)(Batch*),Batch*a,size_t n,int reps,LARGE_INTEGER fq){LARGE_INTEGER x,y;uint64_t acc=0;QueryPerformanceCounter(&x);for(int r=0;r<reps;r++)for(size_t i=0;i<n;i++)acc+=f(&a[i]);QueryPerformanceCounter(&y);sinkv+=acc;return (double)(y.QuadPart-x.QuadPart)*1e9/(double)fq.QuadPart;}
static void fill(const char*sc,Batch*a,size_t n){for(size_t j=0;j<n;j++)for(int i=0;i<8;i++){uint32_t r=rnd32(),p=r%5,m=0;if(!strcmp(sc,"exact"))m=1u<<p;else if(!strcmp(sc,"all"))m=31;else if(!strcmp(sc,"random"))m=rnd32();else if(!strcmp(sc,"sparse"))m=1u<<(rnd32()%5);else if(!strcmp(sc,"zero"))m=0;else if(!strcmp(sc,"p0")){p=0;m=rnd32();}else if(!strcmp(sc,"p4")){p=4;m=rnd32();}else if(!strcmp(sc,"spill")){p=r%4;m=1u<<(p+1);}else{p=1+(r%4);m=1u<<(p-1);}a[j].r[i].p=p;a[j].r[i].m=m;}}
int main(int argc,char**argv){
 if(argc>1){int cpu=atoi(argv[1]);if(cpu>=0&&cpu<64)SetThreadAffinityMask(GetCurrentThread(),1ULL<<cpu);}
 Batch one={0};
 for(int lane=0;lane<8;lane++)for(uint32_t p=0;p<5;p++)for(uint32_t m=0;m<32;m++){for(int i=0;i<8;i++){one.r[i].p=(p+i)%5;one.r[i].m=(m+i)&31;}one.r[lane].p=p;one.r[lane].m=m;uint8_t expect[8];for(int i=0;i<8;i++){uint32_t v=ref(one.r[i].p,one.r[i].m);if(v0_tier_select_valid_v3(one.r[i].p,one.r[i].m)!=v){fprintf(stderr,"BASELINE_REFERENCE_FAIL\n");return 2;}expect[i]=(uint8_t)v;}v0_tier_select_batch8_v12(&one);if(memcmp(expect,one.out,8)){fprintf(stderr,"CAND_EXHAUSTIVE_FAIL\n");return 3;}}
 for(uint32_t j=0;j<1000000;j++){for(int i=0;i<8;i++){one.r[i].p=rnd32()%5;one.r[i].m=rnd32();}uint8_t expect[8];for(int i=0;i<8;i++)expect[i]=(uint8_t)ref(one.r[i].p,one.r[i].m);v0_tier_select_batch8_v12(&one);if(memcmp(expect,one.out,8)){fprintf(stderr,"CAND_RANDOM_FAIL batch=%u\n",j);return 4;}}
 const char*scs[]={"exact","all","random","sparse","zero","p0","p4","spill","upward"};const int NS=9,ROUNDS=15,REPS=12;const size_t N=60000;
 Batch*a=(Batch*)_aligned_malloc(N*sizeof(Batch),64);if(!a)return 5;LARGE_INTEGER fq;QueryPerformanceFrequency(&fq);
 printf("scenario,round,baseline_ns,candidate_ns,speedup\n");
 for(int s=0;s<NS;s++){fill(scs[s],a,N);for(int w=0;w<8;w++){base8(&a[w]);cand8(&a[w]);}for(int r=0;r<ROUNDS;r++){double b,c;if(r&1){c=run(cand8,a,N,REPS,fq);b=run(base8,a,N,REPS,fq);}else{b=run(base8,a,N,REPS,fq);c=run(cand8,a,N,REPS,fq);}printf("%s,%d,%.3f,%.3f,%.9f\n",scs[s],r,b,c,b/c);}}
 _aligned_free(a);fprintf(stderr,"PASS: 8,001,280+ tier decisions parity, sink=%llu\n",(unsigned long long)sinkv);return 0;
}

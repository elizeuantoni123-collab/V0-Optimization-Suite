# V0 External Memory V9 FIX3 -> V11 Lease Squeeze

## Baseline
`V0_EXTERNAL_MEMORY_16GB_TARGET_V9_ADAPTIVE_SHM_SAFE_FIX3` is preserved unchanged.
The V0L core is not modified.

## Candidate
V11 is additive: the original `v0x_get_batch_v9()` copy API remains available.
The new `v0x_get_batch_view_v11()` returns a leased read-only view over the existing V9 shared mapping and removes the client-side `SHM -> out_buffer` copy.

Safety rule: the V9 mapping is process-scoped, therefore the view holds a process-wide exclusive SRW lease until `v0x_release_batch_view_v11()`. Other batch GETs block while the view is live. Nested same-thread batch GET fails rather than deadlocking.

FIX1 also sends and validates `payload_hint`, preserving V9's adaptive batch limits.

This package DOES NOT install or promote anything automatically. Run the Windows gate against the active V9 service first.

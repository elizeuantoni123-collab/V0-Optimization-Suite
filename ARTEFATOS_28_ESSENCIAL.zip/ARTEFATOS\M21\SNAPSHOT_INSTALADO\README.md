# Artefato 21 — V0 Per-Module Telemetry V5 -> V7 Calls-Delta Squeeze

Estado: **LOCAL_PASS / WINDOWS_GATE_REQUIRED**.

A V5 SAFE original está preservada integralmente em `baseline/`. O único fast path candidato é `v0_telemetry_calls_delta_v7`, para uma delta já agregada no formato existente em que `calls=N>=2` e os outros oito counters são zero.

Não há batching atrasado de eventos. O caller já faria uma única chamada V2 com aquela delta agregada; V7 apenas deixa de carregar e somar oito zeros conhecidos.

- V2 continua universal.
- V5 continua para os três eventos individuais promovidos.
- V7 é aditivo.
- nenhum Global/EPT/driver/serviço é tocado.
- o gate Windows apenas compila/testa; não instala nada.

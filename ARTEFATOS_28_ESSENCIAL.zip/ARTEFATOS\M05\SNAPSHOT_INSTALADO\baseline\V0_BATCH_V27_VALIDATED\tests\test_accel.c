#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_batch_accel.h"

static uint32_t st=0x86d1a4c3u;
static uint32_t xr(void){st^=st<<13;st^=st>>17;st^=st<<5;return st;}

static int have_avx2(void){
#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
    __builtin_cpu_init();
    return __builtin_cpu_supports("avx2");
#else
    return 0;
#endif
}

int main(void){
    uint64_t checks=0;
    v0_batch_span ref4[4],got4[4];
    /* Exhaustive exact validation of the specialized <=256 planner. */
    for(uint32_t n=0;n<=256;n++){
        memset(ref4,0x11,sizeof ref4); memset(got4,0x22,sizeof got4);
        uint32_t a=v0_batch_plan64(ref4,n), b=v0_batch_plan64_small4(got4,n);
        if(a!=b){fprintf(stderr,"small4 count mismatch n=%u\n",n);return 1;}
        for(uint32_t i=0;i<a;i++){
            if(memcmp(&ref4[i],&got4[i],sizeof(v0_batch_span))){fprintf(stderr,"small4 span mismatch n=%u i=%u\n",n,i);return 2;}
            checks++;
        }
        if(a<4 && ((unsigned char*)got4)[a*8]!=0x22){fprintf(stderr,"small4 overwrite n=%u\n",n);return 3;}
        checks++;
    }

    if(have_avx2()){
        const uint32_t MAX=4194240u, MAXSPAN=65535u;
        v0_batch_span *a=aligned_alloc(64,(size_t)(MAXSPAN+8)*8u);
        v0_batch_span *b=aligned_alloc(64,(size_t)(MAXSPAN+8)*8u);
        if(!a||!b) return 4;
        const uint32_t edge[]={0,1,2,63,64,65,255,256,257,511,512,1023,1024,4095,4096,4097,65535,65536,262144,1048576,4194240};
        for(unsigned e=0;e<sizeof(edge)/sizeof(edge[0]);e++){
            uint32_t n=edge[e],k=n?((n-1u)>>6)+1u:0u;
            memset(a,0x11,(size_t)(MAXSPAN+8)*8u); memset(b,0x22,(size_t)(MAXSPAN+8)*8u);
            uint32_t x=v0_batch_plan64x4(a,n),y=v0_batch_plan64_avx2_v14(b,n);
            if(x!=y){fprintf(stderr,"avx edge count mismatch n=%u\n",n);return 5;}
            for(uint32_t i=0;i<x;i++){
                if(memcmp(&a[i],&b[i],8)){fprintf(stderr,"avx edge span mismatch n=%u i=%u\n",n,i);return 6;}
                checks++;
            }
            if(((unsigned char*)b)[k*8]!=0x22){fprintf(stderr,"avx edge overwrite n=%u\n",n);return 7;}
            checks++;
        }
        /* Random full-plan differential validation. */
        for(uint32_t t=0;t<100000u;t++){
            uint32_t n=xr()%(MAX+1u),k=n?((n-1u)>>6)+1u:0u;
            ((unsigned char*)b)[k*8]=0x22;
            uint32_t x=v0_batch_plan64x4(a,n),y=v0_batch_plan64_avx2_v14(b,n);
            if(x!=y){fprintf(stderr,"avx rnd count mismatch n=%u\n",n);return 8;}
            for(uint32_t i=0;i<x;i++){
                if(memcmp(&a[i],&b[i],8)){fprintf(stderr,"avx rnd span mismatch n=%u i=%u\n",n,i);return 9;}
                checks++;
            }
            if(((unsigned char*)b)[k*8]!=0x22){fprintf(stderr,"avx rnd overwrite n=%u\n",n);return 10;}
            checks++;
        }
        free(a);free(b);
        printf("PASS accel checks=%llu avx2=1\n",(unsigned long long)checks);
    }else{
        printf("PASS accel checks=%llu avx2=0 (AVX2 execution skipped safely)\n",(unsigned long long)checks);
    }
    return 0;
}

$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$root=Split-Path -Parent $here
$baseZip=Join-Path $root 'baseline\V0_KV_WINDOW_MANAGER_V6_SAFE_PROMOTED.zip'
$tmp=Join-Path $env:TEMP ('V0M12Gate_'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive=[IO.Compression.ZipFile]::OpenRead($baseZip)
try {
  $entry=@($archive.Entries | Where-Object Name -eq 'v0_kv_window_capacity_v6.obj')
  if($entry.Count -ne 1){throw 'Expected exactly one baseline capacity object.'}
  $objectPath=Join-Path $tmp 'v0_kv_window_capacity_v6.obj'
  [IO.Compression.ZipFileExtensions]::ExtractToFile($entry[0],$objectPath)
} finally {$archive.Dispose()}
$baseObj=Get-Item -LiteralPath $objectPath
$candObj=Join-Path $root 'candidate\build\windows\v0_kv_window_pairs_v7.obj'
$src=Join-Path $here 'kv_v7_gate.c'
$cl=(Get-Command cl.exe -ErrorAction SilentlyContinue).Source
if(-not $cl){
  $vswhere='C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe'
  if(Test-Path $vswhere){$vs=& $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath; if($vs){$dev=Join-Path $vs 'VC\Auxiliary\Build\vcvars64.bat'; cmd /c "`"$dev`" && cl /nologo /O2 /EHsc `"$src`" `"$($baseObj.FullName)`" `"$candObj`" /Fe:`"$here\kv_v7_gate.exe`""}}
} else {& $cl /nologo /O2 /EHsc $src $baseObj.FullName $candObj "/Fe:$here\kv_v7_gate.exe"}
if(-not (Test-Path "$here\kv_v7_gate.exe")){throw 'Falha ao compilar gate nativo.'}
$outs=@()
1..5 | ForEach-Object { $f=Join-Path $here ("windows_run_{0}.csv" -f $_); & "$here\kv_v7_gate.exe" 2000000 17 | Set-Content -Encoding ascii $f; $outs+=$f }
$rows=$outs | ForEach-Object { Import-Csv $_ }
$summary=@()
foreach($pair in @('1to5','5to1')){
  $p=$rows | Where-Object pair -eq $pair
  $speeds=$p | ForEach-Object {[double]$_.speedup}
  $mins=$p | ForEach-Object {[double]$_.min_speedup}
  $wins=($p | Measure-Object -Property wins -Sum).Sum
  $rounds=($p | Measure-Object -Property rounds -Sum).Sum
  $sorted=$speeds | Sort-Object
  $med=$sorted[[int][math]::Floor($sorted.Count/2)]
  $summary += [pscustomobject]@{pair=$pair; median_speedup=$med; min_scenario_speedup=($speeds|Measure-Object -Minimum).Minimum; worst_round=($mins|Measure-Object -Minimum).Minimum; wins=$wins; rounds=$rounds; pass=($wins -eq $rounds -and (($mins|Measure-Object -Minimum).Minimum -ge 1.0))}
}
$summary | Format-Table -AutoSize
$summary | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $here 'WINDOWS_GATE_RESULT.json')
Write-Host 'Gate somente leitura/construcao. Nenhum modulo foi instalado ou promovido.'

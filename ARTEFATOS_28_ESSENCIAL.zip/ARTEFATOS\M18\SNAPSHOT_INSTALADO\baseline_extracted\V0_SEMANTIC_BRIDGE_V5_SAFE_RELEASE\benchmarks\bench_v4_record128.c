#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <emmintrin.h>
typedef struct {uint32_t id,score,key,valid;} rec;
extern uint64_t v0_semantic_id_score64_trusted(const rec*);
extern uint64_t v0_semantic_key_valid64_trusted(const rec*);
extern __m128i v0_semantic_record128_trusted(const rec*);
static volatile uint64_t sink;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static double run_v2(const rec*a,uint32_t n){uint64_t x=0,s=ns();for(uint32_t i=0;i<n;i++){const rec*p=&a[i&4095u];uint64_t lo=v0_semantic_id_score64_trusted(p),hi=v0_semantic_key_valid64_trusted(p);x^=lo^hi^i;}uint64_t e=ns();sink=x;return(double)(e-s)/n;}
static double run_v4(const rec*a,uint32_t n){uint64_t x=0,s=ns();for(uint32_t i=0;i<n;i++){__m128i v=v0_semantic_record128_trusted(&a[i&4095u]);uint64_t lo=(uint64_t)_mm_cvtsi128_si64(v);uint64_t hi=(uint64_t)_mm_cvtsi128_si64(_mm_unpackhi_epi64(v,v));x^=lo^hi^i;}uint64_t e=ns();sink=x;return(double)(e-s)/n;}
int main(void){static rec a[4096];for(uint32_t i=0;i<4096;i++)a[i]=(rec){0x10203040u+i,0x89abcdefu-i,0x55667788u^(i*2654435761u),i&1u};const uint32_t N=30000000u;for(int r=0;r<15;r++){double b,c;if(!(r&1)){b=run_v2(a,N);c=run_v4(a,N);}else{c=run_v4(a,N);b=run_v2(a,N);}printf("full128 %02d %.9f %.9f %.6f\n",r,b,c,b/c);}return sink==0xdeadbeef;}

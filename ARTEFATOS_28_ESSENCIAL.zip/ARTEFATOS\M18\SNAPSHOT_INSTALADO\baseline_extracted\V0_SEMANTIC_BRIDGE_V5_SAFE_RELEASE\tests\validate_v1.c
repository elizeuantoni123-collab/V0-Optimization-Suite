#include <stdint.h>
#include <stdio.h>
#include "../include/v0_semantic_bridge.h"
static uint64_t st=0x123456789abcdef0ULL;
static uint32_t r32(void){st^=st>>12;st^=st<<25;st^=st>>27;return (uint32_t)((st*2685821657736338717ULL)>>32);}
int main(void){
  uint64_t checks=0,bad=0; v0_semantic_record r;
#define C(x) do{checks++; if(!(x)) bad++;}while(0)
  for(uint32_t i=0;i<5000000u;i++){
    r.semantic_id=r32(); r.semantic_score=r32(); r.exact_key=r32(); r.valid=r32()&1u;
    C(v0_semantic_id_trusted(&r)==r.semantic_id);
    C(v0_semantic_score_trusted(&r)==r.semantic_score);
    C(v0_semantic_key_trusted(&r)==r.exact_key);
    C(v0_semantic_valid_trusted(&r)==r.valid);
    C(v0_semantic_id_safe(&r)==(r.valid?r.semantic_id:0xffffffffu));
    C(v0_semantic_key_safe(&r)==(r.valid?r.exact_key:0xffffffffu));
  }
  printf("checks=%llu divergences=%llu\n",(unsigned long long)checks,(unsigned long long)bad);
  return bad?1:0;
}

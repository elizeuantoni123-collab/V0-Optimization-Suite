#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_adaptive.h"
extern int32_t v0_lookup_exact(const void*);extern const unsigned char v0l_keys[];
#define TOTAL (1u<<21)
#define REPS 7
static volatile uint64_t sink;static uint64_t now(){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}static int cmpd(const void*a,const void*b){double x=*(double*)a,y=*(double*)b;return x<y?-1:x>y;}static void pin0(){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);}static inline uint32_t exact(uint32_t i){uint32_t id=(i*17u)&1023u;return(uint32_t)v0_lookup_exact(v0l_keys+(size_t)id*22u);}static inline v0_decision_signal_v7_t sig(uint32_t i){int d=(i%100u)<90u;return v0_decision_v7_pack(d?0:60000,d?65535:0,0,0);}static double base(){uint64_t a=0,t=now();for(uint32_t i=0;i<TOTAL;i++)a+=exact(i);uint64_t e=now();sink=a;return(double)(e-t)/TOTAL;}static double always(){uint64_t a=0,t=now();for(uint32_t i=0;i<TOTAL;i++){v0_decision_signal_v7_t s=sig(i);if(v0_preflight_v0l_v7(&s))a+=exact(i);}uint64_t e=now();sink=a;return(double)(e-t)/TOTAL;}static double adapt(v0_v8_state_t*out){v0_v8_state_t st;v0_v8_init(&st,v0_v8_default_config());uint64_t a=0,t=now();uint32_t i=0;while(i<TOTAL){v0_v8_plan_t p=v0_v8_plan(&st);uint32_t n=p.count;if(n>TOTAL-i)n=TOTAL-i;uint64_t tb=p.measure?now():0;if(p.mode==V0_V8_BYPASS){for(uint32_t j=0;j<n;j++,i++)a+=exact(i);}else{for(uint32_t j=0;j<n;j++,i++){v0_decision_signal_v7_t s=sig(i);if(v0_preflight_v0l_v7(&s))a+=exact(i);}}uint64_t dt=p.measure?now()-tb:0;v0_v8_complete(&st,p.mode,dt,n);}uint64_t e=now();sink=a;if(out)*out=st;return(double)(e-t)/TOTAL;}int main(){pin0();double b[REPS],a[REPS],v[REPS];v0_v8_state_t st;for(int k=0;k<REPS;k++){b[k]=base();a[k]=always();v[k]=adapt(&st);}qsort(b,REPS,sizeof(double),cmpd);qsort(a,REPS,sizeof(double),cmpd);qsort(v,REPS,sizeof(double),cmpd);printf("global_predictable_90drop baseline=%.3f alwaysV7=%.3f adaptiveV8=%.3f base/adapt=%.3fx always/adapt=%.3fx selected=%u on=%u off=%u probes=%u\n",b[REPS/2],a[REPS/2],v[REPS/2],b[REPS/2]/v[REPS/2],a[REPS/2]/v[REPS/2],st.selected_mode,st.switches_to_filter,st.switches_to_bypass,st.probes_completed);return 0;}

# Rejected candidates

## V21 constant-hoist only
The compiler hoisted the repeated `rollback_valid` immediate out of the four lanes. Correctness: 420,000,000 differential checks, 0 divergences. Performance vs V19 was not robust: 17/36 wins in the paired screen, minimum 0.930203x, median 0.999868x. Rejected.

## V23 SIMD snapshot + constant hoist
Combined V22 SIMD rollback snapshot with the constant hoist. It was smaller, but direct V23 vs V22 screening had 37/54 wins, minimum 0.925229x, median 1.010434x. Because some relevant rows regressed, V23 is rejected.

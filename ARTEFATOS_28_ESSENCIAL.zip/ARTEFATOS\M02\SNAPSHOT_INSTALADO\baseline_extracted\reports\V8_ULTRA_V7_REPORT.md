# V0 Decision V8 ULTRA V7 — Technical Report

## Decision

**PROMOTED as an additive exact-speed optimization.** V7 does not replace the V6 raw/Q6 paths. It adds faster routes only when the caller already owns the exact V7 bias or an array of existing packed V7 signals.

## Correctness contract

No Decision threshold changed. The thresholds remain exactly:

```text
0 / 64 / 192 / 384
```

No controller hysteresis/probe policy changed. No quality/accuracy rule was relaxed.

The public bias-fused APIs accept the legal 16-bit bias produced by `v0_decision_v7_bias()`.

## Exact bias-fused derivation

For:

```text
value = 64*vq + vr
cost/2 = 64*cq + cr
bias = 64*bq + br
```

V7 computes:

```text
q6 = vq - cq + bq + floor((vr + br - cr)/64)
```

The residual range is `[-63,126]`, so signed arithmetic `>>6` is the exact floor. This removes the compare/blend correction used by the raw path when bias is already available.

## Preflight specialization

The execute/drop predicate is exactly:

```text
value + bias >= cost/2
```

V7 uses unsigned 16-bit saturated subtraction to evaluate this directly, skipping tier construction.

## Direct packed-signal SIMD

The existing V7 ABI is:

```text
+0: u32 value_cost
+4: u16 bias
+6: u16 reserved
```

V7 now consumes this 8-byte AoS directly:

- AVX2: deinterleave eight records at a time and classify in vector lanes;
- AVX-512BW/VL: two 64-byte loads contain 16 records; `VPERMT2D` deinterleaves `value_cost` and `bias` without a separate transpose pass.

This path is intentionally separate from the faster SoA bias path. It is for callers whose data already exists as `v0_decision_signal_v7_t[]`.

## Validation

### V7 bias/SoA

- directed edge matrix: PASS;
- residual identity over all `64^3` remainder combinations: PASS;
- random signals: **20,000,000**;
- divergences: **0**;
- tails `0..257`: PASS;
- AVX2 + AVX-512BW/VL paths: PASS;
- optional AVX-512VBMI output path: exact in validation.

### Packed AoS

- random packed signals: **20,000,768**;
- divergences: **0**;
- tails `0..257`: PASS;
- AVX2 + AVX-512 packed paths: PASS.

### V6 regression after V7 additions

- exhaustive score domain: **131,646**;
- random raw signals: **20,000,000**;
- divergences: **0**.

### Binary inheritance

The inherited Linux and Windows V6 native objects were compared by SHA-256 and are byte-for-byte unchanged in the V7 tree. See `V7_INHERITED_OBJECT_INTEGRITY.txt`.

## Performance — final paired run

Validation host: AMD EPYC 9V74 virtualized environment, GCC `-O3 -march=native`. Absolute values are machine/compiler/cache dependent. SIMD `ns/item` is amortized throughput per item, not the latency of one independent decision call.

| Path | V6/reference p50 | V7 p50 | Reduction | Speedup |
|---|---:|---:|---:|---:|
| raw scalar vs bias-ready scalar | 0.91873 ns | **0.83276 ns** | **9.36%** | **1.10x** |
| raw batch AVX2 vs bias-ready AVX2 | 0.12155 ns | **0.09188 ns** | **24.41%** | **1.32x** |
| raw preflight AVX2 vs bias-ready preflight | 0.11159 ns | **0.06994 ns** | **37.32%** | **1.60x** |
| raw batch AVX-512 vs bias-ready AVX-512 | 0.11072 ns | **0.08922 ns** | **19.42%** | **1.24x** |
| raw batch AVX-512 vs bias-ready AVX-512VBMI | 0.11072 ns | **0.08763 ns** | **20.85%** | **1.26x** |
| raw preflight AVX-512 vs bias-ready preflight | 0.08683 ns | **0.06042 ns** | **30.42%** | **1.44x** |

Bias-ready throughput implied by these hot-cache measurements:

- AVX2 full Decision: ~**10.88 billion items/s**;
- AVX2 preflight-only: ~**14.30 billion items/s**;
- AVX-512VBMI full Decision: ~**11.41 billion items/s**;
- AVX-512 preflight-only: ~**16.55 billion items/s**.

These are arithmetic reciprocals of amortized hot-cache ns/item, not claims about end-to-end application throughput.

## Packed signal benchmark

| Existing `v0_decision_signal_v7_t[]` path | p50 |
|---|---:|
| scalar inline | 0.85261 ns/item |
| AVX2 direct AoS | **0.32675 ns/item** |
| AVX-512 direct AoS | **0.16745 ns/item** |

The direct AVX-512 AoS route is about **5.09x** the scalar throughput for an already-packed signal array in this run. SoA bias remains faster when the application naturally stores SoA.

## Rejected changes

Not promoted because they lost speed, were unstable, or weakened the correctness contract:

- alternate scalar 16-bit raw reconstruction;
- AVX-512 for Q6-only when AVX2 was faster;
- compact `temperature+pinned` meta as the default raw input;
- no-LUT V0L classification;
- manual prefetch for large streaming batches;
- BMI2/PEXT preflight masks;
- extra POPCNT aggregation;
- more aggressive adaptive-controller settings;
- arbitrary-`uint16_t` public bias contract;
- formulas that required additional signed-index handling without a measured win.

## Integration recommendation

1. Keep V6 raw for one-off raw inputs.
2. Use V7 bias-fused SoA when legal bias is already materialized.
3. Use V7 packed-AoS SIMD when `v0_decision_signal_v7_t[]` already exists.
4. Use AVX2 as default portable SIMD.
5. Runtime-dispatch AVX-512BW/VL/VBMI only after CPU capability checks.
6. Keep Decision separate from V0 Global/EPT/VMX.

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
python "$Root\compiler\v0lc_batch_avx2_quadload_v27.py" `
  "$Root\src\v0_batch_plan64_avx2_quadload_v27.v0l" `
  "$Root\build\windows\v0_batch_plan64_avx2_quadload_v27.obj" --target windows
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

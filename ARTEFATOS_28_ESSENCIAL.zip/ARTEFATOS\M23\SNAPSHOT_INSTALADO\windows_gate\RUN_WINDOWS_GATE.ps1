$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$root = Split-Path -Parent $here
$build = Join-Path $here 'build'
$base = Join-Path $build 'baseline'
New-Item -ItemType Directory -Force -Path $base | Out-Null
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'MSVC cl.exe not found. Run from x64 Native Tools Command Prompt.' }
$zip = Join-Path $root 'baseline\M03_SELECTIVE_TRANSFER_TRAFFIC_FILTER_STRICT_V2.zip'
& tar.exe -xf $zip -C $base
if ($LASTEXITCODE -ne 0) { throw 'Could not extract the packaged M03 baseline.' }
$srcRoot = Join-Path $base 'M03_SELECTIVE_TRANSFER_TRAFFIC_FILTER'
$inc = Join-Path $srcRoot 'include'
$exe = Join-Path $build 'traffic_v7_gate.exe'
$sources = @(
  (Join-Path $srcRoot 'src\v0_traffic_filter.c'),
  (Join-Path $srcRoot 'src\v0_copy_kernel.c'),
  (Join-Path $root 'candidate\v0_traffic_exact256_v7.c'),
  (Join-Path $here 'bench.c')
)
& cl.exe /nologo /O2 /arch:AVX2 /I$inc $sources "/Fe:$exe"
if ($LASTEXITCODE -ne 0) { throw 'Native Windows compile failed.' }
& $exe | Tee-Object -FilePath (Join-Path $here 'WINDOWS_GATE_RESULT.csv')
if ($LASTEXITCODE -ne 0) { throw 'Parity/performance gate failed; candidate stays unpromoted.' }
Write-Host 'Windows parity/performance gate passed. No installation or promotion was performed.'

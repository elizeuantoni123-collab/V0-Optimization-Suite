# V0 Decision V8 ULTRA V10 — technical report

## Status

**PROMOTED as an additive exact speed optimization over V9.**

V10 does not change Decision thresholds or output states.  The inherited V9 files remain untouched.

## Correctness

Final validation:

| Build | Cases | Divergences |
|---|---:|---:|
| AVX2-only | 23,758,620 | **0** |
| Native / AVX-512 | 23,758,620 | **0** |

Coverage includes 20 million random full-range inputs, directed boundary neighborhoods, exhaustive `value=0..65535` sweeps for representative cost/temp/pinned configurations, and tails 0..257.

## One-shot raw speed

Median of the per-process p50 values across five independent processes on the test host:

| Path | Previous | V10 | Change |
|---|---:|---:|---:|
| AVX2 raw | V9 **0.09088 ns/item** | **0.08046 ns/item** | **11.47% lower** |
| AVX-512 raw | old **0.07910 ns/item** | **0.07220 ns/item** | **8.72% lower** |

The AVX-512 V10 implementation intentionally uses 256-bit arithmetic plus AVX-512VL masks.  A wider 512-bit implementation was slower on the paired host.

## gate16 cached path

Five-process median p50:

- gate16 build AVX2: **0.06964 ns/item**
- gate16 evaluate AVX2: **0.04965 ns/item**
- gate16 preflight AVX2: **0.04345 ns/item**
- gate16 build AVX-512: **0.06137 ns/item**
- gate16 preflight AVX-512: **0.04012 ns/item**

These are amortized batch throughput figures.  Build cost is real and must not be omitted when deciding whether to cache gate16.

## gate16 break-even

Against the new V10 raw path, not V9:

- 1 use: gate16 loses because of build cost.
- 2 uses: gate16 still loses in the repeated measurements.
- 3 uses: often wins, but a small number of native runs were neutral/slower.
- **4+ uses: gate16 won consistently in the measured AVX2 and native sets.**

Therefore the conservative integration rule is **reuse gate16 at least four times** unless target-machine calibration shows otherwise.

## Large write-only gate16 output

For a 16M-item working set beyond the local cache, optional non-temporal stores were measured in five processes.  Median p50 across those processes:

- normal store: **0.18266 ns/item**
- streaming store: **0.14722 ns/item**
- reduction: about **19.4%**

The streaming API is opt-in because immediate read-after-write workloads may not benefit.

## One-shot preflight

V10 tested a recentered one-shot preflight variant.  It did not consistently beat V9 AVX2, so it was rejected.  **V9 remains the promoted one-shot preflight path.**

## Integrity

`reports/V10_INHERITED_V9_INTEGRITY.txt` verifies every inherited V9 file by SHA-256.  No inherited file is modified by the V10 layer.

## Interpretation of sub-nanosecond values

All sub-nanosecond batch numbers are **amortized throughput per item** for vectorized batches.  They are not the physical latency of one dependent scalar decision.  Absolute values depend on CPU, frequency, cache state, compiler and host load; paired relative comparisons are the relevant promotion criterion.

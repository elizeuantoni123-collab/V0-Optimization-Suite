#ifndef V0_DECISION_V6_H
#define V0_DECISION_V6_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct v0_decision_signal_v6 {
    /* low16=value, high16=raw cost */
    uint32_t value_cost;
    /* temp bonus + pin override bias */
    uint16_t bias;
    uint16_t reserved;
} v0_decision_signal_v6_t;

/* Temperature encoding used by the validated default policy. */
static inline uint16_t v0_decision_v6_bias(uint8_t temperature, uint8_t pinned) {
    uint16_t temp_bonus = (temperature == 1u) ? 64u : ((temperature == 2u) ? 192u : 0u);
    return (uint16_t)(temp_bonus + (pinned ? 33151u : 0u));
}

static inline v0_decision_signal_v6_t v0_decision_v6_pack(
    uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    v0_decision_signal_v6_t s;
    s.value_cost = ((uint32_t)cost << 16) | (uint32_t)value;
    s.bias = v0_decision_v6_bias(temperature, pinned);
    s.reserved = 0u;
    return s;
}

/* 0=DROP_CALL, 1=EXECUTE_CALL */
uint32_t v0_preflight_v0l_v6(const v0_decision_signal_v6_t *signal);
/* 0=DROP, 1=KEEP_BACKING_ONLY, 2=KEEP_METADATA, 3=KEEP_ACTIVE */
uint32_t v0_decide_v0l_v6(const v0_decision_signal_v6_t *signal);

#ifdef __cplusplus
}
#endif
#endif

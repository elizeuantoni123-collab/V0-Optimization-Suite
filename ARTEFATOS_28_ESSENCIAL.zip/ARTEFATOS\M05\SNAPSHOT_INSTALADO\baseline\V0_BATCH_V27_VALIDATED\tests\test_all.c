#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../include/v0_batch.h"

static uint32_t s=0x51f15e5du;
static uint32_t xr(void){ s^=s<<13; s^=s>>17; s^=s<<5; return s; }
static uint32_t ref_count(uint32_t n,uint32_t l){ if(!l)return UINT32_MAX; if(!n)return 0; return 1u+(n-1u)/l; }
static uint32_t ref_take(uint32_t n,uint32_t l){ if(!l)return UINT32_MAX; return n>l?l:n; }
static uint32_t ref_plan(v0_batch_span*out,uint32_t n){ if(!n)return 0; uint32_t k=0,st=0; while(n>64){out[k++] = (v0_batch_span){st,64}; st+=64;n-=64;} out[k++]=(v0_batch_span){st,n}; return k; }

int main(void){
    uint64_t checks=0;
    const uint32_t e[]={0,1,2,63,64,65,127,128,129,255,256,257,4095,4096,UINT32_MAX};
    for(unsigned i=0;i<sizeof(e)/sizeof(e[0]);i++) for(unsigned j=0;j<sizeof(e)/sizeof(e[0]);j++){
        uint32_t n=e[i],l=e[j];
        if(v0_batch_count(n,l)!=ref_count(n,l)) return 1;
        if(v0_batch_take(n,l)!=ref_take(n,l)) return 2;
        checks+=2;
    }
    for(uint32_t i=0;i<5000000u;i++){
        uint32_t n=xr(),l=xr();
        if(v0_batch_count(n,l)!=ref_count(n,l)) return 3;
        if(v0_batch_take(n,l)!=ref_take(n,l)) return 4;
        if(v0_batch_count64(n)!=ref_count(n,64)) return 5;
        if(v0_batch_take64(n)!=ref_take(n,64)) return 6;
        checks+=4;
    }
    v0_batch_span a[258],b[258],c[258];
    for(uint32_t i=0;i<250000u;i++){
        uint32_t n=xr()%16320u;
        memset(a,0x11,sizeof a);memset(b,0x22,sizeof b);memset(c,0x33,sizeof c);
        uint32_t x=ref_plan(a,n), y=v0_batch_plan64(b,n), z=v0_batch_plan64x4(c,n);
        if(x!=y||x!=z) return 7;
        for(uint32_t k=0;k<x;k++){
            if(memcmp(&a[k],&b[k],sizeof(a[k]))||memcmp(&a[k],&c[k],sizeof(a[k]))) return 8;
            checks+=4;
        }
        if(x<258 && (((unsigned char*)b)[x*8]!=0x22 || ((unsigned char*)c)[x*8]!=0x33)) return 9;
        checks++;
    }
    printf("PASS checks=%llu\n",(unsigned long long)checks);
    return 0;
}

# V0 Semantic Bridge V5 SAFE — Relatório de Validação

Data: 2026-09-25
Status: **PROMOVIDO — SUPERSET ADITIVO NÃO REGRESSIVO**

## 1. Arquitetura preservada

O Semantic Bridge permanece isolado do V0 Global. Ele não executa FastText, LLM, encoder semântico, reranker ou rede. Seu contrato é transportar, sem reinterpretar, a saída semântica normalizada para módulos determinísticos.

A qualidade do modelo semântico não é modificada pelo bridge: `semantic_id`, `semantic_score` e `exact_key` são tratados como dados opacos/bit-exatos; `valid` é um booleano canônico 0/1.

## 2. Baselines preservadas

V1 SAFE e V2 SAFE continuam disponíveis e não foram substituídas. A extensão do compilador para V4 foi verificada recompilando V1, V2 e V3 byte por byte em Linux e Windows; os objetos permaneceram idênticos aos anteriores.

### V1 SAFE

- Linux `.text`: 97 B
- 0 `.rodata`
- 0 relocations
- 30.000.000 checks históricos: 0 divergências

### V2 SAFE

- addon `.text`: 21 B
- `v0_semantic_id_score64_trusted`: 4 B
- `v0_semantic_key_valid64_trusted`: 5 B
- 20.000.000 checks históricos: 0 divergências

## 3. V3 SAFE — score + key pair64

Função:

`v0_semantic_score_key64_trusted`

Semântica little-endian:

- low32 = `semantic_score`
- high32 = `exact_key`

Build Linux e Windows:

- função: 5 B
- `.rodata`: 0
- relocations: 0

Correção:

- 20.000.000 checks
- 0 divergências

Benchmark pareado, 15 rodadas:

- duas chamadas V1: mediana 3,2932555 ns/op
- V3: mediana 1,6516852 ns/op
- speedup mediano: **1,993876x**
- mínimo observado: 1,483234x
- máximo observado: 2,327970x
- vitórias: **15/15**

Resultado: **PROMOVIDO**.

## 4. V4 SAFE — full record128

Função:

`v0_semantic_record128_trusted`

Implementação V0L -> x86-64 direta:

`MOVDQU XMM0, [ctx] ; RET`

SSE2 é baseline da arquitetura x86-64. `MOVDQU` foi escolhido para permitir endereços não alinhados.

Build Linux e Windows:

- função: 5 B
- `.rodata`: 0
- relocations: 0

Correção:

- 16.000.000 leituras
- todos os offsets de alinhamento 0..15 exercitados
- 0 divergências

Compatibilidade do compilador:

- V1 Linux: byte-idêntico
- V1 Windows: byte-idêntico
- V2 Linux: byte-idêntico
- V2 Windows: byte-idêntico
- V3 Linux: byte-idêntico
- V3 Windows: byte-idêntico

Benchmark contra duas chamadas V2 (`id_score64 + key_valid64`), 15 rodadas:

- V2: mediana 3,482366733 ns/op
- V4: mediana 1,820831467 ns/op
- speedup mediano: **1,883672x**
- mínimo: 1,609835x
- máximo: 2,251745x
- vitórias: **15/15**

Resultado: **PROMOVIDO**.

## 5. V5 SAFE — batch valid masks

Funções:

- `v0_semantic_valid4_mask`
- `v0_semantic_valid8_mask`

Contrato: registros contíguos de 16 bytes; bit `i` do retorno reproduz exatamente `record[i].valid`.

Build Linux e Windows:

- addon total `.text`: 99 B
- `valid4_mask`: 31 B
- `valid8_mask`: 67 B
- `.rodata`: 0
- relocations: 0

Correção:

- 10.000.000 comparações de máscara
- 40.000.000 registros observados
- 0 divergências

Benchmark pareado contra chamadas V1 individuais, 15 rodadas:

### valid4

- baseline: mediana 8,1310224 ns/grupo
- V5: mediana 2,0069635 ns/grupo
- speedup mediano: **4,022652x**
- mínimo: 3,422462x
- máximo: 4,228796x
- vitórias: **15/15**

### valid8

- baseline: mediana 13,8712325 ns/grupo
- V5: mediana 2,7100596 ns/grupo
- speedup mediano: **5,104795x**
- mínimo: 4,498700x
- máximo: 5,471955x
- vitórias: **15/15**

Resultado: **PROMOVIDO**.

## 6. Tentativas rejeitadas

### SAFE memory-compare

Foi testado substituir `load valid + test` por comparação direta do campo na memória. Apesar de reduzir tamanho, o candidato regrediu no caminho válido e não apresentou vitória universal. Rejeitado.

### V6 valid16 direto

- correção: 5.000.000 checks / 80.000.000 registros, 0 divergências
- comparação contra `2 x valid8`
- speedup mediano: 0,999598x
- 7/15 vitórias

Rejeitado.

### V6 valid16 rebaseado

- correção: 3.000.000 checks / 48.000.000 registros, 0 divergências
- comparação contra `2 x valid8`
- speedup mediano: 0,974038x
- 4/15 vitórias

Rejeitado.

## 7. Baseline promovida final

**V0 Semantic Bridge V5 SAFE**.

Política de uso:

- acesso universal/safe individual: V1
- `id+score`: V2
- `key+valid`: V2
- `score+key`: V3
- registro inteiro: V4
- máscara de validade de 4/8 registros: V5
- 16 registros: continuar usando `2 x valid8` V5

Nenhuma versão nova será promovida se quebrar compatibilidade, perder correção/qualidade ou perder velocidade no domínio que pretende substituir.

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct { uint32_t enabled_mask; } mm_state;
uint32_t v0_mm_matches(mm_state*,uint32_t,uint32_t);
uint32_t v0_mm_matches8_snapshot_v14(mm_state*,const uint32_t*);
static inline uint64_t sm64(uint64_t *x){uint64_t z=(*x+=0x9e3779b97f4a7c15ull);z=(z^(z>>30))*0xbf58476d1ce4e5b9ull;z=(z^(z>>27))*0x94d049bb133111ebull;return z^(z>>31);}
static uint32_t ref8(mm_state*s,const uint32_t*q){uint32_t m=0;for(int i=0;i<8;i++)m|=v0_mm_matches(s,q[i],q[8+i])<<i;return m;}
int main(int argc,char**argv){uint64_t n=argc>1?strtoull(argv[1],0,0):5000000ull;uint64_t seed=0xdecafbad12345678ull,div=0;void*mem=0;if(posix_memalign(&mem,64,256))return 2;uint8_t*raw=mem;for(uint64_t k=0;k<n;k++){int off=(int)(sm64(&seed)&31);uint32_t*q=(uint32_t*)(raw+off);mm_state s={(uint32_t)sm64(&seed)};for(int i=0;i<16;i++)q[i]=(uint32_t)sm64(&seed);if((k&1023)==0){q[0]=q[8]=0;q[1]=s.enabled_mask;q[9]=0;q[2]=0;q[10]=~s.enabled_mask;}uint32_t a=ref8(&s,q),b=v0_mm_matches8_snapshot_v14(&s,q);if(a!=b){if(div<10)printf("div k=%llu off=%d s=%08x a=%02x b=%02x\n",(unsigned long long)k,off,s.enabled_mask,a,b);div++;}}
printf("batches=%llu individual_predicates=%llu divergences=%llu\n",(unsigned long long)n,(unsigned long long)(n*8),(unsigned long long)div);free(mem);return div?1:0;}

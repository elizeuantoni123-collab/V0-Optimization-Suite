# Artefato 23 — Selective Transfer / Traffic Filter — Exact 256 B Squeeze

## Baseline
- `M03_SELECTIVE_TRANSFER_TRAFFIC_FILTER_STRICT_V2.zip` preserved byte-for-byte.
- Baseline archive SHA-256: `53b7f93c104e518b5bd615eca74fd681292b96f36749d5832e265ae4a0e34a2c`.
- V4 history had rejected universal/fixed candidates because no strategy was zero-regression across hot+stream/alignment.

## Candidate V7
Additive function `v0_traffic_transfer_256_v7` for the exact domain `block_bytes == 256` on an AVX2-capable x86-64 caller. It preserves the baseline bounds/overflow checks and replaces only the final generic copy-kernel call with eight unaligned 32-byte AVX2 loads/stores. The universal baseline remains fallback for every other size and for non-AVX2 machines.

## Correctness
- Dedicated randomized parity: 3,000,000 checks, 0 divergences (see `evidence/parity256.txt`).
- Each of the seven performance processes also re-ran candidate-domain parity before timing.

## Local warmed TSC gate
- Independent processes: 7.
- Profiles: 504 = hot/stream × 6 source offsets × 6 destination offsets × 7 processes.
- Profile wins: **504/504**.
- Median speedup: **1.346x**.
- Hot median: **1.349x**.
- Streaming median: **1.298x**.
- Worst profile median: **1.273x**.
- Best profile median: **1.605x**.

This is a local Linux cycle gate, not the final Intel/Windows promotion gate. Short wall/thread-time experiments showed scheduler noise, so the final local decision uses serialized TSC after a long warmup and affinity.

## Decision
**LOCAL_PASS / WINDOWS_GATE_REQUIRED.**

Do not replace the universal function. Candidate dispatch only when all are true: exact 256-byte block, AVX2 prevalidated outside the hot path, same baseline bounds semantics.

# Artefato 19 — V0 Policy Router V10 KEEP BASELINE

Estado final: **KEEP_BASELINE**.

A baseline oficial continua sendo **V0 Policy Router V10 SAFE + V1 scalar fallback**.
Nenhum candidato desta rodada satisfaz a regra de zero regressão no domínio declarado.

## Baseline preservada
- `baseline/V0_POLICY_ROUTER_V10_SAFE.zip` é o arquivo original usado na análise.
- Dispatch continua:
  - count 0..15 -> V1 scalar
  - count 16..4096 -> V10 batch
  - count >4096 -> V1 scalar

## Candidatos rejeitados
- V13: remove `TEST` redundante após `SUB` e usa branch curto.
- V14: V13 + cache de um `stage_ctx` em R15.
- V15: fast path nonzero + branch otimizado.
- V16: unroll de 2 registros; precondição count par.
- V17: unroll de 4 registros; precondição count divisível por 4.

Os objetos e fontes ficam no pacote somente como evidência de pesquisa. **Não usar no dispatcher promovido.**

#ifndef V0_DECISION_V8_ULTRA_V13_CANDIDATE_H
#define V0_DECISION_V8_ULTRA_V13_CANDIDATE_H
#include <stdint.h>
#include "v0_decision_v8_ultra_v12.h"
/* V13 candidate: exact replacement only for gate16 construction.
 * Legal Decision domain: temperature 0..2, pinned 0/1.
 * Evaluator and all inherited SIMD/raw paths remain V12/V11 unchanged. */
static const uint16_t V0X_GATE16_BASE_V13[3] = {0x8000u,0x8040u,0x80c0u};
V0X_FORCEINLINE v0_decision_gate16_v10_t v0_decision_gate16_v13_lut3(
    uint16_t cost, uint8_t temperature, uint8_t pinned) {
    const uint32_t base = (uint32_t)V0X_GATE16_BASE_V13[temperature]
                        - ((uint32_t)cost >> 1);
    return (v0_decision_gate16_v10_t)(base | (0u - (uint32_t)pinned));
}
#endif

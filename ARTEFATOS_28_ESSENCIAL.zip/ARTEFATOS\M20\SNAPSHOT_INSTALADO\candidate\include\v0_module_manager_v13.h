#ifndef V0_MODULE_MANAGER_H
#define V0_MODULE_MANAGER_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct v0_module_manager_state {
    uint32_t enabled_mask;
} v0_module_manager_state;

enum {
    V0_MM_TEMPERATURE      = 1u << 0,
    V0_MM_PIN              = 1u << 1,
    V0_MM_DECISION         = 1u << 2,
    V0_MM_BATCH            = 1u << 3,
    V0_MM_RANGE_DESCRIPTOR = 1u << 4,
    V0_MM_TOPK             = 1u << 5,
    V0_MM_EXTERNAL_MEMORY  = 1u << 6,
    V0_MM_MATERIALIZER     = 1u << 7,
    V0_MM_KV_WINDOW        = 1u << 8,
    V0_MM_SHARED_STATE     = 1u << 9,
    V0_MM_DYNAMIC_STORE    = 1u << 10,
    V0_MM_DEDUP            = 1u << 11,
    V0_MM_COMPRESSION      = 1u << 12,
    V0_MM_PREFETCH         = 1u << 13,
    V0_MM_TIER_MANAGER     = 1u << 14,
    V0_MM_REMAP            = 1u << 15,
    V0_MM_SEMANTIC_BRIDGE  = 1u << 16,
    V0_MM_POLICY_ROUTER    = 1u << 17,
    V0_MM_TELEMETRY        = 1u << 18,
    V0_MM_ALL_MANAGED      = 0x0007ffffu
};

uint32_t v0_mm_get(v0_module_manager_state *state);
uint32_t v0_mm_enabled(v0_module_manager_state *state, uint32_t module_mask);
uint32_t v0_mm_enable(v0_module_manager_state *state, uint32_t module_mask);
uint32_t v0_mm_disable(v0_module_manager_state *state, uint32_t module_mask);
uint32_t v0_mm_set(v0_module_manager_state *state, uint32_t new_mask);
uint32_t v0_mm_apply(v0_module_manager_state *state, uint32_t enable_mask, uint32_t disable_mask);

/* V13 additive queries. */
uint32_t v0_mm_all_enabled(v0_module_manager_state *state, uint32_t module_mask);
uint32_t v0_mm_none_enabled(v0_module_manager_state *state, uint32_t module_mask);
uint32_t v0_mm_exact(v0_module_manager_state *state, uint32_t expected_mask);
uint32_t v0_mm_matches(v0_module_manager_state *state, uint32_t required_on, uint32_t required_off);

#ifdef __cplusplus
}
#endif
#endif

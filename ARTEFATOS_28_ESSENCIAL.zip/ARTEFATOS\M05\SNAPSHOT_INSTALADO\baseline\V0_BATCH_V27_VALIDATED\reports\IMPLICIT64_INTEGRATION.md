# IMPLICIT64 integration rule

Production batch arithmetic remains V0L. No C implementation replaces the V0L core.
The existing V0L primitive `v0_batch_count64(items)` is sufficient to enter the
zero-materialization path.

Conceptual consumer loop:

```text
full = items >> 6
tail = items & 63
start = 0

repeat full times:
    consume(start, 64)
    start += 64

if tail != 0:
    consume(start, tail)
```

This produces exactly the same logical spans as `v0_batch_plan64` /
`v0_batch_plan64x4`, without constructing the temporary span array.

Keep the materialized V11 path whenever the descriptor array itself is part of the
consumer contract.

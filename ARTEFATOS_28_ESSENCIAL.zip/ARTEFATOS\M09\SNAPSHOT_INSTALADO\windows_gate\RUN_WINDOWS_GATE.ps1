param([int]$Runs=15)
$ErrorActionPreference='Stop'
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$Root=Split-Path -Parent $Here
function Find-VcVars64 {
  $candidates=@(
    'C:\BuildTools\VC\Auxiliary\Build\vcvars64.bat',
    'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat',
    'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat'
  )
  foreach($p in $candidates){if(Test-Path $p){return $p}}
  throw 'vcvars64.bat not found. Install VS Build Tools C++ workload.'
}
$vc=Find-VcVars64
$base=Join-Path $Root 'baseline\V0ExternalMemoryClientV5.c'
$cand=Join-Path $Root 'candidate\V0ExternalMemoryClientV11LeaseFix1.c'
$incBase=Join-Path $Root 'baseline'
$incCand=Join-Path $Root 'candidate'
$bench=Join-Path $Here 'bench_external_memory_v11.c'
cmd /c ('"{0}" && cd /d "{1}" && cl /nologo /O2 /LD /MT /I"{2}" "{3}" /link /OUT:baseline_client.dll && cl /nologo /O2 /LD /MT /I"{4}" "{5}" /link /OUT:candidate_client.dll && cl /nologo /O2 /MT /I"{4}" "{6}" /Fe:bench_external_memory_v11.exe' -f $vc,$Here,$incBase,$base,$incCand,$cand,$bench)
if($LASTEXITCODE-ne 0){throw 'compile/link failed'}
& (Join-Path $Here 'bench_external_memory_v11.exe') $Runs | Tee-Object (Join-Path $Here 'WINDOWS_GATE_RESULT.txt')
if($LASTEXITCODE-ne 0){throw 'gate failed'}

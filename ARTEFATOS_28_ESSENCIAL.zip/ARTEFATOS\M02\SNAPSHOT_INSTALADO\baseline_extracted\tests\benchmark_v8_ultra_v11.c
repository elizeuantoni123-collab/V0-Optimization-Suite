#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include <string.h>
#include "../include/v0_decision_v8_ultra_v11.h"
#define N (1u<<20)
#define LARGE_N (1u<<24)
#define REPS 15
static volatile uint64_t sink;
static uint64_t now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return*s=x;}
static void pin0(void){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);}
static uint16_t *v,*g;static uint8_t *out;
static double scalar_v10(void){uint64_t a=now_ns(),q=0;for(int k=0;k<16;k++)for(size_t i=0;i<N;i++)q+=v0_eval_gate16_v10_inline(v[i],g[i]);uint64_t z=now_ns();sink+=q;return(double)(z-a)/(N*16.0);}
static double scalar_v11(void){uint64_t a=now_ns(),q=0;for(int k=0;k<16;k++)for(size_t i=0;i<N;i++)q+=v0_eval_gate16_v11_scalar_lut_inline(v[i],g[i]);uint64_t z=now_ns();sink+=q;return(double)(z-a)/(N*16.0);}
static void bench(const char*n,double(*f)(void)){double x[REPS];for(int k=0;k<3;k++)f();for(int i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmpd);printf("%-24s p50=%9.6f best=%9.6f ns/item\n",n,x[REPS/2],x[0]);}
#if defined(__AVX2__) || defined(_M_AVX2)
static double large_u8(void){uint64_t a=now_ns();v0_eval_gate16_batch_v10_stream_avx2_u8(v,g,out,LARGE_N);uint64_t z=now_ns();sink+=out[777];return(double)(z-a)/LARGE_N;}
static double large_nib(void){uint64_t a=now_ns();v0_eval_gate16_batch_v11_stream_avx2_nibble(v,g,out,LARGE_N);uint64_t z=now_ns();sink+=out[777];return(double)(z-a)/LARGE_N;}
#endif
int main(void){pin0();
    if(posix_memalign((void**)&v,64,LARGE_N*2)||posix_memalign((void**)&g,64,LARGE_N*2)||posix_memalign((void**)&out,64,LARGE_N+64))return 2;
    uint64_t s=0x94D049BB133111EBULL;for(size_t i=0;i<LARGE_N;i++){v[i]=(uint16_t)rng64(&s);g[i]=(uint16_t)rng64(&s);} 
    bench("V10 scalar gate16",scalar_v10);bench("V11 scalar LUT",scalar_v11);
#if defined(__AVX2__) || defined(_M_AVX2)
    {double a[9],b[9];for(int k=0;k<2;k++){large_u8();large_nib();}for(int i=0;i<9;i++){a[i]=large_u8();b[i]=large_nib();}qsort(a,9,sizeof(double),cmpd);qsort(b,9,sizeof(double),cmpd);printf("%-24s p50=%9.6f ns/item\n","V10 large u8 stream",a[4]);printf("%-24s p50=%9.6f ns/item\n","V11 large nibble stream",b[4]);printf("large stream speedup=%6.3fx\n",a[4]/b[4]);}
#endif
    printf("sink=%llu\n",(unsigned long long)sink);return 0;
}

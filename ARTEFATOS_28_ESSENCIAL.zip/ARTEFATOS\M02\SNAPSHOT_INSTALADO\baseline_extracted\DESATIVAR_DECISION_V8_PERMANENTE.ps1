$ErrorActionPreference = "Stop"
$ServiceName = "V0DecisionV8"
$svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if (-not $svc) { Write-Host "Servico nao instalado."; exit 0 }
if ($svc.Status -ne 'Stopped') {
    Stop-Service -Name $ServiceName -Force
    (Get-Service -Name $ServiceName).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(10))
}
Set-Service -Name $ServiceName -StartupType Disabled
Write-Host "V0 Decision V8 permanente: DESATIVADO" -ForegroundColor Yellow

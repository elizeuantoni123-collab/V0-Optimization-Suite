#include "../include/v0_decision_v8_extreme.h"
int main(void){ return (int)v0_eval_v8_bias_ultra_inline(500,200,0); }

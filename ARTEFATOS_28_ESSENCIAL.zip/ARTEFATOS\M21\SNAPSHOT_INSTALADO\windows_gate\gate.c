#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct V0TelemetryCounters {
    uint64_t calls,hits,misses,cycles,bytes_in,bytes_out,bytes_avoided,errors,fallbacks;
} V0TelemetryCounters;
typedef V0TelemetryCounters V0TelemetryDelta;

uint32_t v0_telemetry_accumulate_v2(V0TelemetryCounters*, const V0TelemetryDelta*);
uint32_t v0_telemetry_calls_delta_v7(V0TelemetryCounters*, const V0TelemetryDelta*);

static uint64_t rngs=0x9e3779b97f4a7c15ULL;
static uint64_t rr(void){ rngs^=rngs>>12; rngs^=rngs<<25; rngs^=rngs>>27; return rngs*2685821657736338717ULL; }
static double qpc_seconds(void){ LARGE_INTEGER x,f; QueryPerformanceCounter(&x); QueryPerformanceFrequency(&f); return (double)x.QuadPart/(double)f.QuadPart; }
static int cmpd(const double*a,const double*b){return (*a>*b)-(*a<*b);}
static double median(double*x,int n){ qsort(x,n,sizeof(double),cmpd); return x[n/2]; }

static int correctness(void){
    enum { N=2000000 };
    unsigned char A[128],B[128],D[128];
    for(int i=0;i<N;i++){
        memset(A,0xA5,sizeof A); memset(B,0xA5,sizeof B); memset(D,0x5A,sizeof D);
        V0TelemetryCounters* a=(V0TelemetryCounters*)(A+24);
        V0TelemetryCounters* b=(V0TelemetryCounters*)(B+24);
        V0TelemetryDelta* d=(V0TelemetryDelta*)(D+16);
        uint64_t* pa=(uint64_t*)a; uint64_t* pb=(uint64_t*)b;
        for(int k=0;k<9;k++){pa[k]=rr();pb[k]=pa[k];}
        memset(d,0,sizeof *d); d->calls=rr();
        v0_telemetry_accumulate_v2(a,d);
        v0_telemetry_calls_delta_v7(b,d);
        if(memcmp(a,b,sizeof *a)!=0 || memcmp(A,B,24)!=0){
            printf("CORRECTNESS_FAIL case=%d\n",i); return 10;
        }
    }
    V0TelemetryCounters a,b; V0TelemetryDelta d={0};
    uint64_t* pa=(uint64_t*)&a; uint64_t* pb=(uint64_t*)&b;
    for(int k=0;k<9;k++){pa[k]=UINT64_MAX-(uint64_t)k;pb[k]=pa[k];}
    d.calls=UINT64_MAX;
    v0_telemetry_accumulate_v2(&a,&d); v0_telemetry_calls_delta_v7(&b,&d);
    if(memcmp(&a,&b,sizeof a)!=0){puts("WRAP_FAIL");return 11;}
    puts("CORRECTNESS_PASS cases=2000001 divergences=0"); return 0;
}

static double run_base(V0TelemetryCounters*s,const V0TelemetryDelta*d,uint64_t n){
    for(int i=0;i<30000;i++)v0_telemetry_accumulate_v2(s,d);
    double a=qpc_seconds(); for(uint64_t i=0;i<n;i++)v0_telemetry_accumulate_v2(s,d); double b=qpc_seconds();
    volatile uint64_t z=s->calls; (void)z; return (b-a)*1e9/(double)n;
}
static double run_cand(V0TelemetryCounters*s,const V0TelemetryDelta*d,uint64_t n){
    for(int i=0;i<30000;i++)v0_telemetry_calls_delta_v7(s,d);
    double a=qpc_seconds(); for(uint64_t i=0;i<n;i++)v0_telemetry_calls_delta_v7(s,d); double b=qpc_seconds();
    volatile uint64_t z=s->calls; (void)z; return (b-a)*1e9/(double)n;
}

int main(int argc,char**argv){
    if(argc>1){
        unsigned long long mask=_strtoui64(argv[1],NULL,0);
        if(mask){ DWORD_PTR old=SetThreadAffinityMask(GetCurrentThread(),(DWORD_PTR)mask); if(!old){printf("AFFINITY_FAIL %lu\n",GetLastError());return 3;} printf("CPU_MASK=0x%llx\n",mask); }
    }
    int rc=correctness(); if(rc)return rc;
    const uint64_t counts[3]={2,8,64}; enum { R=15 }; const uint64_t N=10000000ULL;
    int global_fail=0;
    puts("count,round,base_ns,candidate_ns,speedup");
    for(int ci=0;ci<3;ci++){
        double speeds[R],bs[R],cs[R]; int wins=0;
        V0TelemetryDelta d={0}; d.calls=counts[ci];
        for(int r=0;r<R;r++){
            V0TelemetryCounters a={0},b={0}; double x,y;
            if(r&1){y=run_cand(&b,&d,N);x=run_base(&a,&d,N);}else{x=run_base(&a,&d,N);y=run_cand(&b,&d,N);}
            bs[r]=x;cs[r]=y;speeds[r]=x/y;if(speeds[r]>1.0)wins++;
            printf("%llu,%d,%.6f,%.6f,%.6f\n",(unsigned long long)counts[ci],r,x,y,speeds[r]);
        }
        double sm[R],bm[R],cm[R]; memcpy(sm,speeds,sizeof sm);memcpy(bm,bs,sizeof bm);memcpy(cm,cs,sizeof cm);
        double med=median(sm,R), bmed=median(bm,R), cmed=median(cm,R), min=speeds[0];for(int i=1;i<R;i++)if(speeds[i]<min)min=speeds[i];
        printf("SUMMARY count=%llu wins=%d/%d median=%.6fx min=%.6fx base_median=%.6fns cand_median=%.6fns\n",(unsigned long long)counts[ci],wins,R,med,min,bmed,cmed);
        if(wins!=R || med<1.05 || min<1.00) global_fail=1;
    }
    if(global_fail){puts("GATE_FAIL_KEEP_V5_V2");return 20;}
    puts("GATE_PASS_V7_CALLS_DELTA_CANDIDATE");return 0;
}

# M01 Exact Associative Index — V8 Squeeze

## Status

**KEEP_BASELINE for the universal entry point.**

A new V0L-native candidate `v0_lookup_exact_v8` is retained only as a **hit-heavy specialized candidate**. It is not promoted.

## What changed

The canonical OPT3_SAFE baseline already performs three exact qword comparisons at offsets 0, 8 and 14 with early exit. Several earlier C screens did not model this exact baseline and are therefore not promotion evidence.

V8 preserves the first 8-byte early rejection exactly and, only after it matches, compares bytes 6..21 with one unaligned-safe 128-bit sequence:

- `MOVDQU input+6`
- `MOVDQU key+6`
- `PXOR reg,reg`
- `PTEST`

The first experimental form using `PXOR xmm,[unaligned]` was rejected after reproducing a #GP/segfault; it is not present in the final candidate.

## Correctness

Final V0L candidate:

- 1024/1024 known keys: exact IDs
- all 22 one-byte mutations for every key: parity with baseline
- 5,000,000 random 22-byte inputs: parity with baseline
- measured benchmark parity errors: 0

## Performance findings

Against the actual V0L baseline object, the SIMD candidate is not universal:

- all hits: typically about +6–11%
- last-byte misses: typically about +7–13%
- 50/50 or random-miss traffic: no reliable universal win; regressions were observed

Hit-rate sweep using replacement binaries with the same canonical exported function address:

- 99% hits: median ~1.073x, minimum ~1.055x, 5/5 external runs won
- 100% hits: median ~1.067x, minimum ~1.053x, 5/5 external runs won
- 90–95% hits: median positive, but at least one external run regressed
- 50–75% hits: not robust

## Rejected squeeze attempts

- interleaved batch 8/16: unstable versus canonical baseline
- scalar XOR/OR tail fold: no robust universal gain
- 24-byte padded key layout: regressed hit and late-miss paths
- packed id+offset slot table: regressed overall cache behavior
- universal SIMD exact compare: loses the canonical scalar early-exit advantage on miss-heavy traffic

## Decision

Keep OPT3_SAFE as `v0_lookup_exact`.

Retain `v0_lookup_exact_v8` only for a caller that can prove/declare a >=99% hit-heavy domain, and require the Windows/Intel gate before any use in production.

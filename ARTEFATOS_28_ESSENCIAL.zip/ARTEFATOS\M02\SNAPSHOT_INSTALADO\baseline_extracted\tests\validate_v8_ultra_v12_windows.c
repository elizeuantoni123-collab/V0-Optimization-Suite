#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/v0_decision_v8_ultra_v12.h"
#define CHUNK 4096u
#define TOTAL 10000000u
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
int main(void){
    uint16_t*v=(uint16_t*)_aligned_malloc(CHUNK*2,64),*c=(uint16_t*)_aligned_malloc(CHUNK*2,64),*g=(uint16_t*)_aligned_malloc(CHUNK*2,64);
    uint8_t*t=(uint8_t*)_aligned_malloc(CHUNK,64),*p=(uint8_t*)_aligned_malloc(CHUNK,64);uint64_t r=0xA0761D6478BD642FULL;unsigned done=0;size_t i,n;
    if(!v||!c||!g||!t||!p)return 2;
    for(uint32_t sum=0;sum<=131070u;sum++){uint16_t vv=(sum>65535u)?65535u:(uint16_t)sum;uint16_t gg=(uint16_t)(sum-(uint32_t)vv);if(v0_eval_gate16_v10_inline(vv,gg)!=v0_eval_gate16_v12_scalar_direct_inline(vv,gg)){printf("FAIL sum=%u\n",sum);return 3;}}
    for(uint32_t cost=0;cost<65536u;cost++)for(uint32_t temp=0;temp<3u;temp++)for(uint32_t pin=0;pin<2u;pin++)if(v0_decision_gate16_v10((uint16_t)cost,(uint8_t)temp,(uint8_t)pin)!=v0_decision_gate16_v12_branchless((uint16_t)cost,(uint8_t)temp,(uint8_t)pin)){printf("FAIL gate\n");return 4;}
    while(done<TOTAL){n=(TOTAL-done)>CHUNK?CHUNK:(TOTAL-done);for(i=0;i<n;i++){v[i]=(uint16_t)rng64(&r);c[i]=(uint16_t)rng64(&r);t[i]=(uint8_t)(rng64(&r)%3u);p[i]=(uint8_t)(rng64(&r)&1u);g[i]=v0_decision_gate16_v12_branchless(c[i],t[i],p[i]);}for(i=0;i<n;i++){uint8_t ref=(uint8_t)v0_eval_v8_raw_ultra_inline(v[i],c[i],t[i],p[i]);uint8_t got=(uint8_t)v0_eval_gate16_v12_scalar_direct_inline(v[i],g[i]);if(got!=ref){printf("FAIL random i=%zu\n",i);return 5;}}done+=(unsigned)n;}
    printf("V0 Decision V8 ULTRA V12 Windows validation PASS\n");
    printf("exhaustive sums: 131071, exhaustive gates: 393216, random signals: %u, divergences: 0\n",TOTAL);
    _aligned_free(v);_aligned_free(c);_aligned_free(g);_aligned_free(t);_aligned_free(p);return 0;
}

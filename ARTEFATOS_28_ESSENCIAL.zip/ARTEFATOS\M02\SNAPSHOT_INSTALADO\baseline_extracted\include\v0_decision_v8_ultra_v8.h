#ifndef V0_DECISION_V8_ULTRA_V8_H
#define V0_DECISION_V8_ULTRA_V8_H

/*
 * V0 Decision V8 ULTRA V8
 * Additive exact fast paths over V7.  The V7 header and native objects remain
 * unchanged.  Every V8 path returns exactly the same packed Decision states
 * (0,4,5,6,7) for the legal Decision input domain.
 */
#include "v0_decision_v8_extreme.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(__AVX2__) || defined(_M_AVX2)

/* -------------------------------------------------------------------------
 * Exact bias-fused V8 path.
 *
 * Let h=cost/2 and s=value+bias.  We only observe score boundaries up to 384.
 * Saturating s to 65535 is exact for Decision: if true s exceeds 65535 then
 * s-h > 32768 because h<=32767, which is already well above the top boundary.
 * Therefore d=sat_u16(s)-h (saturated at zero), plus a single preflight mask,
 * carries all information Decision consumes.
 * ------------------------------------------------------------------------- */
V0X_FORCEINLINE __m256i v0_eval_v8_bias_block32_ultra_v8_avx2(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m256i one   = _mm256_set1_epi16(1);
    const __m256i seven = _mm256_set1_epi16(7);
    const __m256i lut = _mm256_setr_epi8(
        0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
        0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0);
    const __m256i v0 = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i v1 = _mm256_loadu_si256((const __m256i *)(const void *)(value+16));
    const __m256i h0 = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost), 1);
    const __m256i h1 = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)(cost+16)), 1);
    const __m256i b0 = _mm256_loadu_si256((const __m256i *)(const void *)bias);
    const __m256i b1 = _mm256_loadu_si256((const __m256i *)(const void *)(bias+16));
    const __m256i s0 = _mm256_adds_epu16(v0,b0);
    const __m256i s1 = _mm256_adds_epu16(v1,b1);
    const __m256i d0 = _mm256_subs_epu16(s0,h0);
    const __m256i d1 = _mm256_subs_epu16(s1,h1);
    const __m256i p0 = _mm256_cmpeq_epi16(_mm256_max_epu16(s0,h0),s0);
    const __m256i p1 = _mm256_cmpeq_epi16(_mm256_max_epu16(s1,h1),s1);
    __m256i i0 = _mm256_min_epu16(
        _mm256_add_epi16(_mm256_srli_epi16(d0,6),one),seven);
    __m256i i1 = _mm256_min_epu16(
        _mm256_add_epi16(_mm256_srli_epi16(d1,6),one),seven);
    i0 = _mm256_and_si256(i0,p0);
    i1 = _mm256_and_si256(i1,p1);
    {
        __m256i idx = _mm256_packus_epi16(i0,i1);
        idx = _mm256_permute4x64_epi64(idx,_MM_SHUFFLE(3,1,2,0));
        return _mm256_shuffle_epi8(lut,idx);
    }
}

static inline void v0_eval_v8_bias_batch_ultra_v8_avx2_u8(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out, size_t n) {
    size_t i=0;
    /* One 32-item body was measurably better than deeper unrolling on Zen 4. */
    for (; i+32<=n; i+=32)
        _mm256_storeu_si256((__m256i *)(void *)(out+i),
            v0_eval_v8_bias_block32_ultra_v8_avx2(value+i,cost+i,bias+i));
    if (i<n)
        v0_eval_v8_bias_batch_ultra_v7_avx2_u8(
            value+i,cost+i,bias+i,out+i,n-i);
}

/* Exact 4-bit packed output: two Decision states per byte.
 * low nibble = item 2k, high nibble = item 2k+1. */
V0X_FORCEINLINE __m128i v0_pack_v8_e3_nibbles32_avx2(__m256i e) {
    const __m256i weights = _mm256_set1_epi16(0x1001); /* [1,16] bytes */
    const __m256i w = _mm256_maddubs_epi16(e,weights);
    return _mm_packus_epi16(
        _mm256_castsi256_si128(w),_mm256_extracti128_si256(w,1));
}

static inline void v0_eval_v8_bias_batch_ultra_v8_avx2_nibble(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out_nibbles, size_t n) {
    size_t i=0, j=0;
    for (; i+32<=n; i+=32,j+=16)
        _mm_storeu_si128((__m128i *)(void *)(out_nibbles+j),
            v0_pack_v8_e3_nibbles32_avx2(
                v0_eval_v8_bias_block32_ultra_v8_avx2(value+i,cost+i,bias+i)));
    if (i<n) {
        uint8_t acc=0; unsigned half=0;
        for (; i<n; ++i) {
            const uint8_t e=(uint8_t)v0_eval_v8_bias_ultra_inline(value[i],cost[i],bias[i]);
            if (!half) { acc=e; half=1; }
            else { out_nibbles[j++]=(uint8_t)(acc | (uint8_t)(e<<4)); half=0; }
        }
        if (half) out_nibbles[j]=acc;
    }
}

/* Large write-only compact output.  Destination must be 16-byte aligned for
 * non-temporal stores; otherwise the normal nibble path is used. */
static inline void v0_eval_v8_bias_batch_ultra_v8_stream_avx2_nibble(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out_nibbles, size_t n) {
    size_t i=0,j=0;
    if ((((uintptr_t)out_nibbles)&15u)!=0u || n<256u) {
        v0_eval_v8_bias_batch_ultra_v8_avx2_nibble(value,cost,bias,out_nibbles,n);
        return;
    }
    for (; i+32<=n; i+=32,j+=16)
        _mm_stream_si128((__m128i *)(void *)(out_nibbles+j),
            v0_pack_v8_e3_nibbles32_avx2(
                v0_eval_v8_bias_block32_ultra_v8_avx2(value+i,cost+i,bias+i)));
    _mm_sfence();
    if (i<n) {
        uint8_t acc=0; unsigned half=0;
        for (; i<n; ++i) {
            const uint8_t e=(uint8_t)v0_eval_v8_bias_ultra_inline(value[i],cost[i],bias[i]);
            if (!half) { acc=e; half=1; }
            else { out_nibbles[j++]=(uint8_t)(acc | (uint8_t)(e<<4)); half=0; }
        }
        if (half) out_nibbles[j]=acc;
    }
}

/* -------------------------------------------------------------------------
 * Exact raw path using pinned invariant.
 * For pinned=1, minimum score is 0-32767+33151 = 384, therefore the exact
 * result is always 7.  Unpinned lanes need only the small temperature bonus.
 * ------------------------------------------------------------------------- */
V0X_FORCEINLINE __m128i v0_eval_v8_raw_block16_ultra_v8_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i hh = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost),1);
    const __m256i tt = _mm256_cvtepu8_epi16(
        _mm_loadu_si128((const __m128i *)(const void *)temperature));
    const __m256i pp = _mm256_cvtepu8_epi16(
        _mm_loadu_si128((const __m128i *)(const void *)pinned));
    const __m256i bonus = _mm256_slli_epi16(
        _mm256_add_epi16(tt,_mm256_srli_epi16(tt,1)),6);
    const __m256i ss = _mm256_adds_epu16(vv,bonus);
    const __m256i dd = _mm256_subs_epu16(ss,hh);
    const __m256i pre = _mm256_cmpeq_epi16(_mm256_max_epu16(ss,hh),ss);
    __m256i idx = _mm256_min_epu16(
        _mm256_add_epi16(_mm256_srli_epi16(dd,6),_mm256_set1_epi16(1)),
        _mm256_set1_epi16(7));
    idx = _mm256_and_si256(idx,pre);
    idx = _mm256_blendv_epi8(idx,_mm256_set1_epi16(7),
        _mm256_sub_epi16(_mm256_setzero_si256(),pp));
    {
        const __m128i i8 = _mm_packus_epi16(
            _mm256_castsi256_si128(idx),_mm256_extracti128_si256(idx,1));
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),i8);
    }
}

static inline void v0_eval_v8_raw_batch_ultra_v8_avx2_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i=0;
    for (; i+16<=n; i+=16)
        _mm_storeu_si128((__m128i *)(void *)(out+i),
            v0_eval_v8_raw_block16_ultra_v8_avx2(
                value+i,cost+i,temperature+i,pinned+i));
    for (; i<n; ++i)
        out[i]=(uint8_t)v0_eval_v8_raw_ultra_inline(
            value[i],cost[i],temperature[i],pinned[i]);
}

V0X_FORCEINLINE uint32_t v0_preflight_v8_raw_mask16_ultra_v8_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i hh = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost),1);
    const __m256i tt = _mm256_cvtepu8_epi16(
        _mm_loadu_si128((const __m128i *)(const void *)temperature));
    const __m256i pp = _mm256_cvtepu8_epi16(
        _mm_loadu_si128((const __m128i *)(const void *)pinned));
    const __m256i bonus = _mm256_slli_epi16(
        _mm256_add_epi16(tt,_mm256_srli_epi16(tt,1)),6);
    const __m256i ss = _mm256_adds_epu16(vv,bonus);
    __m256i yes = _mm256_cmpeq_epi16(_mm256_max_epu16(ss,hh),ss);
    yes = _mm256_or_si256(yes,_mm256_sub_epi16(_mm256_setzero_si256(),pp));
    {
        const __m128i pk = _mm_packs_epi16(
            _mm256_castsi256_si128(yes),_mm256_extracti128_si256(yes,1));
        return (uint32_t)(unsigned)_mm_movemask_epi8(pk);
    }
}

static inline uint64_t v0_preflight_v8_raw_count_ultra_v8_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned, size_t n) {
    uint64_t count=0; size_t i=0;
    for (; i+16<=n; i+=16) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask16_ultra_v8_avx2(
            value+i,cost+i,temperature+i,pinned+i));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask16_ultra_v8_avx2(
            value+i,cost+i,temperature+i,pinned+i));
#endif
    }
    for (; i<n; ++i)
        count += (uint64_t)v0_preflight_v8_raw_ultra_inline(
            value[i],cost[i],temperature[i],pinned[i]);
    return count;
}

/* Packed V7 signal AoS: keep the existing deinterleave, replace four tier
 * comparisons with clamp + 8-entry LUT. */
V0X_FORCEINLINE __m128i v0_eval_v8_signal_block8_ultra_v8_avx2(
    const v0_decision_signal_v7_t *signal) {
    __m256i q = v0_q6_signal8_ultra_v7_avx2(signal);
    q = _mm256_min_epi32(
        _mm256_max_epi32(_mm256_add_epi32(q,_mm256_set1_epi32(1)),
                         _mm256_setzero_si256()),
        _mm256_set1_epi32(7));
    {
        const __m128i q16 = _mm_packus_epi32(
            _mm256_castsi256_si128(q),_mm256_extracti128_si256(q,1));
        const __m128i idx = _mm_packus_epi16(q16,_mm_setzero_si128());
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),idx);
    }
}

static inline void v0_eval_v8_signal_batch_ultra_v8_avx2_u8(
    const v0_decision_signal_v7_t *signal, uint8_t *out, size_t n) {
    size_t i=0;
    for (; i+8<=n; i+=8)
        _mm_storel_epi64((__m128i *)(void *)(out+i),
            v0_eval_v8_signal_block8_ultra_v8_avx2(signal+i));
    for (; i<n; ++i)
        out[i]=(uint8_t)v0_eval_v8_signal_ultra_inline(signal+i);
}

#if defined(__AVX512BW__) && defined(__AVX512VL__)

/* AVX-512 V8 bias path: native unsigned compare mask removes the AVX2
 * max/equality preflight construction. */
V0X_FORCEINLINE __m256i v0_eval_v8_bias_block32_ultra_v8_avx512(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m512i vv = _mm512_loadu_si512((const void *)value);
    const __m512i hh = _mm512_srli_epi16(_mm512_loadu_si512((const void *)cost),1);
    const __m512i bb = _mm512_loadu_si512((const void *)bias);
    const __m512i ss = _mm512_adds_epu16(vv,bb);
    const __m512i dd = _mm512_subs_epu16(ss,hh);
    const __mmask32 pre = _mm512_cmpge_epu16_mask(ss,hh);
    __m512i idx = _mm512_min_epu16(
        _mm512_add_epi16(_mm512_srli_epi16(dd,6),_mm512_set1_epi16(1)),
        _mm512_set1_epi16(7));
    idx = _mm512_maskz_mov_epi16(pre,idx);
    {
        const __m256i i8 = _mm512_cvtusepi16_epi8(idx);
        return _mm256_shuffle_epi8(
            _mm256_setr_epi8(
                0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
                0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),i8);
    }
}

static inline void v0_eval_v8_bias_batch_ultra_v8_avx512_u8(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out, size_t n) {
    size_t i=0;
    for (; i+32<=n; i+=32)
        _mm256_storeu_si256((__m256i *)(void *)(out+i),
            v0_eval_v8_bias_block32_ultra_v8_avx512(value+i,cost+i,bias+i));
    if (i<n)
        v0_eval_v8_bias_batch_ultra_v8_avx2_u8(value+i,cost+i,bias+i,out+i,n-i);
}

V0X_FORCEINLINE __m256i v0_eval_v8_raw_block32_ultra_v8_avx512(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m512i vv = _mm512_loadu_si512((const void *)value);
    const __m512i hh = _mm512_srli_epi16(_mm512_loadu_si512((const void *)cost),1);
    const __m512i tt = _mm512_cvtepu8_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)temperature));
    const __m512i pp = _mm512_cvtepu8_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)pinned));
    const __m512i bonus = _mm512_slli_epi16(
        _mm512_add_epi16(tt,_mm512_srli_epi16(tt,1)),6);
    const __m512i ss = _mm512_adds_epu16(vv,bonus);
    const __m512i dd = _mm512_subs_epu16(ss,hh);
    const __mmask32 pre = _mm512_cmpge_epu16_mask(ss,hh);
    const __mmask32 pinm = _mm512_cmpneq_epi16_mask(pp,_mm512_setzero_si512());
    __m512i idx = _mm512_min_epu16(
        _mm512_add_epi16(_mm512_srli_epi16(dd,6),_mm512_set1_epi16(1)),
        _mm512_set1_epi16(7));
    idx = _mm512_maskz_mov_epi16(pre,idx);
    idx = _mm512_mask_mov_epi16(idx,pinm,_mm512_set1_epi16(7));
    {
        const __m256i i8 = _mm512_cvtusepi16_epi8(idx);
        return _mm256_shuffle_epi8(
            _mm256_setr_epi8(
                0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
                0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),i8);
    }
}

static inline void v0_eval_v8_raw_batch_ultra_v8_avx512_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i=0;
    for (; i+32<=n; i+=32)
        _mm256_storeu_si256((__m256i *)(void *)(out+i),
            v0_eval_v8_raw_block32_ultra_v8_avx512(
                value+i,cost+i,temperature+i,pinned+i));
    if (i<n)
        v0_eval_v8_raw_batch_ultra_v8_avx2_u8(
            value+i,cost+i,temperature+i,pinned+i,out+i,n-i);
}

V0X_FORCEINLINE uint32_t v0_preflight_v8_raw_mask32_ultra_v8_avx512(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m512i vv = _mm512_loadu_si512((const void *)value);
    const __m512i hh = _mm512_srli_epi16(_mm512_loadu_si512((const void *)cost),1);
    const __m512i tt = _mm512_cvtepu8_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)temperature));
    const __m512i pp = _mm512_cvtepu8_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)pinned));
    const __m512i bonus = _mm512_slli_epi16(
        _mm512_add_epi16(tt,_mm512_srli_epi16(tt,1)),6);
    const __m512i ss = _mm512_adds_epu16(vv,bonus);
    return (uint32_t)(_mm512_cmpge_epu16_mask(ss,hh) |
                      _mm512_cmpneq_epi16_mask(pp,_mm512_setzero_si512()));
}

static inline uint64_t v0_preflight_v8_raw_count_ultra_v8_avx512(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned, size_t n) {
    uint64_t count=0; size_t i=0;
    for (; i+32<=n; i+=32) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask32_ultra_v8_avx512(
            value+i,cost+i,temperature+i,pinned+i));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask32_ultra_v8_avx512(
            value+i,cost+i,temperature+i,pinned+i));
#endif
    }
    if (i<n)
        count += v0_preflight_v8_raw_count_ultra_v8_avx2(
            value+i,cost+i,temperature+i,pinned+i,n-i);
    return count;
}

/* 16 packed AoS records from two 64-byte loads.  VPERMT2W extracts compact
 * 16-bit value/cost/bias lanes; the lower 256 bits are then evaluated with
 * the same exact saturating identity as the SoA V8 path. */
static const uint16_t V0X_ALIGN64 V0X_SIGNAL_WORD_VALUE_INDEX_V8[32] = {
    0,4,8,12,16,20,24,28,32,36,40,44,48,52,56,60,
    0,4,8,12,16,20,24,28,32,36,40,44,48,52,56,60
};

V0X_FORCEINLINE __m128i v0_eval_v8_signal_block16_ultra_v8_avx512(
    const v0_decision_signal_v7_t *signal) {
    const __m512i a = _mm512_loadu_si512((const void *)signal);
    const __m512i b = _mm512_loadu_si512((const void *)(signal+8));
    const __m512i iv = _mm512_load_si512((const void *)V0X_SIGNAL_WORD_VALUE_INDEX_V8);
    const __m512i ic = _mm512_add_epi16(iv,_mm512_set1_epi16(1));
    const __m512i ib = _mm512_add_epi16(iv,_mm512_set1_epi16(2));
    const __m256i vv = _mm512_castsi512_si256(_mm512_permutex2var_epi16(a,iv,b));
    const __m256i cc = _mm512_castsi512_si256(_mm512_permutex2var_epi16(a,ic,b));
    const __m256i bb = _mm512_castsi512_si256(_mm512_permutex2var_epi16(a,ib,b));
    const __m256i hh = _mm256_srli_epi16(cc,1);
    const __m256i ss = _mm256_adds_epu16(vv,bb);
    const __m256i dd = _mm256_subs_epu16(ss,hh);
    const __m256i pre = _mm256_cmpeq_epi16(_mm256_max_epu16(ss,hh),ss);
    __m256i idx = _mm256_min_epu16(
        _mm256_add_epi16(_mm256_srli_epi16(dd,6),_mm256_set1_epi16(1)),
        _mm256_set1_epi16(7));
    idx = _mm256_and_si256(idx,pre);
    {
        const __m128i i8 = _mm_packus_epi16(
            _mm256_castsi256_si128(idx),_mm256_extracti128_si256(idx,1));
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0),i8);
    }
}

static inline void v0_eval_v8_signal_batch_ultra_v8_avx512_u8(
    const v0_decision_signal_v7_t *signal, uint8_t *out, size_t n) {
    size_t i=0;
    for (; i+16<=n; i+=16)
        _mm_storeu_si128((__m128i *)(void *)(out+i),
            v0_eval_v8_signal_block16_ultra_v8_avx512(signal+i));
    if (i<n)
        v0_eval_v8_signal_batch_ultra_v8_avx2_u8(signal+i,out+i,n-i);
}

V0X_FORCEINLINE uint32_t v0_preflight_v8_signal_mask16_ultra_v8_avx512(
    const v0_decision_signal_v7_t *signal) {
    const __m512i a = _mm512_loadu_si512((const void *)signal);
    const __m512i b = _mm512_loadu_si512((const void *)(signal+8));
    const __m512i iv = _mm512_load_si512((const void *)V0X_SIGNAL_WORD_VALUE_INDEX_V8);
    const __m512i ic = _mm512_add_epi16(iv,_mm512_set1_epi16(1));
    const __m512i ib = _mm512_add_epi16(iv,_mm512_set1_epi16(2));
    const __m256i vv = _mm512_castsi512_si256(_mm512_permutex2var_epi16(a,iv,b));
    const __m256i cc = _mm512_castsi512_si256(_mm512_permutex2var_epi16(a,ic,b));
    const __m256i bb = _mm512_castsi512_si256(_mm512_permutex2var_epi16(a,ib,b));
    const __m256i threshold = _mm256_subs_epu16(_mm256_srli_epi16(cc,1),bb);
    return (uint32_t)_mm256_cmpge_epu16_mask(vv,threshold);
}

static inline uint64_t v0_preflight_v8_signal_count_ultra_v8_avx512(
    const v0_decision_signal_v7_t *signal, size_t n) {
    uint64_t count=0; size_t i=0;
    for (; i+16<=n; i+=16) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_signal_mask16_ultra_v8_avx512(signal+i));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_signal_mask16_ultra_v8_avx512(signal+i));
#endif
    }
    for (; i<n; ++i) count += (uint64_t)(v0_eval_v8_signal_ultra_inline(signal+i)>>2);
    return count;
}

/* Exact minimal 3-bit state in three bitplanes for bandwidth-bound batches.
 * Each uint32_t covers 32 decisions.  tier_lo/tier_hi reconstruct tier 0..3. */
static inline void v0_eval_v8_bias_bitplanes_ultra_v8_avx512(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint32_t *preflight_bits, uint32_t *tier_lo_bits, uint32_t *tier_hi_bits,
    size_t n) {
    size_t i=0,j=0;
    for (; i+32<=n; i+=32,++j) {
        const __m512i vv = _mm512_loadu_si512((const void *)(value+i));
        const __m512i hh = _mm512_srli_epi16(_mm512_loadu_si512((const void *)(cost+i)),1);
        const __m512i bb = _mm512_loadu_si512((const void *)(bias+i));
        const __m512i ss = _mm512_adds_epu16(vv,bb);
        const __m512i dd = _mm512_subs_epu16(ss,hh);
        const __m512i q  = _mm512_srli_epi16(dd,6);
        const __mmask32 p  = _mm512_cmpge_epu16_mask(ss,hh);
        const __mmask32 k1 = _mm512_cmpge_epu16_mask(q,_mm512_set1_epi16(1));
        const __mmask32 k3 = _mm512_cmpge_epu16_mask(q,_mm512_set1_epi16(3));
        const __mmask32 k6 = _mm512_cmpge_epu16_mask(q,_mm512_set1_epi16(6));
        preflight_bits[j]=(uint32_t)p;
        tier_lo_bits[j]=(uint32_t)(k1^k3^k6);
        tier_hi_bits[j]=(uint32_t)k3;
    }
    if (i<n) {
        uint32_t pb=0,lb=0,hb=0; unsigned bit=0;
        for (; i<n; ++i,++bit) {
            const uint32_t e=v0_eval_v8_bias_ultra_inline(value[i],cost[i],bias[i]);
            const uint32_t tier=e&3u;
            pb |= ((e>>2)&1u)<<bit;
            lb |= (tier&1u)<<bit;
            hb |= ((tier>>1)&1u)<<bit;
        }
        preflight_bits[j]=pb; tier_lo_bits[j]=lb; tier_hi_bits[j]=hb;
    }
}

#endif /* AVX512BW + AVX512VL */
#endif /* AVX2 */

#ifdef __cplusplus
}
#endif
#endif

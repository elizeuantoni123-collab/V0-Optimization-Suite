#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/build/linux"
python "$ROOT/compiler/v0lc_plan64x4.py" "$ROOT/src/v0_batch_plan64_small4.v0l" "$ROOT/build/linux/v0_batch_plan64_small4.o"
python "$ROOT/compiler/v0lc_batch_avx2_v14.py" "$ROOT/src/v0_batch_plan64_avx2_v14.v0l" "$ROOT/build/linux/v0_batch_plan64_avx2_v14.o"
echo "V13/V14 Linux objects rebuilt."

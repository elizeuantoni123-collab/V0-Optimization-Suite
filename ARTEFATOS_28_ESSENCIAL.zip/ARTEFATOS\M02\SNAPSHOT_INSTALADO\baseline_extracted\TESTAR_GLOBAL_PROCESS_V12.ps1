$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$client = Join-Path $Root "CLIENTE_DECISION_V8.ps1"

Write-Host "=== TESTE V12 GLOBAL PROCESS ===" -ForegroundColor Cyan
$version = & $client -Command "VERSION"
$global1 = & $client -Command "GLOBALSTATUS"
Write-Host "VERSION     : $version"
Write-Host "GLOBALSTATUS: $global1"

if ($version -notmatch 'V12-GLOBAL-PROCESS-V1') { throw "Versao global incorreta." }

$pidSelf = $PID
$pidStatus = & $client -Command "PIDSTATUS $pidSelf"
Write-Host "PIDSTATUS   : $pidStatus"
if ($pidStatus -notmatch 'live=1') { throw "O proprio PowerShell nao apareceu como processo vivo no broker." }

# Testa API PID-scoped sem alterar nem matar processo algum.
$dec = & $client -Command "DECIDEPID $pidSelf 500 200 1 0"
Write-Host "DECIDEPID   : $dec"
if ($dec -notmatch '^OK pid=') { throw "DECIDEPID falhou." }

# Gate exato para cost=200,temp=1,pinned=0 usando a formula V12.
$cost = 200; $temp = 1; $pinned = 0
$base = 0x8000 + (($temp + ($temp -shr 1)) -shl 6) - ($cost -shr 1)
$gate = ($base -bor (0 - $pinned)) -band 0xFFFF
$gdec = & $client -Command "GATEDECIDEPID $pidSelf 500 $gate"
Write-Host "GATEDECIDEPID: $gdec"
if ($gdec -notmatch '^OK pid=') { throw "GATEDECIDEPID falhou." }

Start-Sleep -Milliseconds 250
$global2 = & $client -Command "GLOBALSTATUS"
Write-Host "GLOBALSTATUS: $global2"
Write-Host "PASS: broker global acompanha processos e aceita decisoes por PID." -ForegroundColor Green

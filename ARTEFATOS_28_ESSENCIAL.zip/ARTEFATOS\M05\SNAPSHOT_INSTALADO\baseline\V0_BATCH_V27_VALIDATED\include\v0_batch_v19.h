#ifndef V0_BATCH_V19_H
#define V0_BATCH_V19_H
#include "v0_batch.h"
#ifdef __cplusplus
extern "C" {
#endif
/* V19: counted dual-YMM AVX2 fixed-64 materialized planner.
   Same exact v0_batch_span ABI as V11/V14.
   Caller must gate AVX2 + OS YMM state.
   Validated performance domain on the reference host: 385..262144 items.
   Existing V11/V14 remain mandatory fallbacks outside the chosen domain. */
uint32_t v0_batch_plan64_avx2_dual_v19(v0_batch_span *out, uint32_t items);
#ifdef __cplusplus
}
#endif
#endif

# Artefato 16 — V0 Tier Manager V3 SAFE -> V12 Batch8 Squeeze

Status: **LOCAL_PASS / WINDOWS_GATE_REQUIRED**.

The promoted V3 scalar path is preserved unchanged. V12 is an additive batch fast path for exactly eight independent requests whose `preferred` values have already been validated to `0..4`.

## Authority / fallback

- universal or untrusted `preferred`: keep `v0_tier_select_v2` from the V3 SAFE baseline package;
- scalar prevalidated request: keep `v0_tier_select_valid_v3`;
- 8 prevalidated requests: candidate `v0_tier_select_batch8_v12`;
- tail of 1..7 requests: scalar V3.

V12 does not change tier semantics, storage movement, EPT/VMX, compression, or V0 Global.

## Batch ABI

One pointer references this fixed layout:

```c
typedef struct { uint32_t preferred, mask; } Rec;
typedef struct {
    Rec in[8];       // bytes 0..63
    uint8_t out[8];  // bytes 64..71
} TierBatch8;
```

Every `preferred` must already be `0..4`. `mask` may contain arbitrary upper bits; V12 masks it to the lower five bits exactly like V3. Outputs are `0..4` or `255`.

## Why it helps

Eight scalar V3 calls each materialize the table address and pay a call/return boundary. V12 keeps one table base live and performs eight exact lookups in one call. The table and selection policy are otherwise unchanged.

## Local result

On the local Linux screening host (AMD EPYC 9V74; **not** the target Intel/Windows machine):

- parity suite: 8,001,280 tier decisions per process, 0 divergences;
- long A/B gate: 4 independent processes;
- 9 workload shapes x 12 paired rounds x 4 processes = 432 paired measurements;
- wins: **432/432**;
- overall median speedup: **1.369869x**;
- worst observed paired speedup: **1.117092x**.

This is a batch-path result, not a claim that the entire Tier Manager service becomes 1.37x faster.

Run `windows_gate/RUN_WINDOWS_GATE.ps1` on the target Windows machine before promotion. It does not install or modify any service.

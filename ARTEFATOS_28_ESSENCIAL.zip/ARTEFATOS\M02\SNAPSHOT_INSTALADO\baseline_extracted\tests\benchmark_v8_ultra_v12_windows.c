#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/v0_decision_v8_ultra_v12.h"
#define N (1u<<20)
static volatile uint64_t sink;
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return*s=x;}
static double ns(LARGE_INTEGER a,LARGE_INTEGER b,LARGE_INTEGER f){return(double)(b.QuadPart-a.QuadPart)*1e9/(double)f.QuadPart;}
int main(void){uint16_t*v=(uint16_t*)_aligned_malloc(N*2,64),*c=(uint16_t*)_aligned_malloc(N*2,64),*g=(uint16_t*)_aligned_malloc(N*2,64),*go=(uint16_t*)_aligned_malloc(N*2,64);uint8_t*t=(uint8_t*)_aligned_malloc(N,64),*p=(uint8_t*)_aligned_malloc(N,64);uint64_t s=0x94D049BB133111EBULL,q=0;LARGE_INTEGER f,a,b;size_t i;int k;if(!v||!c||!g||!go||!t||!p)return 2;for(i=0;i<N;i++){v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);g[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);}QueryPerformanceFrequency(&f);
QueryPerformanceCounter(&a);for(k=0;k<16;k++)for(i=0;i<N;i++)q+=v0_eval_gate16_v11_scalar_lut_inline(v[i],g[i]);QueryPerformanceCounter(&b);printf("V11 scalar gate16: %.6f ns/item\n",ns(a,b,f)/(N*16.0));
QueryPerformanceCounter(&a);for(k=0;k<16;k++)for(i=0;i<N;i++)q+=v0_eval_gate16_v12_scalar_direct_inline(v[i],g[i]);QueryPerformanceCounter(&b);printf("V12 scalar direct2K: %.6f ns/item\n",ns(a,b,f)/(N*16.0));
QueryPerformanceCounter(&a);for(i=0;i<N;i++)go[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);QueryPerformanceCounter(&b);printf("V10 scalar gate builder: %.6f ns/item\n",ns(a,b,f)/N);
QueryPerformanceCounter(&a);for(i=0;i<N;i++)go[i]=v0_decision_gate16_v12_branchless(c[i],t[i],p[i]);QueryPerformanceCounter(&b);printf("V12 branchless gate builder: %.6f ns/item\n",ns(a,b,f)/N);
printf("checksum=%llu\n",(unsigned long long)(q+go[777]));_aligned_free(v);_aligned_free(c);_aligned_free(g);_aligned_free(go);_aligned_free(t);_aligned_free(p);return 0;}

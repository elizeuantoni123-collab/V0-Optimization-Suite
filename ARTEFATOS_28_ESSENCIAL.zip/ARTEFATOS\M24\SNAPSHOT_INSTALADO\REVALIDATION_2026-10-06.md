# M24 revalidation — 2026-10-06

## Baseline identity

The uploaded `V0_GLOBAL_MEMORY_WINDOWS_V8_21_INSTALL_FIX8_20260925` ZIP is byte-identical to the baseline carried by this artifact:

`SHA-256 75181ed7587f6129b7712649f2e472d88b506ef5e71771c7209c9e653ea126cb`

## Baseline integrity

`tools/selftest.py` from V8.21 FIX8: **SELFTEST OK**.

## Candidate correctness

`equiv_small.cpp`:

- checks: **77,043,328**
- divergences: **0**

Direct range benchmark also reported `equiv_bad=0`.

## Re-run screening in current Linux container

Direct-token benchmark medians remained positive across the tested fixed sizes; representative values:

- count=2: **1.5443x**
- count=4: **1.5167x**
- count=64: **1.4811x**
- count=511: **1.5871x**
- count=1024: **2.0408x**
- varied: **1.3372x**

Full-path model preserved `pages/samples/checksum` (`eq=1`) for every tested domain. Representative median speedups:

- count=2: **1.4838x**
- count=3: **3.7167x**
- count=16: **1.2551x**
- count=128: **1.1284x**
- count=511: **1.2477x**
- count=1024: **1.0603x**
- varied 2..1024: **1.0719x**

The varied workload had host-noise outliers (13/15 paired wins in this container), so this revalidation does **not** promote the candidate.

## Decision

Keep **V8.21 FIX8** as the active/promoted baseline. V8.22 remains additive and restricted to the 2..1024-page FastPolicy/range-accounting path until the supplied Windows gate wins on the target Intel machine. No EPT mapping decision, MTRR rule, hypervisor/boot state, or permanent installation behavior is changed by this candidate package.

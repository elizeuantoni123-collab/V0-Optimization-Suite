# M24 — V0 Global Memory V8.22 — Small Range Squeeze (CANDIDATE)

Baseline preservada: **V8.21 FIX8**.

Este pacote NÃO instala driver, NÃO altera EPT, hypervisor, boot, BCD ou firmware.
Ele contém apenas um candidato de FastPolicy para `V0PolicyCompilePhysicalRange()`.

## Ideia

Para ranges consecutivos de 2..1024 páginas:
- o XOR do range é calculado diretamente por `first_page parity + page_count mod 4`;
- em 25% das combinações o token é imediatamente 0 ou 1;
- existe no máximo uma amostra 1/1024, então o loop de sampling vira uma única condição.

Ranges maiores continuam exatamente no caminho V8.21.

## Estado

`LOCAL_CANDIDATE / WINDOWS_GATE_REQUIRED`

Não promover antes de executar `windows_gate/RUN_WINDOWS_GATE.ps1` no Intel/Windows alvo e revisar o resultado.


Revalidated on 2026-10-06; see `REVALIDATION_2026-10-06.md`.

#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<20)
#define R 11
static v0_decision_signal_v7_t *sigs; static uint8_t *out; static volatile uint64_t sink;
static uint64_t rr(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static double now(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return t.tv_sec*1e9+t.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}

static inline __m256i deint_even4(__m256i x){
  const __m256i idx=_mm256_setr_epi32(0,2,4,6,0,0,0,0);
  return _mm256_permutevar8x32_epi32(x,idx);
}
static inline __m256i deint_odd4(__m256i x){
  const __m256i idx=_mm256_setr_epi32(1,3,5,7,1,1,1,1);
  return _mm256_permutevar8x32_epi32(x,idx);
}
static inline __m256i aos_q8(const v0_decision_signal_v7_t *s){
  __m256i a=_mm256_loadu_si256((const __m256i*)(const void*)s);
  __m256i b=_mm256_loadu_si256((const __m256i*)(const void*)(s+4));
  __m256i av=deint_even4(a), bv=deint_even4(b);
  __m256i ab=deint_odd4(a), bb=deint_odd4(b);
  __m128i vcl=_mm256_castsi256_si128(av), vch=_mm256_castsi256_si128(bv);
  __m128i bil=_mm256_castsi256_si128(ab), bih=_mm256_castsi256_si128(bb);
  __m256i vc=_mm256_castsi128_si256(vcl); vc=_mm256_inserti128_si256(vc,vch,1);
  __m256i bi=_mm256_castsi128_si256(bil); bi=_mm256_inserti128_si256(bi,bih,1);
  __m256i value=_mm256_and_si256(vc,_mm256_set1_epi32(65535));
  __m256i hc=_mm256_srli_epi32(vc,17);
  bi=_mm256_and_si256(bi,_mm256_set1_epi32(65535));
  __m256i score=_mm256_add_epi32(_mm256_sub_epi32(value,hc),bi);
  return _mm256_srai_epi32(score,6);
}
static inline __m128i aos_eval8(const v0_decision_signal_v7_t *s){
  __m256i q=aos_q8(s);
  __m256i m0=_mm256_cmpgt_epi32(q,_mm256_set1_epi32(-1));
  __m256i m1=_mm256_cmpgt_epi32(q,_mm256_set1_epi32(0));
  __m256i m3=_mm256_cmpgt_epi32(q,_mm256_set1_epi32(2));
  __m256i m6=_mm256_cmpgt_epi32(q,_mm256_set1_epi32(5));
  __m256i e=_mm256_add_epi32(_mm256_and_si256(m0,_mm256_set1_epi32(4)),
      _mm256_add_epi32(_mm256_and_si256(m1,_mm256_set1_epi32(1)),
      _mm256_add_epi32(_mm256_and_si256(m3,_mm256_set1_epi32(1)),_mm256_and_si256(m6,_mm256_set1_epi32(1)))));
  __m128i lo=_mm256_castsi256_si128(e), hi=_mm256_extracti128_si256(e,1);
  __m128i p16=_mm_packus_epi32(lo,hi);
  return _mm_packus_epi16(p16,_mm_setzero_si128());
}
static void aos_batch(const v0_decision_signal_v7_t*s,uint8_t*o,size_t n){size_t i=0;for(;i+32<=n;i+=32){_mm_storel_epi64((__m128i*)(void*)(o+i),aos_eval8(s+i));_mm_storel_epi64((__m128i*)(void*)(o+i+8),aos_eval8(s+i+8));_mm_storel_epi64((__m128i*)(void*)(o+i+16),aos_eval8(s+i+16));_mm_storel_epi64((__m128i*)(void*)(o+i+24),aos_eval8(s+i+24));}for(;i+8<=n;i+=8)_mm_storel_epi64((__m128i*)(void*)(o+i),aos_eval8(s+i));for(;i<n;i++)o[i]=(uint8_t)v0_eval_v8_signal_ultra_inline(s+i);}
static double scalar(){uint64_t z=0;double a=now();for(size_t i=0;i<N;i++)z+=v0_eval_v8_signal_ultra_inline(sigs+i);double b=now();sink=z;return(b-a)/N;}
static double batch(){double a=now();aos_batch(sigs,out,N);double b=now();sink+=out[777];return(b-a)/N;}
static void bench(const char*n,double(*f)()){double x[R];for(int i=0;i<3;i++)f();for(int i=0;i<R;i++)x[i]=f();qsort(x,R,sizeof(double),cmpd);printf("%-22s p50 %.5f best %.5f\n",n,x[R/2],x[0]);}
int main(){posix_memalign((void**)&sigs,64,N*sizeof(*sigs));posix_memalign((void**)&out,64,N);uint64_t z=123;for(size_t i=0;i<N;i++){uint16_t v=rr(&z),c=rr(&z);uint8_t t=rr(&z)%3,p=rr(&z)&1;sigs[i]=v0_decision_v7_pack(v,c,t,p);}aos_batch(sigs,out,N);for(size_t i=0;i<N;i++)if(out[i]!=(uint8_t)v0_eval_v8_signal_ultra_inline(sigs+i)){printf("bad %zu\n",i);return 2;}bench("packed scalar",scalar);bench("packed AoS AVX2",batch);printf("sink %llu\n",(unsigned long long)sink);}

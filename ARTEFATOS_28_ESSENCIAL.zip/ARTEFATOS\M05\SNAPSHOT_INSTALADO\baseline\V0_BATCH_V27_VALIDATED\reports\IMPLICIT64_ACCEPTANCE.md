# V0 Batch V11 + IMPLICIT64 — Acceptance Report

## Status

**ACCEPTED AS AN OPTIONAL LARGE-BATCH CONSUMPTION MODE.**

This does **not** replace or modify the validated V6/V11 materialized planners.
The original V0L sources, Linux/Windows objects, ABI, and hashes remain unchanged.

## Idea

For fixed batches of 64, the sequence is deterministic:

- span `i` starts at `i * 64`;
- every full span has count `64`;
- only the final span can have a smaller count;
- `v0_batch_count64(items)` already provides the exact number of spans.

A compatible consumer can therefore iterate the spans directly instead of asking
`v0_batch_plan64*()` to first write an intermediate `{start,count}` array and then
reading that array back.

This is zero intermediate descriptor materialization. It is a consumer-fusion mode,
not a new scheduler and not a replacement for the descriptor ABI.

## Compatibility rule

Use the existing materialized planners when:

- the caller needs the descriptor vector;
- descriptors are persisted, transferred, reordered, inspected, or shared;
- the workload is small enough that the difference is noise;
- the downstream consumer cannot derive the fixed-64 sequence directly.

Use IMPLICIT64 only when:

- batch size is exactly 64;
- processing is sequential / derivable from `index * 64`;
- no external component needs the materialized descriptor array;
- the workload is large enough to justify the fused path.

## Correctness validation

`tests/test_implicit64.c` reconstructs implicit spans and compares them with the
existing best materialized path (`v0_batch_plan64` for small plans,
`v0_batch_plan64x4` for large plans).

Result:

- edge cases: PASS;
- 1,000,000 randomized item counts: PASS;
- first/middle/last plus randomized descriptor comparisons: PASS;
- exact `{start,count}` semantics preserved;
- checks: **6,084,121**;
- divergences: **0**.

The original V11 validation was rerun unchanged:

- checks: **148,146,658**;
- divergences: **0**.

Original `HASHES.sha256` also still verifies successfully, proving the validated
V11 core was not modified by this experiment.

## Benchmark — plan construction only

Representative medians from `IMPLICIT64_BENCH.csv`:

| Items | Spans | Materialized plan | Implicit/count | Speed-up |
|---:|---:|---:|---:|---:|
| 4,096 | 64 | 14.291 ns | 1.356 ns | 10.54x |
| 16,384 | 256 | 67.522 ns | 1.361 ns | 49.59x |
| 65,536 | 1,024 | 280.155 ns | 1.390 ns | 201.60x |
| 262,144 | 4,096 | 1,155.334 ns | 1.502 ns | 769.20x |
| 1,048,576 | 16,384 | 4,514.860 ns | 1.502 ns | 3,005.90x |

The large ratios are expected: the implicit path is not writing thousands of
intermediate descriptors. These numbers describe planning overhead only.

## End-to-end synthetic light-consumer benchmark

Both modes perform the same per-span dependent checksum operation. The materialized
path writes then reads descriptors; IMPLICIT64 derives the same spans directly.

Paired cutoff benchmark used 21 samples and alternated execution order.

| Items | Spans | Materialized | IMPLICIT64 | Speed-up |
|---:|---:|---:|---:|---:|
| 3,584 | 56 | 111.976 ns | 110.586 ns | 1.013x |
| 4,096 | 64 | 134.477 ns | 126.112 ns | 1.066x |
| 5,120 | 80 | 165.872 ns | 157.075 ns | 1.056x |
| 6,144 | 96 | 201.836 ns | 187.566 ns | 1.076x |
| 8,192 | 128 | 271.426 ns | 250.108 ns | 1.085x |
| 12,288 | 192 | 413.151 ns | 375.570 ns | 1.100x |
| 16,384 | 256 | 551.751 ns | 500.927 ns | 1.102x |

The broader run continued to show gains at larger sizes, reaching about **1.15x**
at 1,048,576 items for this light synthetic consumer.

## Promotion decision

- **V6 remains the small materialized planner.**
- **V11 packed x4 remains the large materialized planner.**
- **IMPLICIT64 is accepted only as an optional fused mode.**
- Conservative measured activation point on this host: **>= 4,096 items / 64 spans**.
- Do not hard-code that threshold globally across CPUs without local calibration.

Therefore this optimization does not invalidate or conflict with any previously
accepted optimization. It adds a third path for a narrower workload domain.

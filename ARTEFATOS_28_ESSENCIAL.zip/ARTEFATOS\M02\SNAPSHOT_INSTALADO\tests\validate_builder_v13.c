#include <stdint.h>
#include <stdio.h>
#include "V0_DECISION_V8_ULTRA_V12_GLOBAL_PROCESS_FIX1/include/v0_decision_v8_ultra_v12.h"
static inline uint16_t cand(uint16_t cost,uint8_t temp,uint8_t pin){static const uint16_t base[3]={0x8000u,0x8040u,0x80c0u};return (uint16_t)((uint32_t)(base[temp]-(cost>>1)) | (0u-(uint32_t)pin));}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
int main(){uint64_t checked=0,bad=0;for(uint32_t c=0;c<65536;c++)for(uint32_t t=0;t<3;t++)for(uint32_t p=0;p<2;p++){uint16_t a=v0_decision_gate16_v12_branchless((uint16_t)c,(uint8_t)t,(uint8_t)p),b=cand((uint16_t)c,(uint8_t)t,(uint8_t)p);checked++;if(a!=b){if(bad<10)printf("bad c=%u t=%u p=%u a=%u b=%u\n",c,t,p,a,b);bad++;}}uint64_t s=0xD6E8FEB86659FD93ULL;for(uint64_t i=0;i<20000000ULL;i++){uint16_t c=(uint16_t)rng64(&s);uint8_t t=(uint8_t)(rng64(&s)%3),p=(uint8_t)(rng64(&s)&1);uint16_t a=v0_decision_gate16_v12_branchless(c,t,p),b=cand(c,t,p);checked++;if(a!=b){bad++;break;}}printf("checked=%llu divergences=%llu status=%s\n",(unsigned long long)checked,(unsigned long long)bad,bad?"FAIL":"PASS");return bad?3:0;}

#include <stdint.h>
#include "../include/v0_semantic_bridge.h"
__attribute__((noinline,noipa)) uint32_t ref_semantic_id_trusted(const v0_semantic_record*r){return r->semantic_id;}
__attribute__((noinline,noipa)) uint32_t ref_semantic_id_safe(const v0_semantic_record*r){return r->valid?r->semantic_id:0xffffffffu;}

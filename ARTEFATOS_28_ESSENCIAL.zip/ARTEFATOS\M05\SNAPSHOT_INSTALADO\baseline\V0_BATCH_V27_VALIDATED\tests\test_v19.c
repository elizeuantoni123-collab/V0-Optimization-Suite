#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_batch_accel.h"
extern uint32_t v0_batch_plan64_avx2_dual_v19(v0_batch_span*,uint32_t);
static uint32_t st=0xa54e91c3u; static uint32_t xr(void){st^=st<<13;st^=st>>17;st^=st<<5;return st;}
int main(void){__builtin_cpu_init();if(!__builtin_cpu_supports("avx2")){puts("SKIP no avx2");return 0;}uint64_t checks=0;const uint32_t MAX=4194240u,MAXSPAN=65535u;v0_batch_span*a=aligned_alloc(64,(size_t)(MAXSPAN+8)*8u),*b=aligned_alloc(64,(size_t)(MAXSPAN+8)*8u);if(!a||!b)return 2;
const uint32_t edge[]={0,1,2,63,64,65,255,256,257,511,512,513,767,768,1023,1024,1025,1535,1536,2047,2048,2049,4095,4096,4097,65535,65536,65537,262143,262144,262145,1048575,1048576,1048577,4194239,4194240};
for(unsigned e=0;e<sizeof(edge)/sizeof(edge[0]);e++){uint32_t n=edge[e],k=n?((n-1u)>>6)+1u:0u;memset(a,0x11,(size_t)(k+8)*8u);memset(b,0x22,(size_t)(k+8)*8u);uint32_t x=v0_batch_plan64_avx2_v14(a,n),y=v0_batch_plan64_avx2_dual_v19(b,n);if(x!=y){fprintf(stderr,"edge count n=%u %u %u\n",n,x,y);return 3;}for(uint32_t i=0;i<x;i++){if(memcmp(&a[i],&b[i],8)){fprintf(stderr,"edge span n=%u i=%u\n",n,i);return 4;}checks++;}if(((unsigned char*)b)[k*8]!=0x22){fprintf(stderr,"overwrite n=%u\n",n);return 5;}checks++;}
const uint32_t bases[]={512,4096,65536,1048576};for(unsigned q=0;q<4;q++)for(int d=-511;d<=511;d++){uint32_t n=bases[q]+d,k=n?((n-1u)>>6)+1u:0u;((unsigned char*)b)[k*8]=0x22;uint32_t x=v0_batch_plan64_avx2_v14(a,n),y=v0_batch_plan64_avx2_dual_v19(b,n);if(x!=y)return 6;for(uint32_t i=0;i<x;i++){if(memcmp(&a[i],&b[i],8)){fprintf(stderr,"res span n=%u i=%u\n",n,i);return 7;}checks++;}if(((unsigned char*)b)[k*8]!=0x22)return 8;checks++;}
for(uint32_t t=0;t<120000u;t++){uint32_t n=xr()%(MAX+1u),k=n?((n-1u)>>6)+1u:0u;((unsigned char*)b)[k*8]=0x22;uint32_t x=v0_batch_plan64_avx2_v14(a,n),y=v0_batch_plan64_avx2_dual_v19(b,n);if(x!=y){fprintf(stderr,"rnd count n=%u\n",n);return 9;}for(uint32_t i=0;i<x;i++){if(memcmp(&a[i],&b[i],8)){fprintf(stderr,"rnd span n=%u i=%u\n",n,i);return 10;}checks++;}if(((unsigned char*)b)[k*8]!=0x22)return 11;checks++;}
free(a);free(b);printf("PASS V19 checks=%llu\n",(unsigned long long)checks);return 0;}

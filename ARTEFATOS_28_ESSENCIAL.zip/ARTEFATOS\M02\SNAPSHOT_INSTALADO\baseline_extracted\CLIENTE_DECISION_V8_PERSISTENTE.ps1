param(
    [Parameter(Mandatory=$true)]
    [string[]]$Command,
    [int]$TimeoutMs = 3000
)

$ErrorActionPreference = "Stop"
$pipe = New-Object System.IO.Pipes.NamedPipeClientStream(
    ".", "V0DecisionV8",
    [System.IO.Pipes.PipeDirection]::InOut,
    [System.IO.Pipes.PipeOptions]::None
)
$reader = $null
$writer = $null
try {
    $pipe.Connect($TimeoutMs)
    $writer = New-Object System.IO.StreamWriter($pipe, [Text.Encoding]::ASCII, 1024, $true)
    $reader = New-Object System.IO.StreamReader($pipe, [Text.Encoding]::ASCII, $false, 1024, $true)
    $writer.AutoFlush = $true
    foreach ($cmd in $Command) {
        $writer.WriteLine($cmd)
        $reply = $reader.ReadLine()
        [PSCustomObject]@{ Command = $cmd; Reply = $reply }
    }
} finally {
    if ($reader) { $reader.Dispose() }
    if ($writer) { $writer.Dispose() }
    if ($pipe) { $pipe.Dispose() }
}

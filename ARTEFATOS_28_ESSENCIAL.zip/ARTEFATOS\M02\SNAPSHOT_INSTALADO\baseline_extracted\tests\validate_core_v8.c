#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sched.h>
#include "../include/v0_decision_v7.h"
#include "../reference/v6/v0_decision_v6.h"

static inline uint32_t rng32(uint64_t *s){
    uint64_t x=*s; x^=x<<13; x^=x>>7; x^=x<<17; *s=x; return (uint32_t)x;
}
static inline uint32_t temp_bonus_ref(uint32_t t){ return t==1u?64u:(t==2u?192u:0u); }
static inline int32_t score_ref(uint16_t v,uint16_t c,uint32_t t){
    return (int32_t)v - (int32_t)(c>>1) + (int32_t)temp_bonus_ref(t);
}
static inline uint32_t pre_ref(uint16_t v,uint16_t c,uint32_t t,uint32_t pin){
    return pin ? 1u : (uint32_t)(score_ref(v,c,t)>=0);
}
static inline uint32_t dec_ref(uint16_t v,uint16_t c,uint32_t t,uint32_t pin){
    if(pin) return 3u;
    int32_t s=score_ref(v,c,t);
    return (uint32_t)(s>=64)+(uint32_t)(s>=192)+(uint32_t)(s>=384);
}
static void pin_cpu0(void){
    cpu_set_t set; CPU_ZERO(&set); CPU_SET(0,&set); (void)sched_setaffinity(0,sizeof(set),&set);
}

int main(void){
    pin_cpu0();
    uint64_t bad_bias=0,bad_pre=0,bad_dec=0,bad_v6v7_pre=0,bad_v6v7_dec=0;
    for(uint32_t t=0;t<3;t++) for(uint32_t p=0;p<2;p++){
        uint16_t got=v0_decision_v7_bias((uint8_t)t,(uint8_t)p);
        uint16_t exp=(uint16_t)(temp_bonus_ref(t)+(p?33151u:0u));
        if(got!=exp){ bad_bias++; printf("bias mismatch t=%u p=%u got=%u exp=%u\n",t,p,got,exp); }
    }
    const uint16_t vv[]={0,1,63,64,191,192,383,384,385,32767,32768,65534,65535};
    const uint16_t cc[]={0,1,2,3,127,128,383,384,767,768,32767,32768,65534,65535};
    uint64_t directed=0;
    for(size_t i=0;i<sizeof(vv)/sizeof(vv[0]);i++)
      for(size_t j=0;j<sizeof(cc)/sizeof(cc[0]);j++)
       for(uint32_t t=0;t<3;t++) for(uint32_t p=0;p<2;p++){
        uint16_t v=vv[i],c=cc[j];
        v0_decision_signal_v6_t s6=v0_decision_v6_pack(v,c,(uint8_t)t,(uint8_t)p);
        v0_decision_signal_v7_t s7=v0_decision_v7_pack(v,c,(uint8_t)t,(uint8_t)p);
        uint32_t pr=pre_ref(v,c,t,p),dr=dec_ref(v,c,t,p);
        uint32_t p6=v0_preflight_v0l_v6(&s6),p7=v0_preflight_v0l_v7(&s7);
        uint32_t d6=v0_decide_v0l_v6(&s6),d7=v0_decide_v0l_v7(&s7);
        bad_pre+=(p7!=pr); bad_dec+=(d7!=dr); bad_v6v7_pre+=(p6!=p7); bad_v6v7_dec+=(d6!=d7); directed++;
    }
    const uint64_t N=20000000ull;
    uint64_t st=0xD1CEB00B7A11C0DEull;
    for(uint64_t i=0;i<N;i++){
        uint32_t a=rng32(&st),b=rng32(&st);
        uint16_t v=(uint16_t)a,c=(uint16_t)(a>>16); uint32_t t=b%3u,p=(b>>8)&1u;
        v0_decision_signal_v6_t s6=v0_decision_v6_pack(v,c,(uint8_t)t,(uint8_t)p);
        v0_decision_signal_v7_t s7=v0_decision_v7_pack(v,c,(uint8_t)t,(uint8_t)p);
        uint32_t pr=pre_ref(v,c,t,p),dr=dec_ref(v,c,t,p);
        uint32_t p6=v0_preflight_v0l_v6(&s6),p7=v0_preflight_v0l_v7(&s7);
        uint32_t d6=v0_decide_v0l_v6(&s6),d7=v0_decide_v0l_v7(&s7);
        bad_pre+=(p7!=pr); bad_dec+=(d7!=dr); bad_v6v7_pre+=(p6!=p7); bad_v6v7_dec+=(d6!=d7);
    }
    printf("V7 validation\n");
    printf("bias domain checks: 6, bad=%"PRIu64"\n",bad_bias);
    printf("directed cases: %"PRIu64"\n",directed);
    printf("random cases: %"PRIu64"\n",N);
    printf("V7 preflight divergences vs reference: %"PRIu64"\n",bad_pre);
    printf("V7 full divergences vs reference: %"PRIu64"\n",bad_dec);
    printf("V6/V7 preflight divergences: %"PRIu64"\n",bad_v6v7_pre);
    printf("V6/V7 full divergences: %"PRIu64"\n",bad_v6v7_dec);
    return (bad_bias||bad_pre||bad_dec||bad_v6v7_pre||bad_v6v7_dec)?1:0;
}

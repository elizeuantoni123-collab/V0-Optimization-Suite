#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "../include/v0_batch.h"

#if defined(__GNUC__)
#define NOINLINE __attribute__((noinline))
#else
#define NOINLINE
#endif

static volatile uint64_t global_sink;
static inline uint64_t mix(uint64_t a, uint32_t start, uint32_t count){
    a ^= ((uint64_t)start<<32) | count;
    a ^= a << 13; a ^= a >> 7; a ^= a << 17;
    return a;
}

static NOINLINE uint64_t consume_materialized(v0_batch_span *buf, uint32_t items, uint32_t reps){
    uint64_t acc=0x243f6a8885a308d3ULL;
    for(uint32_t r=0;r<reps;r++){
        uint32_t k = items<=256u ? v0_batch_plan64(buf,items) : v0_batch_plan64x4(buf,items);
        for(uint32_t i=0;i<k;i++) acc=mix(acc,buf[i].start,buf[i].count);
    }
    global_sink^=acc; return acc;
}

static NOINLINE uint64_t consume_implicit(uint32_t items, uint32_t reps){
    uint64_t acc=0x243f6a8885a308d3ULL;
    for(uint32_t r=0;r<reps;r++){
        uint32_t full=items>>6;
        uint32_t tail=items&63u;
        for(uint32_t i=0;i<full;i++) acc=mix(acc,i<<6,64u);
        if(tail) acc=mix(acc,full<<6,tail);
    }
    global_sink^=acc; return acc;
}

static NOINLINE uint64_t plan_only_materialized(v0_batch_span *buf,uint32_t items,uint32_t reps){
    uint64_t acc=0;
    for(uint32_t r=0;r<reps;r++){
        uint32_t k=items<=256u?v0_batch_plan64(buf,items):v0_batch_plan64x4(buf,items);
        acc += k; acc ^= buf[k? k-1:0].start;
    }
    global_sink^=acc;return acc;
}
static NOINLINE uint64_t plan_only_implicit(uint32_t items,uint32_t reps){
    uint64_t acc=0;
    for(uint32_t r=0;r<reps;r++){
        uint32_t k=v0_batch_count64(items);
        acc += k; acc ^= items;
    }
    global_sink^=acc;return acc;
}

static uint64_t ns(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return (x>y)-(x<y);}
static double median(double*x,int n){qsort(x,n,sizeof(*x),cmpd);return x[n/2];}

int main(void){
    const uint32_t sizes[]={64,128,256,257,512,1024,4096,16384,65536,262144,1048576};
    enum{R=11};
    uint32_t maxk=v0_batch_count64(1048576u);
    v0_batch_span *buf;
    if(posix_memalign((void**)&buf,64,(size_t)(maxk+8)*sizeof(*buf))) return 2;
    printf("items,spans,plan_mat_ns,plan_impl_ns,plan_speedup,e2e_mat_ns,e2e_impl_ns,e2e_speedup\n");
    for(unsigned s=0;s<sizeof(sizes)/sizeof(sizes[0]);s++){
        uint32_t n=sizes[s], k=v0_batch_count64(n);
        uint32_t reps_plan=2000000u/(k?k:1); if(reps_plan<500)reps_plan=500; if(reps_plan>1000000)reps_plan=1000000;
        uint32_t reps_e2e=8000000u/(k?k:1); if(reps_e2e<100)reps_e2e=100; if(reps_e2e>200000)reps_e2e=200000;
        double pm[R],pi[R],em[R],ei[R];
        plan_only_materialized(buf,n,100); plan_only_implicit(n,100); consume_materialized(buf,n,10); consume_implicit(n,10);
        for(int r=0;r<R;r++){
            uint64_t t0=ns(); plan_only_materialized(buf,n,reps_plan); uint64_t t1=ns();
            plan_only_implicit(n,reps_plan); uint64_t t2=ns();
            consume_materialized(buf,n,reps_e2e); uint64_t t3=ns();
            consume_implicit(n,reps_e2e); uint64_t t4=ns();
            pm[r]=(double)(t1-t0)/reps_plan; pi[r]=(double)(t2-t1)/reps_plan;
            em[r]=(double)(t3-t2)/reps_e2e; ei[r]=(double)(t4-t3)/reps_e2e;
        }
        double a=median(pm,R),b=median(pi,R),c=median(em,R),d=median(ei,R);
        printf("%u,%u,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f\n",n,k,a,b,a/b,c,d,c/d);
    }
    free(buf); fprintf(stderr,"sink=%llu\n",(unsigned long long)global_sink); return 0;
}

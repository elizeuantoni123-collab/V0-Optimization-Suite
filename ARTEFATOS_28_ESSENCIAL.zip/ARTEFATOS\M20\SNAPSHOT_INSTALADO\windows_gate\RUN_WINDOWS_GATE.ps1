$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'MSVC cl.exe nao encontrado. Abra Developer PowerShell/Command Prompt do Visual Studio Build Tools. O gate nao instala nada.' }
Push-Location $Here
try {
  & cl.exe /nologo /O2 /EHsc /arch:AVX2 gate_module_manager_v14.c baseline_v13.obj candidate_matches8_v14.obj /Fe:gate_module_manager_v14.exe
  if ($LASTEXITCODE -ne 0) { throw 'Falha de compilacao/link.' }
  $cpu = 0
  if ($env:V0_CPU) { $cpu = [int]$env:V0_CPU }
  .\gate_module_manager_v14.exe $cpu | Tee-Object -FilePath ("gate_cpu_{0}.txt" -f $cpu)
  if ($LASTEXITCODE -ne 0) { throw 'Gate falhou: paridade ou zero-regression nao passou.' }
  Write-Host "PASS preliminar no CPU $cpu. Em CPU hibrida, repita em pelo menos um P-core e um E-core antes de promover."
} finally { Pop-Location }

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_ultra_v8.h"
#define N (1u<<20)
#define REPS 21
static uint16_t *v,*c,*b;static uint8_t *t,*p,*o,*nib;static v0_decision_signal_v7_t*sig;static volatile uint64_t sink;
static uint64_t ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}static uint64_t rg(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return*s=x;}static int cd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}static void pin0(void){cpu_set_t x;CPU_ZERO(&x);CPU_SET(0,&x);sched_setaffinity(0,sizeof(x),&x);}
#define TIMED_FN(name,call,consume) static double name(void){uint64_t a=ns();call;uint64_t z=ns();consume;return(double)(z-a)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
TIMED_FN(v7_bias2,v0_eval_v8_bias_batch_ultra_v7_avx2_u8(v,c,b,o,N),sink+=o[777])
TIMED_FN(v8_bias2,v0_eval_v8_bias_batch_ultra_v8_avx2_u8(v,c,b,o,N),sink+=o[777])
TIMED_FN(v7_raw2,v0_eval_v8_raw_batch_ultra_avx2_u8(v,c,t,p,o,N),sink+=o[777])
TIMED_FN(v8_raw2,v0_eval_v8_raw_batch_ultra_v8_avx2_u8(v,c,t,p,o,N),sink+=o[777])
TIMED_FN(v7_pre2,sink=v0_preflight_v8_raw_count_avx2(v,c,t,p,N),(void)0)
TIMED_FN(v8_pre2,sink=v0_preflight_v8_raw_count_ultra_v8_avx2(v,c,t,p,N),(void)0)
TIMED_FN(v7_aos2,v0_eval_v8_signal_batch_ultra_v7_avx2_u8(sig,o,N),sink+=o[777])
TIMED_FN(v8_aos2,v0_eval_v8_signal_batch_ultra_v8_avx2_u8(sig,o,N),sink+=o[777])
TIMED_FN(v8_nibble,v0_eval_v8_bias_batch_ultra_v8_avx2_nibble(v,c,b,nib,N),sink+=nib[777])
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
TIMED_FN(v7_bias5,v0_eval_v8_bias_batch_ultra_v7_avx512_u8(v,c,b,o,N),sink+=o[777])
TIMED_FN(v8_bias5,v0_eval_v8_bias_batch_ultra_v8_avx512_u8(v,c,b,o,N),sink+=o[777])
TIMED_FN(v7_raw5,v0_eval_v8_raw_batch_ultra_avx512_u8(v,c,t,p,o,N),sink+=o[777])
TIMED_FN(v8_raw5,v0_eval_v8_raw_batch_ultra_v8_avx512_u8(v,c,t,p,o,N),sink+=o[777])
TIMED_FN(v7_pre5,sink=v0_preflight_v8_raw_count_avx512(v,c,t,p,N),(void)0)
TIMED_FN(v8_pre5,sink=v0_preflight_v8_raw_count_ultra_v8_avx512(v,c,t,p,N),(void)0)
TIMED_FN(v7_aos5,v0_eval_v8_signal_batch_ultra_v7_avx512_u8(sig,o,N),sink+=o[777])
TIMED_FN(v8_aos5,v0_eval_v8_signal_batch_ultra_v8_avx512_u8(sig,o,N),sink+=o[777])
TIMED_FN(v8_aospre5,sink=v0_preflight_v8_signal_count_ultra_v8_avx512(sig,N),(void)0)
#endif
#undef TIMED_FN
static void bench(const char*n,double(*f)(void)){double a[REPS];for(int i=0;i<7;i++)f();for(int i=0;i<REPS;i++)a[i]=f();qsort(a,REPS,sizeof(double),cd);printf("%-28s p50=%9.5f best=%9.5f ns/item\n",n,a[REPS/2],a[0]);}
int main(void){pin0();if(posix_memalign((void**)&v,64,N*2)||posix_memalign((void**)&c,64,N*2)||posix_memalign((void**)&b,64,N*2)||posix_memalign((void**)&t,64,N)||posix_memalign((void**)&p,64,N)||posix_memalign((void**)&o,64,N)||posix_memalign((void**)&nib,64,N/2)||posix_memalign((void**)&sig,64,N*sizeof(*sig)))return 2;uint64_t s=0x243f6a8885a308d3ULL;for(size_t i=0;i<N;i++){v[i]=(uint16_t)rg(&s);c[i]=(uint16_t)rg(&s);t[i]=(uint8_t)(rg(&s)%3u);p[i]=(uint8_t)(rg(&s)&1u);b[i]=v0_decision_v7_bias(t[i],p[i]);sig[i]=v0_decision_v7_pack(v[i],c[i],t[i],p[i]);}
#if defined(__AVX2__) || defined(_M_AVX2)
bench("V7 bias AVX2",v7_bias2);bench("V8 bias AVX2",v8_bias2);bench("V7 raw AVX2",v7_raw2);bench("V8 raw AVX2",v8_raw2);bench("V7 raw preflight AVX2",v7_pre2);bench("V8 raw preflight AVX2",v8_pre2);bench("V7 packed AoS AVX2",v7_aos2);bench("V8 packed AoS AVX2",v8_aos2);bench("V8 bias nibble AVX2",v8_nibble);
#endif
#if defined(__AVX512BW__) && defined(__AVX512VL__)
bench("V7 bias AVX512",v7_bias5);bench("V8 bias AVX512",v8_bias5);bench("V7 raw AVX512",v7_raw5);bench("V8 raw AVX512",v8_raw5);bench("V7 raw preflight AVX512",v7_pre5);bench("V8 raw preflight AVX512",v8_pre5);bench("V7 packed AoS AVX512",v7_aos5);bench("V8 packed AoS AVX512",v8_aos5);bench("V8 AoS preflight AVX512",v8_aospre5);
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

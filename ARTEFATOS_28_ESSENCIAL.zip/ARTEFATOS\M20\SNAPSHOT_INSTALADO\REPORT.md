# Artefato 20 — V0 Module Manager V13 SAFE -> V14 MATCHES8 Snapshot

## Baseline

`V0_MODULE_MANAGER_V13_SAFE` permanece a baseline oficial. Os dez entry points V13 foram recompilados pelo backend V14 e comparados individualmente: **byte-idênticos em Linux e Windows**.

V13 já está muito próxima do piso para consultas escalares; o próprio histórico rejeitou ANDN, packing e formas menores que apresentaram regressão. V14, portanto, não substitui consulta escalar alguma.

## Candidato V14

Novo fast path aditivo:

```c
uint32_t v0_mm_matches8_snapshot_v14(
    v0_module_manager_state *state,
    const v0_mm_matches8_queries *queries);
```

`queries` contém `required_on[8]` seguido de `required_off[8]`. O bit `i` do retorno é 1 quando:

`(snapshot & required_on[i]) == required_on[i] && (snapshot & required_off[i]) == 0`.

### Implementação

- uma carga de `enabled_mask`;
- `VPBROADCASTD` do snapshot;
- duas cargas `VMOVDQU` de 256 bits;
- `VPANDN` para bits ON ausentes;
- `VPAND` para bits OFF proibidos presentes;
- `VPOR + VPCMPEQD`;
- `VMOVMSKPS` produz os oito resultados;
- `VZEROUPPER` antes do retorno.

ISA: **AVX2**. Não usa AVX-512.

## Correção local

Validação direta contra `v0_mm_matches` do objeto V13 real:

- **5.000.000 batches**;
- **40.000.000 predicados individuais**;
- offsets/alinhamentos variados;
- máscaras aleatórias de 32 bits, máscara zero, overlap e casos extremos;
- **0 divergências**.

## Performance local

Comparação: oito chamadas reais de `v0_mm_matches` V13 versus uma chamada V14 para os mesmos oito predicados sobre um estado estável/snapshot comum.

5 processos independentes, 5 perfis, 4 alinhamentos e 15 rodadas por combinação:

- **1.500 medições**;
- **1.500/1.500 vitórias**;
- pior razão observada: **1,643762x**;
- mediana global: **9,838730x**;
- máximo observado: **31,264029x** — outlier de scheduling, não usar como expectativa;
- mediana V13 composta: **14,019794 ns por 8 predicados**;
- mediana V14: **1,416393 ns por 8 predicados**.

O ganho acima de 8x na mediana NÃO representa o serviço inteiro. O V14 remove sete chamadas e executa os oito predicados vetorialmente. O benchmark mede somente `matches8_snapshot`.

## Semântica de concorrência

V14 lê o estado **uma única vez**. Ele não é substituto para oito chamadas V13 se o caller quiser permitir que cada chamada observe uma atualização concorrente diferente.

Use V14 somente quando os oito predicados pertencem à mesma decisão/configuração e devem observar um snapshot comum. Fora desse domínio, V13 continua autoridade.

## Tamanho

- V14 isolado Linux: **48 B `.text`**;
- V14 isolado Windows: **48 B `.text`**;
- V13+V14 Linux: **224 B `.text`**;
- V13+V14 Windows: **240 B `.text`**;
- relocations: **0**.

## Estado

**LOCAL_PASS / WINDOWS_GATE_REQUIRED**.

Não promover automaticamente antes de confirmar no Intel/Windows alvo: AVX2+YMM, paridade, zero regressão e benefício no caller real que agrupa consultas de mesmo snapshot.

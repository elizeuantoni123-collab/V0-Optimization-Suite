#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>

typedef struct { uint32_t enabled_mask; } mm_state;
uint32_t v0_mm_matches(mm_state*, uint32_t, uint32_t);
uint32_t v0_mm_matches8_snapshot_v14(mm_state*, const uint32_t*);

static volatile uint64_t sink;
static inline uint64_t nsnow(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW,&t); return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec; }
static inline uint64_t sm64(uint64_t *x){ uint64_t z=(*x+=0x9e3779b97f4a7c15ull); z=(z^(z>>30))*0xbf58476d1ce4e5b9ull; z=(z^(z>>27))*0x94d049bb133111ebull; return z^(z>>31); }
static uint32_t ref8(uint32_t s,const uint32_t*q){ uint32_t m=0; for(int i=0;i<8;i++){uint32_t on=q[i],off=q[8+i]; uint32_t ok=(((s&on)==on)&&((s&off)==0)); m|=ok<<i;} return m; }
static uint32_t base8(mm_state* st,const uint32_t*q){ uint32_t m=0; for(int i=0;i<8;i++) m |= v0_mm_matches(st,q[i],q[8+i])<<i; return m; }

static void fillq(uint32_t*q,int profile,uint64_t*seed,uint32_t s){
 for(int i=0;i<8;i++){
   uint32_t on,off;
   if(profile==0){ on=(1u<<(i%19)); off=0; }
   else if(profile==1){ on=s & (uint32_t)sm64(seed); off=(~s)&(uint32_t)sm64(seed); }
   else if(profile==2){ on=(uint32_t)sm64(seed)&0x7ffffu; off=(uint32_t)sm64(seed)&0x7ffffu; }
   else if(profile==3){ on=0; off=(1u<<((i*3)%19)); }
   else { on=(uint32_t)sm64(seed); off=(uint32_t)sm64(seed); }
   q[i]=on; q[8+i]=off;
 }
}

static double bench_base(mm_state*st,uint32_t*q,int it){ uint64_t t0=nsnow(); uint64_t x=0; for(int i=0;i<it;i++) x+=base8(st,q); uint64_t t1=nsnow(); sink+=x; return (double)(t1-t0)/it; }
static double bench_cand(mm_state*st,uint32_t*q,int it){ uint64_t t0=nsnow(); uint64_t x=0; for(int i=0;i<it;i++) x+=v0_mm_matches8_snapshot_v14(st,q); uint64_t t1=nsnow(); sink+=x; return (double)(t1-t0)/it; }

int main(int argc,char**argv){
 int rounds=15,it=2000000; if(argc>1) rounds=atoi(argv[1]); if(argc>2) it=atoi(argv[2]);
 cpu_set_t set; CPU_ZERO(&set); CPU_SET(0,&set); sched_setaffinity(0,sizeof(set),&set);
 void*mem=NULL; if(posix_memalign(&mem,64,256)) return 2; uint8_t*raw=mem;
 printf("profile,align,round,base_ns,cand_ns,speedup,parity\n");
 uint64_t seed=0x123456789abcdef0ull;
 for(int p=0;p<5;p++) for(int alidx=0;alidx<4;alidx++){
   int align=(int[]){0,4,16,28}[alidx]; uint32_t*q=(uint32_t*)(raw+align); mm_state st={(uint32_t)sm64(&seed)&0x7ffffu}; fillq(q,p,&seed,st.enabled_mask);
   uint32_t r=ref8(st.enabled_mask,q),b=base8(&st,q),c=v0_mm_matches8_snapshot_v14(&st,q); int parity=(r==b&&b==c);
   for(int w=0;w<3;w++){bench_base(&st,q,10000);bench_cand(&st,q,10000);} 
   for(int k=0;k<rounds;k++){
     double bn,cn; if(k&1){cn=bench_cand(&st,q,it);bn=bench_base(&st,q,it);} else {bn=bench_base(&st,q,it);cn=bench_cand(&st,q,it);} 
     printf("%d,%d,%d,%.6f,%.6f,%.6f,%d\n",p,align,k,bn,cn,bn/cn,parity);
   }
 }
 fprintf(stderr,"sink=%llu\n",(unsigned long long)sink); free(mem); return 0;
}

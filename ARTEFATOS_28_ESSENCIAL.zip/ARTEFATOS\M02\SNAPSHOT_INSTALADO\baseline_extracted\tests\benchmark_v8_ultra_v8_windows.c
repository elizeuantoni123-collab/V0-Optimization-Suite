#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/v0_decision_v8_bandwidth_v8.h"
#define N (1u<<20)
#define REPS 15
static uint16_t *v,*c,*b; static uint8_t *t,*p,*o,*nib; static v0_decision_signal_v7_t *sig; static v0_decision_meta8_v8_t *meta;
static LARGE_INTEGER fq; static volatile uint64_t sink;
static uint64_t rg(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static double ns(void){LARGE_INTEGER q;QueryPerformanceCounter(&q);return(double)q.QuadPart*1e9/(double)fq.QuadPart;}
static int cmp(const void*a,const void*b2){double x=*(const double*)a,y=*(const double*)b2;return x<y?-1:x>y;}
static double v7bias(void){double a=ns();v0_eval_v8_bias_batch_ultra_v7_avx2_u8(v,c,b,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v8bias(void){double a=ns();v0_eval_v8_bias_batch_ultra_v8_avx2_u8(v,c,b,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v7raw(void){double a=ns();v0_eval_v8_raw_batch_ultra_avx2_u8(v,c,t,p,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v8raw(void){double a=ns();v0_eval_v8_raw_batch_ultra_v8_avx2_u8(v,c,t,p,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v7pre(void){double a=ns();uint64_t q=v0_preflight_v8_raw_count_avx2(v,c,t,p,N);double z=ns();sink+=q;return(z-a)/N;}
static double v8pre(void){double a=ns();uint64_t q=v0_preflight_v8_raw_count_ultra_v8_avx2(v,c,t,p,N);double z=ns();sink+=q;return(z-a)/N;}
static double v7aos(void){double a=ns();v0_eval_v8_signal_batch_ultra_v7_avx2_u8(sig,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v8aos(void){double a=ns();v0_eval_v8_signal_batch_ultra_v8_avx2_u8(sig,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static double v8nib(void){double a=ns();v0_eval_v8_bias_batch_ultra_v8_avx2_nibble(v,c,b,nib,N);double z=ns();sink+=nib[777];return(z-a)/N;}
static double v8meta(void){double a=ns();v0_eval_v8_meta8_batch_avx2_u8(v,c,meta,o,N);double z=ns();sink+=o[777];return(z-a)/N;}
static void be(const char*n,double(*f)(void)){double x[REPS];int i;for(i=0;i<5;i++)f();for(i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmp);printf("%-30s p50=%9.4f ns/item best=%9.4f\n",n,x[REPS/2],x[0]);}
int main(void){size_t i;uint64_t r=0x9e3779b97f4a7c15ULL;QueryPerformanceFrequency(&fq);SetThreadAffinityMask(GetCurrentThread(),1);
 v=(uint16_t*)_aligned_malloc(N*2,64);c=(uint16_t*)_aligned_malloc(N*2,64);b=(uint16_t*)_aligned_malloc(N*2,64);t=(uint8_t*)_aligned_malloc(N,64);p=(uint8_t*)_aligned_malloc(N,64);o=(uint8_t*)_aligned_malloc(N,64);nib=(uint8_t*)_aligned_malloc(N/2+64,64);sig=(v0_decision_signal_v7_t*)_aligned_malloc(N*sizeof(*sig),64);meta=(v0_decision_meta8_v8_t*)_aligned_malloc(N,64);
 if(!v||!c||!b||!t||!p||!o||!nib||!sig||!meta)return 2;
 for(i=0;i<N;i++){v[i]=(uint16_t)rg(&r);c[i]=(uint16_t)rg(&r);t[i]=(uint8_t)(rg(&r)%3u);p[i]=(uint8_t)(rg(&r)&1u);b[i]=v0_decision_v7_bias(t[i],p[i]);meta[i]=v0_decision_v8_meta8(t[i],p[i]);sig[i]=v0_decision_v7_pack(v[i],c[i],t[i],p[i]);}
 puts("V0 Decision V8 ULTRA V8 - Windows AVX2 paired benchmark");printf("N=%u, p50 of %d timed runs; batch throughput, not single-call latency\n",N,REPS);
 be("V7 bias AVX2",v7bias);be("V8 bias AVX2",v8bias);be("V7 raw AVX2",v7raw);be("V8 raw AVX2",v8raw);be("V7 raw preflight",v7pre);be("V8 raw preflight",v8pre);be("V7 packed AoS",v7aos);be("V8 packed AoS",v8aos);be("V8 nibble output",v8nib);be("V8 meta8 optional",v8meta);
 printf("sink=%llu\n",(unsigned long long)sink);return 0;}

# Artefato 22 — Trusted Lookup

Resultado: KEEP_BASELINE.

Inclui a baseline strict e as evidências de duas linhas novas rejeitadas por regressão de desempenho: perfect hash direto e AVX2 batch.

Nada é promovido automaticamente.

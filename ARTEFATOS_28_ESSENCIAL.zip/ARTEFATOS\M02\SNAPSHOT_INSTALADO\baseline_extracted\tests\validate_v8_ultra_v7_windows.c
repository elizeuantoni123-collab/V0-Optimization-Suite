#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v8_extreme.h"

#define CHUNK 4096u
#define TOTAL 10000000u

static uint64_t rng64(uint64_t *s) {
    uint64_t x=*s; x^=x<<13; x^=x>>7; x^=x<<17; return *s=x;
}
static int check_bytes(const uint16_t *v,const uint16_t *c,const uint16_t *b,
                       const v0_decision_signal_v7_t *sig,const uint8_t *out,size_t n) {
    for(size_t i=0;i<n;i++) {
        uint8_t ref=(uint8_t)v0_eval_v8_signal_ultra_inline(sig+i);
        if(out[i]!=ref || (uint8_t)v0_eval_v8_bias_ultra_inline(v[i],c[i],b[i])!=ref) {
            printf("DIVERGENCE i=%zu got=%u ref=%u bias=%u\n",i,(unsigned)out[i],(unsigned)ref,(unsigned)b[i]);
            return 0;
        }
    }
    return 1;
}
int main(void) {
    uint16_t *v=(uint16_t*)_aligned_malloc(CHUNK*sizeof(uint16_t),64);
    uint16_t *c=(uint16_t*)_aligned_malloc(CHUNK*sizeof(uint16_t),64);
    uint16_t *b=(uint16_t*)_aligned_malloc(CHUNK*sizeof(uint16_t),64);
    uint8_t *o=(uint8_t*)_aligned_malloc(CHUNK,64);
    v0_decision_signal_v7_t *s=(v0_decision_signal_v7_t*)_aligned_malloc(CHUNK*sizeof(*s),64);
    if(!v||!c||!b||!o||!s) return 2;
    uint64_t r=0xD1B54A32D192ED03ULL;
    unsigned done=0;
    while(done<TOTAL) {
        size_t n=(TOTAL-done)>CHUNK?CHUNK:(TOTAL-done);
        for(size_t i=0;i<n;i++) {
            uint8_t t=(uint8_t)(rng64(&r)%3u), p=(uint8_t)(rng64(&r)&1u);
            v[i]=(uint16_t)rng64(&r); c[i]=(uint16_t)rng64(&r);
            b[i]=v0_decision_v7_bias(t,p); s[i]=v0_decision_v7_pack(v[i],c[i],t,p);
        }
#if defined(__AVX2__) || defined(_M_AVX2)
        v0_eval_v8_bias_batch_ultra_v7_avx2_u8(v,c,b,o,n);
        if(!check_bytes(v,c,b,s,o,n)) return 3;
        v0_eval_v8_signal_batch_ultra_v7_avx2_u8(s,o,n);
        if(!check_bytes(v,c,b,s,o,n)) return 4;
#else
#error AVX2 build required
#endif
        done+=(unsigned)n;
    }
    for(size_t n=0;n<=257;n++) {
        for(size_t i=0;i<n;i++) {
            uint8_t t=(uint8_t)(rng64(&r)%3u), p=(uint8_t)(rng64(&r)&1u);
            v[i]=(uint16_t)rng64(&r); c[i]=(uint16_t)rng64(&r);
            b[i]=v0_decision_v7_bias(t,p); s[i]=v0_decision_v7_pack(v[i],c[i],t,p);
        }
        v0_eval_v8_bias_batch_ultra_v7_avx2_u8(v,c,b,o,n);
        if(!check_bytes(v,c,b,s,o,n)) return 5;
        v0_eval_v8_signal_batch_ultra_v7_avx2_u8(s,o,n);
        if(!check_bytes(v,c,b,s,o,n)) return 6;
    }
    printf("V0 Decision V8 ULTRA V7 Windows validation PASS\n");
    printf("random signals: %u, divergences: 0\n",TOTAL);
    printf("tails 0..257: PASS\n");
    printf("bias-fused AVX2 + packed-signal AVX2: PASS\n");
    _aligned_free(v);_aligned_free(c);_aligned_free(b);_aligned_free(o);_aligned_free(s);
    return 0;
}

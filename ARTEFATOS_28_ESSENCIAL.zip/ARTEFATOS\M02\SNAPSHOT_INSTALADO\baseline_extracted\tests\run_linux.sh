#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GLOBAL_OBJ="${1:-}"
cc -O3 -march=native -I"$ROOT/include" "$ROOT/tests/validate_controller_v8.c" -o "$ROOT/build/linux/validate_controller_v8"
"$ROOT/build/linux/validate_controller_v8"
cc -O3 -march=native -I"$ROOT/include" "$ROOT/tests/validate_core_v8.c" "$ROOT/reference/v6/v0_decision_v6.o" "$ROOT/build/linux/v0_decision_v7.o" -o "$ROOT/build/linux/validate_core_v8"
"$ROOT/build/linux/validate_core_v8"
if [[ -n "$GLOBAL_OBJ" ]]; then
  cc -O3 -march=native -I"$ROOT/include" "$ROOT/tests/validate_global_v8.c" "$ROOT/build/linux/v0_decision_v7.o" "$GLOBAL_OBJ" -o "$ROOT/build/linux/validate_global_v8"
  "$ROOT/build/linux/validate_global_v8"
  cc -O3 -march=native -I"$ROOT/include" "$ROOT/tests/benchmark_v8.c" "$ROOT/build/linux/v0_decision_v7.o" "$GLOBAL_OBJ" -o "$ROOT/build/linux/benchmark_v8"
  "$ROOT/build/linux/benchmark_v8"
fi

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <time.h>
typedef struct {uint32_t id,score,key,valid;} rec;
extern uint32_t v0_semantic_valid_trusted(const rec*);
extern uint32_t v0_semantic_valid4_mask(const rec*);
extern uint32_t v0_semantic_valid8_mask(const rec*);
static volatile uint32_t sink;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static double run4_base(const rec*a,uint32_t groups){uint32_t x=0;uint64_t s=ns();for(uint32_t i=0;i<groups;i++){const rec*p=&a[(i&511u)*8u];uint32_t m=0;for(int j=0;j<4;j++)m|=v0_semantic_valid_trusted(p+j)<<j;x^=m+i;}uint64_t e=ns();sink=x;return(double)(e-s)/groups;}
static double run4_v5(const rec*a,uint32_t groups){uint32_t x=0;uint64_t s=ns();for(uint32_t i=0;i<groups;i++){const rec*p=&a[(i&511u)*8u];x^=v0_semantic_valid4_mask(p)+i;}uint64_t e=ns();sink=x;return(double)(e-s)/groups;}
static double run8_base(const rec*a,uint32_t groups){uint32_t x=0;uint64_t s=ns();for(uint32_t i=0;i<groups;i++){const rec*p=&a[(i&511u)*8u];uint32_t m=0;for(int j=0;j<8;j++)m|=v0_semantic_valid_trusted(p+j)<<j;x^=m+i;}uint64_t e=ns();sink=x;return(double)(e-s)/groups;}
static double run8_v5(const rec*a,uint32_t groups){uint32_t x=0;uint64_t s=ns();for(uint32_t i=0;i<groups;i++){const rec*p=&a[(i&511u)*8u];x^=v0_semantic_valid8_mask(p)+i;}uint64_t e=ns();sink=x;return(double)(e-s)/groups;}
static void pair(const char*n,double(*b)(const rec*,uint32_t),double(*c)(const rec*,uint32_t),const rec*a,uint32_t N,int flip,int r){double x,y;if(!flip){x=b(a,N);y=c(a,N);}else{y=c(a,N);x=b(a,N);}printf("%s %02d %.9f %.9f %.6f\n",n,r,x,y,x/y);}
int main(void){static rec a[4096];for(uint32_t i=0;i<4096;i++)a[i]=(rec){i,0xabcdef01u-i,0x12345678u+i,(i*13u+7u)&1u};const uint32_t G=10000000u;for(int r=0;r<15;r++){pair("valid4",run4_base,run4_v5,a,G,r&1,r);pair("valid8",run8_base,run8_v5,a,G,r&1,r);}return sink==0xdeadbeef;}

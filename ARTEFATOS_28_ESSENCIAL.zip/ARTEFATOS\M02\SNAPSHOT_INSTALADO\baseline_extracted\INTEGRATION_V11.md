# V0 Decision V8 ULTRA V11 — Integration

V11 is additive over V10. Do not remove or rewrite V10 fallbacks.

## Recommended use

- Raw one-shot: keep V10 raw dispatch.
- One-shot preflight: keep V9 preflight dispatch inherited through V10.
- Reused gate16, vector batch: V10/V11 vector body is unchanged.
- Scalar gate16 with unpredictable inputs: use `v0_eval_gate16_v11_scalar_lut_inline`.
- Standard u8 vector batches and tails: keep the inherited V10 API. A V11 automatic short-batch replacement was tested and rejected because it did not win consistently.
- Large write-only gate16 output where compact representation is accepted: use `v0_eval_gate16_batch_v11_stream_avx2_nibble`.

Nibble format is lossless: low nibble = even item, high nibble = odd item. Values remain exactly 0/4/5/6/7.

# V0 Decision V8 ULTRA V8 — Technical Report

## Status

**Promoted as an additive exact optimization layer.** No V7/V6 fallback was replaced.

## Correctness

- Native/AVX-512 validation: 21,005,735 checked, 0 divergences.
- AVX2-only validation: 21,005,735 checked, 0 divergences.
- Directed boundaries and tails 0..257 included.
- V7 raw regression: 20,000,000 random signals, 0 divergences.
- V7 packed-AoS regression: 20,000,768 signals, 0 divergences.
- Inherited V7 files: 154 checked by SHA-256, 154 identical, 0 missing, 0 mismatches.

## Main exact transformations

### Saturating bias-fused evaluation

For `h=cost>>1`, Decision only distinguishes score boundaries through 384. Using unsigned saturating `s = sat_u16(value+bias)` and `d = sat_u16(s-h)` is exact: if the mathematical sum exceeds 65535, even the maximum `h` leaves a score far above the top boundary.

### Pinned invariant

Legal pinned bias is 33151. The minimum possible pinned score is `0 - 32767 + 33151 = 384`, exactly the highest threshold. Therefore pinned lanes can be forced directly to state 7 without approximation.

### Compact outputs

Packed results are only 0/4/5/6/7. Nibble output stores two exact states per byte. AVX-512 3-bit bitplanes store the same information in three masks per 32 decisions. Both were decode-validated item by item.

## Paired benchmark — median p50 across 9 process runs

| Path | V7 | V8 | Change |
|---|---:|---:|---:|
| bias AVX2 | 0.09072 | 0.07124 | -21.47% |
| raw AVX2 | 0.12011 | 0.10351 | -13.82% |
| raw preflight AVX2 | 0.11205 | 0.07082 | -36.80% |
| packed AoS AVX2 | 0.31709 | 0.23261 | -26.64% |
| bias AVX-512 | 0.08952 | 0.07093 | -20.77% |
| raw AVX-512 | 0.11073 | 0.07930 | -28.38% |
| raw preflight AVX-512 | 0.08710 | 0.06127 | -29.66% |
| packed AoS AVX-512 | 0.16667 | 0.12516 | -24.91% |

Absolute timings are environment-sensitive. These are amortized batch throughput values, not independent-call latency.

## Large-output benchmark — median across 5 process runs

- byte AVX2: 0.25496 ns/item
- nibble AVX2: 0.24132 ns/item
- nibble non-temporal streaming: **0.21810 ns/item**
- byte AVX-512: 0.25056 ns/item
- 3-bit bitplanes: 0.23331 ns/item

## Optional meta8

`meta8` reduces the temperature/pinned state from two-byte bias to one byte. It is exact for Decision but intentionally optional. It was slower in the hot-cache test and clearly faster in the measured large native/AVX-512 workload. It must therefore be selected by workload/target benchmark, not globally promoted over bias16.

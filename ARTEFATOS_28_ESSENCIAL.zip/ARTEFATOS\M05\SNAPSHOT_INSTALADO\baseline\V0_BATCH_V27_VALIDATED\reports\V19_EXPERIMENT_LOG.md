# V19 optimization experiment log

Only V19 is promoted.

- V15 counted single-YMM: rejected; correctness passed but performance regressed at several sizes.
- V16 AVX-512: rejected as universal replacement; strong midrange gains but mixed vs V18/V19 and regressions on long sustained plans.
- V17 dual-YMM: rejected; tail=256 weakness.
- V18 dual-YMM tail fix: correct and fast, used as stepping stone.
- V19 counted dual-YMM: promoted in bounded domain.
- V20 register-direct tail: rejected; smaller `.text`, slower hot path.

This keeps the project rule intact: smaller code alone is not accepted if speed drops.

#pragma once
#include <ntddk.h>

#ifdef __cplusplus
extern "C" {
#endif

// Compile one 4 KiB physical page into the current pass-through V0 policy.
void V0PolicyCompilePhysicalPage(ULONG64 physical_address);

// Batch version used by large EPT leaves.  It preserves the scalar policy's
// page count/checksum while avoiding one function call per 4 KiB page.
void V0PolicyCompilePhysicalRange(ULONG64 physical_address, ULONG64 page_count);

void V0PolicyLogSummary(void);

#ifdef __cplusplus
}
#endif

# V0 Shared-State Cache V1 SAFE — Validation Report

Data: 2026-09-25

## Decisão de promoção

**V1 SAFE promovida como baseline universal.**

Não existe uma versão anterior dedicada do `v0_shared_state_cache` para preservar byte a byte; o estado histórico era apenas reutilização parcial de `encode_state`. Assim, V1 é a primeira baseline nativa isolada formalmente validada.

## Correção

V1 vs referência independente:
- 6.600.000 operações aleatórias;
- 8 capacidades, de 1 a 4096 slots;
- 0 divergências;
- canários PASS;
- colisões forçadas sem falso hit;
- IDs de borda PASS.

Candidatos posteriores:
- V2: 8.000.000 comparações, 0 divergências;
- V3: 8.000.000 operações, 0 divergências;
- V4: 8.000.000 operações-base + misses adicionais, 0 divergências.

Nenhum candidato foi promovido por falhar no gate de desempenho.

## Desempenho V1 standalone

AMD EPYC 9V74, CPU fixa, 11 amostras por cenário, 3 processos independentes. Mediana por processo e depois mediana entre processos.

| Capacidade | Cenário | ns/chamada | Mops/s |
|---:|---|---:|---:|
| 64 | collision_miss | 1.673547 | 597.533 |
| 64 | empty_miss | 1.936618 | 516.364 |
| 64 | hit | 1.732714 | 577.129 |
| 64 | mixed80 | 1.815377 | 550.850 |
| 256 | collision_miss | 1.713697 | 583.534 |
| 256 | empty_miss | 1.777792 | 562.496 |
| 256 | hit | 1.707678 | 585.590 |
| 256 | mixed80 | 1.808017 | 553.092 |
| 1024 | collision_miss | 1.693928 | 590.344 |
| 1024 | empty_miss | 1.782829 | 560.906 |
| 1024 | hit | 1.722830 | 580.440 |
| 1024 | mixed80 | 1.746986 | 572.414 |
| 4096 | collision_miss | 1.667278 | 599.780 |
| 4096 | empty_miss | 1.942207 | 514.878 |
| 4096 | hit | 1.685995 | 593.122 |
| 4096 | mixed80 | 1.741588 | 574.189 |

Mediana geral: **1.737151 ns/chamada** (~575.655 Mops/s no loop medido).

## Gate de candidatos

### V2 fixed/direct-slots
- correção: PASS;
- benchmark final fixed CPU: 12/16 wins pela mediana;
- wins em todas as 5 execuções: 5/16;
- mínimo speedup: 0.986404x;
- mediana speedup: 1.022313x;
- máximo: 1.152506x;
- decisão: **REJEITADA como substituição universal**.

### V3 direct compare branch
- correção: PASS;
- 0/32 wins pela mediana;
- mediana speedup vs V1: 0.835651x;
- decisão: **REJEITADA**.

### V4 CMOV branchless
- correção: PASS;
- 1/32 wins pela mediana;
- 0/32 wins em todas as 3 execuções;
- mediana speedup vs V1: 0.851361x;
- decisão: **REJEITADA**.

## Isolamento

Varredura do source/compiler promovido:
- `V0Global`: nenhuma referência;
- `EPT`: nenhuma referência;
- `VMX`: nenhuma referência;
- `Shared-EPT`: nenhuma referência;
- `HyperPlatform`: nenhuma referência;
- `MTRR`: nenhuma referência.

Objeto Linux: nenhum símbolo externo/undefined.

## Limites

- V1 não é cache semântico.
- V1 não gera `state_id`; o contrato de identidade exata é responsabilidade do host.
- V1 não faz lifetime management do ponteiro.
- V1 não é thread-safe para múltiplos writers sem sincronização externa.
- O runtime Windows foi validado estruturalmente por geração COFF; o benchmark executado neste pacote foi Linux.

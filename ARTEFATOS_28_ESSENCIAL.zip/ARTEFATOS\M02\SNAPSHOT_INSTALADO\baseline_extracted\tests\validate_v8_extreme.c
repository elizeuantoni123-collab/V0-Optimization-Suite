#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_fast.h"
#include "../include/v0_decision_v8_extreme.h"

static uint64_t rng64(uint64_t *s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}

static int check_score(int32_t score) {
    const int16_t q = v0_decision_v8_q6_from_score(score);
    const uint32_t old_pre = v0_preflight_v8_inline(score);
    const uint32_t old_dec = v0_decide_v8_inline(score);
    const uint32_t old_eval = v0_eval_v8_inline(score);
    const uint32_t qpre = v0_preflight_v0l_v8_q6((uint32_t)(int32_t)q);
    const uint32_t qdec = v0_decide_v0l_v8_q6((uint32_t)(int32_t)q);
    const uint32_t qeval = v0_eval_v0l_v8_q6((uint32_t)(int32_t)q);
    const uint32_t qinline = v0_eval_v8_q6_extreme_inline(q);
    if (qpre!=old_pre || qdec!=old_dec || qeval!=old_eval || qinline!=old_eval) {
        fprintf(stderr,"score mismatch s=%d q=%d old=%u/%u/%u q=%u/%u/%u inline=%u\n",
                score,(int)q,old_pre,old_dec,old_eval,qpre,qdec,qeval,qinline);
        return 1;
    }
    return 0;
}

int main(void){
    uint64_t checked=0, random_checked=0;
    for(int32_t s=-32767;s<=98878;s++){ if(check_score(s)) return 2; checked++; }

    enum { N=131646 };
    int16_t *q=(int16_t*)malloc(N*sizeof(*q));
    int32_t *score=(int32_t*)malloc(N*sizeof(*score));
    uint8_t *out=(uint8_t*)malloc(N);
    if(!q||!score||!out) return 3;
    for(int i=0;i<N;i++){ score[i]=-32767+i; q[i]=v0_decision_v8_q6_from_score(score[i]); }

    memset(out,0,N); v0_eval_v8_q6_batch_scalar_u8(q,out,N);
    for(int i=0;i<N;i++) if(out[i]!=(uint8_t)v0_eval_v8_inline(score[i])) {fprintf(stderr,"scalar batch mismatch %d\n",i);return 4;}
#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__) || defined(_M_IX86)
    memset(out,0,N); v0_eval_v8_q6_batch_sse2_u8(q,out,N);
    for(int i=0;i<N;i++) if(out[i]!=(uint8_t)v0_eval_v8_inline(score[i])) {fprintf(stderr,"sse2 mismatch %d\n",i);return 5;}
#if defined(__AVX2__) || defined(_M_AVX2)
    memset(out,0,N); v0_eval_v8_q6_batch_avx2_u8(q,out,N);
    for(int i=0;i<N;i++) if(out[i]!=(uint8_t)v0_eval_v8_inline(score[i])) {fprintf(stderr,"avx2 q6 mismatch %d\n",i);return 6;}
    memset(out,0,N); v0_eval_v8_score_batch_avx2_u8(score,out,N);
    for(int i=0;i<N;i++) if(out[i]!=(uint8_t)v0_eval_v8_inline(score[i])) {fprintf(stderr,"avx2 score mismatch %d\n",i);return 7;}
#endif
#endif

    uint64_t st=0xD1CEB00C12345678ULL;
    for(uint32_t i=0;i<20000000u;i++){
        uint16_t value=(uint16_t)rng64(&st), cost=(uint16_t)rng64(&st);
        uint8_t temp=(uint8_t)(rng64(&st)%3u), pin=(uint8_t)(rng64(&st)&1u);
        v0_decision_signal_v7_t sig=v0_decision_v7_pack(value,cost,temp,pin);
        int32_t sc=v0_decision_v8_score(value,cost,temp,pin);
        int16_t qq=v0_decision_v8_q6_from_score(sc);
        uint32_t p7=v0_preflight_v0l_v7(&sig), d7=v0_decide_v0l_v7(&sig);
        uint32_t ev=v0_eval_v8_q6_extreme_inline(qq);
        if(v0_eval_v8_preflight(ev)!=p7 || v0_eval_v8_decision(ev)!=d7){
            fprintf(stderr,"random mismatch i=%u\n",i); return 8;
        }
        random_checked++;
    }

    printf("V8 EXTREME validation PASS\n");
    printf("exhaustive_scores=%llu\n",(unsigned long long)checked);
    printf("random_raw=%llu\n",(unsigned long long)random_checked);
    printf("q6_domain=[-512,1544], storage=16-bit\n");
    printf("divergences=0\n");
    return 0;
}

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BASE="$ROOT/baseline/V0_BATCH_V27_VALIDATED"
"$BASE/tests/test_v27"
"$BASE/tests/test_all"

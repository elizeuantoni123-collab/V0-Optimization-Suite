#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<25)
#define REPS 7
static int16_t*q;static uint8_t*out;static volatile uint64_t sink;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static void pin0(void){cpu_set_t c;CPU_ZERO(&c);CPU_SET(0,&c);sched_setaffinity(0,sizeof(c),&c);}
static double normal(void){uint64_t t=ns();v0_eval_v8_q6_batch_ultra_avx2_u8(q,out,N);uint64_t e=ns();sink+=out[777];return(double)(e-t)/N;}
static double stream(void){uint64_t t=ns();v0_eval_v8_q6_batch_ultra_stream_avx2_u8(q,out,N);uint64_t e=ns();sink+=out[777];return(double)(e-t)/N;}
static void b(const char*n,double(*f)(void)){double x[REPS];for(int i=0;i<2;i++)f();for(int i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmpd);printf("%-20s p50=%.4f best=%.4f ns/decision\n",n,x[REPS/2],x[0]);}
int main(){pin0();q=aligned_alloc(64,N*2);out=aligned_alloc(64,N);if(!q||!out)return 2;for(size_t i=0;i<N;i++)q[i]=(int16_t)((int)(i%2057)-512);b("normal cached store",normal);b("streaming store",stream);printf("sink=%llu\n",(unsigned long long)sink);return 0;}

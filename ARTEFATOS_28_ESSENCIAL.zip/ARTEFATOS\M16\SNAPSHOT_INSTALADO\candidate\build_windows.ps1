$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
python compiler\v0lc_x64_tier_batch8.py src\v0_tier_batch8_v12.v0l build\windows\v0_tier_batch8_v12.obj --target windows
Get-FileHash build\windows\v0_tier_batch8_v12.obj -Algorithm SHA256

$ErrorActionPreference = "Stop"
$ServiceName = "V0DecisionV8"
$svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if (-not $svc) {
    Write-Host "V0 Decision V8: NAO INSTALADO" -ForegroundColor Red
    exit 1
}
Write-Host "Servico: $($svc.Status)" -ForegroundColor $(if ($svc.Status -eq 'Running') {'Green'} else {'Yellow'})
$cfg = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'"
Write-Host "StartMode: $($cfg.StartMode)"
Write-Host "Path: $($cfg.PathName)"
if ($svc.Status -eq 'Running') {
    try {
        $reply = & (Join-Path $PSScriptRoot "CLIENTE_DECISION_V8.ps1") -Command "STATUS" -TimeoutMs 2000
        Write-Host "Host: $reply"
    } catch {
        Write-Host "Host residente, mas pipe sem resposta: $($_.Exception.Message)" -ForegroundColor Yellow
        exit 2
    }
}

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_batch_accel.h"
static volatile uint64_t sink; static uint32_t rs=0x516f2d39u;
static uint32_t xr(void){rs^=rs<<13;rs^=rs>>17;rs^=rs<<5;return rs;}
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}typedef uint32_t(*F)(v0_batch_span*,uint32_t);
static uint64_t run(F f,v0_batch_span*b,uint32_t n,uint32_t reps){uint64_t s=0,t=ns();for(uint32_t r=0;r<reps;r++){uint32_t k=f(b,n);s+=k;if(k)s+=b[k-1].start+b[k-1].count;}uint64_t e=ns();sink+=s;return e-t;}
static void pair(const char*name,F a,F b,uint32_t n,uint32_t reps){uint32_t k=n?((n-1u)>>6)+1u:0u;v0_batch_span*x=aligned_alloc(64,(size_t)(k+8)*8u),*y=aligned_alloc(64,(size_t)(k+8)*8u);double A[21],B[21];int wins=0;for(int r=0;r<21;r++){uint64_t p,q;if(xr()&1){q=run(b,y,n,reps);p=run(a,x,n,reps);}else{p=run(a,x,n,reps);q=run(b,y,n,reps);}A[r]=(double)p/reps;B[r]=(double)q/reps;if(q<=p)wins++;}qsort(A,21,sizeof(double),cmpd);qsort(B,21,sizeof(double),cmpd);printf("%s items=%u base=%.3f ns cand=%.3f ns speedup=%.3fx wins=%d/21\n",name,n,A[10],B[10],A[10]/B[10],wins);free(x);free(y);}
int main(void){
    pair("small4",v0_batch_plan64,v0_batch_plan64_small4,64,1000000);
    pair("small4",v0_batch_plan64,v0_batch_plan64_small4,128,1000000);
    pair("small4",v0_batch_plan64,v0_batch_plan64_small4,192,1000000);
    pair("small4",v0_batch_plan64,v0_batch_plan64_small4,256,1000000);
#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
    __builtin_cpu_init();
    if(__builtin_cpu_supports("avx2")){
        pair("avx2-v14",v0_batch_plan64x4,v0_batch_plan64_avx2_v14,4096,200000);
        pair("avx2-v14",v0_batch_plan64x4,v0_batch_plan64_avx2_v14,65536,20000);
        pair("avx2-v14",v0_batch_plan64x4,v0_batch_plan64_avx2_v14,1048576,1000);
    }
#endif
    fprintf(stderr,"sink=%llu\n",(unsigned long long)sink);return 0;
}

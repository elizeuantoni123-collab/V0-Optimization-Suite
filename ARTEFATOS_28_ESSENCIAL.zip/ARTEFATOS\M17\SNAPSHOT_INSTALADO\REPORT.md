# Artefato 17 — V0 Remap V19 SAFE -> V22 SIMD APPLY4 Squeeze

## Status
**LOCAL_PASS / WINDOWS_GATE_REQUIRED**

The promoted V19 package remains the production baseline until the target Intel/Windows gate passes.

## Baseline preservation
- Original archive SHA-256: `33928562d0580f46fed73bd3f353f8915b09487902346371f0a1891fd6d32bb1`
- V19 Linux batch4 object SHA-256: `dc0442909cd1628d9b4297c5bcd611692d20f6dfec90ca491333464e33ee0707`
- V1 SAFE, V11 PRECHECKED and V19 BATCH4 are included unchanged under `baseline/`.
- V0 Global / EPT / hypervisor / drivers are untouched.

## New candidate
Only the **prechecked apply4** path changes.

V19 snapshots target/version/checksum with three scalar loads and three scalar stores per lane. V22 adds one V0L backend primitive, `copy16`, emitted as two unaligned-safe SSE2 `MOVDQU` instructions. The 16-byte store covers rollback_target/rollback_version/rollback_checksum and temporarily overwrites guard; guard is recomputed later in the same lane exactly as in V19.

The source removes the dead scalar snapshot loads. No validation/precondition is skipped.

- V22 Linux object SHA-256: `55894b064a5cd025bc4baf162f2f25fe968dd692c224baabbfe6ae80c21d4187`
- V22 Windows object SHA-256: `f239392f021249d1a43b5c24611cf532db3fc0d95f7f166510e21c711769b6ee`
- SSE2 only; no AVX-512.
- Linux apply4 size: V19 273 B -> V22 247 B.
- Windows apply4 size: V19 325 B -> V22 287 B.
- rollback dispatch remains **V19**, not V22.

## Correctness
Differential against four scalar V11 calls:
- **420,000,000 checks**
- **0 divergences**

The extended V22 compiler recompiles the original V19 source byte-identically when `copy16` is not used.

## Final local performance gate — V22 APPLY4 vs promoted V19 APPLY4
Same total work as the V19 promotion gate: 2,097,152 descriptors per measured run.

Coverage: 7 independent processes x 3 working sets (256/4096/65536) x 3 offsets (0/4/16) x 2 A/B orders = **126 paired medians**.

- wins: **126/126**
- minimum: **1.051308x**
- median: **1.149642x**
- maximum: **1.260852x**

By working set:
- 256: 42/42 wins; median 1.178262x; min 1.068416x
- 4096: 42/42 wins; median 1.145103x; min 1.051308x
- 65536: 42/42 wins; median 1.145672x; min 1.071341x

## Rejected candidates
- V21 constant hoist: correct, but median ~1.000x and regressions down to 0.930203x.
- V23 SIMD + constant hoist: smaller but 37/54 wins only, minimum 0.925229x. Rejected.

## Candidate dispatch
V1 universal and V11 scalar remain unchanged. Complete prechecked groups of four APPLY operations may use V22 after Windows validation. ROLLBACK groups remain V19. Tails 1..3 remain V11.

## Promotion requirement
Promote V22 only if the included Windows QPC gate on the target Intel system has exact correctness, no crash, and no relevant paired regression. The gate does not install a service or modify the OS.

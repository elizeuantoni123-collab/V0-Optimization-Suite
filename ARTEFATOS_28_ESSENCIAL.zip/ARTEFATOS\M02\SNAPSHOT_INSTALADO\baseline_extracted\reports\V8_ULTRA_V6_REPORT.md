# V0 Decision V8 ULTRA V6 — Technical Report

## Status

**Promoted candidate: exact speed-only optimization.** No Decision threshold, controller rule, or output mapping was changed.

## Correctness

Final validation (`reports/V8_ULTRA_VALIDATION_FINAL.txt`):

- exhaustive valid score domain: **131,646 cases**;
- random raw V7 signals: **20,000,000 cases**;
- Q6 hot LUT, raw scalar, packed inline, native V0L packed evaluator, AVX2 raw batch/stream and AVX-512 raw batch/stream were checked against the reference where applicable;
- **divergences: 0**.

## Main optimizations

1. **Biased direct Q6 LUT** — exact 2,057-byte table indexed by signed Q6; removes scalar threshold reconstruction and the per-loop offset addition.
2. **16-bit raw AVX2 derivation** — avoids 32-bit widening and evaluates 16 raw signals per arithmetic vector.
3. **AVX-512BW/VL optional path** — 32 raw signals/vector with k-mask corrections.
4. **Packed-signal inline evaluator** — avoids two V7 native calls and the fused-object call overhead when integrating in-process.
5. **Non-temporal large-batch stores** — optional write-only paths reduce output cache pollution.
6. **Native fused V0L signal kernel** — one stable ABI call returns packed preflight+decision.
7. **Preflight-only raw scan** — exact AVX2/AVX-512 mask/count APIs skip tier materialization when the caller only needs execute/drop.

## Paired benchmark — medians of 9 process runs

Environment: Linux x86-64, GCC 14.2.0, `-O3 -march=native`, AMD EPYC 9V74 virtualized host, one pinned benchmark thread.

| Test | Baseline | V6 | Speedup | Latency reduction |
|---|---:|---:|---:|---:|
| Q6 scalar | V5 1.3967 ns | **0.3111 ns** | **4.49x** | **77.7%** |
| Raw scalar | V5 2.0883 ns | **0.8904 ns** | **2.35x** | **57.4%** |
| Packed signal | V7 pre+decide 3.0742 ns | **0.8148 ns** | **3.77x** | **73.5%** |
| Q6 AVX2 batch | V5 0.0500 ns/item | **0.0298 ns/item** | **1.68x** | **40.4%** |
| Raw AVX2 batch | V6 raw scalar 0.8904 ns | **0.1199 ns/item** | **7.43x** | **86.5%** |
| Raw AVX-512 batch | AVX2 0.1199 ns/item | **0.1106 ns/item** | **1.08x** | **7.8%** |

The AVX2/AVX-512 figures are amortized batch throughput, not single-request latency.

Preflight-only raw counts: AVX2 **0.1119 ns/item**; AVX-512 **0.0873 ns/item** (~11.45 billion items/s amortized on this host).

For context, V5 raw scalar itself was 2.0883 ns; V6 raw AVX2 batch is ~17.4x lower per item when work is available in batch.

## Large write-only batch

`N = 33,554,432` raw decisions:

| Path | Cached output | Streaming output | Reduction |
|---|---:|---:|---:|
| AVX2 | 0.2809 ns/item | **0.2343 ns/item** | **16.6%** |
| AVX-512 | 0.2566 ns/item | **0.2290 ns/item** | **10.8%** |

## Rejected experiments

The following were tested and **not promoted** because they were slower, unsafe, or not consistently better:

- BMI2/PEXT preflight-mask variant;
- alternate arithmetic raw-Q6 scalar formula;
- 16-bit bias LUT (slower than the existing 32-bit hot bias table);
- Q6 AVX-512 path (no consistent gain over the AVX2 Q6 batch);
- packed-meta raw SIMD input (extra decode cost outweighed the saved byte load);
- folding the negative Q6 table offset into an unsigned native V0L indexed load without sign extension (rejected as unsafe);
- extra-aggressive controller probe/window changes (not promoted because they could change adaptation quality).

## Scope

V6 optimizes Decision only. V0 Global is not modified. Absolute timing depends on hardware/compiler/cache state; correctness validation is independent of those timings.

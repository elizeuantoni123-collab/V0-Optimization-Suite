# Candidate dispatch after V22 Windows gate

```text
untrusted / generic / uncertain state
    -> V1 SAFE

prechecked scalar
    -> V11 SAFE PRECHECKED

complete group of 4 PRECHECKED APPLY descriptors + requests
    -> V22 SIMD APPLY4 candidate

complete group of 4 PRECHECKED ROLLBACK descriptors + requests
    -> V19 SAFE ROLLBACK4

tail 1..3
    -> V11 SAFE PRECHECKED per descriptor
```

V22 has exactly the same preconditions as V19 apply4. It does not validate or weaken them.

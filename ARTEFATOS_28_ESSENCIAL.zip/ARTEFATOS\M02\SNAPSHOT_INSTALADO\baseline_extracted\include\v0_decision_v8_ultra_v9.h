#ifndef V0_DECISION_V8_ULTRA_V9_H
#define V0_DECISION_V8_ULTRA_V9_H

/*
 * V0 Decision V8 ULTRA V9
 *
 * Additive exact AVX2 raw/preflight fast paths over ULTRA V8.
 * All V8 headers/objects remain untouched. V9 only promotes transformations
 * that are score-equivalent on the legal Decision domain.
 *
 * Key identity used here:
 *   temperature 0/1/2 -> bonus 0/64/192
 *
 * V8 widened temperature to i16 and then evaluated
 *   ((t + (t >> 1)) << 6).
 * V9 performs an exact PSHUFB byte lookup first and widens the resulting
 * 0/64/192 bytes once. Pinned remains byte-sized through the tier path and is
 * applied only after indices have been packed to bytes. This removes hot-path
 * widening/arithmetic while preserving every Decision state exactly.
 */
#include "v0_decision_v8_bandwidth_v8.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(__AVX2__) || defined(_M_AVX2)

V0X_FORCEINLINE __m128i v0_temperature_bonus8_ultra_v9_avx2(
    const uint8_t *temperature) {
    const __m128i t = _mm_loadu_si128((const __m128i *)(const void *)temperature);
    const __m128i lut = _mm_setr_epi8(
        0, 64, (char)192, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0);
    return _mm_shuffle_epi8(lut, t);
}

/* 16 exact raw decisions. Legal pinned values are 0/1. */
V0X_FORCEINLINE __m128i v0_eval_v8_raw_block16_ultra_v9_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i hh = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost), 1);
    const __m128i p8 = _mm_loadu_si128((const __m128i *)(const void *)pinned);
    const __m256i bonus = _mm256_cvtepu8_epi16(
        v0_temperature_bonus8_ultra_v9_avx2(temperature));
    const __m256i ss = _mm256_adds_epu16(vv, bonus);
    const __m256i dd = _mm256_subs_epu16(ss, hh);
    const __m256i pre = _mm256_cmpeq_epi16(_mm256_max_epu16(ss, hh), ss);
    __m256i idx = _mm256_min_epu16(
        _mm256_add_epi16(_mm256_srli_epi16(dd, 6), _mm256_set1_epi16(1)),
        _mm256_set1_epi16(7));
    idx = _mm256_and_si256(idx, pre);
    {
        __m128i i8 = _mm_packus_epi16(
            _mm256_castsi256_si128(idx), _mm256_extracti128_si256(idx, 1));
        /* Pinned is mathematically always final state 7 in the legal domain. */
        i8 = _mm_blendv_epi8(
            i8, _mm_set1_epi8(7),
            _mm_cmpeq_epi8(p8, _mm_set1_epi8(1)));
        return _mm_shuffle_epi8(
            _mm_setr_epi8(0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0), i8);
    }
}

static inline void v0_eval_v8_raw_batch_ultra_v9_avx2_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i = 0;
    /* A single 16-item body is intentionally retained: deeper store fusion
       regressed on the paired Zen 4 measurements used for promotion. */
    for (; i + 16 <= n; i += 16)
        _mm_storeu_si128((__m128i *)(void *)(out + i),
            v0_eval_v8_raw_block16_ultra_v9_avx2(
                value + i, cost + i, temperature + i, pinned + i));
    for (; i < n; ++i)
        out[i] = (uint8_t)v0_eval_v8_raw_ultra_inline(
            value[i], cost[i], temperature[i], pinned[i]);
}

/* Public exact 16-lane preflight mask. Bit k=1 iff item k executes. */
V0X_FORCEINLINE uint16_t v0_preflight_v8_raw_mask16_ultra_v9_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i hh = _mm256_srli_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)cost), 1);
    const __m128i p8 = _mm_loadu_si128((const __m128i *)(const void *)pinned);
    const __m256i ss = _mm256_adds_epu16(
        vv, _mm256_cvtepu8_epi16(v0_temperature_bonus8_ultra_v9_avx2(temperature)));
    const __m256i yes = _mm256_cmpeq_epi16(_mm256_max_epu16(ss, hh), ss);
    __m128i packed = _mm_packs_epi16(
        _mm256_castsi256_si128(yes), _mm256_extracti128_si256(yes, 1));
    packed = _mm_or_si128(packed, _mm_cmpeq_epi8(p8, _mm_set1_epi8(1)));
    return (uint16_t)_mm_movemask_epi8(packed);
}

static inline uint64_t v0_preflight_v8_raw_count_ultra_v9_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 16 <= n; i += 16) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt((unsigned)v0_preflight_v8_raw_mask16_ultra_v9_avx2(
            value+i, cost+i, temperature+i, pinned+i));
#else
        count += (uint32_t)__builtin_popcount((unsigned)v0_preflight_v8_raw_mask16_ultra_v9_avx2(
            value+i, cost+i, temperature+i, pinned+i));
#endif
    }
    for (; i < n; ++i)
        count += (uint64_t)v0_preflight_v8_raw_ultra_inline(
            value[i], cost[i], temperature[i], pinned[i]);
    return count;
}

#endif /* AVX2 */

#ifdef __cplusplus
}
#endif
#endif

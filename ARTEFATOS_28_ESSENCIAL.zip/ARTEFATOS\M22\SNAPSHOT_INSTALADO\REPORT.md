# Artefato 22 — V0 Trusted Lookup — KEEP BASELINE

## Veredito
**KEEP_BASELINE / NO NEW PROMOTION**

Baseline preservada: M02 Trusted Lookup strict V2, cujo hot path canônico continua sendo o Trusted Lookup V1 separado.

- SHA-256 baseline ZIP: c2ff1a1f817ed3706b195fbfb5564f974cb40ed8393ae04c6812bc9d59d79333
- SHA-256 baseline Linux object: 71af3d27a351ce2efcc55465c706b67f9a2c1c554b097d12319b6308f0802ae9
- baseline v0_lookup_trusted: caminho de ~48 B, 2 multiplicadores + tabelas disp/slot.

## Histórico já existente
O V4 já havia testado batches 2/4/8/16 e rejeitado substituição universal: melhor mediana batch16 ~1.315x, porém mínimo ~0.948x.

## Busca nova 1 — perfect hash direto V22
Foi encontrado um perfect hash sem colisões para as 1024 chaves trusted:

idx = ((((x * 0x28bd9dd9) mod 2^32) XOR (x >> 7)) >> 17)

- 32768 slots (64 KiB como u16)
- 1024/1024 chaves sem colisão
- código V0L nativo: 30 B Linux / 31 B Windows
- 1 multiply + 1 lookup em vez de 2 multiplies + 2 lookups

Resultado em 5 processos / 6 perfis / 300 medições:
- mediana geral: ~1.104x
- vitórias: 245/300
- pior rodada: ~0.741x

REJECTED: o ganho de instruções não compensou a pressão de cache de forma universal.

## Busca nova 2 — AVX2 trusted batch
Protótipo AVX2 com VPMULLD + gathers em tabelas u32 expandidas.

### Batch8
- mediana geral: ~1.311x
- vitórias: 288/300
- pior rodada: ~0.498x

### Batch16
Gate de 240 medições:
- mediana geral: ~1.372x
- vitórias: 236/240
- pior rodada: ~0.846x

Gate longo do batch16 (16M chaves por trecho):
- mediana geral: ~1.187x
- vitórias: 114/120
- pior rodada: ~0.823x

REJECTED: throughput melhor na mediana, mas com regressões relevantes.

## Correção
- baseline strict/exhaustive preservada;
- direct15: 1024/1024 chaves exatas, sem colisões;
- AVX2 batch: paridade contra o objeto baseline real nos perfis testados;
- candidatos rejeitados por desempenho, não por correção.

## Estado final
A baseline Trusted Lookup continua sendo a autoridade. Nenhum dispatcher novo deve ser ativado.

param(
  [string]$CpuMask = "0"
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Here
$Build = Join-Path $Here "build"
New-Item -ItemType Directory -Force -Path $Build | Out-Null

$baseline = Join-Path $Root "baseline\v0_telemetry_v2_windows.obj"
$candidate = Join-Path $Root "candidate\v0_telemetry_v7_windows.obj"
$gate = Join-Path $Here "gate.c"

$expectedBaseline = "5a0ffcd43cb6fd5aac3015c03857fb4f23ccb288d8639968a0959f7f7aa7eb0b"
$expectedCandidate = "2843f99f88b28466e4ab8da8ff537ee586f4d94a1c32ac9cf937f3c5617de04e"
if ((Get-FileHash $baseline -Algorithm SHA256).Hash.ToLower() -ne $expectedBaseline) { throw "Baseline V2 hash mismatch" }
if ((Get-FileHash $candidate -Algorithm SHA256).Hash.ToLower() -ne $expectedCandidate) { throw "Candidate V7 hash mismatch" }

$vcvars = @(
  "C:\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
  "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $vcvars) { throw "MSVC Build Tools not found. Nothing was installed or changed." }

$exe = Join-Path $Build "telemetry_v7_gate.exe"
$cmd = 'call "' + $vcvars + '" >nul && cl /nologo /O2 /GS- /W4 "' + $gate + '" "' + $baseline + '" "' + $candidate + '" /Fe:"' + $exe + '"'
cmd /c $cmd
if ($LASTEXITCODE -ne 0) { throw "Compilation failed" }

$out = Join-Path $Build "windows_gate_output.txt"
& $exe $CpuMask | Tee-Object -FilePath $out
$rc = $LASTEXITCODE
Write-Host "Result saved to $out"
if ($rc -ne 0) { exit $rc }

# V0 Decision V0L V8 Adaptive Test — Validation Report

Date: 2026-09-24
Status: **EXPERIMENTAL / TEST BUILD**

## 1. Goal

V8 answers a specific problem found while testing `Decision -> V0 Global`:

- when Decision is beneficial, keep it active;
- when Decision costs more than the work it avoids, bypass it;
- periodically re-test both paths and switch back automatically if workload behavior changes.

The Decision V7 V0L kernel itself is **not changed**. V8 is a block-level supervisor around that proven kernel.

## 2. Adaptive method

Default cycle:

1. measure BYPASS for 2,048 requests;
2. measure FILTER for 2,048 requests;
3. choose the cheaper path, but require a >=5% win to switch;
4. use the chosen path for 65,536 requests;
5. repeat;
6. reverse A/B probe order every epoch.

This makes the decision based on **actual measured cost**, not only on drop percentage.

No floating point is used by the supervisor. The supervisor runs at block boundaries, not per Decision call.

## 3. Correctness

### Controller state machine

- transition test: PASS
- 5% hysteresis test: PASS

### Decision core

The byte-identical V7 core was revalidated against the reference logic:

- directed cases: 1,092
- randomized cases: 20,000,000
- preflight divergences: **0**
- full-decision divergences: **0**
- V6/V7 preflight divergences: **0**
- V6/V7 full divergences: **0**

### V8 + V0 Global combined

10,000,000 operations with changing workload phases:

- Global exact errors: **0**
- Global trusted errors: **0**
- automatic switches to FILTER: 3
- automatic switches to BYPASS: 3
- completed A/B probes: 144

The Global native core was not modified.

## 4. Rebuild integrity

Decision V7 native core clean rebuild:

- Linux ELF64: **byte-for-byte identical**
- Windows COFF x86-64: **byte-for-byte identical**
- Linux `.text`: 83 B
- Windows `.text`: 91 B
- `.rodata`: 0 B

Windows-target syntax check for the V8 adaptive header: PASS.

## 5. Performance — adaptive supervisor

The following values are the median across three independent process runs; each process internally uses repeated timing samples.

### V0 Global exact only

| Scenario | Global baseline | Always Decision V7 | Adaptive V8 | Interpretation |
|---|---:|---:|---:|---|
| Low drop, random | 3.251 ns/op | 6.375 ns/op | **3.413 ns/op** | V8 bypasses; ~5% controller/probe overhead vs baseline, ~1.87x faster than always filtering |
| 90% drop, random | 3.237 ns/op | 3.850 ns/op | **3.263 ns/op** | V8 correctly prefers BYPASS because random branch/signal cost makes filtering slower despite high drop rate |
| Phase-shifting random | 3.279 ns/op | 5.247 ns/op | **3.444 ns/op** | V8 stays near baseline and is ~1.52x faster than always filtering |

This is an important result: **drop percentage alone is not enough** to choose the right mode.

### Same Global exact, 90% predictable drop

- Global baseline: 2.367 ns/op
- Always Decision V7: 1.978 ns/op
- Adaptive V8: **2.027 ns/op**
- V8 selected: **FILTER**
- V8 vs Global baseline: **~1.17x faster**

At the same nominal 90% drop rate, V8 selected BYPASS for a random branch pattern but FILTER for a predictable pattern. This is exactly why V8 uses runtime A/B cost measurement.

### ~10 ns downstream operation

| Scenario | Baseline | Always Decision V7 | Adaptive V8 | Result |
|---|---:|---:|---:|---|
| Low drop | 10.653 ns/op | 11.998 ns/op | **10.660 ns/op** | essentially baseline; V8 bypasses |
| High drop | 10.503 ns/op | 4.492 ns/op | **4.716 ns/op** | ~2.23x faster than baseline; V8 selects FILTER |
| Phase-shifting | 10.482 ns/op | 8.393 ns/op | **8.154 ns/op** | ~1.29x faster than baseline and ~1.03x faster than always filtering |

In the workload where the best mode changes over time, adaptive V8 was better than both fixed strategies in the measured run set.

## 6. Architecture

```text
                    V8 ADAPTIVE SUPERVISOR
                           |
                  short A/B measurement
                           |
             +-------------+-------------+
             |                           |
          BYPASS                       FILTER
             |                           |
       V0 Global / work        Decision V7 V0L
                                         |
                                  V0 Global / work
```

The V0 Global object remains separate and unchanged.

## 7. Limitations

- This validates native V0L cores and the adaptive supervisor on the current Linux/KVM host.
- The Windows VMX/EPT driver was **not loaded** on this host.
- Probe measurements are workload-local and can be noisy; the 5% hysteresis is intended to prevent rapid mode thrashing.
- A FILTER probe actually exercises the FILTER path so its measured cost is real. Only place Decision in front of operations that are semantically allowed to be dropped.
- Very fast downstream work can make even a tiny controller/probe overhead visible; for larger downstream work the relative overhead falls sharply.

## 8. Recommended test placement

Use:

```text
V8 supervisor -> [BYPASS or Decision V7] -> V0 Global / expensive work
```

Do not place the supervisor inside individual EPT load/store handling. Keep V0 Global frozen and use one adaptive state per independent worker/stream where practical.

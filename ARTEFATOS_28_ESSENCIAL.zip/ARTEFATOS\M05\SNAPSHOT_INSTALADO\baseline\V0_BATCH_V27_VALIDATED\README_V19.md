# V0 Batch V19 — VALIDATED

V19 is an additive AVX2 accelerator. It does not replace or modify the validated V11/V14/IMPLICIT64 objects.

## What changed

`v0_batch_plan64_avx2_dual_v19` emits 8 fixed-64 descriptors per loop iteration using two YMM lanes. The loop is counted, so the main 512-item body uses one backward branch instead of the older compare + forward branch + back jump shape.

Output ABI is unchanged:

```c
typedef struct v0_batch_span {
    uint32_t start;
    uint32_t count;
} v0_batch_span;
```

## Correctness

- inherited V11/V14/IMPLICIT64 validation: 3,429,832,829 checks, PASS;
- V19 differential/full-plan validation: 3,958,793,361 checks, PASS;
- combined final validation executed: 7,388,626,190 checks, 0 divergences;
- overwrite sentinels: PASS;
- Linux ELF64: executed successfully;
- Windows COFF x86-64: generated and structurally recognized;
- Linux and Windows V19 rebuilds are byte-identical;
- Linux V19 object has 0 undefined symbols.

## Conservative performance domain measured on the validation host

Reference host: AMD EPYC 9V74 virtualized x86-64.

Against the actual previous dispatch:

- 257: V19 not promoted (slight regression/variance);
- 320: essentially tie;
- 385: first measured safe suffix in the dense low sweep;
- 512: about 1.59x vs V11 in the paired benchmark;
- 1,024: about 2.12x vs V11;
- 2,048: about 2.54x vs V11;
- 3,584: about 3.07x vs V11;
- 4,096: about 1.60x vs V14;
- 16,384: about 1.23x vs V14;
- 65,536: about 1.03x vs V14;
- 262,144: about 1.02x vs V14.

Dense validation of the promoted performance domain:

- 257..511 low sweep: first suffix with no measured regression starts at 385;
- 512..4,095: every integer measured;
- 4,096..262,144: dense step coverage plus exact neighborhoods around key boundaries;
- promoted-domain dense sweep: 5,235 measured points, 0 regressions, no point below 1.01x in that sweep;
- worst speedup in the 512+ dense sweep: about 1.10x.

The cutoff is performance-specific, not correctness-specific. Other CPUs should benchmark and may choose a different cutoff.

## Conservative dispatch

```text
no AVX2:
    keep existing V6/V11 paths

AVX2 and items < 385:
    keep existing validated path

AVX2 and 385 <= items <= 262144:
    V19 dual-YMM

AVX2 and items > 262144:
    V14 (or the already validated existing path)
```

No old path is deleted.

## IMPLICIT64 interaction

V19 makes materialization faster, so the older implicit cutoff is not universal anymore. In the included consumer benchmark, 8,192 was no longer consistently favorable. A conservative measured point was 16,384+ for this consumer, while the exact break-even remains consumer- and CPU-dependent. IMPLICIT64 itself is unchanged.

## Rejected attempts after V14

- V15 counted single-YMM: correct but had performance regressions at multiple sizes;
- V16 AVX-512: correct and fast in part of the range, but not uniformly better and regressed on sustained large plans;
- V17 dual-YMM: good direction, but had a 256-item-tail weakness;
- V18 fixed that tail and was promotable in a narrower conservative range;
- V20 reduced code size but slowed the hot path materially, so it was rejected.

## Build / test

```bash
./BUILD_V19_LINUX.sh
./TEST_V19_LINUX.sh
```

Windows object generation:

```powershell
.\BUILD_V19_WINDOWS.ps1
```

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../candidate/V0_EXTERNAL_MEMORY_CLIENT_V11_LEASE_FIX1.h"
#include "../candidate/V0_EXTERNAL_MEMORY_CLIENT_V5.h"

typedef uint32_t (__cdecl *PFN_put)(uint32_t,const void*,uint32_t);
typedef uint32_t (__cdecl *PFN_getbatch)(const uint32_t*,uint32_t,void*,uint32_t,uint32_t*,uint32_t*);
typedef uint32_t (__cdecl *PFN_remove)(uint32_t);
typedef uint32_t (__cdecl *PFN_select)(uint32_t);
typedef uint32_t (__cdecl *PFN_view)(const uint32_t*,uint32_t,uint32_t,V0XBatchViewV11*);
typedef uint32_t (__cdecl *PFN_release)(void);
static volatile uint64_t sinkv;
static uint64_t qpc(void){LARGE_INTEGER x;QueryPerformanceCounter(&x);return x.QuadPart;}
static double qns(uint64_t d){LARGE_INTEGER f;QueryPerformanceFrequency(&f);return 1e9*(double)d/(double)f.QuadPart;}
static uint64_t consume(const uint8_t*p,uint32_t n){uint64_t x=1469598103934665603ull;for(uint32_t i=0;i<n;i+=64){x^=p[i];x*=1099511628211ull;}if(n)x^=p[n-1];return x;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y?1:0;}
static double bench_copy(PFN_getbatch f,const uint32_t*ids,uint32_t count,uint8_t*out,uint32_t cap,uint32_t*offs,uint32_t*lens,int loops){uint64_t t=qpc();for(int z=0;z<loops;z++){uint32_t got=f(ids,count,out,cap,offs,lens);if(got!=count)return-1;for(uint32_t i=0;i<got;i++)sinkv^=consume(out+offs[i],lens[i]);}return qns(qpc()-t)/loops;}
static double bench_view(PFN_view f,PFN_release rel,const uint32_t*ids,uint32_t count,uint32_t hint,int loops){V0XBatchViewV11 v;uint64_t t=qpc();for(int z=0;z<loops;z++){uint32_t got=f(ids,count,hint,&v);if(got!=count)return-1;for(uint32_t i=0;i<got;i++)sinkv^=consume(v.base+v.offsets[i],v.lens[i]);if(!rel())return-1;}return qns(qpc()-t)/loops;}
typedef struct TCtx{PFN_getbatch get;const uint32_t*ids;uint32_t count;uint8_t*out;uint32_t cap,*offs,*lens;HANDLE entered,done;uint32_t got;}TCtx;
static DWORD WINAPI other_get(LPVOID p){TCtx*c=(TCtx*)p;SetEvent(c->entered);c->got=c->get(c->ids,c->count,c->out,c->cap,c->offs,c->lens);SetEvent(c->done);return 0;}
int main(int argc,char**argv){int runs=15;if(argc>1)runs=atoi(argv[1]);if(runs<9)runs=9;
 HMODULE b=LoadLibraryA("baseline_client.dll"),c=LoadLibraryA("candidate_client.dll");if(!b||!c){printf("LOAD_FAIL %lu\n",GetLastError());return 2;}
 PFN_put put=(PFN_put)GetProcAddress(b,"v0x_put_v5");PFN_getbatch bg=(PFN_getbatch)GetProcAddress(b,"v0x_get_batch_v9");PFN_remove rem=(PFN_remove)GetProcAddress(b,"v0x_remove_v5");PFN_select sel=(PFN_select)GetProcAddress(b,"v0x_select_batch_v9");PFN_getbatch cg=(PFN_getbatch)GetProcAddress(c,"v0x_get_batch_v9");PFN_view view=(PFN_view)GetProcAddress(c,"v0x_get_batch_view_v11");PFN_release rel=(PFN_release)GetProcAddress(c,"v0x_release_batch_view_v11");if(!put||!bg||!rem||!sel||!cg||!view||!rel)return 3;
 uint32_t sizes[]={4096,16384,65536,262144,1048576};int parity=0,safety=0,overall=1;
 for(int si=0;si<5;si++){uint32_t sz=sizes[si],count=sel(sz);if(count>64)count=64;uint32_t total=count*sz;uint32_t*ids=malloc(count*4),*offs=malloc(count*4),*lens=malloc(count*4);uint8_t**src=calloc(count,sizeof(*src));uint8_t*out=_aligned_malloc((size_t)total+64,64);if(!ids||!offs||!lens||!src||!out)return 4;
  for(uint32_t i=0;i<count;i++){ids[i]=0x7A000000u+si*1000u+i;src[i]=_aligned_malloc(sz,64);for(uint32_t j=0;j<sz;j++)src[i][j]=(uint8_t)(j*131u+i*17u+si*29u);if(!put(ids[i],src[i],sz))return 5;}
  if(bg(ids,count,out,total,offs,lens)!=count)return 6;for(uint32_t i=0;i<count;i++)if(lens[i]!=sz||memcmp(out+offs[i],src[i],sz))parity++;
  V0XBatchViewV11 v;if(view(ids,count,sz,&v)!=count)return 7;for(uint32_t i=0;i<count;i++)if(v.lens[i]!=sz||memcmp(v.base+v.offsets[i],src[i],sz))parity++;
  /* Same-thread nested batch must fail while the lease is active. */ if(cg(ids,count,out,total,offs,lens)!=0)safety++;
  /* Other thread must block until release, proving the process mapping cannot be overwritten. */TCtx tc={0};tc.get=cg;tc.ids=ids;tc.count=count;tc.out=out;tc.cap=total;tc.offs=offs;tc.lens=lens;tc.entered=CreateEvent(NULL,TRUE,FALSE,NULL);tc.done=CreateEvent(NULL,TRUE,FALSE,NULL);HANDLE th=CreateThread(NULL,0,other_get,&tc,0,NULL);if(!th)return 8;WaitForSingleObject(tc.entered,2000);Sleep(25);if(WaitForSingleObject(tc.done,0)!=WAIT_TIMEOUT)safety++;uint64_t before=0,during=0;for(uint32_t i=0;i<count;i++)before^=consume(v.base+v.offsets[i],v.lens[i]);Sleep(10);for(uint32_t i=0;i<count;i++)during^=consume(v.base+v.offsets[i],v.lens[i]);if(before!=during)safety++;if(!rel())safety++;if(WaitForSingleObject(tc.done,5000)!=WAIT_OBJECT_0||tc.got!=count)safety++;CloseHandle(th);CloseHandle(tc.entered);CloseHandle(tc.done);
  int loops=sz<=4096?400:sz<=16384?240:sz<=65536?120:sz<=262144?50:18;double rr[31];if(runs>31)runs=31;for(int r=0;r<runs;r++){double a,bn;if(r&1){bn=bench_view(view,rel,ids,count,sz,loops);a=bench_copy(bg,ids,count,out,total,offs,lens,loops);}else{a=bench_copy(bg,ids,count,out,total,offs,lens,loops);bn=bench_view(view,rel,ids,count,sz,loops);}if(a<=0||bn<=0)return 9;rr[r]=a/bn;}qsort(rr,runs,sizeof(double),cmpd);double med=rr[runs/2],p25=rr[runs/4],mn=rr[0];int wins=0;for(int r=0;r<runs;r++)if(rr[r]>1.0)wins++;const char*gate=(med>=1.02&&p25>=1.0&&wins*5>=runs*4)?"PASS_CANDIDATE":(med<0.98?"REJECT":"INCONCLUSIVE");if(strcmp(gate,"REJECT")==0)overall=-1;else if(strcmp(gate,"PASS_CANDIDATE")&&overall>0)overall=0;printf("SIZE %u BATCH %u MED %.6f P25 %.6f MIN %.6f WINS %d/%d GATE %s\n",sz,count,med,p25,mn,wins,runs,gate);
  for(uint32_t i=0;i<count;i++){rem(ids[i]);_aligned_free(src[i]);}free(ids);free(src);free(offs);free(lens);_aligned_free(out);
 }
 printf("PARITY_BAD %d\nLEASE_SAFETY_BAD %d\nFINAL %s\n",parity,safety,(parity||safety)?"REJECT":overall>0?"PASS_CANDIDATE":overall<0?"REJECT":"INCONCLUSIVE");fprintf(stderr,"sink=%llu\n",(unsigned long long)sinkv);return(parity||safety)?10:0;}

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
$cl = Get-Command cl.exe -ErrorAction SilentlyContinue
if (-not $cl) { throw 'cl.exe not found. Run from a VS x64 Native Tools prompt or load the MSVC environment.' }
$base = Join-Path $root 'baseline\v0_remap_prechecked_batch4_v19_safe.obj'
$cand = Join-Path $root 'candidate\v22_windows.obj'
$src  = Join-Path $here 'bench_v22_windows.c'
$exe  = Join-Path $here 'bench_v22_windows.exe'
& cl.exe /nologo /O2 /EHsc /Fe:$exe $src $base $cand | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'compile/link failed' }
& $exe | Tee-Object -FilePath (Join-Path $here 'windows_gate_results.csv')
if ($LASTEXITCODE -ne 0) { throw 'gate failed: at least one paired median regressed' }
Write-Host 'PASS: all Windows paired medians beat V19. No service/install changes were made.'

# V0 Decision V8 ULTRA V11

Exact additive optimization over V10.

V11 does not change Decision thresholds, states, controller behavior, V10 raw paths, V9 one-shot preflight, or inherited binaries.

New paths:

1. 1 KiB scalar gate16 direct lookup table for branch-free classification after the saturated sum.
2. Optional exact 4-bit gate16 output with non-temporal stores for large write-only batches.

An automatic V11 short-batch/tail replacement was tested but rejected because it was not consistently faster than the inherited V10 batch path.

Every promoted path must pass exact regression against the inherited Decision reference before use.

# Artefato 13 — Shared-State Cache — squeeze report

## Baseline

`V0_SHARED_STATE_CACHE_V1_SAFE` continua promovida.

Baseline histórica:
- 6.600.000 operações diferenciais, 0 divergências;
- `get`: 49 B Linux / 52 B Windows;
- mediana geral histórica: 1,737151 ns/chamada no AMD EPYC 9V74;
- 16 cenários históricos: 1,667278–1,942207 ns/chamada.

## Tentativas desta rodada

### 1. Paired/batch GET
O backend V0L atual tem limite de parâmetros e pressão de registradores. Um protótipo equivalente em C para duas consultas foi comparado diretamente contra o objeto V1 real.

Resultado: **rejeitado**.
Em geral ficou em aproximadamente 0,39x–0,83x da velocidade da V1, dependendo do perfil. O custo do request/output e a excelente latência escalar da V1 eliminaram a vantagem de amortização.

### 2. Probe preindexado V0L
Foi criado `v0_ssc_probe_slot_v2(slot,key)`, 30 B Linux / 33 B Windows, 0 relocations.
A ideia era permitir ao caller reutilizar um ponteiro de slot já calculado.

Correção: 0 divergências nos testes.

Em microbench curto a mediana chegou a mostrar +5–20%, mas rodadas longas em processos separados derrubaram o sinal. Em workload 99% hit:

| capacity | baseline ns | candidate ns | ratio baseline/candidate | wins |
|---:|---:|---:|---:|---:|
| 64 | 1,6041 | 1,7046 | 0,943x | 1/9 |
| 256 | 1,5700 | 1,7631 | 0,909x | 1/9 |
| 1024 | 1,6245 | 1,9047 | 0,880x | 0/9 |
| 4096 | 1,8092 | 2,0478 | 0,901x | 0/9 |

Resultado: **rejeitado**.

### 3. Prefetch em lote
Testado prefetch com distâncias 4/8/16/32 em capacidades 1024, 4096, 16384 e 65536.

Resultado: **rejeitado**.
Nenhuma combinação apresentou ganho robusto. As medianas ficaram aproximadamente entre 0,888x e 0,985x na maioria dos melhores casos, com regressões claras.

## Decisão

**KEEP_BASELINE — V1 SAFE.**

Não há candidato novo promovível nesta rodada. A V1 já está suficientemente perto do piso para GET direto que otimizações genéricas adicionam overhead em vez de remover custo.

Próximos ganhos só fazem sentido se o contrato mudar para um domínio explicitamente diferente, por exemplo epoch invalidation em massa ou um consumidor que permita eliminar a própria consulta, não apenas acelerar `get_v1`.

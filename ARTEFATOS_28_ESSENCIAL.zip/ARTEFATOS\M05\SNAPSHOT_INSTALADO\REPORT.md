# V0 Batch Planner / Batch — V27 Squeeze Recheck

## Decision

**KEEP_BASELINE — V27 remains the promoted Batch Planner baseline.**

No new candidate is promoted by this artifact. The validated narrow-domain V27 AVX2 accelerator remains intact and all fallback paths remain available.

## Preserved baseline

The package carries the complete validated `V0_BATCH_V27_VALIDATED` tree, including V6/V11/V14/IMPLICIT64/V19/V27 sources, compilers, Linux/Windows objects, reports and test harnesses.

V27 remains an optional narrow-domain accelerator for exactly:

- 1024 items
- 2048 items
- 3072 items
- 4096 items

Preconditions remain unchanged: AVX2 + OS YMM support and the same materialized `{u32 start, u32 count}` ABI. Outside that domain, use the previously validated V19/V14/V11/IMPLICIT64 fallback policy.

## Fresh baseline revalidation

Executed again in this packaging environment:

- `test_v27`: **PASS, 205,017,440 checks**
- `test_all`: **PASS, 148,146,658 checks**

No baseline source/object was modified by these tests.

## Additional squeeze attempt

A diagnostic exact-size unrolled AVX2 candidate was screened against the real V27 Linux object. The candidate removes V27's group-loop bookkeeping by specializing each of the four exact item counts.

Correctness passed for the exercised exact-size/alignment cases, but performance did **not** satisfy the zero-regression rule. Representative fresh medians included:

- 1024 aligned: about **1.16x** candidate win, but unaligned cases fell to roughly **0.90x–0.96x**.
- 2048: several unaligned conditions were roughly **0.87x–0.90x**.
- 3072: mostly near parity, with a condition around **0.92x**.
- 4096: small wins in some conditions, but other conditions remained below 1x.

Therefore the exact-size unrolled experiment is **REJECTED** and included only as evidence. It is not part of any dispatcher.

## Why V27 stays

The inherited V27 acceptance already established exact output parity and a narrow performance domain. Earlier expansion attempts outside that domain were rejected, including contract-invalid expansion. The fresh squeeze attempt again failed the no-regression requirement across alignment conditions.

## Promotion rule

Do not replace V27 from Linux-only timing. Any future candidate must:

1. preserve exact descriptor output and bounds contract;
2. keep V27/fallback available;
3. pass parity before timing;
4. win the full declared domain without material regressions;
5. pass the paired Intel/Windows target gate before promotion.

## Deployment

This artifact does **not** install services, drivers, hooks, EPT, hypervisor components, boot/BCD changes, or firmware changes. It is an isolated Batch Planner package.

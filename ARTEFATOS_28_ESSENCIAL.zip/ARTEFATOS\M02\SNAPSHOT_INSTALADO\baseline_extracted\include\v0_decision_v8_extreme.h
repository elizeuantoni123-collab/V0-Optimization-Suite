#ifndef V0_DECISION_V8_EXTREME_H
#define V0_DECISION_V8_EXTREME_H

#include <stdint.h>
#include <stddef.h>
#include "v0_decision_v8_fast.h"
#include "v0_decision_v7.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_MSC_VER)
#define V0X_FORCEINLINE static __forceinline
#define V0X_ALIGN64 __declspec(align(64))
#else
#define V0X_FORCEINLINE static inline __attribute__((always_inline))
#define V0X_ALIGN64 __attribute__((aligned(64)))
#endif

/*
 * Exact Q6 decision coordinate.
 *
 * The Decision boundaries are 0/64/192/384. On x86-64, signed >> is an
 * arithmetic shift, so q6=score>>6 maps those exact boundaries to 0/1/3/6.
 * Valid score range -32767..98878 maps to -512..1544 and therefore fits i16.
 * This is exact for Decision V8; it is not an approximation or quantization
 * of any information that Decision actually consumes.
 */
typedef int16_t v0_decision_q6_v8_t;

V0X_FORCEINLINE v0_decision_q6_v8_t
v0_decision_v8_q6_from_score(v0_decision_score_v8_t score) {
    return (v0_decision_q6_v8_t)(score >> 6);
}

V0X_FORCEINLINE v0_decision_q6_v8_t
v0_decision_v8_q6(uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    return v0_decision_v8_q6_from_score(
        v0_decision_v8_score(value, cost, temperature, pinned));
}

/* Stable V0L ABI. q_bits is the sign-extended Q6 coordinate in a u32 ABI slot. */
uint32_t v0_preflight_v0l_v8_q6(uint32_t q_bits);
uint32_t v0_decide_v0l_v8_q6(uint32_t q_bits);
uint32_t v0_eval_v0l_v8_q6(uint32_t q_bits);

V0X_FORCEINLINE uint32_t v0_preflight_v8_q6_inline(v0_decision_q6_v8_t q) {
    return (uint32_t)(q >= 0);
}

V0X_FORCEINLINE uint32_t v0_decide_v8_q6_inline(v0_decision_q6_v8_t q) {
    const int32_t x = (int32_t)q;
    return (uint32_t)(x >= 1) + (uint32_t)(x >= 3) + (uint32_t)(x >= 6);
}

/*
 * Exact fused scalar path optimized for Q6. The triangular threshold pattern
 * 1/3/6 lets tier be reconstructed arithmetically after clamping q>=0.
 * Valid Q6 domain is small enough that all intermediates are overflow-free.
 */
V0X_FORCEINLINE uint32_t v0_eval_v8_q6_extreme_inline(v0_decision_q6_v8_t q16) {
    const int32_t q = (int32_t)q16;
    const uint32_t pre = (uint32_t)(q >= 0);
    const uint32_t nonneg = (uint32_t)(q < 0 ? 0 : q);
    uint32_t tier = (3u * nonneg + 7u) >> 3;
    {
        const int32_t d = (int32_t)tier - 3;
        tier = (uint32_t)(3 + (d & (d >> 31)));
    }
    return (pre << 2) | tier;
}

/* Portable scalar batch fallback; outputs packed V8 result byte (0,4,5,6,7). */
static inline void v0_eval_v8_q6_batch_scalar_u8(
    const v0_decision_q6_v8_t *q, uint8_t *out, size_t n) {
    size_t i;
    for (i = 0; i < n; ++i) out[i] = (uint8_t)v0_eval_v8_q6_extreme_inline(q[i]);
}

#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__) || defined(_M_IX86)
#include <immintrin.h>

/* SSE2 is baseline on x86-64: 8 exact Q6 decisions per vector. */
static inline void v0_eval_v8_q6_batch_sse2_u8(
    const v0_decision_q6_v8_t *q, uint8_t *out, size_t n) {
    size_t i = 0;
    const __m128i z    = _mm_setzero_si128();
    const __m128i t0   = _mm_set1_epi16(-1); /* q >= 0 */
    const __m128i t1   = _mm_set1_epi16(0);  /* q >= 1 */
    const __m128i t2   = _mm_set1_epi16(2);  /* q >= 3 */
    const __m128i t3   = _mm_set1_epi16(5);  /* q >= 6 */
    const __m128i four = _mm_set1_epi16(4);
    for (; i + 8 <= n; i += 8) {
        const __m128i x  = _mm_loadu_si128((const __m128i *)(const void *)(q + i));
        const __m128i m0 = _mm_cmpgt_epi16(x, t0);
        const __m128i m1 = _mm_cmpgt_epi16(x, t1);
        const __m128i m2 = _mm_cmpgt_epi16(x, t2);
        const __m128i m3 = _mm_cmpgt_epi16(x, t3);
        const __m128i sum = _mm_add_epi16(_mm_add_epi16(m1, m2), m3);
        const __m128i tier = _mm_sub_epi16(z, sum); /* 0,1,2,3 */
        const __m128i r16 = _mm_or_si128(_mm_and_si128(m0, four), tier);
        const __m128i r8 = _mm_packus_epi16(r16, z);
        _mm_storel_epi64((__m128i *)(void *)(out + i), r8);
    }
    for (; i < n; ++i) out[i] = (uint8_t)v0_eval_v8_q6_extreme_inline(q[i]);
}

/* AVX2 helpers. */
#if defined(__AVX2__) || defined(_M_AVX2)
V0X_FORCEINLINE __m128i v0_eval_v8_q6_block16_avx2(
    const v0_decision_q6_v8_t *q,
    __m256i z, __m256i t0, __m256i t1, __m256i t2, __m256i t3, __m256i four) {
    const __m256i x  = _mm256_loadu_si256((const __m256i *)(const void *)q);
    const __m256i m0 = _mm256_cmpgt_epi16(x, t0);
    const __m256i m1 = _mm256_cmpgt_epi16(x, t1);
    const __m256i m2 = _mm256_cmpgt_epi16(x, t2);
    const __m256i m3 = _mm256_cmpgt_epi16(x, t3);
    const __m256i sum = _mm256_add_epi16(_mm256_add_epi16(m1, m2), m3);
    const __m256i tier = _mm256_sub_epi16(z, sum);
    const __m256i r16 = _mm256_or_si256(_mm256_and_si256(m0, four), tier);
    const __m128i lo = _mm256_castsi256_si128(r16);
    const __m128i hi = _mm256_extracti128_si256(r16, 1);
    return _mm_packus_epi16(lo, hi);
}

/*
 * AVX2 full evaluator. Eight-way loop unroll amortizes loop control over
 * 128 exact decisions while retaining a scalar tail.
 */
static inline void v0_eval_v8_q6_batch_avx2_u8(
    const v0_decision_q6_v8_t *q, uint8_t *out, size_t n) {
    size_t i = 0;
    const __m256i z    = _mm256_setzero_si256();
    const __m256i t0   = _mm256_set1_epi16(-1);
    const __m256i t1   = _mm256_set1_epi16(0);
    const __m256i t2   = _mm256_set1_epi16(2);
    const __m256i t3   = _mm256_set1_epi16(5);
    const __m256i four = _mm256_set1_epi16(4);
#define V0X_Q6_STORE16(OFF) \
    _mm_storeu_si128((__m128i *)(void *)(out + i + (OFF)), \
        v0_eval_v8_q6_block16_avx2(q + i + (OFF), z, t0, t1, t2, t3, four))
    for (; i + 128 <= n; i += 128) {
        V0X_Q6_STORE16(0);   V0X_Q6_STORE16(16);
        V0X_Q6_STORE16(32);  V0X_Q6_STORE16(48);
        V0X_Q6_STORE16(64);  V0X_Q6_STORE16(80);
        V0X_Q6_STORE16(96);  V0X_Q6_STORE16(112);
    }
    for (; i + 16 <= n; i += 16) V0X_Q6_STORE16(0);
#undef V0X_Q6_STORE16
    for (; i < n; ++i) out[i] = (uint8_t)v0_eval_v8_q6_extreme_inline(q[i]);
}

/*
 * Fastest preflight-only batch representation: one 16-bit mask for 16 Q6
 * decisions. Bit k is 1 iff q[k] >= 0. No per-decision output stores.
 */
V0X_FORCEINLINE uint16_t v0_preflight_v8_q6_mask16_avx2(
    const v0_decision_q6_v8_t *q) {
    const __m256i x = _mm256_loadu_si256((const __m256i *)(const void *)q);
    const __m256i m = _mm256_cmpgt_epi16(x, _mm256_set1_epi16(-1));
    const __m128i lo = _mm256_castsi256_si128(m);
    const __m128i hi = _mm256_extracti128_si256(m, 1);
    const __m128i p = _mm_packs_epi16(lo, hi);
    return (uint16_t)_mm_movemask_epi8(p);
}

/* Count executable calls with 128-decision unrolling; useful for scan/filter stages. */
static inline uint64_t v0_preflight_v8_q6_count_avx2(
    const v0_decision_q6_v8_t *q, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 128 <= n; i += 128) {
#if defined(_MSC_VER)
#define V0X_PC16(OFF) ((uint32_t)__popcnt((unsigned)v0_preflight_v8_q6_mask16_avx2(q + i + (OFF))))
#else
#define V0X_PC16(OFF) ((uint32_t)__builtin_popcount((unsigned)v0_preflight_v8_q6_mask16_avx2(q + i + (OFF))))
#endif
        count += V0X_PC16(0) + V0X_PC16(16) + V0X_PC16(32) + V0X_PC16(48)
               + V0X_PC16(64) + V0X_PC16(80) + V0X_PC16(96) + V0X_PC16(112);
#undef V0X_PC16
    }
    for (; i + 16 <= n; i += 16) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt((unsigned)v0_preflight_v8_q6_mask16_avx2(q + i));
#else
        count += (uint32_t)__builtin_popcount((unsigned)v0_preflight_v8_q6_mask16_avx2(q + i));
#endif
    }
    for (; i < n; ++i) count += (uint64_t)(q[i] >= 0);
    return count;
}

/* AVX2 score path when 32-bit scores are already materialized. */
static inline void v0_eval_v8_score_batch_avx2_u8(
    const int32_t *score, uint8_t *out, size_t n) {
    size_t i = 0;
    const __m256i z    = _mm256_setzero_si256();
    const __m256i t0   = _mm256_set1_epi32(-1);
    const __m256i t1   = _mm256_set1_epi32(63);
    const __m256i t2   = _mm256_set1_epi32(191);
    const __m256i t3   = _mm256_set1_epi32(383);
    const __m256i four = _mm256_set1_epi32(4);
    for (; i + 8 <= n; i += 8) {
        const __m256i x  = _mm256_loadu_si256((const __m256i *)(const void *)(score + i));
        const __m256i m0 = _mm256_cmpgt_epi32(x, t0);
        const __m256i m1 = _mm256_cmpgt_epi32(x, t1);
        const __m256i m2 = _mm256_cmpgt_epi32(x, t2);
        const __m256i m3 = _mm256_cmpgt_epi32(x, t3);
        const __m256i sum = _mm256_add_epi32(_mm256_add_epi32(m1, m2), m3);
        const __m256i tier = _mm256_sub_epi32(z, sum);
        const __m256i r32 = _mm256_or_si256(_mm256_and_si256(m0, four), tier);
        const __m128i lo = _mm256_castsi256_si128(r32);
        const __m128i hi = _mm256_extracti128_si256(r32, 1);
        const __m128i r16 = _mm_packs_epi32(lo, hi);
        const __m128i r8 = _mm_packus_epi16(r16, r16);
        _mm_storel_epi64((__m128i *)(void *)(out + i), r8);
    }
    for (; i < n; ++i) out[i] = (uint8_t)v0_eval_v8_inline(score[i]);
}
#endif /* AVX2 */
#endif /* x86 */


/* -------------------------------------------------------------------------
 * V6 ULTRA exact hot paths
 * ------------------------------------------------------------------------- */

/*
 * Exact direct Q6 LUT for the valid Decision input domain.
 * q6 is guaranteed to be in [-512,1544] when produced by v0_decision_v8_q6().
 * The table stores the final packed result (0,4,5,6,7), so this is an exact
 * replacement for the scalar comparison/arithmetic evaluator, not an
 * approximation.  2057 bytes fits comfortably in L1.
 */
static const uint8_t V0X_ALIGN64 V0X_Q6_DIRECT_LUT_V6[2057] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    4,5,5,6,6,6,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,
};

uint32_t v0_eval_v0l_v8_signal_lut(const v0_decision_signal_v7_t *signal);

typedef uint8_t v0_decision_e3_v8_t;

V0X_FORCEINLINE uint32_t v0_eval_v8_q6_hot_lut_inline(v0_decision_q6_v8_t q) {
    return (uint32_t)(V0X_Q6_DIRECT_LUT_V6 + 512)[(int32_t)q];
}

V0X_FORCEINLINE uint32_t v0_preflight_v8_q6_hot_lut_inline(v0_decision_q6_v8_t q) {
    return v0_eval_v8_q6_hot_lut_inline(q) >> 2;
}

V0X_FORCEINLINE uint32_t v0_decide_v8_q6_hot_lut_inline(v0_decision_q6_v8_t q) {
    return v0_eval_v8_q6_hot_lut_inline(q) & 3u;
}

V0X_FORCEINLINE uint32_t v0_eval_v8_raw_ultra_inline(
    uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    const v0_decision_score_v8_t score = v0_decision_v8_score(value, cost, temperature, pinned);
    return v0_eval_v8_q6_hot_lut_inline(v0_decision_v8_q6_from_score(score));
}
V0X_FORCEINLINE uint32_t v0_preflight_v8_raw_ultra_inline(
    uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    return v0_eval_v8_raw_ultra_inline(value,cost,temperature,pinned) >> 2;
}
V0X_FORCEINLINE uint32_t v0_decide_v8_raw_ultra_inline(
    uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    return v0_eval_v8_raw_ultra_inline(value,cost,temperature,pinned) & 3u;
}

/* Existing V7 packed-signal fast path, kept inline to remove ABI call overhead.
 * This is algebraically identical to the native V0L signal evaluator. */
V0X_FORCEINLINE uint32_t v0_eval_v8_signal_ultra_inline(
    const v0_decision_signal_v7_t *signal) {
    const uint32_t vc = signal->value_cost;
    const int32_t score = (int32_t)(vc & 65535u) - (int32_t)(vc >> 17)
                        + (int32_t)signal->bias;
    return (uint32_t)(V0X_Q6_DIRECT_LUT_V6 + 512)[score >> 6];
}

/* Exact one-byte cached state. Useful when the same Decision result is consumed
 * repeatedly: no semantics are removed because the consumer only needs packed
 * preflight+decision. */
V0X_FORCEINLINE v0_decision_e3_v8_t v0_decision_v8_e3_from_q6(v0_decision_q6_v8_t q) {
    return (v0_decision_e3_v8_t)v0_eval_v8_q6_hot_lut_inline(q);
}
V0X_FORCEINLINE uint32_t v0_e3_v8_preflight(v0_decision_e3_v8_t e) { return (uint32_t)(e >> 2); }
V0X_FORCEINLINE uint32_t v0_e3_v8_decision(v0_decision_e3_v8_t e) { return (uint32_t)(e & 3u); }

#if defined(__AVX2__) || defined(_M_AVX2)
/*
 * 32 exact decisions with a vector LUT.  Transform q -> clamp(q+1,0,7), then
 * PSHUFB with {0,4,5,5,6,6,6,7}.  This replaces four vector comparisons and
 * their reduction with add/max/min/pack/shuffle.
 */
V0X_FORCEINLINE __m256i v0_eval_v8_q6_block32_ultra_avx2(const v0_decision_q6_v8_t *q) {
    const __m256i one = _mm256_set1_epi16(1);
    const __m256i z = _mm256_setzero_si256();
    const __m256i seven = _mm256_set1_epi16(7);
    const __m256i lut = _mm256_setr_epi8(
        0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
        0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0);
    __m256i a = _mm256_loadu_si256((const __m256i *)(const void *)(q));
    __m256i b = _mm256_loadu_si256((const __m256i *)(const void *)(q + 16));
    a = _mm256_min_epi16(_mm256_max_epi16(_mm256_add_epi16(a, one), z), seven);
    b = _mm256_min_epi16(_mm256_max_epi16(_mm256_add_epi16(b, one), z), seven);
    {
        __m256i idx = _mm256_packus_epi16(a, b);
        idx = _mm256_permute4x64_epi64(idx, _MM_SHUFFLE(3,1,2,0));
        return _mm256_shuffle_epi8(lut, idx);
    }
}

static inline void v0_eval_v8_q6_batch_ultra_avx2_u8(
    const v0_decision_q6_v8_t *q, uint8_t *out, size_t n) {
    size_t i = 0;
#define V0X_ULTRA_STORE32(OFF) \
    _mm256_storeu_si256((__m256i *)(void *)(out + i + (OFF)), \
        v0_eval_v8_q6_block32_ultra_avx2(q + i + (OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_ULTRA_STORE32(0);
        V0X_ULTRA_STORE32(32);
        V0X_ULTRA_STORE32(64);
        V0X_ULTRA_STORE32(96);
    }
    for (; i + 32 <= n; i += 32) V0X_ULTRA_STORE32(0);
#undef V0X_ULTRA_STORE32
    for (; i < n; ++i) out[i] = (uint8_t)v0_eval_v8_q6_hot_lut_inline(q[i]);
}

/* Exact raw-input AVX2 path for structure-of-arrays input.  No Q6 prepass is
 * required.  temperature must be 0..2 and pinned 0..1, same valid domain as
 * the scalar API. */
V0X_FORCEINLINE __m256i v0_q6_raw16_ultra_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    /* Exact 16-bit derivation of floor((value - (cost>>1) + bias)/64). */
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i cc = _mm256_loadu_si256((const __m256i *)(const void *)cost);
    const __m256i tt = _mm256_cvtepu8_epi16(
        _mm_loadu_si128((const __m128i *)(const void *)temperature));
    const __m256i pp = _mm256_cvtepu8_epi16(
        _mm_loadu_si128((const __m128i *)(const void *)pinned));
    const __m256i mask63 = _mm256_set1_epi16(63);
    const __m256i z = _mm256_setzero_si256();
    const __m256i vq = _mm256_srli_epi16(vv,6);
    const __m256i cq = _mm256_srli_epi16(cc,7);
    const __m256i vr = _mm256_and_si256(vv,mask63);
    const __m256i cr = _mm256_and_si256(_mm256_srli_epi16(cc,1),mask63);
    const __m256i gt = _mm256_cmpgt_epi16(vr,cr);
    const __m256i lt = _mm256_cmpgt_epi16(cr,vr);
    /* pinned bias 33151 = 517*64 + 63. */
    const __m256i pcorr = _mm256_sub_epi16(_mm256_set1_epi16(517),gt);
    const __m256i pmask = _mm256_sub_epi16(z,pp);
    const __m256i corr = _mm256_blendv_epi8(lt,pcorr,pmask);
    const __m256i tu = _mm256_add_epi16(tt,_mm256_srli_epi16(tt,1));
    return _mm256_add_epi16(
        _mm256_add_epi16(_mm256_sub_epi16(vq,cq),corr),tu);
}

V0X_FORCEINLINE __m128i v0_eval_v8_raw_block16_ultra_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i z = _mm256_setzero_si256();
    __m256i q = v0_q6_raw16_ultra_avx2(value,cost,temperature,pinned);
    q = _mm256_min_epi16(
        _mm256_max_epi16(_mm256_add_epi16(q,_mm256_set1_epi16(1)),z),
        _mm256_set1_epi16(7));
    {
        const __m128i idx = _mm_packus_epi16(
            _mm256_castsi256_si128(q),_mm256_extracti128_si256(q,1));
        const __m128i lut = _mm_setr_epi8(
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0);
        return _mm_shuffle_epi8(lut,idx);
    }
}

/* Exact raw preflight mask: bit k is 1 iff input k executes. */
V0X_FORCEINLINE uint32_t v0_preflight_v8_raw_mask16_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m256i q = v0_q6_raw16_ultra_avx2(value,cost,temperature,pinned);
    const __m256i yes = _mm256_cmpgt_epi16(q,_mm256_set1_epi16(-1));
    const __m128i packed = _mm_packs_epi16(
        _mm256_castsi256_si128(yes),_mm256_extracti128_si256(yes,1));
    return (uint32_t)(unsigned)_mm_movemask_epi8(packed);
}

static inline uint64_t v0_preflight_v8_raw_count_avx2(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 64 <= n; i += 64) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask16_avx2(value+i,cost+i,temperature+i,pinned+i));
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask16_avx2(value+i+16,cost+i+16,temperature+i+16,pinned+i+16));
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask16_avx2(value+i+32,cost+i+32,temperature+i+32,pinned+i+32));
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask16_avx2(value+i+48,cost+i+48,temperature+i+48,pinned+i+48));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask16_avx2(value+i,cost+i,temperature+i,pinned+i));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask16_avx2(value+i+16,cost+i+16,temperature+i+16,pinned+i+16));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask16_avx2(value+i+32,cost+i+32,temperature+i+32,pinned+i+32));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask16_avx2(value+i+48,cost+i+48,temperature+i+48,pinned+i+48));
#endif
    }
    for (; i + 16 <= n; i += 16) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask16_avx2(value+i,cost+i,temperature+i,pinned+i));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask16_avx2(value+i,cost+i,temperature+i,pinned+i));
#endif
    }
    for (; i < n; ++i) count += (uint64_t)(v0_eval_v8_raw_ultra_inline(
        value[i],cost[i],temperature[i],pinned[i]) >> 2);
    return count;
}

static inline void v0_eval_v8_raw_batch_ultra_avx2_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i = 0;
#define V0X_RAW_STORE16(OFF) \
    _mm_storeu_si128((__m128i *)(void *)(out+i+(OFF)), \
      v0_eval_v8_raw_block16_ultra_avx2(value+i+(OFF),cost+i+(OFF), \
                                        temperature+i+(OFF),pinned+i+(OFF)))
    for (; i + 64 <= n; i += 64) {
        V0X_RAW_STORE16(0);
        V0X_RAW_STORE16(16);
        V0X_RAW_STORE16(32);
        V0X_RAW_STORE16(48);
    }
    for (; i + 16 <= n; i += 16) V0X_RAW_STORE16(0);
#undef V0X_RAW_STORE16
    for (; i < n; ++i) out[i] = (uint8_t)v0_eval_v8_raw_ultra_inline(
        value[i],cost[i],temperature[i],pinned[i]);
}


/* Large write-only raw batch.  Non-temporal stores avoid write-allocating the
 * output cache lines; prefer this only when the result will not be consumed
 * immediately.  Falls back automatically for an unaligned destination. */
static inline void v0_eval_v8_raw_batch_ultra_stream_avx2_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i = 0;
    if ((((uintptr_t)out) & 15u) != 0u) {
        v0_eval_v8_raw_batch_ultra_avx2_u8(value,cost,temperature,pinned,out,n);
        return;
    }
#define V0X_RAW_STREAM16(OFF) \
    _mm_stream_si128((__m128i *)(void *)(out+i+(OFF)), \
      v0_eval_v8_raw_block16_ultra_avx2(value+i+(OFF),cost+i+(OFF), \
                                        temperature+i+(OFF),pinned+i+(OFF)))
    for (; i + 64 <= n; i += 64) {
        V0X_RAW_STREAM16(0);
        V0X_RAW_STREAM16(16);
        V0X_RAW_STREAM16(32);
        V0X_RAW_STREAM16(48);
    }
    for (; i + 16 <= n; i += 16) V0X_RAW_STREAM16(0);
#undef V0X_RAW_STREAM16
    _mm_sfence();
    for (; i < n; ++i) out[i] = (uint8_t)v0_eval_v8_raw_ultra_inline(
        value[i],cost[i],temperature[i],pinned[i]);
}

/* Optional large-batch/write-only variant. Requires 32-byte aligned output.
 * Non-temporal stores reduce cache pollution for large arrays; use the normal
 * batch function when the output will be consumed immediately. */
static inline void v0_eval_v8_q6_batch_ultra_stream_avx2_u8(
    const v0_decision_q6_v8_t *q, uint8_t *out, size_t n) {
    size_t i = 0;
    if ((((uintptr_t)out) & 31u) != 0u) {
        v0_eval_v8_q6_batch_ultra_avx2_u8(q,out,n);
        return;
    }
#define V0X_ULTRA_STREAM32(OFF) \
    _mm256_stream_si256((__m256i *)(void *)(out + i + (OFF)), \
        v0_eval_v8_q6_block32_ultra_avx2(q + i + (OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_ULTRA_STREAM32(0);
        V0X_ULTRA_STREAM32(32);
        V0X_ULTRA_STREAM32(64);
        V0X_ULTRA_STREAM32(96);
    }
#undef V0X_ULTRA_STREAM32
    _mm_sfence();
    if (i < n) v0_eval_v8_q6_batch_ultra_avx2_u8(q+i,out+i,n-i);
}


#if defined(__AVX512BW__) && defined(__AVX512VL__)
/* Optional AVX-512BW raw path: 32 exact raw decisions per vector.  k-mask
 * corrections avoid materializing blend vectors.  This is intentionally a
 * separate entry point: callers should only dispatch here after confirming
 * AVX-512BW+VL support. */
V0X_FORCEINLINE __m512i v0_q6_raw32_ultra_avx512(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m512i vv = _mm512_loadu_si512((const void *)value);
    const __m512i cc = _mm512_loadu_si512((const void *)cost);
    const __m512i tt = _mm512_cvtepu8_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)temperature));
    const __m512i pp = _mm512_cvtepu8_epi16(
        _mm256_loadu_si256((const __m256i *)(const void *)pinned));
    const __m512i mask63 = _mm512_set1_epi16(63);
    const __m512i z = _mm512_setzero_si512();
    const __m512i vq = _mm512_srli_epi16(vv,6);
    const __m512i cq = _mm512_srli_epi16(cc,7);
    const __m512i vr = _mm512_and_si512(vv,mask63);
    const __m512i cr = _mm512_and_si512(_mm512_srli_epi16(cc,1),mask63);
    const __mmask32 kgt = _mm512_cmpgt_epi16_mask(vr,cr);
    const __mmask32 klt = _mm512_cmpgt_epi16_mask(cr,vr);
    const __mmask32 kp = _mm512_cmpneq_epi16_mask(pp,z);
    const __mmask32 kunpinned_lt = (__mmask32)(klt & ~kp);
    const __mmask32 kpinned_gt = (__mmask32)(kgt & kp);
    const __m512i tu = _mm512_add_epi16(tt,_mm512_srli_epi16(tt,1));
    __m512i q = _mm512_add_epi16(_mm512_sub_epi16(vq,cq),tu);
    q = _mm512_mask_add_epi16(q,kp,q,_mm512_set1_epi16(517));
    q = _mm512_mask_sub_epi16(q,kunpinned_lt,q,_mm512_set1_epi16(1));
    q = _mm512_mask_add_epi16(q,kpinned_gt,q,_mm512_set1_epi16(1));
    return q;
}

V0X_FORCEINLINE __m256i v0_eval_v8_raw_block32_ultra_avx512(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    const __m512i z = _mm512_setzero_si512();
    __m512i q = v0_q6_raw32_ultra_avx512(value,cost,temperature,pinned);
    q = _mm512_min_epi16(
        _mm512_max_epi16(_mm512_add_epi16(q,_mm512_set1_epi16(1)),z),
        _mm512_set1_epi16(7));
    {
        const __m256i idx = _mm512_cvtusepi16_epi8(q);
        const __m256i lut = _mm256_setr_epi8(
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0);
        return _mm256_shuffle_epi8(lut,idx);
    }
}

V0X_FORCEINLINE uint32_t v0_preflight_v8_raw_mask32_avx512(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned) {
    return (uint32_t)_mm512_cmpge_epi16_mask(
        v0_q6_raw32_ultra_avx512(value,cost,temperature,pinned),
        _mm512_setzero_si512());
}

static inline uint64_t v0_preflight_v8_raw_count_avx512(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 128 <= n; i += 128) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask32_avx512(value+i,cost+i,temperature+i,pinned+i));
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask32_avx512(value+i+32,cost+i+32,temperature+i+32,pinned+i+32));
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask32_avx512(value+i+64,cost+i+64,temperature+i+64,pinned+i+64));
        count += (uint32_t)__popcnt(v0_preflight_v8_raw_mask32_avx512(value+i+96,cost+i+96,temperature+i+96,pinned+i+96));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask32_avx512(value+i,cost+i,temperature+i,pinned+i));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask32_avx512(value+i+32,cost+i+32,temperature+i+32,pinned+i+32));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask32_avx512(value+i+64,cost+i+64,temperature+i+64,pinned+i+64));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_raw_mask32_avx512(value+i+96,cost+i+96,temperature+i+96,pinned+i+96));
#endif
    }
    if (i < n) count += v0_preflight_v8_raw_count_avx2(
        value+i,cost+i,temperature+i,pinned+i,n-i);
    return count;
}

static inline void v0_eval_v8_raw_batch_ultra_avx512_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i = 0;
#define V0X_RAW512_STORE32(OFF) \
    _mm256_storeu_si256((__m256i *)(void *)(out+i+(OFF)), \
      v0_eval_v8_raw_block32_ultra_avx512(value+i+(OFF),cost+i+(OFF), \
                                          temperature+i+(OFF),pinned+i+(OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_RAW512_STORE32(0);
        V0X_RAW512_STORE32(32);
        V0X_RAW512_STORE32(64);
        V0X_RAW512_STORE32(96);
    }
    for (; i + 32 <= n; i += 32) V0X_RAW512_STORE32(0);
#undef V0X_RAW512_STORE32
    if (i < n) v0_eval_v8_raw_batch_ultra_avx2_u8(
        value+i,cost+i,temperature+i,pinned+i,out+i,n-i);
}


static inline void v0_eval_v8_raw_batch_ultra_stream_avx512_u8(
    const uint16_t *value, const uint16_t *cost,
    const uint8_t *temperature, const uint8_t *pinned,
    uint8_t *out, size_t n) {
    size_t i = 0;
    if ((((uintptr_t)out) & 31u) != 0u) {
        v0_eval_v8_raw_batch_ultra_avx512_u8(value,cost,temperature,pinned,out,n);
        return;
    }
#define V0X_RAW512_STREAM32(OFF) \
    _mm256_stream_si256((__m256i *)(void *)(out+i+(OFF)), \
      v0_eval_v8_raw_block32_ultra_avx512(value+i+(OFF),cost+i+(OFF), \
                                          temperature+i+(OFF),pinned+i+(OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_RAW512_STREAM32(0);
        V0X_RAW512_STREAM32(32);
        V0X_RAW512_STREAM32(64);
        V0X_RAW512_STREAM32(96);
    }
    for (; i + 32 <= n; i += 32) V0X_RAW512_STREAM32(0);
#undef V0X_RAW512_STREAM32
    _mm_sfence();
    if (i < n) v0_eval_v8_raw_batch_ultra_avx2_u8(
        value+i,cost+i,temperature+i,pinned+i,out+i,n-i);
}
#endif /* AVX-512BW + VL */

#endif /* AVX2 V6 */


/* -------------------------------------------------------------------------
 * V7 ULTRA BIAS-FUSED exact paths
 * -------------------------------------------------------------------------
 *
 * These entry points consume the exact 16-bit V7 bias directly:
 *   score = value - (cost >> 1) + bias
 *
 * No thresholds or semantics change.  When temperature/pinned have already
 * been encoded as v0_decision_v7_bias(), reusing bias avoids rebuilding that
 * state in the hot loop.  Public V7 bias-fused entry points require the bias
 * field produced by v0_decision_v7_bias() (the same six legal V7 states).
 * This keeps the scalar LUT access inside the already-validated Q6 domain.
 */

V0X_FORCEINLINE uint32_t v0_eval_v8_bias_ultra_inline(
    uint16_t value, uint16_t cost, uint16_t bias) {
    const int32_t score = (int32_t)(uint32_t)value
                        - (int32_t)((uint32_t)cost >> 1)
                        + (int32_t)(uint32_t)bias;
    return (uint32_t)(V0X_Q6_DIRECT_LUT_V6 + 512)[score >> 6];
}

V0X_FORCEINLINE uint32_t v0_preflight_v8_bias_ultra_inline(
    uint16_t value, uint16_t cost, uint16_t bias) {
    return (uint32_t)(((int32_t)(uint32_t)value
                     - (int32_t)((uint32_t)cost >> 1)
                     + (int32_t)(uint32_t)bias) >= 0);
}

V0X_FORCEINLINE uint32_t v0_decide_v8_bias_ultra_inline(
    uint16_t value, uint16_t cost, uint16_t bias) {
    return v0_eval_v8_bias_ultra_inline(value, cost, bias) & 3u;
}

#if defined(__AVX2__) || defined(_M_AVX2)
/*
 * Exact Q6 identity, lane-wise in i16:
 *   value = 64*vq + vr
 *   cost/2 = 64*cq + cr
 *   bias = 64*bq + br
 *   q6 = vq - cq + bq + floor((vr + br - cr)/64)
 *
 * vr,br,cr are each 0..63, so the residual is in [-63,126].  Therefore one
 * arithmetic >> 6 is the exact floor; no compare/blend correction is needed.
 */
V0X_FORCEINLINE __m256i v0_q6_bias16_ultra_v7_avx2(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i cc = _mm256_loadu_si256((const __m256i *)(const void *)cost);
    const __m256i bb = _mm256_loadu_si256((const __m256i *)(const void *)bias);
    const __m256i m63 = _mm256_set1_epi16(63);
    const __m256i vq = _mm256_srli_epi16(vv, 6);
    const __m256i cq = _mm256_srli_epi16(cc, 7);
    const __m256i bq = _mm256_srli_epi16(bb, 6);
    const __m256i vr = _mm256_and_si256(vv, m63);
    const __m256i cr = _mm256_and_si256(_mm256_srli_epi16(cc, 1), m63);
    const __m256i br = _mm256_and_si256(bb, m63);
    const __m256i residual = _mm256_sub_epi16(_mm256_add_epi16(vr, br), cr);
    const __m256i carry = _mm256_srai_epi16(residual, 6);
    return _mm256_add_epi16(
        _mm256_add_epi16(_mm256_sub_epi16(vq, cq), bq), carry);
}

V0X_FORCEINLINE __m128i v0_eval_v8_bias_block16_ultra_v7_avx2(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m256i z = _mm256_setzero_si256();
    __m256i q = v0_q6_bias16_ultra_v7_avx2(value, cost, bias);
    q = _mm256_min_epi16(
        _mm256_max_epi16(_mm256_add_epi16(q, _mm256_set1_epi16(1)), z),
        _mm256_set1_epi16(7));
    {
        const __m128i idx = _mm_packus_epi16(
            _mm256_castsi256_si128(q), _mm256_extracti128_si256(q, 1));
        const __m128i lut = _mm_setr_epi8(
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0);
        return _mm_shuffle_epi8(lut, idx);
    }
}

V0X_FORCEINLINE __m256i v0_eval_v8_bias_block32_ultra_v7_avx2(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m256i z = _mm256_setzero_si256();
    const __m256i one = _mm256_set1_epi16(1);
    const __m256i seven = _mm256_set1_epi16(7);
    __m256i a = v0_q6_bias16_ultra_v7_avx2(value, cost, bias);
    __m256i b = v0_q6_bias16_ultra_v7_avx2(value+16, cost+16, bias+16);
    a = _mm256_min_epi16(_mm256_max_epi16(_mm256_add_epi16(a, one), z), seven);
    b = _mm256_min_epi16(_mm256_max_epi16(_mm256_add_epi16(b, one), z), seven);
    {
        __m256i idx = _mm256_packus_epi16(a, b);
        idx = _mm256_permute4x64_epi64(idx, _MM_SHUFFLE(3,1,2,0));
        const __m256i lut = _mm256_setr_epi8(
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0);
        return _mm256_shuffle_epi8(lut, idx);
    }
}

static inline void v0_eval_v8_bias_batch_ultra_v7_avx2_u8(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out, size_t n) {
    size_t i = 0;
#define V0X_BIAS7_STORE32(OFF) \
    _mm256_storeu_si256((__m256i *)(void *)(out + i + (OFF)), \
        v0_eval_v8_bias_block32_ultra_v7_avx2( \
            value + i + (OFF), cost + i + (OFF), bias + i + (OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_BIAS7_STORE32(0);  V0X_BIAS7_STORE32(32);
        V0X_BIAS7_STORE32(64); V0X_BIAS7_STORE32(96);
    }
    for (; i + 32 <= n; i += 32) V0X_BIAS7_STORE32(0);
#undef V0X_BIAS7_STORE32
    for (; i + 16 <= n; i += 16)
        _mm_storeu_si128((__m128i *)(void *)(out+i),
            v0_eval_v8_bias_block16_ultra_v7_avx2(value+i,cost+i,bias+i));
    for (; i < n; ++i)
        out[i] = (uint8_t)v0_eval_v8_bias_ultra_inline(value[i], cost[i], bias[i]);
}

/* Write-only large-batch form. 32-byte alignment enables one NT store per
 * 32 decisions; unaligned output falls back to the normal exact path. */
static inline void v0_eval_v8_bias_batch_ultra_v7_stream_avx2_u8(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out, size_t n) {
    size_t i = 0;
    if ((((uintptr_t)out) & 31u) != 0u) {
        v0_eval_v8_bias_batch_ultra_v7_avx2_u8(value, cost, bias, out, n);
        return;
    }
#define V0X_BIAS7_STREAM32(OFF) \
    _mm256_stream_si256((__m256i *)(void *)(out + i + (OFF)), \
        v0_eval_v8_bias_block32_ultra_v7_avx2( \
            value + i + (OFF), cost + i + (OFF), bias + i + (OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_BIAS7_STREAM32(0);  V0X_BIAS7_STREAM32(32);
        V0X_BIAS7_STREAM32(64); V0X_BIAS7_STREAM32(96);
    }
    for (; i + 32 <= n; i += 32) V0X_BIAS7_STREAM32(0);
#undef V0X_BIAS7_STREAM32
    _mm_sfence();
    if (i < n)
        v0_eval_v8_bias_batch_ultra_v7_avx2_u8(value+i,cost+i,bias+i,out+i,n-i);
}

/* Exact preflight-only mask.  value+bias >= cost/2 can be tested with
 * unsigned saturated subtraction, avoiding Q6/tier construction entirely. */
V0X_FORCEINLINE uint32_t v0_preflight_v8_bias_mask16_ultra_v7_avx2(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m256i vv = _mm256_loadu_si256((const __m256i *)(const void *)value);
    const __m256i cc = _mm256_loadu_si256((const __m256i *)(const void *)cost);
    const __m256i bb = _mm256_loadu_si256((const __m256i *)(const void *)bias);
    const __m256i z = _mm256_setzero_si256();
    const __m256i threshold = _mm256_subs_epu16(_mm256_srli_epi16(cc, 1), bb);
    const __m256i deficit = _mm256_subs_epu16(threshold, vv);
    const __m256i yes = _mm256_cmpeq_epi16(deficit, z);
    const __m128i packed = _mm_packs_epi16(
        _mm256_castsi256_si128(yes), _mm256_extracti128_si256(yes, 1));
    return (uint32_t)(unsigned)_mm_movemask_epi8(packed);
}

static inline uint64_t v0_preflight_v8_bias_count_ultra_v7_avx2(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 64 <= n; i += 64) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i,    cost+i,    bias+i));
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i+16, cost+i+16, bias+i+16));
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i+32, cost+i+32, bias+i+32));
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i+48, cost+i+48, bias+i+48));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i,    cost+i,    bias+i));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i+16, cost+i+16, bias+i+16));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i+32, cost+i+32, bias+i+32));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i+48, cost+i+48, bias+i+48));
#endif
    }
    for (; i + 16 <= n; i += 16) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i, cost+i, bias+i));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask16_ultra_v7_avx2(value+i, cost+i, bias+i));
#endif
    }
    for (; i < n; ++i)
        count += (uint64_t)v0_preflight_v8_bias_ultra_inline(value[i], cost[i], bias[i]);
    return count;
}


/* Packed V7 signal AoS batch path. This reads the existing 8-byte
 * v0_decision_signal_v7_t directly, so callers do not need to transpose into
 * SoA arrays merely to obtain SIMD throughput. Exact packed result semantics
 * are unchanged. */
V0X_FORCEINLINE __m256i v0_q6_signal8_ultra_v7_avx2(
    const v0_decision_signal_v7_t *signal) {
    const __m256i even_idx = _mm256_setr_epi32(0,2,4,6,0,0,0,0);
    const __m256i odd_idx  = _mm256_setr_epi32(1,3,5,7,1,1,1,1);
    const __m256i mask16 = _mm256_set1_epi32(65535);
    const __m256i a = _mm256_loadu_si256((const __m256i *)(const void *)signal);
    const __m256i b = _mm256_loadu_si256((const __m256i *)(const void *)(signal + 4));
    const __m256i ae = _mm256_permutevar8x32_epi32(a, even_idx);
    const __m256i be = _mm256_permutevar8x32_epi32(b, even_idx);
    const __m256i ao = _mm256_permutevar8x32_epi32(a, odd_idx);
    const __m256i bo = _mm256_permutevar8x32_epi32(b, odd_idx);
    __m256i vc = _mm256_castsi128_si256(_mm256_castsi256_si128(ae));
    __m256i bi = _mm256_castsi128_si256(_mm256_castsi256_si128(ao));
    vc = _mm256_inserti128_si256(vc, _mm256_castsi256_si128(be), 1);
    bi = _mm256_inserti128_si256(bi, _mm256_castsi256_si128(bo), 1);
    bi = _mm256_and_si256(bi, mask16);
    return _mm256_srai_epi32(
        _mm256_add_epi32(
            _mm256_sub_epi32(_mm256_and_si256(vc, mask16), _mm256_srli_epi32(vc, 17)),
            bi), 6);
}

V0X_FORCEINLINE __m128i v0_eval_v8_signal_block8_ultra_v7_avx2(
    const v0_decision_signal_v7_t *signal) {
    const __m256i q = v0_q6_signal8_ultra_v7_avx2(signal);
    const __m256i m0 = _mm256_cmpgt_epi32(q, _mm256_set1_epi32(-1));
    const __m256i m1 = _mm256_cmpgt_epi32(q, _mm256_setzero_si256());
    const __m256i m3 = _mm256_cmpgt_epi32(q, _mm256_set1_epi32(2));
    const __m256i m6 = _mm256_cmpgt_epi32(q, _mm256_set1_epi32(5));
    const __m256i one = _mm256_set1_epi32(1);
    const __m256i e = _mm256_add_epi32(
        _mm256_and_si256(m0, _mm256_set1_epi32(4)),
        _mm256_add_epi32(
            _mm256_and_si256(m1, one),
            _mm256_add_epi32(_mm256_and_si256(m3, one), _mm256_and_si256(m6, one))));
    const __m128i p16 = _mm_packus_epi32(
        _mm256_castsi256_si128(e), _mm256_extracti128_si256(e, 1));
    return _mm_packus_epi16(p16, _mm_setzero_si128());
}

static inline void v0_eval_v8_signal_batch_ultra_v7_avx2_u8(
    const v0_decision_signal_v7_t *signal, uint8_t *out, size_t n) {
    size_t i = 0;
    for (; i + 32 <= n; i += 32) {
        _mm_storel_epi64((__m128i *)(void *)(out+i),
            v0_eval_v8_signal_block8_ultra_v7_avx2(signal+i));
        _mm_storel_epi64((__m128i *)(void *)(out+i+8),
            v0_eval_v8_signal_block8_ultra_v7_avx2(signal+i+8));
        _mm_storel_epi64((__m128i *)(void *)(out+i+16),
            v0_eval_v8_signal_block8_ultra_v7_avx2(signal+i+16));
        _mm_storel_epi64((__m128i *)(void *)(out+i+24),
            v0_eval_v8_signal_block8_ultra_v7_avx2(signal+i+24));
    }
    for (; i + 8 <= n; i += 8)
        _mm_storel_epi64((__m128i *)(void *)(out+i),
            v0_eval_v8_signal_block8_ultra_v7_avx2(signal+i));
    for (; i < n; ++i)
        out[i] = (uint8_t)v0_eval_v8_signal_ultra_inline(signal+i);
}

#if defined(__AVX512BW__) && defined(__AVX512VL__)
V0X_FORCEINLINE __m512i v0_q6_bias32_ultra_v7_avx512(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m512i vv = _mm512_loadu_si512((const void *)value);
    const __m512i cc = _mm512_loadu_si512((const void *)cost);
    const __m512i bb = _mm512_loadu_si512((const void *)bias);
    const __m512i m63 = _mm512_set1_epi16(63);
    const __m512i vq = _mm512_srli_epi16(vv, 6);
    const __m512i cq = _mm512_srli_epi16(cc, 7);
    const __m512i bq = _mm512_srli_epi16(bb, 6);
    const __m512i vr = _mm512_and_si512(vv, m63);
    const __m512i cr = _mm512_and_si512(_mm512_srli_epi16(cc, 1), m63);
    const __m512i br = _mm512_and_si512(bb, m63);
    const __m512i residual = _mm512_sub_epi16(_mm512_add_epi16(vr, br), cr);
    const __m512i carry = _mm512_srai_epi16(residual, 6);
    return _mm512_add_epi16(
        _mm512_add_epi16(_mm512_sub_epi16(vq, cq), bq), carry);
}

V0X_FORCEINLINE __m256i v0_eval_v8_bias_block32_ultra_v7_avx512(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m512i z = _mm512_setzero_si512();
    __m512i q = v0_q6_bias32_ultra_v7_avx512(value, cost, bias);
    q = _mm512_min_epi16(
        _mm512_max_epi16(_mm512_add_epi16(q, _mm512_set1_epi16(1)), z),
        _mm512_set1_epi16(7));
    {
        const __m256i idx = _mm512_cvtusepi16_epi8(q);
        const __m256i lut = _mm256_setr_epi8(
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0,
            0,4,5,5,6,6,6,7,0,0,0,0,0,0,0,0);
        return _mm256_shuffle_epi8(lut, idx);
    }
}

static inline void v0_eval_v8_bias_batch_ultra_v7_avx512_u8(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out, size_t n) {
    size_t i = 0;
#define V0X_BIAS7_512_STORE32(OFF) \
    _mm256_storeu_si256((__m256i *)(void *)(out + i + (OFF)), \
        v0_eval_v8_bias_block32_ultra_v7_avx512( \
            value + i + (OFF), cost + i + (OFF), bias + i + (OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_BIAS7_512_STORE32(0);  V0X_BIAS7_512_STORE32(32);
        V0X_BIAS7_512_STORE32(64); V0X_BIAS7_512_STORE32(96);
    }
    for (; i + 32 <= n; i += 32) V0X_BIAS7_512_STORE32(0);
#undef V0X_BIAS7_512_STORE32
    if (i < n)
        v0_eval_v8_bias_batch_ultra_v7_avx2_u8(
            value+i, cost+i, bias+i, out+i, n-i);
}

static inline void v0_eval_v8_bias_batch_ultra_v7_stream_avx512_u8(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out, size_t n) {
    size_t i = 0;
    if ((((uintptr_t)out) & 31u) != 0u) {
        v0_eval_v8_bias_batch_ultra_v7_avx512_u8(value, cost, bias, out, n);
        return;
    }
#define V0X_BIAS7_512_STREAM32(OFF) \
    _mm256_stream_si256((__m256i *)(void *)(out + i + (OFF)), \
        v0_eval_v8_bias_block32_ultra_v7_avx512( \
            value + i + (OFF), cost + i + (OFF), bias + i + (OFF)))
    for (; i + 128 <= n; i += 128) {
        V0X_BIAS7_512_STREAM32(0);  V0X_BIAS7_512_STREAM32(32);
        V0X_BIAS7_512_STREAM32(64); V0X_BIAS7_512_STREAM32(96);
    }
    for (; i + 32 <= n; i += 32) V0X_BIAS7_512_STREAM32(0);
#undef V0X_BIAS7_512_STREAM32
    _mm_sfence();
    if (i < n)
        v0_eval_v8_bias_batch_ultra_v7_avx2_u8(
            value+i, cost+i, bias+i, out+i, n-i);
}

V0X_FORCEINLINE uint32_t v0_preflight_v8_bias_mask32_ultra_v7_avx512(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m512i vv = _mm512_loadu_si512((const void *)value);
    const __m512i cc = _mm512_loadu_si512((const void *)cost);
    const __m512i bb = _mm512_loadu_si512((const void *)bias);
    const __m512i threshold = _mm512_subs_epu16(_mm512_srli_epi16(cc, 1), bb);
    return (uint32_t)_mm512_cmpge_epu16_mask(vv, threshold);
}

static inline uint64_t v0_preflight_v8_bias_count_ultra_v7_avx512(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias, size_t n) {
    uint64_t count = 0;
    size_t i = 0;
    for (; i + 128 <= n; i += 128) {
#if defined(_MSC_VER)
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i,    cost+i,    bias+i));
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i+32, cost+i+32, bias+i+32));
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i+64, cost+i+64, bias+i+64));
        count += (uint32_t)__popcnt(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i+96, cost+i+96, bias+i+96));
#else
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i,    cost+i,    bias+i));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i+32, cost+i+32, bias+i+32));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i+64, cost+i+64, bias+i+64));
        count += (uint32_t)__builtin_popcount(v0_preflight_v8_bias_mask32_ultra_v7_avx512(value+i+96, cost+i+96, bias+i+96));
#endif
    }
    if (i < n)
        count += v0_preflight_v8_bias_count_ultra_v7_avx2(
            value+i, cost+i, bias+i, n-i);
    return count;
}



/* Direct SIMD over the existing 8-byte packed V7 signal. Two 64-byte loads
 * contain 16 records; VPERMT2D deinterleaves value_cost and bias without an
 * SoA conversion pass. */
V0X_FORCEINLINE __m512i v0_q6_signal16_ultra_v7_avx512(
    const v0_decision_signal_v7_t *signal) {
    const __m512i a = _mm512_loadu_si512((const void *)signal);
    const __m512i b = _mm512_loadu_si512((const void *)(signal + 8));
    const __m512i even_idx = _mm512_setr_epi32(
        0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30);
    const __m512i odd_idx = _mm512_setr_epi32(
        1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31);
    const __m512i mask16 = _mm512_set1_epi32(65535);
    const __m512i vc = _mm512_permutex2var_epi32(a, even_idx, b);
    const __m512i bi = _mm512_and_si512(_mm512_permutex2var_epi32(a, odd_idx, b), mask16);
    return _mm512_srai_epi32(
        _mm512_add_epi32(
            _mm512_sub_epi32(_mm512_and_si512(vc, mask16), _mm512_srli_epi32(vc, 17)),
            bi), 6);
}

V0X_FORCEINLINE __m128i v0_eval_v8_signal_block16_ultra_v7_avx512(
    const v0_decision_signal_v7_t *signal) {
    const __m512i q = v0_q6_signal16_ultra_v7_avx512(signal);
    const __mmask16 k0 = _mm512_cmpge_epi32_mask(q, _mm512_setzero_si512());
    const __mmask16 k1 = _mm512_cmpge_epi32_mask(q, _mm512_set1_epi32(1));
    const __mmask16 k3 = _mm512_cmpge_epi32_mask(q, _mm512_set1_epi32(3));
    const __mmask16 k6 = _mm512_cmpge_epi32_mask(q, _mm512_set1_epi32(6));
    const __m128i one = _mm_set1_epi8(1);
    __m128i e = _mm_maskz_set1_epi8(k0, 4);
    e = _mm_mask_add_epi8(e, k1, e, one);
    e = _mm_mask_add_epi8(e, k3, e, one);
    e = _mm_mask_add_epi8(e, k6, e, one);
    return e;
}

static inline void v0_eval_v8_signal_batch_ultra_v7_avx512_u8(
    const v0_decision_signal_v7_t *signal, uint8_t *out, size_t n) {
    size_t i = 0;
    for (; i + 64 <= n; i += 64) {
        _mm_storeu_si128((__m128i *)(void *)(out+i),
            v0_eval_v8_signal_block16_ultra_v7_avx512(signal+i));
        _mm_storeu_si128((__m128i *)(void *)(out+i+16),
            v0_eval_v8_signal_block16_ultra_v7_avx512(signal+i+16));
        _mm_storeu_si128((__m128i *)(void *)(out+i+32),
            v0_eval_v8_signal_block16_ultra_v7_avx512(signal+i+32));
        _mm_storeu_si128((__m128i *)(void *)(out+i+48),
            v0_eval_v8_signal_block16_ultra_v7_avx512(signal+i+48));
    }
    for (; i + 16 <= n; i += 16)
        _mm_storeu_si128((__m128i *)(void *)(out+i),
            v0_eval_v8_signal_block16_ultra_v7_avx512(signal+i));
    if (i < n)
        v0_eval_v8_signal_batch_ultra_v7_avx2_u8(signal+i, out+i, n-i);
}

#if defined(__AVX512VBMI__)
/* Optional 64-item output fusion for CPUs with VBMI.  Two 32-lane Q6 vectors
 * are converted to byte indices, joined, and resolved by one VPERMB + store. */
V0X_FORCEINLINE __m512i v0_eval_v8_bias_block64_ultra_v7_avx512vbmi(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias) {
    const __m512i z = _mm512_setzero_si512();
    const __m512i one = _mm512_set1_epi16(1);
    const __m512i seven = _mm512_set1_epi16(7);
    __m512i a = v0_q6_bias32_ultra_v7_avx512(value, cost, bias);
    __m512i b = v0_q6_bias32_ultra_v7_avx512(value+32, cost+32, bias+32);
    a = _mm512_min_epi16(_mm512_max_epi16(_mm512_add_epi16(a, one), z), seven);
    b = _mm512_min_epi16(_mm512_max_epi16(_mm512_add_epi16(b, one), z), seven);
    {
        const __m256i ia = _mm512_cvtusepi16_epi8(a);
        const __m256i ib = _mm512_cvtusepi16_epi8(b);
        __m512i idx = _mm512_castsi256_si512(ia);
        idx = _mm512_inserti64x4(idx, ib, 1);
        return _mm512_permutexvar_epi8(
            idx, _mm512_set1_epi64((long long)0x0706060605050400ULL));
    }
}

static inline void v0_eval_v8_bias_batch_ultra_v7_avx512vbmi_u8(
    const uint16_t *value, const uint16_t *cost, const uint16_t *bias,
    uint8_t *out, size_t n) {
    size_t i = 0;
    for (; i + 128 <= n; i += 128) {
        _mm512_storeu_si512((void *)(out+i),
            v0_eval_v8_bias_block64_ultra_v7_avx512vbmi(value+i,cost+i,bias+i));
        _mm512_storeu_si512((void *)(out+i+64),
            v0_eval_v8_bias_block64_ultra_v7_avx512vbmi(value+i+64,cost+i+64,bias+i+64));
    }
    for (; i + 64 <= n; i += 64)
        _mm512_storeu_si512((void *)(out+i),
            v0_eval_v8_bias_block64_ultra_v7_avx512vbmi(value+i,cost+i,bias+i));
    if (i < n)
        v0_eval_v8_bias_batch_ultra_v7_avx512_u8(value+i,cost+i,bias+i,out+i,n-i);
}
#endif /* AVX512VBMI */

#endif /* AVX-512BW + VL */
#endif /* AVX2 */

#ifdef __cplusplus
}
#endif
#endif

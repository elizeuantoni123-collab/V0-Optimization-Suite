# V0 Decision V8 ULTRA V10

V10 is an additive optimization layer over V9.  It does not replace or edit the inherited V9 implementation.

## Promotion rule

A path is promoted only when it is exact and measurably faster than the previous promoted path.  Experiments that lost speed were rejected and are listed in `reports/V10_REJECTED_CANDIDATES.txt`.

## New promoted paths

1. **One-shot raw AVX2** — recentered `0x8000` classifier, two-block overlap.
2. **One-shot raw AVX-512VL** — 256-bit arithmetic with AVX-512 masks; pinned is folded into the recentered gate before classification.
3. **Cached `gate16` descriptor** — exact 16-bit descriptor containing all cost/temperature/pinned information used by Decision.
4. **Cached gate16 preflight** — preflight is exactly bit 15 of the saturated `value + gate16` sum.
5. **Optional large write-only streaming output** — non-temporal stores; not a default path.

## Important gate16 rule

`gate16` has a build cost.  Do not build it for a single one-shot Decision call.

In the paired measurements in this package:

- 1 reuse: slower than V10 raw;
- 2 reuses: still slightly slower;
- 3 reuses: often faster, but not sufficiently stable across all native runs;
- **4+ reuses: consistently faster in the tested AVX2/native runs.**

Therefore V10 recommends gate16 only when the descriptor is expected to be reused at least four times, or when the caller independently benchmarks a lower break-even point on its target CPU.

## Correctness

Final Linux validation was executed twice:

- AVX2-only: **23,758,620 cases, 0 divergences**
- native/AVX-512: **23,758,620 cases, 0 divergences**

The test set includes 20 million random full-range signals, directed threshold neighborhoods, the full 16-bit `value` domain for representative cost/temperature/pinned combinations, and all tails from 0 through 257.

## Compatibility

All inherited V9 files are kept byte-for-byte unchanged.  See `reports/V10_INHERITED_V9_INTEGRITY.txt`.

## Windows

- `TESTAR_ULTRA_V10.ps1` — builds and runs the AVX2 validation with MSVC.
- `BENCHMARK_ULTRA_V10_WINDOWS.ps1` — paired V9/V10 AVX2 benchmark on the target Windows PC.

Absolute sub-nanosecond figures in the reports are amortized batch throughput per item, not single-call latency.

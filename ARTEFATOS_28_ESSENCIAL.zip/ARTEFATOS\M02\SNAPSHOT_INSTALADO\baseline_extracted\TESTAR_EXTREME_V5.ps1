$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$Test = Join-Path $Root "tests\validate_v8_extreme.c"
$Include = Join-Path $Root "include"
$ObjV7 = Join-Path $Root "build\windows\v0_decision_v7.obj"
$ObjQ6 = Join-Path $Root "build\windows\v0_decision_v8_q6.obj"
$OutDir = Join-Path $Root "windows_permanent\build"
$Exe = Join-Path $OutDir "ValidateV8Extreme.exe"

$vcvarsCandidates = @(
    "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat",
    "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
)
$VcVars = $vcvarsCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $VcVars) { throw "Visual Studio 2022 C++ Build Tools x64 nao encontrado." }
foreach ($f in @($Test,$ObjV7,$ObjQ6)) { if (-not (Test-Path $f)) { throw "Arquivo ausente: $f" } }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

Write-Host "V0 Decision V8 EXTREME V5 - validacao Windows" -ForegroundColor Cyan
Write-Host "Compilando com AVX2..." -ForegroundColor Yellow
$cmd = "`"$VcVars`" && cl /nologo /O2 /arch:AVX2 /D__AVX2__=1 /I`"$Include`" `"$Test`" `"$ObjV7`" `"$ObjQ6`" /Fe:`"$Exe`""
cmd /c $cmd
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $Exe)) { throw "Falha ao compilar a validacao V5." }

Write-Host "Executando validacao exaustiva + 20.000.000 sinais..." -ForegroundColor Yellow
& $Exe
if ($LASTEXITCODE -ne 0) { throw "V5 falhou na validacao (exit $LASTEXITCODE)." }
Write-Host "V5 PASS - 0 divergencias." -ForegroundColor Green

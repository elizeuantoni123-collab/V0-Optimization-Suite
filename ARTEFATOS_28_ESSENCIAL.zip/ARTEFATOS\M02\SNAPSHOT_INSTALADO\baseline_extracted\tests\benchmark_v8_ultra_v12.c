#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_ultra_v12.h"
#define N (1u<<20)
#define REPS 17
static volatile uint64_t sink; static uint16_t *v,*c,*g,*go; static uint8_t *t,*p;
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return*s=x;}
static void pin0(void){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);}
static double eval11(void){uint64_t a=now_ns(),q=0;for(int k=0;k<24;k++)for(size_t i=0;i<N;i++)q+=v0_eval_gate16_v11_scalar_lut_inline(v[i],g[i]);uint64_t z=now_ns();sink+=q;return(double)(z-a)/(N*24.0);}
static double eval12(void){uint64_t a=now_ns(),q=0;for(int k=0;k<24;k++)for(size_t i=0;i<N;i++)q+=v0_eval_gate16_v12_scalar_direct_inline(v[i],g[i]);uint64_t z=now_ns();sink+=q;return(double)(z-a)/(N*24.0);}
static double build10(void){volatile uint16_t*cc=c;volatile uint8_t*tt=t,*pp=p;uint64_t a=now_ns();for(size_t i=0;i<N;i++)go[i]=v0_decision_gate16_v10(cc[i],tt[i],pp[i]);uint64_t z=now_ns();sink+=go[777];return(double)(z-a)/N;}
static double build12(void){volatile uint16_t*cc=c;volatile uint8_t*tt=t,*pp=p;uint64_t a=now_ns();for(size_t i=0;i<N;i++)go[i]=v0_decision_gate16_v12_branchless(cc[i],tt[i],pp[i]);uint64_t z=now_ns();sink+=go[777];return(double)(z-a)/N;}
static double med(double(*f)(void)){double x[REPS];for(int k=0;k<3;k++)f();for(int i=0;i<REPS;i++)x[i]=f();qsort(x,REPS,sizeof(double),cmpd);return x[REPS/2];}
int main(void){pin0();posix_memalign((void**)&v,64,N*2);posix_memalign((void**)&c,64,N*2);posix_memalign((void**)&g,64,N*2);posix_memalign((void**)&go,64,N*2);posix_memalign((void**)&t,64,N);posix_memalign((void**)&p,64,N);uint64_t s=0xA0761D6478BD642FULL;for(size_t i=0;i<N;i++){v[i]=(uint16_t)rng64(&s);c[i]=(uint16_t)rng64(&s);t[i]=(uint8_t)(rng64(&s)%3u);p[i]=(uint8_t)(rng64(&s)&1u);g[i]=v0_decision_gate16_v10(c[i],t[i],p[i]);}double a=med(eval11),b=med(eval12),c0=med(build10),d=med(build12);printf("V11 scalar gate16 p50=%.6f ns/item\n",a);printf("V12 scalar direct2K p50=%.6f ns/item speedup=%.4fx\n",b,a/b);printf("V10 scalar gate builder p50=%.6f ns/item\n",c0);printf("V12 branchless gate builder p50=%.6f ns/item speedup=%.4fx\n",d,c0/d);printf("sink=%llu\n",(unsigned long long)sink);return 0;}

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/compiler/v0lc_batch_avx2_quadload_v27.py" \
  "$ROOT/src/v0_batch_plan64_avx2_quadload_v27.v0l" \
  "$ROOT/build/linux/v0_batch_plan64_avx2_quadload_v27.o"

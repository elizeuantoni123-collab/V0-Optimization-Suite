# Artefato 12 — V0 KV Window Manager V6 SAFE → V7 Exact-Pair SSE2 Squeeze

## Baseline

`V0_KV_WINDOW_MANAGER_V6_SAFE_PROMOTED.zip` is preserved unchanged under `baseline/`.

V6 already has a mature count-only composite dispatcher, inherited V1/V3/V4/V5 kernels, and V6 exact-capacity K3/K5 planners. The new work does not modify those objects.

## New candidate

The V6 K5 planner is generic for capacity 5, although production dispatch promotes it only for exact pairs `1→5` and `5→1`. V7 specializes only those two pairs.

New V0L exports:
- `v0_kv_window5_1to5_v7`
- `v0_kv_window5_5to1_v7`

Implementation:
- SSE2 equality against the first four IDs;
- one scalar equality for the fifth ID;
- exact enter/leave masks;
- no count checks inside the kernel because exact counts are dispatcher preconditions;
- return value is exactly 1 because sets with cardinalities 1 and 5 cannot be unchanged.

The final V7 object contains only these two functions:
- `.text`: 187 B
- `.rodata`: 0 B
- relocations: 0
- Linux ELF64 and Windows x86-64 COFF generated directly by V0L compiler.

## Correctness

Final object versus canonical reference and actual V6 object:
- `1→5`: 10,000,000 randomized cases, 0 divergences;
- `5→1`: 10,000,000 randomized cases, 0 divergences;
- total: **20,000,000 cases, 0 divergences**.

The earlier experimental `3→2` SSE2 path was also correct but is not selected because expanded performance testing had isolated regressions. V6 remains active for `3→2`.

## Final local performance gate

Five independent benchmark processes. Each process tests 8 overlap/access patterns, 2,000,000 calls per measurement, 17 paired A/B rounds per pattern.

### 1→5
- representative baseline median: **6.410520 ns/call**
- representative V7 median: **3.037688 ns/call**
- median speedup across scenario/process medians: **2.104974x**
- worst process-median speedup: **2.048098x**
- worst individual paired round: **1.352814x**
- wins: **680/680**

### 5→1
- representative baseline median: **6.750024 ns/call**
- representative V7 median: **3.220346 ns/call**
- median speedup across scenario/process medians: **2.032680x**
- worst process-median speedup: **1.844803x**
- worst individual paired round: **1.171580x**
- wins: **680/680**

These are kernel-call results, not end-to-end application latency.

## Decision

**LOCAL_PASS / WINDOWS_GATE_REQUIRED**

V6 stays promoted. V7 is an additive candidate for only `1→5` and `5→1` until the Intel/Windows target gate confirms the result.

# Permanent Windows host — V8 compatibility

V8 does not alter the permanent named-pipe service or the validated V7/V6 native objects. The new optimization layer is header/API-side and remains compatible with the existing host/control plane.

Use `TESTAR_ULTRA_V8.ps1` first to validate the AVX2 paths on the target Windows machine, then `BENCHMARK_ULTRA_V8_WINDOWS.ps1` for a paired V7/V8 measurement. Optional AVX-512/meta8 paths should be enabled only after target-machine benchmarking.

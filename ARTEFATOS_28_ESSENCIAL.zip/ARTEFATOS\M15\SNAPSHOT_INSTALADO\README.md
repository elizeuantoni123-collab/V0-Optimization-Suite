# Artefato 15 — Prefetch

Resultado: **KEEP_BASELINE**.

Use `baseline/baseline_archive_V2_SAFE.zip` como versão promovida. A pasta `rejected_search/` contém somente candidatos experimentais rejeitados e não deve entrar no dispatcher de produção.

Veja `REPORT.md` para os gates e `results/` para os CSVs A/B.

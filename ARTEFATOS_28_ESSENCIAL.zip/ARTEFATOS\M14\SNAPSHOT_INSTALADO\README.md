# Artefato 14 — V0 Compression V10 SAFE — KEEP BASELINE

Baseline promovida: `V0_COMPRESSION_V0L_V10_SAFE_PROMOTED.zip`.

Foi testado um candidato V12 aditivo para decodificação de streams canônicos zero/uniforme, preservando o wire format RLE V1 e mantendo os decoders V2/V3 como referência.

Resultado: correção passou, mas o candidato não cumpriu o gate permanente de zero regressão em todos os alinhamentos/rodadas. Portanto **não é promovido**.

A V10 continua sendo a baseline.

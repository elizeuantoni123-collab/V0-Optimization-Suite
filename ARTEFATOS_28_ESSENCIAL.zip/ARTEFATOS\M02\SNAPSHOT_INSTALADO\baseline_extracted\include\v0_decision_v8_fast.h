#ifndef V0_DECISION_V8_FAST_H
#define V0_DECISION_V8_FAST_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_MSC_VER)
#define V0_FORCEINLINE static __forceinline
#elif defined(__GNUC__) || defined(__clang__)
#define V0_FORCEINLINE static inline __attribute__((always_inline))
#else
#define V0_FORCEINLINE static inline
#endif

typedef int32_t v0_decision_score_v8_t;

/*
 * Exact bias table for valid input domain:
 * index = temperature + 3*pinned
 * 0,1,2 => COLD/WARM/HOT unpinned
 * 3,4,5 => COLD/WARM/HOT pinned
 *
 * 24 bytes total. Once hot, this avoids rebuilding the temperature and PIN
 * bias arithmetically on every raw-input evaluation.
 */
V0_FORCEINLINE int32_t v0_decision_v8_bias_fast(uint8_t temperature, uint8_t pinned) {
    static const int32_t bias[6] = { 0, 64, 192, 33151, 33215, 33343 };
    return bias[(uint32_t)temperature + 3u * (uint32_t)pinned];
}

/* Fastest raw-input score builder for hot/repeated use. */
V0_FORCEINLINE v0_decision_score_v8_t v0_decision_v8_score(
    uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    return (int32_t)(uint32_t)value
         - (int32_t)((uint32_t)cost >> 1)
         + v0_decision_v8_bias_fast(temperature, pinned);
}

/* No-table variant for cold/standalone use; exactly equivalent. */
V0_FORCEINLINE v0_decision_score_v8_t v0_decision_v8_score_arith(
    uint16_t value, uint16_t cost, uint8_t temperature, uint8_t pinned) {
    const uint32_t t = (uint32_t)temperature;
    return (int32_t)(uint32_t)value
         - (int32_t)((uint32_t)cost >> 1)
         + (int32_t)((t + (t >> 1)) << 6)
         + (int32_t)((uint32_t)pinned * 33151u);
}

/* V0L native scalar-score ABI. */
uint32_t v0_preflight_v0l_v8_fast(uint32_t score_bits);
uint32_t v0_decide_v0l_v8_fast(uint32_t score_bits);
uint32_t v0_eval_v0l_v8_fast(uint32_t score_bits);

/* Absolute-minimum in-process path: lets the host compiler remove call ABI. */
V0_FORCEINLINE uint32_t v0_preflight_v8_inline(v0_decision_score_v8_t score) {
    return (uint32_t)(score >= 0);
}

V0_FORCEINLINE uint32_t v0_decide_v8_inline(v0_decision_score_v8_t score) {
    return (uint32_t)(score >= 64)
         + (uint32_t)(score >= 192)
         + (uint32_t)(score >= 384);
}

V0_FORCEINLINE uint32_t v0_eval_v8_inline(v0_decision_score_v8_t score) {
    return (v0_preflight_v8_inline(score) << 2) | v0_decide_v8_inline(score);
}

V0_FORCEINLINE uint32_t v0_eval_v8_preflight(uint32_t packed) {
    return (packed >> 2) & 1u;
}

V0_FORCEINLINE uint32_t v0_eval_v8_decision(uint32_t packed) {
    return packed & 3u;
}

#ifdef __cplusplus
}
#endif
#endif

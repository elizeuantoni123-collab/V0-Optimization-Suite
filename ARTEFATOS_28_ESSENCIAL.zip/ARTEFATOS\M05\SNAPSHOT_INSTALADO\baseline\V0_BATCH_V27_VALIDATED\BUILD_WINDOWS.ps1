$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Out = Join-Path $Root "build\windows"
New-Item -ItemType Directory -Force -Path $Out | Out-Null
python "$Root\compiler\v0lc_count.py" "$Root\src\v0_batch_count.v0l" "$Out\v0_batch_count.obj" --target windows
python "$Root\compiler\v0lc_primitives.py" "$Root\src\v0_batch_take.v0l" "$Out\v0_batch_take.obj" --target windows
python "$Root\compiler\v0lc_primitives.py" "$Root\src\v0_batch_fixed64.v0l" "$Out\v0_batch_fixed64.obj" --target windows
python "$Root\compiler\v0lc_plan64.py" "$Root\src\v0_batch_plan64.v0l" "$Out\v0_batch_plan64.obj" --target windows
python "$Root\compiler\v0lc_plan64x4.py" "$Root\src\v0_batch_plan64x4.v0l" "$Out\v0_batch_plan64x4.obj" --target windows
Write-Host "Windows x86-64 COFF objects rebuilt."

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_decision_v8_extreme.h"
#define N (1u<<20)
#define REPS 21
static uint16_t *value,*cost,*bias;static uint8_t *temp,*pin,*out;static volatile uint64_t sink;
static uint64_t now_ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+(uint64_t)x.tv_nsec;}
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static void pin0(void){cpu_set_t c;CPU_ZERO(&c);CPU_SET(0,&c);(void)sched_setaffinity(0,sizeof(c),&c);}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double raw_scalar_v6(void){uint64_t z=0,t=now_ns();for(size_t i=0;i<N;i++)z+=v0_eval_v8_raw_ultra_inline(value[i],cost[i],temp[i],pin[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((optimize("no-tree-vectorize")))
#endif
static double bias_scalar_v7(void){uint64_t z=0,t=now_ns();for(size_t i=0;i<N;i++)z+=v0_eval_v8_bias_ultra_inline(value[i],cost[i],bias[i]);uint64_t e=now_ns();sink=z;return(double)(e-t)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
static double raw_batch_v6_a2(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_avx2_u8(value,cost,temp,pin,out,N);uint64_t e=now_ns();sink+=out[777];return(double)(e-t)/N;}
static double bias_batch_v7_a2(void){uint64_t t=now_ns();v0_eval_v8_bias_batch_ultra_v7_avx2_u8(value,cost,bias,out,N);uint64_t e=now_ns();sink+=out[777];return(double)(e-t)/N;}
static double raw_pre_v6_a2(void){uint64_t t=now_ns(),z=v0_preflight_v8_raw_count_avx2(value,cost,temp,pin,N),e=now_ns();sink+=z;return(double)(e-t)/N;}
static double bias_pre_v7_a2(void){uint64_t t=now_ns(),z=v0_preflight_v8_bias_count_ultra_v7_avx2(value,cost,bias,N),e=now_ns();sink+=z;return(double)(e-t)/N;}
#if defined(__AVX512BW__) && defined(__AVX512VL__)
static double raw_batch_v6_a5(void){uint64_t t=now_ns();v0_eval_v8_raw_batch_ultra_avx512_u8(value,cost,temp,pin,out,N);uint64_t e=now_ns();sink+=out[777];return(double)(e-t)/N;}
static double bias_batch_v7_a5(void){uint64_t t=now_ns();v0_eval_v8_bias_batch_ultra_v7_avx512_u8(value,cost,bias,out,N);uint64_t e=now_ns();sink+=out[777];return(double)(e-t)/N;}
static double raw_pre_v6_a5(void){uint64_t t=now_ns(),z=v0_preflight_v8_raw_count_avx512(value,cost,temp,pin,N),e=now_ns();sink+=z;return(double)(e-t)/N;}
static double bias_pre_v7_a5(void){uint64_t t=now_ns(),z=v0_preflight_v8_bias_count_ultra_v7_avx512(value,cost,bias,N),e=now_ns();sink+=z;return(double)(e-t)/N;}
#if defined(__AVX512VBMI__)
static double bias_batch_v7_vbmi(void){uint64_t t=now_ns();v0_eval_v8_bias_batch_ultra_v7_avx512vbmi_u8(value,cost,bias,out,N);uint64_t e=now_ns();sink+=out[777];return(double)(e-t)/N;}
#endif
#endif
#endif
static void bench(const char*n,double(*fn)(void)){double v[REPS];for(int i=0;i<7;i++)(void)fn();for(int i=0;i<REPS;i++)v[i]=fn();qsort(v,REPS,sizeof(double),cmpd);printf("%-31s p50=%8.5f best=%8.5f ns/item\n",n,v[REPS/2],v[0]);}
int main(void){pin0();value=aligned_alloc(64,N*2);cost=aligned_alloc(64,N*2);bias=aligned_alloc(64,N*2);temp=aligned_alloc(64,N);pin=aligned_alloc(64,N);out=aligned_alloc(64,N);if(!value||!cost||!bias||!temp||!pin||!out)return 2;uint64_t st=0x243f6a8885a308d3ULL;for(size_t i=0;i<N;i++){value[i]=(uint16_t)rng64(&st);cost[i]=(uint16_t)rng64(&st);temp[i]=(uint8_t)(rng64(&st)%3u);pin[i]=(uint8_t)(rng64(&st)&1u);bias[i]=v0_decision_v7_bias(temp[i],pin[i]);if(v0_eval_v8_bias_ultra_inline(value[i],cost[i],bias[i])!=v0_eval_v8_raw_ultra_inline(value[i],cost[i],temp[i],pin[i]))return 3;}
bench("V6 raw scalar",raw_scalar_v6);bench("V7 bias scalar",bias_scalar_v7);
#if defined(__AVX2__) || defined(_M_AVX2)
bench("V6 raw batch AVX2",raw_batch_v6_a2);bench("V7 bias batch AVX2",bias_batch_v7_a2);bench("V6 raw preflight AVX2",raw_pre_v6_a2);bench("V7 bias preflight AVX2",bias_pre_v7_a2);
#if defined(__AVX512BW__) && defined(__AVX512VL__)
bench("V6 raw batch AVX512",raw_batch_v6_a5);bench("V7 bias batch AVX512",bias_batch_v7_a5);
#if defined(__AVX512VBMI__)
bench("V7 bias batch AVX512VBMI",bias_batch_v7_vbmi);
#endif
bench("V6 raw preflight AVX512",raw_pre_v6_a5);bench("V7 bias preflight AVX512",bias_pre_v7_a5);
#endif
#endif
printf("sink=%llu\n",(unsigned long long)sink);return 0;}

#include <stdint.h>
#include <stdio.h>
typedef struct { uint32_t semantic_id, semantic_score, exact_key, valid; } rec;
extern uint64_t v0_semantic_score_key64_trusted(const rec*);
static uint64_t rng=0x9e3779b97f4a7c15ull;
static uint32_t rnd32(void){ rng^=rng<<7; rng^=rng>>9; rng^=rng<<8; return (uint32_t)rng; }
int main(void){
    uint64_t checks=0, bad=0;
    for(uint32_t i=0;i<20000000u;i++){
        rec r={rnd32(),rnd32(),rnd32(),rnd32()&1u};
        uint64_t exp=((uint64_t)r.exact_key<<32)|r.semantic_score;
        uint64_t got=v0_semantic_score_key64_trusted(&r);
        checks++;
        if(got!=exp){bad++; if(bad<4) printf("mismatch i=%u got=%016llx exp=%016llx\n",i,(unsigned long long)got,(unsigned long long)exp);}
    }
    printf("checks=%llu divergences=%llu\n",(unsigned long long)checks,(unsigned long long)bad);
    return bad?1:0;
}

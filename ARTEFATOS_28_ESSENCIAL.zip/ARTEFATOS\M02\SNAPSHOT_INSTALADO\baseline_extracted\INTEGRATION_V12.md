# V0 Decision V8 ULTRA V12 — integração

V12 é uma camada **aditiva** sobre V11. Nenhuma função V11/V10 é substituída automaticamente.

## Fast paths promovidos

### 1. Construção scalar de gate16
Use `v0_decision_gate16_v12_branchless(cost, temperature, pinned)` quando o descritor gate16 é preparado scalarmente. O domínio validado permanece `temperature=0..2`, `pinned=0/1`.

### 2. Avaliação scalar de gate16 já pronto
Use `v0_eval_gate16_v12_scalar_direct_inline(value, gate)` quando `gate16` já existe. A LUT direta de 2 KiB elimina clamp/saturação do hot path.

### 3. Preflight
Continue usando a aritmética herdada de V10 (`v0_preflight_gate16_v10_inline`) — V12 a expõe via `v0_preflight_gate16_v12_scalar_inline`. LUT não é usada no preflight porque não ganhou.

## O que continua V11/V10
Raw one-shot, AVX2/AVX-512 batch, nibble streaming, short-batch automático e todos os fallbacks existentes permanecem exatamente inalterados.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/v0_decision_v8_extreme.h"
#define N (1u << 20)
#define REPS 15
static uint16_t *g_value,*g_cost,*g_bias;
static uint8_t *g_temp,*g_pin,*g_out;
static v0_decision_signal_v7_t *g_sig;
static volatile uint64_t g_sink; static LARGE_INTEGER g_freq;
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;return *s=x;}
static double now_ns(void){LARGE_INTEGER q;QueryPerformanceCounter(&q);return(double)q.QuadPart*1.0e9/(double)g_freq.QuadPart;}
static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return x<y?-1:x>y;}
static double raw_scalar(void){uint64_t z=0;double a=now_ns();for(size_t i=0;i<N;i++)z+=v0_eval_v8_raw_ultra_inline(g_value[i],g_cost[i],g_temp[i],g_pin[i]);double b=now_ns();g_sink=z;return(b-a)/N;}
static double bias_scalar(void){uint64_t z=0;double a=now_ns();for(size_t i=0;i<N;i++)z+=v0_eval_v8_bias_ultra_inline(g_value[i],g_cost[i],g_bias[i]);double b=now_ns();g_sink=z;return(b-a)/N;}
static double packed_scalar(void){uint64_t z=0;double a=now_ns();for(size_t i=0;i<N;i++)z+=v0_eval_v8_signal_ultra_inline(g_sig+i);double b=now_ns();g_sink=z;return(b-a)/N;}
#if defined(__AVX2__) || defined(_M_AVX2)
static double raw_batch(void){double a=now_ns();v0_eval_v8_raw_batch_ultra_avx2_u8(g_value,g_cost,g_temp,g_pin,g_out,N);double b=now_ns();g_sink+=g_out[777];return(b-a)/N;}
static double bias_batch(void){double a=now_ns();v0_eval_v8_bias_batch_ultra_v7_avx2_u8(g_value,g_cost,g_bias,g_out,N);double b=now_ns();g_sink+=g_out[777];return(b-a)/N;}
static double raw_preflight(void){double a=now_ns();uint64_t z=v0_preflight_v8_raw_count_avx2(g_value,g_cost,g_temp,g_pin,N);double b=now_ns();g_sink+=z;return(b-a)/N;}
static double bias_preflight(void){double a=now_ns();uint64_t z=v0_preflight_v8_bias_count_ultra_v7_avx2(g_value,g_cost,g_bias,N);double b=now_ns();g_sink+=z;return(b-a)/N;}
static double packed_batch(void){double a=now_ns();v0_eval_v8_signal_batch_ultra_v7_avx2_u8(g_sig,g_out,N);double b=now_ns();g_sink+=g_out[777];return(b-a)/N;}
#endif
static void bench(const char*n,double(*f)(void)){double v[REPS];for(int i=0;i<5;i++)f();for(int i=0;i<REPS;i++)v[i]=f();qsort(v,REPS,sizeof(double),cmpd);printf("%-31s p50=%9.4f ns/item best=%9.4f\n",n,v[REPS/2],v[0]);}
int main(void){
 QueryPerformanceFrequency(&g_freq);SetThreadAffinityMask(GetCurrentThread(),1);
 g_value=(uint16_t*)_aligned_malloc(N*2,64);g_cost=(uint16_t*)_aligned_malloc(N*2,64);g_bias=(uint16_t*)_aligned_malloc(N*2,64);
 g_temp=(uint8_t*)_aligned_malloc(N,64);g_pin=(uint8_t*)_aligned_malloc(N,64);g_out=(uint8_t*)_aligned_malloc(N,64);g_sig=(v0_decision_signal_v7_t*)_aligned_malloc(N*sizeof(*g_sig),64);
 if(!g_value||!g_cost||!g_bias||!g_temp||!g_pin||!g_out||!g_sig)return 2;
 uint64_t r=0x9e3779b97f4a7c15ULL;for(size_t i=0;i<N;i++){g_value[i]=(uint16_t)rng64(&r);g_cost[i]=(uint16_t)rng64(&r);g_temp[i]=(uint8_t)(rng64(&r)%3u);g_pin[i]=(uint8_t)(rng64(&r)&1u);g_bias[i]=v0_decision_v7_bias(g_temp[i],g_pin[i]);g_sig[i]=v0_decision_v7_pack(g_value[i],g_cost[i],g_temp[i],g_pin[i]);}
 puts("V0 Decision V8 ULTRA V7 - Windows AVX2 benchmark"); printf("N=%u, p50 of %d timed runs\n",N,REPS);
 bench("V6 raw scalar",raw_scalar);bench("V7 bias scalar",bias_scalar);bench("V7 packed signal scalar",packed_scalar);
#if defined(__AVX2__) || defined(_M_AVX2)
 bench("V6 raw batch AVX2",raw_batch);bench("V7 bias batch AVX2",bias_batch);bench("V7 packed signal AVX2",packed_batch);bench("V6 raw preflight AVX2",raw_preflight);bench("V7 bias preflight AVX2",bias_preflight);
#endif
 printf("sink=%llu\n",(unsigned long long)g_sink);
 _aligned_free(g_value);_aligned_free(g_cost);_aligned_free(g_bias);_aligned_free(g_temp);_aligned_free(g_pin);_aligned_free(g_out);_aligned_free(g_sig);return 0;
}

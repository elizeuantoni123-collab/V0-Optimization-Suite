# V0 Batch V14 — Acceptance Report

## Regra de promoção

Nenhuma tentativa substitui um caminho validado se quebrar compatibilidade, mudar qualquer span ou apresentar perda de velocidade no domínio para o qual seria promovida.

## V13 small4 — PROMOVIDO COMO CAMINHO ESPECIALIZADO

- função: `v0_batch_plan64_small4`;
- sem heap, rede, locks ou dependência do V0 Global;
- ABI de span preservada;
- 0..256: equivalência exata validada;
- promoção de desempenho: 64..256 apenas;
- abaixo de 64: V6 continua.

Sweep completo 64..256 (`SMALL4_SWEEP_64_256.csv`):
- cutoff contínuo sem regressão mediana: 64;
- pior speedup observado na faixa promovida: ~1,028x;
- pontos maiores chegam perto de ~1,9x.

## V14 AVX2 — PROMOVIDO COMO ACELERADOR OPCIONAL

Kernel V0L usa:
1. `vmovdqa ymm0` com 4 descriptors iniciais;
2. `vmovdqa ymm1` com incremento `[256,256,256,256]`;
3. loop: `vmovdqu [out], ymm0`; `vpaddq ymm0,ymm0,ymm1`; avanço do output e remaining;
4. cauda escalar exata de até 4 spans;
5. `vzeroupper` antes do retorno.

Validação diferencial final e pré-release: bilhões de comparações de descriptors, 0 divergências.

Sweep de todos os 256 restos:
- base 4096: 0 regressões, pior ~1,322x;
- base 65536: 0 regressões, pior ~2,880x.

Cutoff conservador promovido: `items >= 4096`, apenas quando AVX2/YMM está disponível.

## Fallback

V11 `v0_batch_plan64x4` não foi removido, recompilado com lógica nova ou alterado. É o fallback para:
- CPU sem AVX2;
- qualquer integração que não queira habilitar V14;
- faixas fora dos aceleradores promovidos.

## IMPLICIT64

Continua compatível, mas o break-even deve ser recalibrado contra V14. O cutoff antigo 4096 deixa de ser regra fixa quando AVX2 está ativo.

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <inttypes.h>
#include <sched.h>
#include "../include/v0_decision_v7.h"
#include "../include/v0_decision_v8_adaptive.h"
extern int32_t v0_lookup_exact(const void*);extern int32_t v0_lookup_trusted(const void*);extern const unsigned char v0l_keys[];
static uint64_t ns(void){struct timespec x;clock_gettime(CLOCK_MONOTONIC_RAW,&x);return(uint64_t)x.tv_sec*1000000000ull+x.tv_nsec;}static inline uint32_t rng(uint64_t*s){uint64_t x=*s;x^=x<<13;x^=x>>7;x^=x<<17;*s=x;return(uint32_t)x;}static void pin0(){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);sched_setaffinity(0,sizeof(s),&s);}int main(){pin0();const uint64_t TOTAL=10000000ull;const uint64_t PH=1250000ull;const int dp[8]={90,20,85,10,75,95,30,80};uint64_t q=0,rs=0xabcdef0123456789ull,exerr=0,trerr=0;v0_v8_state_t st;v0_v8_init(&st,v0_v8_default_config());while(q<TOTAL){v0_v8_plan_t pl=v0_v8_plan(&st);uint32_t n=pl.count;if((uint64_t)n>TOTAL-q)n=(uint32_t)(TOTAL-q);uint64_t t0=pl.measure?ns():0;for(uint32_t j=0;j<n;j++,q++){uint32_t r=rng(&rs),id=r&1023u;const void*key=v0l_keys+(size_t)id*22u;uint32_t phase=(uint32_t)((q/PH)&7u);int d=(int)((r>>9)%100u)<dp[phase];uint32_t go=1;if(pl.mode==V0_V8_FILTER){v0_decision_signal_v7_t s=v0_decision_v7_pack(d?0:60000,d?65535:0,(uint8_t)(r%3u),0u);go=v0_preflight_v0l_v7(&s);}if(go){exerr+=(v0_lookup_exact(key)!=(int32_t)id);trerr+=(v0_lookup_trusted(key)!=(int32_t)id);}}uint64_t dt=pl.measure?ns()-t0:0;v0_v8_complete(&st,pl.mode,dt,n);}printf("global_adaptive_10M exact_errors=%"PRIu64" trusted_errors=%"PRIu64" selected=%u switches_on=%u switches_off=%u probes=%u epochs=%u\n",exerr,trerr,st.selected_mode,st.switches_to_filter,st.switches_to_bypass,st.probes_completed,st.epoch);return(exerr||trerr)?1:0;}

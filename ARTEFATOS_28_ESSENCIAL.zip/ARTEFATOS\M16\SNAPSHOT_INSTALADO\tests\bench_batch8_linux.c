#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sched.h>
#include <x86intrin.h>
extern uint32_t v0_tier_select_valid_v3(uint32_t,uint32_t);
extern uint32_t v0_tier_select_batch8_v12(void*);

typedef struct { uint32_t p,m; } R;
typedef struct __attribute__((aligned(64))) { R r[8]; uint8_t out[8]; uint8_t pad[56]; } B;
static volatile uint64_t sink; static uint64_t rs=0x9e3779b97f4a7c15ULL;
static inline uint32_t rnd(void){rs^=rs>>12;rs^=rs<<25;rs^=rs>>27;return (uint32_t)((rs*2685821657736338717ULL)>>32);}
static void pin(void){cpu_set_t s;CPU_ZERO(&s);if(!sched_getaffinity(0,sizeof s,&s))for(int i=0;i<CPU_SETSIZE;i++)if(CPU_ISSET(i,&s)){cpu_set_t t;CPU_ZERO(&t);CPU_SET(i,&t);sched_setaffinity(0,sizeof t,&t);break;}}
static inline uint64_t tsc(void){unsigned a;_mm_lfence();uint64_t t=__rdtscp(&a);_mm_lfence();return t;}
static __attribute__((noinline)) uint32_t base8(B*b){uint32_t s=0;for(int i=0;i<8;i++){uint8_t v=(uint8_t)v0_tier_select_valid_v3(b->r[i].p,b->r[i].m);b->out[i]=v;s+=v;}return s;}
static __attribute__((noinline)) uint32_t cand8(B*b){v0_tier_select_batch8_v12(b);uint32_t s=0;for(int i=0;i<8;i++)s+=b->out[i];return s;}
static uint64_t run(uint32_t(*f)(B*),B*a,size_t n,int reps){uint64_t acc=0,t0=tsc();for(int r=0;r<reps;r++)for(size_t i=0;i<n;i++)acc+=f(&a[i]);uint64_t t1=tsc();sink+=acc;return t1-t0;}
static void fill(const char*sc,B*a,size_t n){for(size_t j=0;j<n;j++)for(int i=0;i<8;i++){uint32_t r=rnd();uint32_t p=r%5,m=0;if(!strcmp(sc,"exact"))m=1u<<p;else if(!strcmp(sc,"all"))m=31;else if(!strcmp(sc,"random"))m=rnd();else if(!strcmp(sc,"sparse"))m=1u<<(rnd()%5);else if(!strcmp(sc,"zero"))m=0;else if(!strcmp(sc,"p0")){p=0;m=rnd();}else if(!strcmp(sc,"p4")){p=4;m=rnd();}else if(!strcmp(sc,"spill")){p=r%4;m=1u<<(p+1);}else {p=1+(r%4);m=1u<<(p-1);}a[j].r[i].p=p;a[j].r[i].m=m;} }
int main(){pin(); B one={0};
 // exhaustive all pairs in every lane
 for(int lane=0;lane<8;lane++)for(uint32_t p=0;p<5;p++)for(uint32_t m=0;m<32;m++){for(int i=0;i<8;i++){one.r[i].p=(p+i)%5;one.r[i].m=(m+i)&31;}one.r[lane].p=p;one.r[lane].m=m;uint8_t ref[8];for(int i=0;i<8;i++)ref[i]=(uint8_t)v0_tier_select_valid_v3(one.r[i].p,one.r[i].m);v0_tier_select_batch8_v12(&one);if(memcmp(ref,one.out,8)){fprintf(stderr,"BAD_EXH\n");return 2;}}
 // 1M random batches = 8M decisions
 for(int j=0;j<1000000;j++){for(int i=0;i<8;i++){one.r[i].p=rnd()%5;one.r[i].m=rnd();}uint8_t ref[8];for(int i=0;i<8;i++)ref[i]=(uint8_t)v0_tier_select_valid_v3(one.r[i].p,one.r[i].m);v0_tier_select_batch8_v12(&one);if(memcmp(ref,one.out,8)){fprintf(stderr,"BAD_RND\n");return 3;}}
 const char*scs[]={"exact","all","random","sparse","zero","p0","p4","spill","upward"}; int NS=9,ROUNDS=12,REPS=12;size_t N=60000;B*a=aligned_alloc(64,N*sizeof(B));if(!a)return 4;printf("scenario,round,base_cycles,cand_cycles,speedup\n");
 for(int s=0;s<NS;s++){fill(scs[s],a,N);for(int w=0;w<4;w++){base8(&a[w]);cand8(&a[w]);}for(int r=0;r<ROUNDS;r++){uint64_t b,c;if(r&1){c=run(cand8,a,N,REPS);b=run(base8,a,N,REPS);}else{b=run(base8,a,N,REPS);c=run(cand8,a,N,REPS);}printf("%s,%d,%llu,%llu,%.9f\n",scs[s],r,(unsigned long long)b,(unsigned long long)c,(double)b/c);}}
 fprintf(stderr,"CORRECTNESS_PASS 8001280 decisions sink=%llu\n",(unsigned long long)sink);return 0;}

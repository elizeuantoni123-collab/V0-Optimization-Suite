# V0 Decision V8 ULTRA — V8

V8 is an additive optimization layer over V7. It does not replace or modify the validated V7/V6 paths. New fast paths are used only when their input representation and ISA match the measured case.

## Promoted exact fast paths

- **Bias-fused AVX2/AVX-512:** uses unsigned saturating add/subtract. Saturation is exact because Decision's highest boundary is 384 while `cost/2 <= 32767`; any true sum above 65535 is already unambiguously in state 7.
- **Raw pinned fast path:** for legal Decision inputs, `pinned=1` has minimum score `0 - 32767 + 33151 = 384`, therefore its exact result is always state 7.
- **Raw preflight-only:** computes only execute/drop and skips tier construction.
- **Packed AoS:** faster SIMD over the existing 8-byte `v0_decision_signal_v7_t` ABI.
- **Nibble output:** optional exact 4-bit packed states, two decisions per byte.
- **3-bit bitplanes:** optional minimum-storage output on AVX-512; exact but intended for bandwidth-bound workloads.
- **meta8:** optional one-byte Decision state (`temp_q6 | pinned<<7`). It is not the default hot-cache path; enable only after local benchmarking for bandwidth-bound workloads.

## What does not change

Thresholds remain exactly `0 / 64 / 192 / 384`. Controller policy/hysteresis, V7 ABI, V6 raw/Q6 paths, native objects and the permanent Windows host remain unchanged.

## Validation

Both native/AVX-512 and AVX2-only builds were checked against the reference:

- **21,005,735 cases per build**
- random signals + directed threshold cases + tails `0..257`
- bias/raw/AoS/meta8/nibble/bitplane/preflight paths
- **0 divergences**

Inherited V7 integrity: **154/154 inherited files matched SHA-256**, 0 missing, 0 mismatches. The original V7 regression suites also passed again: 20,000,000 raw signals with 0 divergences and 20,000,768 packed signals with 0 divergences.

## Paired benchmark

Validation host: AMD EPYC 9V74 virtualized host, GCC `-O3 -march=native`. Values below are median p50 across 9 process runs. SIMD `ns/item` is amortized batch throughput, not single-call latency.

| Path | V7 | V8 | Reduction |
|---|---:|---:|---:|
| bias AVX2 | 0.09072 | **0.07124 ns/item** | **21.5%** |
| raw AVX2 | 0.12011 | **0.10351** | **13.8%** |
| raw preflight AVX2 | 0.11205 | **0.07082** | **36.8%** |
| packed AoS AVX2 | 0.31709 | **0.23261** | **26.6%** |
| bias AVX-512 | 0.08952 | **0.07093** | **20.8%** |
| raw AVX-512 | 0.11073 | **0.07930** | **28.4%** |
| raw preflight AVX-512 | 0.08710 | **0.06127** | **29.7%** |
| packed AoS AVX-512 | 0.16667 | **0.12516** | **24.9%** |

V8 nibble output AVX2: **0.07044 ns/item** hot. On a large 33.5M-item output workload, median values were byte AVX2 0.25496, nibble 0.24132, and nibble non-temporal streaming **0.21810 ns/item**.

## Windows

Validate the AVX2-safe paths on the target PC:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\TESTAR_ULTRA_V8.ps1
```

Run a paired local V7-vs-V8 benchmark:

```powershell
.\BENCHMARK_ULTRA_V8_WINDOWS.ps1
```

Do not treat the sub-nanosecond batch numbers above as single-decision latency. Run the Windows benchmark on the target CPU before choosing optional `meta8` or compact-output modes.

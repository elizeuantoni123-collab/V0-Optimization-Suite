#ifndef V0_DECISION_V8_ULTRA_V11_H
#define V0_DECISION_V8_ULTRA_V11_H

/*
 * V0 Decision V8 ULTRA V11
 *
 * Additive exact acceleration layer over ULTRA V10.
 * No inherited V10 file is modified.
 *
 * Promoted additions:
 *  1) scalar gate16 direct-q LUT: 1024 bytes, exact for every possible
 *     saturated value+gate16 sum. This removes unpredictable scalar threshold
 *     branches from cached gate16 evaluation.
 *  2) AVX2 gate16 batch with LUT scalar tail for short batches/tails.
 *     The vector body is the validated V10 body; only the scalar fallback is
 *     replaced by the exact V11 LUT.
 *  3) optional exact 4-bit gate16 output for large write-only batches.
 *     Two Decision states are packed per byte and non-temporal stores reduce
 *     output traffic. This is opt-in and does not replace the standard u8 API.
 */
#include "v0_decision_v8_ultra_v10.h"

#ifdef __cplusplus
extern "C" {
#endif

static const uint8_t V0X_ALIGN64 V0X_GATE16_Q10_LUT_V11[1024] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    4,5,5,6,6,6,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
};

V0X_FORCEINLINE uint32_t v0_eval_gate16_v11_scalar_lut_inline(
    uint16_t value, v0_decision_gate16_v10_t gate) {
    uint32_t s = (uint32_t)value + (uint32_t)gate;
    if (s > 0xffffu) s = 0xffffu;
    return (uint32_t)V0X_GATE16_Q10_LUT_V11[s >> 6];
}

V0X_FORCEINLINE uint32_t v0_preflight_gate16_v11_scalar_lut_inline(
    uint16_t value, v0_decision_gate16_v10_t gate) {
    return v0_eval_gate16_v11_scalar_lut_inline(value, gate) >> 2;
}

#if defined(__AVX2__) || defined(_M_AVX2)

V0X_FORCEINLINE __m128i v0_eval_gate16_nibbles32_v11_avx2(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate) {
    const __m128i a = v0_eval_gate16_block16_v10_avx2(value, gate);
    const __m128i b = v0_eval_gate16_block16_v10_avx2(value+16, gate+16);
    const __m256i e = _mm256_set_m128i(b, a);
    return v0_pack_v8_e3_nibbles32_avx2(e);
}

/* Exact compact output: low nibble=item 2k, high nibble=item 2k+1. */
static inline void v0_eval_gate16_batch_v11_avx2_nibble(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate,
    uint8_t *out_nibbles, size_t n) {
    size_t i = 0, j = 0;
    for (; i + 32 <= n; i += 32, j += 16)
        _mm_storeu_si128((__m128i *)(void *)(out_nibbles+j),
            v0_eval_gate16_nibbles32_v11_avx2(value+i, gate+i));
    if (i < n) {
        uint8_t acc = 0; unsigned half = 0;
        for (; i < n; ++i) {
            const uint8_t e = (uint8_t)v0_eval_gate16_v11_scalar_lut_inline(value[i], gate[i]);
            if (!half) { acc = e; half = 1; }
            else { out_nibbles[j++] = (uint8_t)(acc | (uint8_t)(e << 4)); half = 0; }
        }
        if (half) out_nibbles[j] = acc;
    }
}

/* Large write-only compact output. Destination must be 16-byte aligned.
 * Opt-in because immediate read-after-write consumers may prefer normal u8. */
static inline void v0_eval_gate16_batch_v11_stream_avx2_nibble(
    const uint16_t *value, const v0_decision_gate16_v10_t *gate,
    uint8_t *out_nibbles, size_t n) {
    size_t i = 0, j = 0;
    if ((((uintptr_t)out_nibbles) & 15u) != 0u || n < 256u) {
        v0_eval_gate16_batch_v11_avx2_nibble(value, gate, out_nibbles, n);
        return;
    }
    for (; i + 32 <= n; i += 32, j += 16)
        _mm_stream_si128((__m128i *)(void *)(out_nibbles+j),
            v0_eval_gate16_nibbles32_v11_avx2(value+i, gate+i));
    _mm_sfence();
    if (i < n) {
        uint8_t acc = 0; unsigned half = 0;
        for (; i < n; ++i) {
            const uint8_t e = (uint8_t)v0_eval_gate16_v11_scalar_lut_inline(value[i], gate[i]);
            if (!half) { acc = e; half = 1; }
            else { out_nibbles[j++] = (uint8_t)(acc | (uint8_t)(e << 4)); half = 0; }
        }
        if (half) out_nibbles[j] = acc;
    }
}

#endif /* AVX2 */

#ifdef __cplusplus
}
#endif
#endif

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include "../include/v0_batch_accel.h"
extern uint32_t v0_batch_plan64_avx2_dual_v19(v0_batch_span*,uint32_t);typedef uint32_t(*F)(v0_batch_span*,uint32_t);static volatile uint64_t sink;static uint32_t rs=0x8d3a51b7u;static uint32_t xr(void){rs^=rs<<13;rs^=rs>>17;rs^=rs<<5;return rs;}static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return(uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;}static int cmpd(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return(x>y)-(x<y);}static uint64_t run(F f,v0_batch_span*b,uint32_t n,uint32_t reps){uint64_t z=0,t=ns();for(uint32_t r=0;r<reps;r++){uint32_t k=f(b,n);z+=k;if(k)z+=b[k-1].start+b[k-1].count;}uint64_t e=ns();sink+=z;return e-t;}static double one(F base,uint32_t n,uint32_t reps,v0_batch_span*a,v0_batch_span*b){double A[5],B[5];for(int r=0;r<5;r++){uint64_t p,q;if(xr()&1){q=run(v0_batch_plan64_avx2_dual_v19,b,n,reps);p=run(base,a,n,reps);}else{p=run(base,a,n,reps);q=run(v0_batch_plan64_avx2_dual_v19,b,n,reps);}A[r]=(double)p/reps;B[r]=(double)q/reps;}qsort(A,5,sizeof(double),cmpd);qsort(B,5,sizeof(double),cmpd);return A[2]/B[2];}
int main(void){cpu_set_t set;CPU_ZERO(&set);CPU_SET(0,&set);sched_setaffinity(0,sizeof(set),&set);__builtin_cpu_init();if(!__builtin_cpu_supports("avx2"))return 0;uint32_t maxn=262144,maxk=((maxn-1)>>6)+1;v0_batch_span*a=aligned_alloc(64,(maxk+16)*8ull),*b=aligned_alloc(64,(maxk+16)*8ull);FILE*f=fopen("reports/V19_DENSE_SWEEP.csv","w");fprintf(f,"n,baseline,speedup\n");double worst=99,sum=0;uint32_t wn=0,total=0,reg=0,lt101=0;
/* Every integer across the entire V11 dispatch interval from the proposed 512 cutoff. */
for(uint32_t n=512;n<4096;n++){double s=one(v0_batch_plan64x4,n,12000,a,b);fprintf(f,"%u,V11,%.9f\n",n,s);total++;sum+=s;if(s<worst){worst=s;wn=n;}if(s<1)reg++;if(s<1.01)lt101++;}
/* Dense coverage of the V14 interval through the conservative 262144 ceiling. */
for(uint32_t n=4096;n<=262144;n+=257){uint32_t reps=n<=16384?8000:n<=65536?2500:700;double s=one(v0_batch_plan64_avx2_v14,n,reps,a,b);fprintf(f,"%u,V14,%.9f\n",n,s);total++;sum+=s;if(s<worst){worst=s;wn=n;}if(s<1)reg++;if(s<1.01)lt101++;}
/* Exact neighborhoods around key powers/boundaries. */
const uint32_t bases[]={4096,8192,16384,65536,131072,262144};for(unsigned q=0;q<6;q++)for(int d=-64;d<=64;d++){int64_t nn=(int64_t)bases[q]+d;if(nn<4096||nn>262144)continue;uint32_t n=(uint32_t)nn,reps=n<=16384?8000:n<=65536?2500:700;double s=one(v0_batch_plan64_avx2_v14,n,reps,a,b);fprintf(f,"%u,V14,%.9f\n",n,s);total++;sum+=s;if(s<worst){worst=s;wn=n;}if(s<1)reg++;if(s<1.01)lt101++;}
fclose(f);printf("V19 dense total=%u regressions=%u below1.01=%u worst=%.6fx n=%u mean=%.6fx sink=%llu\n",total,reg,lt101,worst,wn,sum/total,(unsigned long long)sink);return reg?1:0;}

# Windows gate

Nenhum novo candidato foi encaminhado para promoção nesta rodada porque todos falharam o filtro local de zero regressão.

A baseline V2 já contém seu próprio gate de validação. Se uma futura V3 sobreviver ao screening local, o gate final deverá ser executado no Intel 12th-gen Windows alvo com QPC, afinidade, A/B alternado e os domínios exatos 2 e 4 linhas.

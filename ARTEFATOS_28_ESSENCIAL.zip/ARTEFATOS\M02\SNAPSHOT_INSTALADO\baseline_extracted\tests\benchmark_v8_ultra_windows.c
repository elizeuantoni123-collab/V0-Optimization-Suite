#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/v0_decision_v8_extreme.h"

#define N (1u << 20)
#define REPS 15

static uint16_t *g_value, *g_cost;
static uint8_t *g_temp, *g_pin, *g_out;
static v0_decision_q6_v8_t *g_q6;
static v0_decision_signal_v7_t *g_sig;
static volatile uint64_t g_sink;
static LARGE_INTEGER g_freq;

static uint64_t rng64(uint64_t *s) {
    uint64_t x=*s; x^=x<<13; x^=x>>7; x^=x<<17; return *s=x;
}
static double now_ns(void) {
    LARGE_INTEGER q; QueryPerformanceCounter(&q);
    return (double)q.QuadPart * 1.0e9 / (double)g_freq.QuadPart;
}
static int cmpd(const void *a,const void *b) {
    double x=*(const double*)a,y=*(const double*)b; return x<y?-1:x>y;
}

static double q6_scalar(void) {
    uint64_t z=0; double t0=now_ns();
    for (size_t i=0;i<N;i++) z += v0_eval_v8_q6_hot_lut_inline(g_q6[i]);
    double t1=now_ns(); g_sink=z; return (t1-t0)/(double)N;
}
static double raw_scalar(void) {
    uint64_t z=0; double t0=now_ns();
    for (size_t i=0;i<N;i++) z += v0_eval_v8_raw_ultra_inline(g_value[i],g_cost[i],g_temp[i],g_pin[i]);
    double t1=now_ns(); g_sink=z; return (t1-t0)/(double)N;
}
static double packed_inline(void) {
    uint64_t z=0; double t0=now_ns();
    for (size_t i=0;i<N;i++) z += v0_eval_v8_signal_ultra_inline(&g_sig[i]);
    double t1=now_ns(); g_sink=z; return (t1-t0)/(double)N;
}
#if defined(__AVX2__) || defined(_M_AVX2)
static double q6_batch(void) {
    double t0=now_ns(); v0_eval_v8_q6_batch_ultra_avx2_u8(g_q6,g_out,N); double t1=now_ns();
    g_sink += g_out[777]; return (t1-t0)/(double)N;
}
static double raw_batch(void) {
    double t0=now_ns(); v0_eval_v8_raw_batch_ultra_avx2_u8(g_value,g_cost,g_temp,g_pin,g_out,N); double t1=now_ns();
    g_sink += g_out[777]; return (t1-t0)/(double)N;
}
static double raw_preflight(void) {
    double t0=now_ns(); uint64_t z=v0_preflight_v8_raw_count_avx2(g_value,g_cost,g_temp,g_pin,N); double t1=now_ns();
    g_sink += z; return (t1-t0)/(double)N;
}
#endif

static void bench(const char *name, double (*fn)(void)) {
    double v[REPS];
    for(int i=0;i<5;i++) (void)fn();
    for(int i=0;i<REPS;i++) v[i]=fn();
    qsort(v,REPS,sizeof(double),cmpd);
    printf("%-29s p50=%9.4f ns/item best=%9.4f\n",name,v[REPS/2],v[0]);
}

int main(void) {
    QueryPerformanceFrequency(&g_freq);
    SetThreadAffinityMask(GetCurrentThread(),1);
    g_value=(uint16_t*)_aligned_malloc(N*sizeof(uint16_t),64);
    g_cost=(uint16_t*)_aligned_malloc(N*sizeof(uint16_t),64);
    g_temp=(uint8_t*)_aligned_malloc(N,64);
    g_pin=(uint8_t*)_aligned_malloc(N,64);
    g_out=(uint8_t*)_aligned_malloc(N,64);
    g_q6=(v0_decision_q6_v8_t*)_aligned_malloc(N*sizeof(v0_decision_q6_v8_t),64);
    g_sig=(v0_decision_signal_v7_t*)_aligned_malloc(N*sizeof(v0_decision_signal_v7_t),64);
    if(!g_value||!g_cost||!g_temp||!g_pin||!g_out||!g_q6||!g_sig) return 2;
    {
        uint64_t s=0x9e3779b97f4a7c15ULL;
        for(size_t i=0;i<N;i++) {
            g_value[i]=(uint16_t)rng64(&s); g_cost[i]=(uint16_t)rng64(&s);
            g_temp[i]=(uint8_t)(rng64(&s)%3u); g_pin[i]=(uint8_t)(rng64(&s)&1u);
            g_q6[i]=v0_decision_v8_q6(g_value[i],g_cost[i],g_temp[i],g_pin[i]);
            g_sig[i]=v0_decision_v7_pack(g_value[i],g_cost[i],g_temp[i],g_pin[i]);
        }
    }
    printf("V0 Decision V8 ULTRA V6 - Windows benchmark\n");
    printf("N=%u, p50 of %d timed runs\n",N,REPS);
    bench("V6 Q6 scalar hot LUT",q6_scalar);
    bench("V6 raw scalar ultra",raw_scalar);
    bench("V6 packed inline LUT",packed_inline);
#if defined(__AVX2__) || defined(_M_AVX2)
    bench("V6 Q6 batch AVX2",q6_batch);
    bench("V6 raw batch AVX2",raw_batch);
    bench("V6 raw preflight AVX2",raw_preflight);
#endif
    printf("sink=%llu\n",(unsigned long long)g_sink);
    _aligned_free(g_value);_aligned_free(g_cost);_aligned_free(g_temp);_aligned_free(g_pin);
    _aligned_free(g_out);_aligned_free(g_q6);_aligned_free(g_sig);
    return 0;
}

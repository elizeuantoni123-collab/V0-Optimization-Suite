#ifndef V0_EXTERNAL_MEMORY_CLIENT_V11_LEASE_FIX1_H
#define V0_EXTERNAL_MEMORY_CLIENT_V11_LEASE_FIX1_H
#include <stdint.h>
#include "V0_EXTERNAL_MEMORY_CLIENT_V5.h"
#include "V0_EXTERNAL_MEMORY_PROTOCOL_V5.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct V0XBatchViewV11 {
    const uint8_t *base;
    uint32_t count;
    uint32_t used_bytes;
    uint32_t offsets[V0X_V9_MAX_BATCH];
    uint32_t lens[V0X_V9_MAX_BATCH];
} V0XBatchViewV11;

/* Additive zero-copy API. payload_hint must be the expected per-item payload size
   and is gated by the same v0x_select_batch_v9() policy as the V9 copy API. */
V0X_API uint32_t v0x_get_batch_view_v11(
    const uint32_t *ids,
    uint32_t count,
    uint32_t payload_hint,
    V0XBatchViewV11 *view);

/* Mandatory: releases the process-wide SHM lease. A view is valid only until
   this function is called. */
V0X_API uint32_t v0x_release_batch_view_v11(void);

#ifdef __cplusplus
}
#endif
#endif

#include "../include/v0_decision_v8_ultra_v10.h"
int main(void){
    v0_decision_gate16_v10_t g=v0_decision_gate16_v10(200,1,0);
    return (int)v0_eval_gate16_v10_inline(500,g);
}

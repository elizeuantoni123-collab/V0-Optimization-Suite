# Artefato 12 — V0 KV Window Manager V7 candidate

Baseline: **V0 KV Window Manager V6 SAFE PROMOTED**.

This package adds two V0L-native SSE2 exact-pair kernels while keeping every V6 path intact:

- `1→5` -> V7 candidate
- `5→1` -> V7 candidate
- `3→2` -> remains V6
- every other domain -> remains V6 composite dispatch

Local final gate: 20M correctness cases, 0 divergences; 680/680 performance wins for each promoted-candidate pair across five independent benchmark processes.

Nothing in this package installs or promotes the candidate automatically. Run `windows_gate/RUN_WINDOWS_GATE.ps1` on the target Intel/Windows machine first.

# External Memory V9 -> V11 Lease Squeeze — local report

## Preserved baseline
- Original V9 FIX3 archive preserved in `baseline/`.
- V0L core unchanged.
- `v0_external_memory.obj` SHA-256: `f003a9b6b464e85d5996f6ccdc3a8650a7b6134ee34d3e4b2bc7c9bba4aebbb7`.

## Baseline revalidation
The original Linux general-blob test was rebuilt against the packaged V0L object and passed on a 512 MiB payload set.

## Candidate
The service already copies each requested record from the store into V9 SHM. The V9 client then copies the same SHM bytes again into `out_buffer`.
V11 keeps that service copy but removes the second client copy for consumers that can consume a temporary leased view.

The old copy API is retained as fallback.

## Local copy-stage model
This is NOT a Windows end-to-end result. It isolates the client-side copy that V11 removes while keeping the same consumer touches.

- 256 KiB: median ~2.124x, min ~1.853x
- 1 MiB: median ~2.263x, min ~2.022x
- 2 MiB: median ~2.252x, min ~2.131x
- 4 MiB: median ~2.216x, min ~1.981x

The final Windows gate measures the real pipe + service + SHM + consumer path and includes lease overhead.

## Concurrency correction
A plain zero-copy view over V9 SHM is unsafe if another thread can issue a batch GET and overwrite the mapping. V11 therefore serializes batch operations while a view is active. `payload_hint` is also enforced so the adaptive V9 batch policy is not bypassed.

## Status
`LOCAL_MODEL_PASS / WINDOWS_GATE_REQUIRED`
No permanent promotion is claimed from the local copy-stage model.
